/**
 * Customers Repository
 * Handles customer-related API calls
 */

import { apiClient } from '../api-client';

export interface Customer {
    id: string;
    businessId: string;
    type: 'PERSON' | 'COMPANY';
    displayName: string; // The primary name to show
    address?: string;
    phone?: string;
    email?: string;
    taxId?: string;
    createdAt?: string; // ISO string
    updatedAt?: string; // ISO string
}

export interface CustomerListResponse {
    businessId: string;
    customers: Customer[];
    count: number;
}

export const customersRepo = {
    /**
     * List customers for active business
     */
    listCustomers: async (params?: { limit?: number; q?: string }): Promise<CustomerListResponse> => {
        const query = new URLSearchParams();
        if (params?.limit) query.append('limit', String(params.limit));
        if (params?.q) query.append('q', params.q);

        return apiClient<CustomerListResponse>('GET', `/v1/customers?${query.toString()}`);
    },

    /**
     * Get single customer
     */
    getCustomer: async (customerId: string): Promise<Customer> => {
        return apiClient<Customer>('GET', `/v1/customers/${customerId}`);
    },

    /**
     * Create new customer
     */
    createCustomer: async (data: Partial<Customer>): Promise<Customer> => {
        return apiClient<Customer>('POST', '/v1/customers', data);
    },

    /**
     * Update customer
     */
    updateCustomer: async (customerId: string, data: Partial<Customer>): Promise<Customer> => {
        return apiClient<Customer>('PATCH', `/v1/customers/${customerId}`, data);
    },

    /**
     * Delete customer
     */
    deleteCustomer: async (customerId: string): Promise<{ success: boolean; deleted: string }> => {
        return apiClient('DELETE', `/v1/customers/${customerId}`);
    }
};
