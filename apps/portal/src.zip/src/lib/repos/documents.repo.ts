/**
 * Documents Repository
 * Handles document-related API calls
 */

import { apiClient } from '../api-client';

// Shared types (should match backend shared/types.ts ideally, but defined here for frontend)
export interface DocumentItem {
    line_no: number;
    description_th: string;
    description_en?: string | null;
    qty: number;
    unit: string;
    unit_price: number;
    amount: number;
}

export interface MoneySummary {
    subtotal: number;
    discount_amount: number;
    extra_fee_amount: number;
    vat_amount: number;
    wht_amount: number;
    total_amount: number;
    net_receive_amount: number;

    // Flags
    discount_enabled: boolean;
    vat_enabled: boolean;
    wht_enabled: boolean;
    extra_fee_enabled: boolean;
    vat_rate_pct: number;
    wht_rate_pct: number;
}

export interface TaxSnapshot {
    vatEnabled: boolean;
    vatRate: number;
    whtEnabled: boolean;
    whtRate: number;
    whtBase: 'BEFORE_VAT' | 'AFTER_VAT';
}

export interface EzDocument {
    id: string;
    docNo: string;
    docType: 'QUO' | 'BILL' | 'RECEIPT';
    status: 'DRAFT' | 'ISSUED' | 'PAID' | 'CANCELLED';
    customerId: string;
    customerSnapshot?: {
        displayName: string;
        address?: string;
        taxId?: string;
    };
    issueDate: string; // YYYY-MM-DD
    dueDate?: string;
    subjectTh?: string;
    subjectEn?: string;
    items: DocumentItem[];
    money: MoneySummary;
    taxSnapshot?: TaxSnapshot;
    revision: number;
    pdfReady: boolean;
    pdfUrl: string | null;
    pdfState?: 'QUEUED' | 'RENDERING' | 'READY' | 'FAILED';
    createdAt?: string;
    updatedAt?: string;

    // Versioning (Immutability)
    version: number;
    origin_document_id: string | null;
    supersedes_document_id: string | null;
    is_void: boolean;
}

export interface DocumentListResponse {
    documents: EzDocument[];
    count: number;
}

export const documentsRepo = {
    /**
     * List documents
     */
    listDocuments: async (params?: { limit?: number; type?: string; status?: string }): Promise<DocumentListResponse> => {
        const query = new URLSearchParams();
        if (params?.limit) query.append('limit', String(params.limit));
        if (params?.type) query.append('type', params.type);
        if (params?.status) query.append('status', params.status);

        return apiClient<DocumentListResponse>('GET', `/v1/documents?${query.toString()}`);
    },

    /**
     * Get single document
     */
    getDocument: async (docId: string): Promise<EzDocument> => {
        return apiClient<EzDocument>('GET', `/v1/documents/${docId}`);
    },

    /**
     * Create new document (Draft)
     */
    createDocument: async (data: Partial<EzDocument>): Promise<EzDocument> => {
        return apiClient<EzDocument>('POST', '/v1/documents', data);
    },

    /**
     * Update document (Draft)
     */
    updateDocument: async (docId: string, data: Partial<EzDocument>): Promise<EzDocument> => {
        return apiClient<EzDocument>('PATCH', `/v1/documents/${docId}`, data);
    },

    /**
     * Trigger PDF generation
     */
    generatePdf: async (docId: string): Promise<{ success: boolean; jobId: string }> => {
        return apiClient('POST', `/v1/documents/${docId}/generate-pdf`);
    },

    /**
     * Confirm document (Draft -> Issued)
     * Allocates atomic DocNo
     */
    confirmDocument: async (docId: string): Promise<EzDocument> => {
        return apiClient<EzDocument>('POST', `/v1/documents/${docId}/confirm`);
    }
};
