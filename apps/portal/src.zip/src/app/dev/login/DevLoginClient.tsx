"use client";

import { useState } from "react";
import { GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function DevLoginClient() {
    const [token, setToken] = useState<string>("");
    const [userEmail, setUserEmail] = useState<string>("");
    const [error, setError] = useState<string>("");

    const doLogin = async () => {
        setError("");
        try {
            const provider = new GoogleAuthProvider();
            const cred = await signInWithPopup(auth, provider);

            const idToken = await cred.user.getIdToken(true);
            setToken(idToken);
            setUserEmail(cred.user.email ?? "");

            // Intentionally logs token for copy/paste during QA.
            console.log("[DEV_LOGIN] Firebase ID Token:", idToken);
        } catch (e: any) {
            setError(e?.message || "Login failed");
        }
    };

    const doLogout = async () => {
        setError("");
        await signOut(auth);
        setToken("");
        setUserEmail("");
    };

    return (
        <main style={{ padding: 24, fontFamily: "system-ui" }}>
            <h1 style={{ fontSize: 22, fontWeight: 700 }}>Dev Login (E2E Token)</h1>
            <p style={{ opacity: 0.8 }}>
                ใช้หน้านี้เพื่อดึง Firebase ID Token เท่านั้น แล้วปิด feature นี้หลังทดสอบ
            </p>

            <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
                <button onClick={doLogin} style={{ padding: "10px 14px", fontWeight: 600 }}>
                    Sign in with Google
                </button>
                <button onClick={doLogout} style={{ padding: "10px 14px" }}>
                    Sign out
                </button>
            </div>

            {error ? (
                <p style={{ marginTop: 12, color: "#b00020" }}>{error}</p>
            ) : null}

            {userEmail ? (
                <p style={{ marginTop: 16 }}>
                    Signed in as: <b>{userEmail}</b>
                </p>
            ) : null}

            <h2 style={{ marginTop: 20, fontSize: 16 }}>Firebase ID Token</h2>
            <textarea
                value={token}
                readOnly
                rows={10}
                style={{ width: "100%", marginTop: 8, padding: 12 }}
                placeholder="Login แล้ว token จะขึ้นตรงนี้"
            />

            <p style={{ marginTop: 10, opacity: 0.8 }}>
                ใช้ token นี้ไปใส่ Authorization: Bearer ... หรือ export เป็น ID_TOKEN
            </p>
        </main>
    );
}
