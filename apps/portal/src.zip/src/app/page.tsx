'use client';

import { useAuth } from '@/lib/auth-context';

export default function Home() {
  // Keep the root page simple: show a friendly loading/landing UI.
  // Redirects are intentionally handled by the appropriate layouts so
  // we don't cause nested redirects or bootstrap loops.
  const { sessionReady } = useAuth();

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-2">EzDoc</h1>
        <p className="text-gray-500">{sessionReady ? 'Ready' : 'Loading...'}</p>
      </div>
    </div>
  );
}
