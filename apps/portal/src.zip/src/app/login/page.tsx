'use client';

import { useState, useEffect, Suspense, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { GoogleAuthProvider } from 'firebase/auth';
import { auth } from '@/lib/firebase';

function LoginContent() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const returnUrl = searchParams.get('returnUrl');
    
    const handledRef = useRef(false);
    
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { signIn, error } = useAuth();
    const [loading, setLoading] = useState(false);
    const [googleLoading, setGoogleLoading] = useState(false);
    const [googleError, setGoogleError] = useState('');

    // Check if already logged in
    useEffect(() => {
        if (handledRef.current) {
            return;
        }
        
        const handleAuthRedirect = async () => {
            try {
                // Check for redirect result (Google OAuth redirect)
                const { getRedirectResult } = await import('firebase/auth');
                const result = await getRedirectResult(auth);
                
                // Always clear the flag after getting result
                sessionStorage.removeItem('redirectInFlight');
                
                if (result && result.user) {
                    handledRef.current = true;
                    
                    // Get stored returnUrl
                    const storedReturnUrl = sessionStorage.getItem('auth_returnUrl');
                    sessionStorage.removeItem('auth_returnUrl');
                    
                    const finalReturnUrl = storedReturnUrl || returnUrl || '/dashboard';
                    
                    if (finalReturnUrl !== '/login') {
                        router.push(finalReturnUrl);
                    } else {
                        router.push('/dashboard');
                    }
                    return;
                } else {
                    // Clear flag if no result
                    sessionStorage.removeItem('redirectInFlight');
                }
            } catch (err: any) {
                // Always clear flag on error
                sessionStorage.removeItem('redirectInFlight');
                
                const errorCode = err?.code || 'UNKNOWN_CODE';
                const errorMessage = err?.message || 'Unknown error';
                
                // Show error in UI (except for null-user which is normal)
                if (errorCode !== 'auth/null-user') {
                    setGoogleError(errorMessage);
                }
            }
            
            // Normal auth state check - redirect if already logged in
                const unsubscribe = auth.onAuthStateChanged((user) => {
                    if (user && returnUrl && returnUrl !== '/login') {
                        router.push(returnUrl);
                    }
                });
                
                return unsubscribe;
        };
        
        handleAuthRedirect();
    }, [returnUrl, router]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await signIn(email, password);
            // If returnUrl exists, redirect there
            if (returnUrl) {
                router.push(returnUrl);
            }
        } catch (err) {
            // Error handled by auth context
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        // Check if redirect already in flight
        const inFlight = sessionStorage.getItem('redirectInFlight');
        if (inFlight === '1') {
            return; // Already processing
        }
        
        setGoogleLoading(true);
        setGoogleError('');
        
        try {
            // Mark redirect as in-flight
            sessionStorage.setItem('redirectInFlight', '1');
            
            // Store returnUrl for after redirect
            if (returnUrl) {
                sessionStorage.setItem('auth_returnUrl', returnUrl);
            }
            
            // Use REDIRECT instead of POPUP (works in LINE browser)
            const provider = new GoogleAuthProvider();
            const { signInWithRedirect } = await import('firebase/auth');
            
            await signInWithRedirect(auth, provider);
            
            // User will be redirected, no code after this runs
            
        } catch (err: any) {
            // Clear flag on error
            sessionStorage.removeItem('redirectInFlight');
            
            const errorCode = err?.code || 'UNKNOWN_CODE';
            let errorMessage = 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ';
            
            // Map Firebase errors to Thai messages
            if (errorCode === 'auth/popup-blocked') {
                errorMessage = 'กรุณาอนุญาตให้เปิด popup และลองอีกครั้ง';
            } else if (errorCode === 'auth/popup-closed-by-user') {
                errorMessage = 'ยกเลิกการเข้าสู่ระบบ';
                setGoogleLoading(false);
                return;
            } else if (errorCode === 'auth/operation-not-allowed') {
                errorMessage = 'การเข้าสู่ระบบด้วย Google ยังไม่ได้เปิดใช้งาน กรุณาติดต่อผู้ดูแลระบบ';
            } else if (err?.message) {
                errorMessage = err.message;
            }
            
            setGoogleError(errorMessage);
            setGoogleLoading(false);
        }
    };

    return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4 py-12 sm:px-6 lg:px-8">
            <div className="w-full max-w-md space-y-8">
                <div className="text-center">
                    <div className="mx-auto h-16 w-16 rounded-full bg-indigo-600 flex items-center justify-center mb-4">
                        <svg className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                        เข้าสู่ระบบ EzDoc
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        ระบบจัดการเอกสารธุรกิจออนไลน์
                    </p>
                </div>

                <div className="bg-white rounded-lg shadow-lg p-8 space-y-6">
                    <form className="space-y-5" onSubmit={handleSubmit}>
                        <div className="space-y-4">
                        <div>
                                <label htmlFor="email-address" className="block text-sm font-medium text-gray-700 mb-1">
                                    อีเมล
                                </label>
                            <input
                                id="email-address"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-2.5 border"
                                    placeholder="your@email.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                    disabled={loading || googleLoading}
                            />
                        </div>
                        <div>
                                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                                    รหัสผ่าน
                                </label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                autoComplete="current-password"
                                required
                                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-2.5 border"
                                    placeholder="••••••••"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                    disabled={loading || googleLoading}
                            />
                        </div>
                    </div>

                        {(error || googleError) && (
                            <div className="rounded-md bg-red-50 p-4">
                                <div className="flex">
                                    <div className="flex-shrink-0">
                                        <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div className="ml-3">
                                        <p className="text-sm text-red-800">{error || googleError}</p>
                                    </div>
                                </div>
                            </div>
                    )}

                    <div>
                        <button
                            type="submit"
                                disabled={loading || googleLoading}
                                className="w-full flex justify-center items-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                                {loading ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        กำลังเข้าสู่ระบบ...
                                    </>
                                ) : (
                                    'เข้าสู่ระบบ'
                                )}
                        </button>
                    </div>
                    </form>
                    
                    <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-gray-300"></div>
                        </div>
                        <div className="relative flex justify-center text-sm">
                            <span className="bg-white px-4 text-gray-500">หรือ</span>
                        </div>
                    </div>
                    
                    <div>
                        <button
                            type="button"
                            onClick={handleGoogleSignIn}
                            disabled={loading || googleLoading}
                            className="w-full flex justify-center items-center gap-3 py-2.5 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            {googleLoading ? (
                                <>
                                    <svg className="animate-spin h-5 w-5 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    กำลังเข้าสู่ระบบ...
                                </>
                            ) : (
                                <>
                            <svg className="w-5 h-5" viewBox="0 0 24 24">
                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                            </svg>
                                    เข้าสู่ระบบด้วย Google
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default function LoginPage() {
    return (
        <Suspense fallback={<div className="flex min-h-screen items-center justify-center">Loading...</div>}>
            <LoginContent />
        </Suspense>
    );
}
