'use client';

import { useEffect, useState } from 'react';
import { auth } from '@/lib/firebase';

// LIFF SDK (dynamic import to avoid SSR issues)
let liff: any = null;

type Status = 
  | 'loading' 
  | 'liff-init' 
  | 'line-login' 
  | 'checking' 
  | 'not-linked' 
  | 'linked' 
  | 'linking' 
  | 'unlinking'
  | 'success' 
  | 'error';

interface LinkStatus {
  linked: boolean;
  uid?: string;
  email?: string;
  linkedAt?: string;
  lineUserId?: string;
}

export default function LiffLinkPage() {
  const [status, setStatus] = useState<Status>('loading');
  const [error, setError] = useState<string>('');
  const [linkStatus, setLinkStatus] = useState<LinkStatus | null>(null);
  // ✅ FIX 4: Debug panel state (env gated)
  const [debugInfo, setDebugInfo] = useState<{
    liffInit: boolean;
    isLoggedIn: boolean;
    hasIdToken: boolean;
    hasAccessToken: boolean;
    lastError: string | null;
  } | null>(null);

  useEffect(() => {
    initLiff();
  }, []);

  const initLiff = async () => {
    try {
      setStatus('liff-init');

      // Dynamic import LIFF
      if (!liff) {
        const liffModule = await import('@line/liff');
        liff = liffModule.default;
      }

      const liffId = process.env.NEXT_PUBLIC_LIFF_ID;
      if (!liffId) {
        throw new Error('LIFF configuration error');
      }

      await liff.init({ liffId });

      // Check if logged in to LINE
      const isLoggedIn = liff.isLoggedIn();
      
      // ✅ FIX 4: Update debug info
      const hasIdToken = !!liff.getIDToken();
      let hasAccessToken = false;
      try {
        hasAccessToken = !!liff.getAccessToken();
      } catch (e) {
        // Ignore
      }
      
      if (process.env.NEXT_PUBLIC_DEBUG === 'true') {
        setDebugInfo({
          liffInit: true,
          isLoggedIn,
          hasIdToken,
          hasAccessToken,
          lastError: null,
        });
      }

      if (!isLoggedIn) {
        setStatus('line-login');
        const currentUrl = window.location.href.split('#')[0];
        liff.login({ redirectUri: currentUrl });
        return;
      }

      await checkLinkStatus();
    } catch (err) {
      console.error('[LIFF] Init error:', err);
      const errorMsg = err instanceof Error ? err.message : String(err);
      setStatus('error');
      setError('เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่อีกครั้ง');
      
      // ✅ FIX 4: Update debug info on error
      if (process.env.NEXT_PUBLIC_DEBUG === 'true') {
        setDebugInfo(prev => prev ? {
          ...prev,
          lastError: errorMsg,
        } : {
          liffInit: false,
          isLoggedIn: false,
          hasIdToken: false,
          hasAccessToken: false,
          lastError: errorMsg,
        });
      }
    }
  };

  const checkLinkStatus = async () => {
    try {
      setStatus('checking');

      // ✅ FIX 3: Standardize auth - getIDToken with retry
      let idToken = liff.getIDToken();
      
      if (!idToken) {
        // Force login if no token
        console.warn('[LIFF] Missing ID token, forcing login');
        const currentUrl = window.location.href.split('#')[0];
        liff.login({ redirectUri: currentUrl });
        return;
      }

      // ✅ FIX 3: Standardize client -> backend auth: Authorization: Bearer <ID_TOKEN>
      const functionsUrl = process.env.NEXT_PUBLIC_FUNCTIONS_BASE_URL || '';
      const checkUrl = `${functionsUrl}/checkLineLink`;

      const res = await fetch(checkUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`, // ✅ Standardized auth header
        },
        body: JSON.stringify({ idToken }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        const errorCode = errorData.code || errorData.error;
        
        // ✅ FIX 3: Handle missing auth error with actionable message
        if (errorCode === 'ERR_MISSING_AUTH_HEADER' || res.status === 401) {
          // Retry login
          console.warn('[LIFF] Auth error, retrying login');
          const currentUrl = window.location.href.split('#')[0];
          liff.login({ redirectUri: currentUrl });
          return;
        }
        
        throw new Error(errorData.error || 'Failed to check link status');
      }

      const data = await res.json() as LinkStatus;
      setLinkStatus(data);
      setStatus(data.linked ? 'linked' : 'not-linked');
    } catch (err: any) {
      console.error('[LIFF] Check error:', err);
      setStatus('error');
      setError(err.message || 'เกิดข้อผิดพลาดในการตรวจสอบสถานะ');
    }
  };

  const handleStartLink = async () => {
    try {
      setStatus('linking');

      // ✅ FIX 3: Standardize auth - getIDToken with retry
      let idToken = liff.getIDToken();
      
      if (!idToken) {
        // Show actionable error and retry login
        setError('กรุณาเข้าสู่ระบบ LINE อีกครั้ง');
        const currentUrl = window.location.href.split('#')[0];
        liff.login({ redirectUri: currentUrl });
        return;
      }

      const functionsUrl = process.env.NEXT_PUBLIC_FUNCTIONS_BASE_URL || '';
      const startUrl = `${functionsUrl}/linkLineStart`;

      const res = await fetch(startUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`, // ✅ Standardized auth header
        },
        body: JSON.stringify({ idToken }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to start linking');
      }

      const { code } = await res.json();
      
      // Open external browser
      const completeUrl = `https://doc.ezboq.com/link/complete?code=${code}`;
      
      if (liff) {
        liff.openWindow({
          url: completeUrl,
          external: true,
        });
      } else {
        window.location.href = completeUrl;
      }
      
      setStatus('success');
    } catch (err: any) {
      console.error('[LIFF] Link error:', err);
      setStatus('error');
      setError(err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ');
    }
  };

  const handleUnlink = async () => {
    if (!confirm('ยืนยันการยกเลิกการเชื่อมต่อบัญชี?')) {
      return;
    }

    try {
      setStatus('unlinking');

      // ✅ FIX 3: Standardize auth - getIDToken with retry
      const idToken = liff.getIDToken();
      if (!idToken) {
        setError('กรุณาเข้าสู่ระบบ LINE อีกครั้ง');
        const currentUrl = window.location.href.split('#')[0];
        liff.login({ redirectUri: currentUrl });
        return;
      }

      // Get Firebase token
      const user = auth.currentUser;
      if (!user) {
        throw new Error('กรุณาเข้าสู่ระบบก่อน');
      }

      const firebaseToken = await user.getIdToken();

      const functionsUrl = process.env.NEXT_PUBLIC_FUNCTIONS_BASE_URL || '';
      const unlinkUrl = `${functionsUrl}/unlinkLine`;

      const res = await fetch(unlinkUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${firebaseToken}`,
        },
        body: JSON.stringify({ idToken }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to unlink');
      }

      // Refresh status
      setLinkStatus(null);
      await checkLinkStatus();
    } catch (err: any) {
      console.error('[LIFF] Unlink error:', err);
      setStatus('error');
      setError(err.message || 'เกิดข้อผิดพลาดในการยกเลิกการเชื่อมต่อ');
    }
  };

  const handleCloseLiff = () => {
    if (liff) {
      liff.closeWindow();
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#ffffff',
        padding: '20px',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      }}
    >
      <div
        style={{
          backgroundColor: 'white',
          padding: '48px 32px',
          borderRadius: '16px',
          boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
          textAlign: 'center',
          maxWidth: '420px',
          width: '100%',
        }}
      >
        {/* Logo / Brand */}
        <div style={{ marginBottom: '32px' }}>
          <h1 style={{ 
            margin: '0 0 8px 0', 
            color: '#1DB446', 
            fontSize: '32px',
            fontWeight: '700',
            letterSpacing: '-0.5px',
          }}>
            EzDoc
          </h1>
          <p style={{ 
            margin: 0, 
            color: '#666666', 
            fontSize: '14px',
            lineHeight: '1.5',
          }}>
            ออกเอกสารธุรกิจผ่าน LINE<br />ง่าย เร็ว ไม่ต้องใช้คอม
          </p>
        </div>

        {/* Loading States */}
        {(status === 'loading' || status === 'liff-init' || status === 'line-login' || status === 'checking') && (
          <div style={{ padding: '40px 20px' }}>
            <div style={{ 
              width: '48px', 
              height: '48px', 
              border: '3px solid #f0f0f0',
              borderTopColor: '#1DB446',
              borderRadius: '50%',
              margin: '0 auto 20px',
              animation: 'spin 1s linear infinite',
            }} />
            <p style={{ color: '#666666', fontSize: '15px', margin: 0 }}>
              {status === 'loading' && 'กำลังโหลด...'}
              {status === 'liff-init' && 'กำลังเตรียมระบบ...'}
              {status === 'line-login' && 'กำลังเข้าสู่ระบบ LINE...'}
              {status === 'checking' && 'กำลังตรวจสอบสถานะ...'}
            </p>
          </div>
        )}

        {/* Linking State */}
        {status === 'linking' && (
          <div style={{ padding: '40px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔗</div>
            <p style={{ color: '#333333', fontSize: '16px', fontWeight: '500', margin: '0 0 8px 0' }}>
              กำลังเปิดเบราว์เซอร์...
            </p>
            <p style={{ color: '#666666', fontSize: '14px', margin: 0, lineHeight: '1.6' }}>
              กรุณาดำเนินการต่อในเบราว์เซอร์ที่เปิดขึ้นมา
            </p>
          </div>
        )}

        {/* Unlinking State */}
        {status === 'unlinking' && (
          <div style={{ padding: '40px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔓</div>
            <p style={{ color: '#666666', fontSize: '15px', margin: 0 }}>
              กำลังยกเลิกการเชื่อมต่อ...
            </p>
          </div>
        )}

        {/* Not Linked State */}
        {status === 'not-linked' && linkStatus && (
          <div>
            <div style={{ 
              backgroundColor: '#FFF9E6',
              border: '1px solid #FFE066',
              borderRadius: '12px',
              padding: '24px',
              marginBottom: '24px',
            }}>
              <div style={{ fontSize: '40px', marginBottom: '12px' }}>🔗</div>
              <p style={{ 
                margin: '0 0 8px 0', 
                fontWeight: '600', 
                fontSize: '17px',
                color: '#333333',
              }}>
                ยังไม่ได้เชื่อมต่อบัญชี
              </p>
              <p style={{ 
                margin: 0, 
                fontSize: '14px',
                color: '#666666',
                lineHeight: '1.5',
              }}>
                เชื่อมต่อบัญชี Google เพื่อใช้งาน EzDoc ผ่าน LINE
              </p>
            </div>
            <button
              onClick={handleStartLink}
              style={{
                padding: '14px 24px',
                fontSize: '16px',
                fontWeight: '600',
                backgroundColor: '#1DB446',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
                marginBottom: '12px',
                transition: 'background-color 0.2s',
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#1AA03A'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#1DB446'}
            >
              เชื่อมต่อบัญชี
            </button>
            <button
              onClick={handleCloseLiff}
              style={{
                padding: '12px 24px',
                fontSize: '15px',
                backgroundColor: 'transparent',
                color: '#666666',
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              ปิดหน้าต่าง
            </button>
          </div>
        )}

        {/* Linked State */}
        {status === 'linked' && linkStatus && (
          <div>
            <div style={{ 
              backgroundColor: '#E8F5E9',
              border: '1px solid #C8E6C9',
              borderRadius: '12px',
              padding: '24px',
              marginBottom: '24px',
            }}>
              <div style={{ fontSize: '40px', marginBottom: '12px' }}>✅</div>
              <p style={{ 
                margin: '0 0 16px 0', 
                fontWeight: '600', 
                fontSize: '17px',
                color: '#2E7D32',
              }}>
                บัญชีเชื่อมต่อแล้ว
              </p>
              <div style={{ 
                textAlign: 'left',
                backgroundColor: 'white',
                borderRadius: '8px',
                padding: '16px',
                fontSize: '14px',
                color: '#333333',
              }}>
                {linkStatus.email && (
                  <p style={{ margin: '0 0 8px 0' }}>
                    <strong>อีเมล:</strong> {linkStatus.email}
                  </p>
                )}
                {linkStatus.linkedAt && (
                  <p style={{ margin: 0 }}>
                    <strong>เชื่อมต่อเมื่อ:</strong> {new Date(linkStatus.linkedAt).toLocaleString('th-TH', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={handleUnlink}
              style={{
                padding: '12px 24px',
                fontSize: '15px',
                fontWeight: '500',
                backgroundColor: 'transparent',
                color: '#D32F2F',
                border: '1px solid #FFCDD2',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
                marginBottom: '12px',
              }}
            >
              ยกเลิกการเชื่อมต่อ
            </button>
            <button
              onClick={handleCloseLiff}
              style={{
                padding: '12px 24px',
                fontSize: '15px',
                backgroundColor: '#1DB446',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              ปิดหน้าต่าง
            </button>
          </div>
        )}

        {/* Success State */}
        {status === 'success' && (
          <div>
            <div style={{ 
              backgroundColor: '#E8F5E9',
              border: '1px solid #C8E6C9',
              borderRadius: '12px',
              padding: '32px 24px',
              marginBottom: '24px',
            }}>
              <div style={{ fontSize: '48px', marginBottom: '16px' }}>✅</div>
              <p style={{ 
                margin: '0 0 8px 0', 
                fontWeight: '600', 
                fontSize: '17px',
                color: '#2E7D32',
              }}>
                กำลังเปิดเบราว์เซอร์...
              </p>
              <p style={{ 
                margin: '0 0 16px 0', 
                fontSize: '14px',
                color: '#666666',
                lineHeight: '1.6',
              }}>
                กรุณาดำเนินการต่อในหน้าต่างที่เปิดขึ้น
              </p>
              <p style={{ 
                margin: 0, 
                fontSize: '12px',
                color: '#999999',
              }}>
                หลังจากเชื่อมต่อสำเร็จ คุณสามารถปิดหน้าต่างนี้ได้
              </p>
            </div>
            <button
              onClick={handleCloseLiff}
              style={{
                padding: '14px 24px',
                fontSize: '16px',
                fontWeight: '600',
                backgroundColor: '#1DB446',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              ปิดหน้าต่างนี้
            </button>
          </div>
        )}

        {/* Error State */}
        {status === 'error' && (
          <div>
            <div style={{ 
              backgroundColor: '#FFEBEE',
              border: '1px solid #FFCDD2',
              borderRadius: '12px',
              padding: '24px',
              marginBottom: '24px',
            }}>
              <div style={{ fontSize: '40px', marginBottom: '12px' }}>❌</div>
              <p style={{ 
                margin: '0 0 8px 0', 
                fontWeight: '600', 
                fontSize: '17px',
                color: '#C62828',
              }}>
                เกิดข้อผิดพลาด
              </p>
              <p style={{ 
                margin: 0, 
                fontSize: '14px',
                color: '#666666',
                lineHeight: '1.6',
              }}>
                {error}
              </p>
            </div>
            <button
              onClick={() => window.location.reload()}
              style={{
                padding: '14px 24px',
                fontSize: '16px',
                fontWeight: '600',
                backgroundColor: '#1DB446',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
                marginBottom: '12px',
              }}
            >
              ลองใหม่อีกครั้ง
            </button>
            <button
              onClick={handleCloseLiff}
              style={{
                padding: '12px 24px',
                fontSize: '15px',
                backgroundColor: 'transparent',
                color: '#666666',
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              ปิดหน้าต่าง
            </button>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
