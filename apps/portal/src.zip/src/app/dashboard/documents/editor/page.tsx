'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { documentsRepo } from '@/lib/repos/documents.repo';
import { EzDocument as Document } from '@/lib/repos/documents.repo';
import DocumentEditor from '@/components/document-editor';

function EditorContent() {
    const searchParams = useSearchParams();
    const [document, setDocument] = useState<Document | undefined>(undefined);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const id = searchParams.get('id');
        if (!id) {
            setLoading(false);
            setError('Missing document ID');
            return;
        }

        if (id === 'new') {
            setLoading(false);
            return;
        }

        documentsRepo.getDocument(id)
            .then(setDocument)
            .catch(err => {
                console.error(err);
                setError('Failed to load document');
            })
            .finally(() => setLoading(false));
    }, [searchParams]);

    if (loading) return <div className="p-8 text-center text-gray-500">Loading document...</div>;
    if (error) return <div className="p-8 text-center text-red-500">{error}</div>;
    if (!document && !loading && searchParams.get('id') !== 'new') return <div className="p-8 text-center text-gray-500">Document not found</div>;

    return <DocumentEditor initialData={document} />;
}

export default function EditDocumentPage() {
    return (
        <Suspense fallback={<div className="p-8 text-center text-gray-500">Loading...</div>}>
            <EditorContent />
        </Suspense>
    );
}
