'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '@/lib/firebase';

type Status = 'loading' | 'need-signin' | 'linking' | 'success' | 'error';

function LinkCompleteContent() {
  const searchParams = useSearchParams();
  const code = searchParams.get('code');
  
  const [status, setStatus] = useState<Status>('loading');
  const [error, setError] = useState<string>('');
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    console.log(message);
    setLogs(prev => [...prev, message]);
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    addLog('[COMPLETE_START] Checking authentication...');
    
    if (!code) {
      setStatus('error');
      setError('Missing link code. Please start from LINE bot.');
      return;
    }

    addLog(`[COMPLETE_CODE] Code received: ${code.substring(0, 8)}...`);

    // Check if already signed in
    const user = auth.currentUser;
    if (user) {
      addLog(`[COMPLETE_AUTH] Already signed in as: ${user.uid}`);
      await consumeCode();
    } else {
      addLog('[COMPLETE_NEED_SIGNIN] Not signed in - showing Google sign-in');
      setStatus('need-signin');
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      addLog('[COMPLETE_SIGNIN_START] Starting Google sign-in...');
      setStatus('loading');

      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      addLog(`[COMPLETE_SIGNIN_OK] Signed in as: ${result.user.uid}`);
      
      await consumeCode();
    } catch (err: any) {
      addLog(`[COMPLETE_SIGNIN_FAIL] ${err.message}`);
      
      // Enhanced error handling for operation-not-allowed
      let errorMessage = `Google sign-in failed: ${err.message}`;
      
      if (err.code === 'auth/operation-not-allowed') {
        errorMessage = `🔧 Firebase Configuration Required\n\n` +
          `Google Sign-in Provider is not enabled.\n\n` +
          `Please enable it:\n` +
          `1. Go to Firebase Console\n` +
          `2. Authentication → Sign-in method\n` +
          `3. Enable Google provider\n` +
          `4. Add support email\n` +
          `5. Save changes\n\n` +
          `Firebase Console:\n` +
          `https://console.firebase.google.com/project/ezdoc-v1-th/authentication/providers\n\n` +
          `Error: ${err.code}`;
      } else if (err.code === 'auth/popup-blocked') {
        errorMessage = `Popup blocked by browser. Please allow popups and try again.`;
      } else if (err.code === 'auth/popup-closed-by-user') {
        errorMessage = `Sign-in cancelled. Please try again.`;
        // Don't set error state for user cancellation
        setStatus('need-signin');
        return;
      }
      
      setStatus('error');
      setError(errorMessage);
    }
  };

  const consumeCode = async () => {
    try {
      setStatus('linking');
      addLog('[COMPLETE_CONSUME_START] Consuming link code...');

      const user = auth.currentUser;
      if (!user) {
        throw new Error('Not signed in');
      }

      const firebaseToken = await user.getIdToken();
      const functionsUrl = process.env.NEXT_PUBLIC_FUNCTIONS_BASE_URL || '';
      const consumeUrl = `${functionsUrl}/linkLineConsume`;

      addLog(`[COMPLETE_CONSUME_CALL] Calling ${consumeUrl}`);

      const res = await fetch(consumeUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${firebaseToken}`,
        },
        body: JSON.stringify({ code }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        addLog(`[COMPLETE_CONSUME_FAIL] ${res.status}: ${JSON.stringify(errorData)}`);
        throw new Error(errorData.error || 'Failed to link account');
      }

      const { lineUserId, uid } = await res.json();
      addLog(`[COMPLETE_CONSUME_OK] Successfully linked ${lineUserId} → ${uid}`);

      setStatus('success');
    } catch (err: any) {
      addLog(`[COMPLETE_CONSUME_FAIL] ${err.message}`);
      setStatus('error');
      setError(err.message || 'Failed to complete linking');
    }
  };

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      backgroundColor: '#f5f5f5',
      padding: '20px',
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '40px',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        textAlign: 'center',
        maxWidth: '500px',
        width: '100%',
      }}>
        <h1 style={{ marginBottom: '20px', color: '#333', fontSize: '24px' }}>
          เชื่อมต่อบัญชี LINE
        </h1>

        {/* Debug Panel */}
        <div style={{
          backgroundColor: '#f8f9fa',
          padding: '10px',
          borderRadius: '4px',
          marginBottom: '20px',
          fontSize: '11px',
          textAlign: 'left',
          fontFamily: 'monospace',
          maxHeight: '150px',
          overflowY: 'auto',
        }}>
          {logs.map((log, i) => (
            <div key={i}>{log}</div>
          ))}
        </div>

        {status === 'loading' && (
          <div style={{ padding: '20px' }}>
            <p style={{ color: '#666' }}>⏳ กำลังโหลด...</p>
          </div>
        )}

        {status === 'need-signin' && (
          <div>
            <p style={{ marginBottom: '20px', color: '#666' }}>
              กรุณาล็อกอินด้วย Google เพื่อเชื่อมต่อบัญชี LINE
            </p>
            <button
              onClick={handleGoogleSignIn}
              style={{
                padding: '12px 24px',
                fontSize: '16px',
                backgroundColor: '#4285f4',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              🔐 เข้าสู่ระบบด้วย Google
            </button>
          </div>
        )}

        {status === 'linking' && (
          <div style={{ padding: '20px' }}>
            <p style={{ color: '#666' }}>🔗 กำลังเชื่อมต่อบัญชี...</p>
          </div>
        )}

        {status === 'success' && (
          <div>
            <div style={{
              backgroundColor: '#d4edda',
              color: '#155724',
              padding: '20px',
              borderRadius: '4px',
              marginBottom: '20px',
            }}>
              <p style={{ margin: 0, fontSize: '48px' }}>✅</p>
              <p style={{ margin: '10px 0', fontWeight: 'bold', fontSize: '18px' }}>
                เชื่อมต่อสำเร็จ!
              </p>
              <p style={{ margin: '5px 0', fontSize: '14px' }}>
                ตอนนี้คุณสามารถใช้งานบอทใน LINE ได้แล้ว
              </p>
            </div>
            <button
              onClick={() => window.close()}
              style={{
                padding: '12px 24px',
                fontSize: '16px',
                backgroundColor: '#00B900',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              กลับไป LINE
            </button>
          </div>
        )}

        {status === 'error' && (
          <div>
            <div style={{
              backgroundColor: '#f8d7da',
              color: '#721c24',
              padding: '20px',
              borderRadius: '4px',
              marginBottom: '20px',
              textAlign: 'left',
            }}>
              <p style={{ margin: 0, fontSize: '48px', textAlign: 'center' }}>❌</p>
              <p style={{ margin: '10px 0', fontWeight: 'bold', textAlign: 'center' }}>เกิดข้อผิดพลาด</p>
              <pre style={{
                margin: '10px 0 0 0',
                fontSize: '11px',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
                backgroundColor: '#fff',
                padding: '10px',
                borderRadius: '4px',
              }}>
                {error}
              </pre>
            </div>
            <button
              onClick={() => window.close()}
              style={{
                padding: '12px 24px',
                fontSize: '16px',
                backgroundColor: '#6c757d',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                width: '100%',
              }}
            >
              ปิดหน้าต่าง
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function LinkCompletePage() {
  return (
    <Suspense fallback={
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
      }}>
        <p>Loading...</p>
      </div>
    }>
      <LinkCompleteContent />
    </Suspense>
  );
}
