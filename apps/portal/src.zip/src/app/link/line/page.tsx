'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { signInWithCustomToken } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';

/**
 * LinkLineContent - Manual OAuth + Custom Token Flow
 */
function LinkLineContent() {
  const router = useRouter();
  const [state, setState] = useState<string | null>(null);
  const [lineUserId, setLineUserId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);

  const [status, setStatus] = useState<'loading' | 'validating' | 'need-auth' | 'authenticated' | 'linking' | 'success' | 'error'>('loading');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [errorCode, setErrorCode] = useState<string>('');

  // Read state from hash fragment on mount (client-side only)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const hash = window.location.hash.substring(1); // Remove '#'
    const params = new URLSearchParams(hash);
    let stateParam = params.get('state');
    
    // If no state in hash, try sessionStorage
    if (!stateParam) {
      const pendingState = sessionStorage.getItem('pendingLineState');
      if (pendingState) {
        stateParam = pendingState;
        sessionStorage.removeItem('pendingLineState');
      }
    }
    
    setState(stateParam);
    
    if (!stateParam) {
      setStatus('error');
      setErrorMessage('ไม่พบข้อมูลการเชื่อมต่อ กรุณาขอลิงก์ใหม่จาก LINE');
      setErrorCode('NO_STATE');
      return;
    }

    // Validate state and extract lineUserId
    validateState(stateParam);
  }, []);

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user && lineUserId && status !== 'success' && status !== 'linking') {
        // User is already signed in, create link immediately
        setCurrentUser(user);
        createLineLink(user.uid);
      }
    });

    return () => unsubscribe();
  }, [lineUserId, status]);

  const validateState = async (stateParam: string) => {
    try {
      setStatus('validating');
      
      // Decode and parse state (it's base64-encoded JSON)
      const decoded = atob(decodeURIComponent(stateParam));
      const payload = JSON.parse(decoded);
      
      if (!payload.lineUserId) {
        throw new Error('Invalid state: missing lineUserId');
      }
      
      // Check expiration
      const now = Math.floor(Date.now() / 1000);
      if (payload.exp && now > payload.exp) {
        throw new Error('ลิงก์หมดอายุแล้ว กรุณาขอลิงก์ใหม่จาก LINE');
      }
      
      setLineUserId(payload.lineUserId);
      
      // Check if user is already signed in
      const currentAuthUser = auth.currentUser;
      if (currentAuthUser) {
        setCurrentUser(currentAuthUser);
        createLineLink(currentAuthUser.uid);
      } else {
        setStatus('need-auth');
      }
      
    } catch (err) {
      setStatus('error');
      setErrorMessage(err instanceof Error ? err.message : 'ข้อมูลไม่ถูกต้อง');
      setErrorCode('INVALID_STATE');
    }
  };

  const createLineLink = async (uid: string) => {
    if (!lineUserId) return;

    try {
      setStatus('linking');
      
      await setDoc(doc(db, 'line_links', lineUserId), {
        lineUserId,
        uid,
        provider: 'manual',
        linkedAt: serverTimestamp(),
        status: 'active'
      });
      
      // Success!
      setStatus('success');
      
      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
      
    } catch (err) {
      setStatus('error');
      setErrorMessage(err instanceof Error ? err.message : 'เกิดข้อผิดพลาดในการเชื่อมต่อ');
      setErrorCode('LINK_FAILED');
    }
  };

  const handleManualSignIn = () => {
    if (!state) {
      return;
    }
    
    // Store state in sessionStorage (not in URL)
    sessionStorage.setItem('pendingLineState', state);
    
    // Redirect to login page with simple returnUrl (no hash)
    const returnUrl = '/link/line';
    router.push(`/login?returnUrl=${encodeURIComponent(returnUrl)}`);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4 py-12">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-8 text-center">
        <div className="mb-6">
          <div className="mx-auto h-16 w-16 rounded-full bg-indigo-600 flex items-center justify-center mb-4">
            <svg className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">เชื่อมต่อบัญชี LINE</h1>
        </div>

        {(status === 'loading' || status === 'validating') && (
          <div className="py-8">
            <div className="flex justify-center mb-4">
              <svg className="animate-spin h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
            <p className="text-gray-600">กำลังตรวจสอบ...</p>
          </div>
        )}

        {status === 'need-auth' && (
          <div className="py-4">
            <p className="text-gray-600 mb-6">
              กรุณาเข้าสู่ระบบเพื่อเชื่อมต่อบัญชี LINE กับ EzDoc
            </p>
            <button
              onClick={handleManualSignIn}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
              </svg>
              <span>เข้าสู่ระบบ</span>
            </button>
          </div>
        )}

        {status === 'linking' && (
          <div className="py-8">
            <div className="flex justify-center mb-4">
              <svg className="animate-spin h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
            <p className="text-gray-600">กำลังเชื่อมต่อบัญชี...</p>
          </div>
        )}

        {status === 'success' && (
          <div className="py-6">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
              <svg className="h-10 w-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">เชื่อมต่อสำเร็จ!</h2>
            <p className="text-sm text-gray-600 mb-4">กำลังนำคุณไปยังแดชบอร์ด...</p>
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-600"></div>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="py-6">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-100 mb-4">
              <svg className="h-10 w-10 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">เกิดข้อผิดพลาด</h2>
            <p className="text-sm text-red-600 mb-4">{errorMessage}</p>
            
            {errorCode === 'EXPIRED' && (
              <p className="text-xs text-amber-600 mb-4">
                💡 กรุณาขอลิงก์ใหม่จาก LINE
              </p>
            )}

            <button
              onClick={() => window.location.reload()}
              className="w-full py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              ลองอีกครั้ง
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * /link/line page - Uses hash fragment for state (works with static export)
 * 
 * OAuth callback for linking LINE account with Firebase
 * 
 * Flow:
 * 1. User receives link from LINE: /link/line#state={signedState}
 * 2. Auto-call Cloud Function to consume state and get customToken
 * 3. Sign in with customToken
 * 4. Redirect to dashboard
 */
export default function LinkLinePage() {
  return <LinkLineContent />;
}
