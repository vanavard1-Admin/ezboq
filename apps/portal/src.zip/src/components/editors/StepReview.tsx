interface StepReviewProps {
    subtotal: number;
    discount: number;
    setDiscount: (val: number) => void;
    extraFee: number;
    setExtraFee: (val: number) => void;
    vatEnabled: boolean;
    setVatEnabled: (val: boolean) => void;
    vatRate: number;
    setVatRate: (val: number) => void;
    whtEnabled: boolean;
    setWhtEnabled: (val: boolean) => void;
    whtRate: number;
    setWhtRate: (val: number) => void;
    totalAmount: number;
    netReceive: number;
    vatAmount: number;
    whtAmount: number;
    isReadOnly: boolean;
}

export function StepReview({
    subtotal,
    discount,
    setDiscount,
    extraFee,
    setExtraFee,
    vatEnabled,
    setVatEnabled,
    vatRate,
    setVatRate,
    whtEnabled,
    setWhtEnabled,
    whtRate,
    setWhtRate,
    totalAmount,
    netReceive,
    vatAmount,
    whtAmount,
    isReadOnly
}: StepReviewProps) {
    return (
        <div className="space-y-6">
            <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Financial Summary</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Settings */}
                    <div className="space-y-4">
                        <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider">Settings</h4>

                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                            <div className="flex items-center">
                                <input
                                    type="checkbox"
                                    id="vat"
                                    disabled={isReadOnly}
                                    checked={vatEnabled}
                                    onChange={(e) => setVatEnabled(e.target.checked)}
                                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                />
                                <label htmlFor="vat" className="ml-2 block text-sm text-gray-900">VAT Registered</label>
                            </div>
                            {vatEnabled && (
                                <div className="flex items-center">
                                    <input
                                        type="number"
                                        disabled={isReadOnly}
                                        value={vatRate}
                                        onChange={(e) => setVatRate(parseFloat(e.target.value) || 0)}
                                        className="w-16 text-right border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-1"
                                    />
                                    <span className="ml-1 text-sm text-gray-500">%</span>
                                </div>
                            )}
                        </div>

                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                            <div className="flex items-center">
                                <input
                                    type="checkbox"
                                    id="wht"
                                    disabled={isReadOnly}
                                    checked={whtEnabled}
                                    onChange={(e) => setWhtEnabled(e.target.checked)}
                                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                />
                                <label htmlFor="wht" className="ml-2 block text-sm text-gray-900">Withholding Tax</label>
                            </div>
                            {whtEnabled && (
                                <div className="flex items-center">
                                    <input
                                        type="number"
                                        disabled={isReadOnly}
                                        value={whtRate}
                                        onChange={(e) => setWhtRate(parseFloat(e.target.value) || 0)}
                                        className="w-16 text-right border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-1"
                                    />
                                    <span className="ml-1 text-sm text-gray-500">%</span>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Totals */}
                    <div className="space-y-3 text-sm">
                        <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-3">Totals</h4>

                        <div className="flex justify-between">
                            <span className="text-gray-500">Subtotal</span>
                            <span className="font-medium text-gray-900">{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>

                        <div className="flex justify-between items-center">
                            <span className="text-gray-500">Discount (Amount)</span>
                            <input
                                type="number"
                                disabled={isReadOnly}
                                value={discount}
                                onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                                className="w-28 text-right border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-1"
                            />
                        </div>

                        <div className="flex justify-between items-center">
                            <span className="text-gray-500">Extra Fee</span>
                            <input
                                type="number"
                                disabled={isReadOnly}
                                value={extraFee}
                                onChange={(e) => setExtraFee(parseFloat(e.target.value) || 0)}
                                className="w-28 text-right border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-1"
                            />
                        </div>

                        {vatEnabled && (
                            <div className="flex justify-between items-center text-gray-600">
                                <span>VAT {vatRate}%</span>
                                <span>{vatAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                            </div>
                        )}

                        <div className="flex justify-between items-center pt-3 border-t">
                            <span className="font-bold text-gray-900 text-base">Grand Total</span>
                            <span className="font-bold text-gray-900 text-base">{totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>

                        {whtEnabled && (
                            <div className="flex justify-between items-center text-red-600 bg-red-50 p-2 rounded">
                                <span className="text-sm">Less WHT {whtRate}%</span>
                                <span>-{whtAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                            </div>
                        )}

                        <div className="flex justify-between items-center pt-3 border-t-2 border-indigo-100 mt-2">
                            <span className="font-bold text-indigo-700 text-lg">Net Receive</span>
                            <span className="font-bold text-indigo-700 text-lg">{netReceive.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
