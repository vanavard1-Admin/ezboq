import { DocumentItem } from '@/lib/repos/documents.repo';
import { Plus, Trash2 } from 'lucide-react';

interface StepItemsProps {
    items: DocumentItem[];
    setItems: (items: DocumentItem[]) => void;
    isReadOnly: boolean;
}

const DEFAULT_ITEM: DocumentItem = {
    line_no: 1,
    description_th: '',
    qty: 1,
    unit: 'รายการ',
    unit_price: 0,
    amount: 0,
};

export function StepItems({ items, setItems, isReadOnly }: StepItemsProps) {
    const handleItemChange = (index: number, field: keyof DocumentItem, value: string | number) => {
        const newItems = [...items];
        const item = { ...newItems[index], [field]: value };

        // Recalc line amount
        if (field === 'qty' || field === 'unit_price') {
            item.amount = Number(item.qty) * Number(item.unit_price);
        }

        newItems[index] = item;
        setItems(newItems);
    };

    const addItem = () => {
        // Find max line_no
        const maxLine = items.reduce((max, item) => Math.max(max, item.line_no), 0);
        setItems([...items, { ...DEFAULT_ITEM, line_no: maxLine + 1 }]);
    };

    const removeItem = (index: number) => {
        if (items.length === 1) return;
        const newItems = items.filter((_, i) => i !== index);
        // Re-index line numbers
        const reindexed = newItems.map((item, i) => ({ ...item, line_no: i + 1 }));
        setItems(reindexed);
    };

    return (
        <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Items</h3>

            {items.length === 0 && (
                <div className="text-center py-8 text-gray-500 border-2 border-dashed rounded-lg mb-4">
                    No items added yet. Click "Add Item" to start.
                </div>
            )}

            <div className="space-y-4">
                {items.map((item, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-12 gap-2 items-start text-sm border-b md:border-b-0 pb-4 md:pb-0 mb-4 md:mb-0">
                        <div className="col-span-1 pt-3 text-center text-gray-400 hidden md:block">{index + 1}</div>

                        <div className="col-span-12 md:col-span-5">
                            <label className="block text-xs text-gray-500 md:hidden mb-1">Description</label>
                            <input
                                type="text"
                                placeholder="Description"
                                disabled={isReadOnly}
                                value={item.description_th}
                                onChange={(e) => handleItemChange(index, 'description_th', e.target.value)}
                                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                            />
                        </div>

                        <div className="col-span-4 md:col-span-2">
                            <label className="block text-xs text-gray-500 md:hidden mb-1">Qty</label>
                            <input
                                type="number"
                                placeholder="Qty"
                                disabled={isReadOnly}
                                value={item.qty}
                                onChange={(e) => handleItemChange(index, 'qty', parseFloat(e.target.value) || 0)}
                                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 text-right"
                            />
                        </div>

                        <div className="col-span-4 md:col-span-1">
                            <label className="block text-xs text-gray-500 md:hidden mb-1">Unit</label>
                            <input
                                type="text"
                                placeholder="Unit"
                                disabled={isReadOnly}
                                value={item.unit}
                                onChange={(e) => handleItemChange(index, 'unit', e.target.value)}
                                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 text-center"
                            />
                        </div>

                        <div className="col-span-4 md:col-span-2">
                            <label className="block text-xs text-gray-500 md:hidden mb-1">Price</label>
                            <input
                                type="number"
                                placeholder="Price"
                                disabled={isReadOnly}
                                value={item.unit_price}
                                onChange={(e) => handleItemChange(index, 'unit_price', parseFloat(e.target.value) || 0)}
                                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 text-right"
                            />
                        </div>

                        <div className="col-span-12 md:col-span-1 pt-2 text-center flex md:block justify-end">
                            {!isReadOnly && (
                                <button
                                    onClick={() => removeItem(index)}
                                    className="text-red-400 hover:text-red-600 p-2"
                                    title="Remove Item"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {!isReadOnly && (
                <button
                    onClick={addItem}
                    className="mt-4 flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500 bg-indigo-50 px-3 py-2 rounded-md"
                >
                    <Plus className="w-4 h-4 mr-1" /> Add New Item
                </button>
            )}

            <div className="mt-4 pt-4 border-t text-right text-gray-500 text-sm">
                Total Items: {items.length}
            </div>
        </div>
    );
}
