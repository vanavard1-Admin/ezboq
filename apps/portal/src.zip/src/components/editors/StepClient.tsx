import { Customer } from '@/lib/repos/customers.repo';

interface StepClientProps {
    docType: 'QUO' | 'BILL' | 'RECEIPT';
    setDocType: (type: 'QUO' | 'BILL' | 'RECEIPT') => void;
    issueDate: string;
    setIssueDate: (date: string) => void;
    customerId: string;
    setCustomerId: (id: string) => void;
    customers: Customer[];
    subjectTh: string;
    setSubjectTh: (subject: string) => void;
    isReadOnly: boolean;
    isNew: boolean;
}

export function StepClient({
    docType,
    setDocType,
    issueDate,
    setIssueDate,
    customerId,
    setCustomerId,
    customers,
    subjectTh,
    setSubjectTh,
    isReadOnly,
    isNew
}: StepClientProps) {
    return (
        <div className="space-y-6">
            <div className="bg-white shadow rounded-lg p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Document Type</label>
                    <select
                        disabled={!isNew}
                        value={docType}
                        onChange={(e) => setDocType(e.target.value as any)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                    >
                        <option value="QUO">Quotation (ใบเสนอราคา)</option>
                        <option value="BILL">Billing Note (ใบวางบิล)</option>
                        <option value="RECEIPT">Receipt (ใบเสร็จรับเงิน)</option>
                    </select>
                    {!isNew && <p className="mt-1 text-xs text-gray-500">Document type cannot be changed after creation.</p>}
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700">Issue Date</label>
                    <input
                        type="date"
                        disabled={isReadOnly}
                        value={issueDate}
                        onChange={(e) => setIssueDate(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700">Customer <span className="text-red-500">*</span></label>
                    <select
                        disabled={isReadOnly}
                        value={customerId}
                        onChange={(e) => setCustomerId(e.target.value)}
                        className={`mt-1 block w-full rounded-md shadow-sm focus:ring-indigo-500 sm:text-sm border p-2 ${!customerId && !isNew ? 'border-red-300 focus:border-red-500' : 'border-gray-300 focus:border-indigo-500'
                            }`}
                    >
                        <option value="">-- Select Customer --</option>
                        {customers.map((c) => (
                            <option key={c.id} value={c.id}>
                                {c.displayName} ({c.type})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700">Subject (TH) <span className="text-red-500">*</span></label>
                    <input
                        type="text"
                        disabled={isReadOnly}
                        value={subjectTh}
                        onChange={(e) => setSubjectTh(e.target.value)}
                        placeholder="Project name or description"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                    />
                </div>
            </div>
        </div>
    );
}
