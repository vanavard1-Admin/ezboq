'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { EzDocument as Document, DocumentItem, documentsRepo } from '@/lib/repos/documents.repo';
import { Customer, customersRepo } from '@/lib/repos/customers.repo';
import { ArrowLeft, ArrowRight, CheckCircle2, AlertCircle, Loader2, Printer, FileText, Send } from 'lucide-react';
import Link from 'next/link';

// Step Components
import { StepClient } from './editors/StepClient';
import { StepItems } from './editors/StepItems';
import { StepReview } from './editors/StepReview';
import { useDocumentAutoSave } from '@/hooks/use-document-auto-save';

interface DocumentEditorProps {
    initialData?: Document;
    isNew?: boolean;
}

const DEFAULT_ITEM: DocumentItem = {
    line_no: 1,
    description_th: '',
    qty: 1,
    unit: 'รายการ',
    unit_price: 0,
    amount: 0,
};

const STEPS = [
    { id: 1, name: 'Client Info' },
    { id: 2, name: 'Items' },
    { id: 3, name: 'Review' },
];

export default function DocumentEditor({ initialData, isNew: initialIsNew = false }: DocumentEditorProps) {
    const router = useRouter();

    // Core Identity
    const [docIds, setDocId] = useState<string | undefined>(initialData?.id);
    const [isNew, setIsNew] = useState(initialIsNew);
    const [revision, setRevision] = useState(initialData?.revision || 0);

    // UX State
    const [loading, setLoading] = useState(false);
    const [currentStep, setCurrentStep] = useState(1);

    // Data State - Level 1 (Client)
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [docType, setDocType] = useState<'QUO' | 'BILL' | 'RECEIPT'>(initialData?.docType || 'QUO');
    const [customerId, setCustomerId] = useState<string>(initialData?.customerId || '');
    const [issueDate, setIssueDate] = useState<string>(initialData?.issueDate || new Date().toISOString().slice(0, 10));
    const [subjectTh, setSubjectTh] = useState(initialData?.subjectTh || '');

    // Data State - Level 2 (Items)
    const [items, setItems] = useState<DocumentItem[]>(initialData?.items || [DEFAULT_ITEM]);

    // Data State - Level 3 (Calculated/Review)
    const [status, setStatus] = useState(initialData?.status || 'DRAFT');
    const [discount, setDiscount] = useState(initialData?.money?.discount_amount || 0);
    const [extraFee, setExtraFee] = useState(initialData?.money?.extra_fee_amount || 0);
    const [vatEnabled, setVatEnabled] = useState(initialData?.taxSnapshot?.vatEnabled ?? true);
    const [vatRate, setVatRate] = useState(initialData?.taxSnapshot?.vatRate ?? 7);
    const [whtEnabled, setWhtEnabled] = useState(initialData?.taxSnapshot?.whtEnabled ?? false);
    const [whtRate, setWhtRate] = useState(initialData?.taxSnapshot?.whtRate ?? 3);

    // Derived Client-Side Totals (For Display Only - Server is Truth)
    const subtotal = useMemo(() => items.reduce((sum, item) => sum + (Number(item.qty) * Number(item.unit_price)), 0), [items]);
    const afterDiscount = subtotal - discount + extraFee;
    const vatAmount = vatEnabled ? afterDiscount * (vatRate / 100) : 0;
    const totalAmount = afterDiscount + vatAmount;
    const whtAmount = whtEnabled ? afterDiscount * (whtRate / 100) : 0;
    const netReceive = totalAmount - whtAmount;

    // Load Customers
    useEffect(() => {
        customersRepo.listCustomers().then(res => setCustomers(res.customers));
    }, []);

    // -------------------------------------------------------------------------
    // Auto-Save Engine
    // -------------------------------------------------------------------------

    // Construct payload strictly
    const currentData = useMemo(() => ({
        docType,
        customerId,
        issueDate,
        subjectTh,
        items,
        discount_amount: discount,
        extra_fee_amount: extraFee,
        taxSnapshot: {
            vatEnabled,
            vatRate,
            whtEnabled,
            whtRate,
            whtBase: 'BEFORE_VAT' as const,
        },
        revision, // Include Revision for Optimistic Locking
    }), [docType, customerId, issueDate, subjectTh, items, discount, extraFee, vatEnabled, vatRate, whtEnabled, whtRate, revision]);

    // Handle Server Sync
    const handleServerSync = useCallback((serverDoc: Document) => {
        // Sync Revision (Critical)
        if (serverDoc.revision) setRevision(serverDoc.revision);

        // Sync Calculated Fields (Source of Truth)
        if (serverDoc.items) setItems(serverDoc.items);
        if (serverDoc.money) {
            setDiscount(serverDoc.money.discount_amount);
            setExtraFee(serverDoc.money.extra_fee_amount);
            // Note: We don't sync subtotal etc directly as they are derived, 
            // but syncing items+discounts ensures local calc matches server calc.
        }
    }, []);

    const { saving, lastSaved, error, isDirty, saveNow } = useDocumentAutoSave({
        docId: docIds,
        data: currentData,
        enabled: !isNew && status === 'DRAFT',
        onSaveSuccess: handleServerSync,
        onSaveError: (err) => {
            console.error('Auto-save error:', err);
            // If conflict (409), we might need to reload. 
            // Ideally we prompt user, but for now we just log.
        }
    });

    // -------------------------------------------------------------------------
    // Wizard Logic
    // -------------------------------------------------------------------------

    const handleNext = async () => {
        // Validation Step 1
        if (currentStep === 1) {
            if (!customerId) return alert('Please select a customer');
            if (!subjectTh) return alert('Please enter a subject');

            if (isNew) {
                setLoading(true);
                try {
                    // Create Draft Immediately
                    const res = await documentsRepo.createDocument(currentData);
                    setDocId(res.id);
                    setIsNew(false);
                    setRevision(res.revision); // Init Version
                    // Persist ID in URL
                    window.history.replaceState(null, '', `/dashboard/documents/editor?id=${res.id}`);
                    setCurrentStep(2);
                } catch (err) {
                    console.error(err);
                    alert('Failed to initialize document.');
                } finally {
                    setLoading(false);
                }
            } else {
                // Moving 1 -> 2
                if (isDirty) await saveNow();
                setCurrentStep(2);
            }
        }
        // Validation Step 2 -> 3
        else if (currentStep === 2) {
            // MUST Save & Recalc before Review
            setLoading(true); // Show momentary loading
            try {
                const updatedDoc = await saveNow();
                if (updatedDoc) {
                    // Sync done in hook, but we double checking existence
                    setCurrentStep(3);
                } else if (!isDirty) {
                    // Clean, just move
                    setCurrentStep(3);
                } else {
                    // Error saving
                    alert('Could not save changes. Please try again.');
                }
            } finally {
                setLoading(false);
            }
        }
    };

    const handleBack = () => {
        setCurrentStep(prev => Math.max(1, prev - 1));
    };

    // -------------------------------------------------------------------------
    // Actions
    // -------------------------------------------------------------------------

    const handleGeneratePdf = async () => {
        if (!docIds) return;
        if (confirm('Lock items and Generate PDF?')) {
            setLoading(true);
            try {
                if (isDirty) await saveNow();
                await documentsRepo.generatePdf(docIds);
                alert('PDF Queued!');
                router.refresh();
            } catch (e) { console.error(e); alert('Error generating PDF'); }
            finally { setLoading(false); }
        }
    };

    const handleConfirm = async () => {
        if (!docIds) return;
        if (!confirm('Confirm and Issue? This cannot be undone.')) return;
        setLoading(true);
        try {
            await documentsRepo.confirmDocument(docIds);
            alert('Document Issued Successfully');
            router.refresh();
        } catch (e: any) { console.error(e); alert('Error: ' + e.message); }
        finally { setLoading(false); }
    };

    const isReadOnly = status !== 'DRAFT' && !isNew;

    // -------------------------------------------------------------------------
    // Render
    // -------------------------------------------------------------------------
    return (
        <div className="max-w-5xl mx-auto pb-32">
            {/* Header & Status Bar */}
            <div className="flex items-center justify-between mb-8 pt-6">
                <div className="flex items-center gap-4">
                    <Link href="/dashboard/documents" className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                        <ArrowLeft className="w-5 h-5" />
                    </Link>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                            {docType} {status !== 'DRAFT' ? initialData?.docNo : <span className="text-gray-400 font-normal">New Draft</span>}
                        </h1>
                        <div className="flex items-center gap-3 text-sm mt-1 h-5">
                            {/* Auto-save Indicator */}
                            {!isNew && status === 'DRAFT' && (
                                <>
                                    {saving ? (
                                        <span className="flex items-center gap-1 text-gray-500">
                                            <Loader2 className="w-3 h-3 animate-spin" /> Saving...
                                        </span>
                                    ) : error ? (
                                        <span className="flex items-center gap-1 text-red-600 font-medium">
                                            <AlertCircle className="w-3 h-3" /> Save Failed
                                        </span>
                                    ) : lastSaved ? (
                                        <span className="flex items-center gap-1 text-green-600">
                                            <CheckCircle2 className="w-3 h-3" /> Saved
                                        </span>
                                    ) : (
                                        <span className="text-gray-400">All changes saved</span>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>

                {/* Step Indicator */}
                <div className="hidden md:flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
                    {STEPS.map((s, idx) => (
                        <div key={s.id} className="flex items-center">
                            <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${currentStep === s.id ? 'bg-indigo-600 text-white' :
                                currentStep > s.id ? 'bg-green-500 text-white' : 'bg-gray-300 text-white'
                                }`}>
                                {currentStep > s.id ? '✓' : s.id}
                            </div>
                            <span className={`ml-2 text-sm ${currentStep === s.id ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                                {s.name}
                            </span>
                            {idx < STEPS.length - 1 && <div className="w-8 h-px bg-gray-300 mx-3" />}
                        </div>
                    ))}
                </div>
            </div>

            {/* Content */}
            <div className="bg-white min-h-[400px]">
                {currentStep === 1 && (
                    <StepClient
                        docType={docType} setDocType={setDocType}
                        customerId={customerId} setCustomerId={setCustomerId}
                        issueDate={issueDate} setIssueDate={setIssueDate}
                        subjectTh={subjectTh} setSubjectTh={setSubjectTh}
                        customers={customers} isReadOnly={isReadOnly} isNew={isNew}
                    />
                )}
                {currentStep === 2 && (
                    <StepItems items={items} setItems={setItems} isReadOnly={isReadOnly} />
                )}
                {currentStep === 3 && (
                    <StepReview
                        subtotal={subtotal} totalAmount={totalAmount} netReceive={netReceive}
                        vatAmount={vatAmount} whtAmount={whtAmount}
                        discount={discount} setDiscount={setDiscount}
                        extraFee={extraFee} setExtraFee={setExtraFee}
                        vatEnabled={vatEnabled} setVatEnabled={setVatEnabled} vatRate={vatRate} setVatRate={setVatRate}
                        whtEnabled={whtEnabled} setWhtEnabled={setWhtEnabled} whtRate={whtRate} setWhtRate={setWhtRate}
                        isReadOnly={isReadOnly}
                    />
                )}
            </div>

            {/* Footer Controls */}
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 z-20 shadow-lg">
                <div className="max-w-5xl mx-auto flex justify-between items-center">
                    <div>
                        {currentStep > 1 && (
                            <button onClick={handleBack} className="px-5 py-2 border rounded-md hover:bg-gray-50 text-gray-700 font-medium">
                                Back
                            </button>
                        )}
                    </div>
                    <div className="flex gap-3">
                        {currentStep < 3 ? (
                            <button
                                onClick={handleNext}
                                disabled={loading}
                                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md font-medium flex items-center gap-2"
                            >
                                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                                Next Step <ArrowRight className="w-4 h-4" />
                            </button>
                        ) : (
                            // Final Actions
                            <>
                                {status === 'DRAFT' && (
                                    <button
                                        onClick={handleGeneratePdf}
                                        disabled={loading || saving}
                                        className="px-6 py-2 bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-50 rounded-md font-medium flex items-center gap-2"
                                    >
                                        <Printer className="w-4 h-4" /> Generate PDF
                                    </button>
                                )}
                                <button
                                    onClick={handleConfirm}
                                    disabled={loading || status !== 'DRAFT'} // Confirm only if ready? No, Confirm endpoint handles it. Logic usually READY -> CONFIRM.
                                    className={`px-6 py-2 rounded-md font-medium flex items-center gap-2 text-white ${status === 'ISSUED' ? 'bg-gray-400' : 'bg-green-600 hover:bg-green-700'}`}
                                >
                                    <Send className="w-4 h-4" /> {status === 'ISSUED' ? 'Issued' : 'Confirm & Issue'}
                                </button>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
