import { useState, useEffect, useRef, useCallback } from 'react';
import { documentsRepo, EzDocument } from '@/lib/repos/documents.repo';

interface UseDocumentAutoSaveProps {
    docId?: string;
    data: Partial<EzDocument>;
    enabled?: boolean;
    onSaveSuccess?: (updatedDoc: EzDocument) => void;
    onSaveError?: (error: any) => void;
}

export function useDocumentAutoSave({
    docId,
    data,
    enabled = true,
    onSaveSuccess,
    onSaveError
}: UseDocumentAutoSaveProps) {
    const [saving, setSaving] = useState(false);
    const [lastSaved, setLastSaved] = useState<Date | null>(null);
    const [error, setError] = useState<any>(null);
    const [isDirty, setIsDirty] = useState(false);

    const dataRef = useRef(data);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);
    const savedDocRef = useRef<EzDocument | null>(null);

    // Keep dataRef current
    useEffect(() => {
        dataRef.current = data;
        if (enabled && docId) {
            setIsDirty(true);
        }
    }, [data, enabled, docId]);

    const save = useCallback(async () => {
        // Guard: No ID or disabled
        if (!docId || !enabled) return null;

        setSaving(true);
        setError(null);

        try {
            // Optimistic Lock: The data payload should ideally include 'revision' from the consumer
            const updatedDoc = await documentsRepo.updateDocument(docId, dataRef.current);

            setLastSaved(new Date());
            setIsDirty(false);
            savedDocRef.current = updatedDoc;

            if (onSaveSuccess) onSaveSuccess(updatedDoc);
            return updatedDoc;
        } catch (err) {
            console.error('[AutoSave] Failed:', err);
            setError(err);
            if (onSaveError) onSaveError(err);
            return null;
        } finally {
            setSaving(false);
        }
    }, [docId, enabled, onSaveSuccess, onSaveError]);

    // Debounce Logic
    useEffect(() => {
        if (!isDirty || !enabled || !docId) return;

        if (timeoutRef.current) clearTimeout(timeoutRef.current);

        timeoutRef.current = setTimeout(() => {
            save();
        }, 2000); // 2000ms debounce as requested

        return () => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
        };
    }, [isDirty, enabled, docId, save]);

    // Manual Save (Immediate)
    const saveNow = useCallback(async () => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        return await save();
    }, [save]);

    return {
        saving,
        lastSaved,
        error,
        isDirty,
        saveNow
    };
}
