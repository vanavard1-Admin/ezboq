import * as functions from "firebase-functions/v1";
import * as admin from "firebase-admin";

// Initialize Firebase Admin SDK if not already initialized
if (!admin.apps.length) {
  admin.initializeApp();
}

import crypto from "crypto";
import {
  decideFirstMessageOrFallback,
} from "./core/lineFirstMessage";
import { handleConversationMessage } from "./core/conversationHandler";
import { getLineLink } from "./core/lineLinkService";
import { LINE_API } from "./shared/config";
import {
  generateTraceId,
  logWithTrace,
  withAsyncSafety,
  FALLBACK_MESSAGES,
  type TraceContext,
  extractEventId,
  acquireEventLock,
} from "./utils/asyncSafety";

// ============================================================================
// HELPER FUNCTIONS: Smart ACK Router, Unified Transport, Anti-Loop Guard
// ============================================================================

/**
 * LINE Message type for unified transport helper
 */
type LineMessage = {
  type: "text";
  text: string;
  quickReply?: { items: unknown[] };
} | {
  type: "template";
  altText: string;
  template: unknown;
};

/**
 * Smart ACK Router: Context-aware acknowledgment messages with cooldown
 * Returns appropriate ACK message based on intent and context
 */
async function getSmartAckMessage(
  messageText: string,
  intent: string,
  lineUserId: string,
  db: admin.firestore.Firestore
): Promise<string | null> {
  // Cooldown: 2-3 seconds per user to prevent ACK spam
  const ACK_COOLDOWN_MS = 2500;
  const cooldownKey = `ack_cooldown_${lineUserId}`;
  
  try {
    const cooldownRef = db.collection("_temp_ack_cooldown").doc(cooldownKey);
    const cooldownDoc = await cooldownRef.get();
    
    if (cooldownDoc.exists) {
      const lastAckAt = cooldownDoc.get("lastAckAt")?.toMillis() || 0;
      const elapsed = Date.now() - lastAckAt;
      
      if (elapsed < ACK_COOLDOWN_MS) {
        // Still in cooldown - return progress message instead
        return "กำลังประมวลผล...";
      }
    }
    
    // Update cooldown (fire-and-forget)
    cooldownRef.set({
      lastAckAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 60000), // 1 min TTL
    }).catch(() => { /* Non-blocking */ });
  } catch (err) {
    // Fail-open: proceed with ACK even if cooldown check fails
    console.warn("[ACK_COOLDOWN_FAILED]", err);
  }

  // Intent-based ACK messages (premium, human-first Thai)
  const { Intent } = await import("./core/conversationOrchestrator");
  
  // Document creation intents
  if (intent === Intent.CREATE_QUOTATION) {
    return "รับคำสั่งสร้างใบเสนอราคาแล้ว กำลังเตรียมข้อมูล";
  }
  if (intent === Intent.CREATE_INVOICE || intent === Intent.CREATE_INV_FROM_QUO) {
    return "รับคำสั่งสร้างใบวางบิลแล้ว กำลังดำเนินการ";
  }
  if (intent === Intent.CREATE_RECEIPT || intent === Intent.CREATE_REC_FROM_INV) {
    return "รับคำสั่งสร้างใบเสร็จแล้ว กำลังประมวลผล";
  }
  
  // Purchase intents
  if (intent === Intent.BUY_PACKAGE_99 || intent === Intent.BUY_PACKAGE_299) {
    return "กำลังเตรียม QR Code สำหรับชำระเงิน";
  }
  
  // Slip/OCR related
  if (messageText.match(/สลิป|slip|ชำระเงิน/i)) {
    return "รับข้อมูลแล้ว กำลังตรวจสอบการชำระเงิน";
  }
  
  // Help/General
  if (intent === Intent.HELP || intent === Intent.USAGE_GUIDE) {
    return "กำลังเตรียมข้อมูลช่วยเหลือ";
  }
  
  // Report
  if (intent === Intent.REPORT) {
    return "กำลังสร้างรายงาน";
  }
  
  // Settings
  if (intent === Intent.SETTINGS) {
    return "กำลังโหลดการตั้งค่า";
  }
  
  // Default: Generic but professional
  return "รับข้อความแล้ว กำลังประมวลผล";
}

/**
 * Unified LINE Transport Helper: sendReplyOrPush
 * Uses REPLY API when replyToken exists (with 25s timeout), falls back to PUSH
 * Centralizes error handling, logging, and status codes
 */
async function sendReplyOrPush(params: {
  replyToken?: string;
  to: string;
  messages: LineMessage[];
  accessToken: string;
  traceContext: TraceContext;
}): Promise<{ success: boolean; method: "reply" | "push"; latencyMs: number }> {
  const { replyToken, to, messages, accessToken, traceContext } = params;
  const startTime = Date.now();
  
  // Prefer REPLY API if replyToken exists (within 30s timeout window)
  if (replyToken) {
    try {
      const replyResponse = await Promise.race([
        fetch(LINE_API.REPLY, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            replyToken,
            messages,
          }),
        }),
        new Promise<Response>((_, reject) =>
          setTimeout(() => reject(new Error("replyToken timeout (25s limit)")), 25000)
        ),
      ]);
      
      const latencyMs = Date.now() - startTime;
      
      if (replyResponse.ok) {
        logWithTrace(
          "[LINE_TRANSPORT_OK]",
          { ...traceContext, stage: "ack_sent" },
          `Message sent via REPLY API (${latencyMs}ms)`,
          { method: "reply", messageCount: messages.length }
        );
        return { success: true, method: "reply", latencyMs };
      }
      
      // Reply API failed - fall through to PUSH
      const errorText = await replyResponse.text();
      logWithTrace(
        "[LINE_TRANSPORT_REPLY_FAILED]",
        { ...traceContext, stage: "ack_failed" },
        `REPLY API failed: ${replyResponse.status}`,
        { statusText: replyResponse.statusText, body: errorText.substring(0, 200) }
      );
    } catch (replyErr) {
      // Reply timeout or error - fall through to PUSH
      const latencyMs = Date.now() - startTime;
      logWithTrace(
        "[LINE_TRANSPORT_REPLY_ERROR]",
        { ...traceContext, stage: "ack_error" },
        `REPLY API error: ${replyErr instanceof Error ? replyErr.message : String(replyErr)}`,
        { latencyMs }
      );
    }
  }
  
  // Fallback to PUSH API (no timeout limit)
  try {
    const pushStartTime = Date.now();
    const pushResponse = await fetch(LINE_API.PUSH, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        to,
        messages,
      }),
    });
    
    const latencyMs = Date.now() - pushStartTime;
    
    if (!pushResponse.ok) {
      const errorText = await pushResponse.text();
      logWithTrace(
        "[LINE_TRANSPORT_PUSH_FAILED]",
        { ...traceContext, stage: "ack_failed" },
        `PUSH API failed: ${pushResponse.status}`,
        { statusText: pushResponse.statusText, body: errorText.substring(0, 200) }
      );
      return { success: false, method: "push", latencyMs };
    }
    
    logWithTrace(
      "[LINE_TRANSPORT_OK]",
      { ...traceContext, stage: "ack_sent" },
      `Message sent via PUSH API (${latencyMs}ms)`,
      { method: "push", messageCount: messages.length }
    );
    return { success: true, method: "push", latencyMs };
  } catch (pushErr) {
    const latencyMs = Date.now() - startTime;
    logWithTrace(
      "[LINE_TRANSPORT_PUSH_ERROR]",
      { ...traceContext, stage: "ack_error" },
      `PUSH API error: ${pushErr instanceof Error ? pushErr.message : String(pushErr)}`,
      { latencyMs }
    );
    return { success: false, method: "push", latencyMs };
  }
}

/**
 * Anti-Loop Session Guard: Prevent sending identical messages repeatedly
 * Tracks lastBotMessageHash + lastBotAt per lineUserId
 * Returns true if message should be sent, false if it's a duplicate (should use progress instead)
 * 
 * NOTE: Prepared for integration into processMessageAsync to prevent loops like
 * "ยังไม่มีเอกสาร...พิมพ์ทำใบเสนอราคา" - can be integrated when needed
 * Exported for potential future use in other modules
 */
export async function shouldSendMessage(
  lineUserId: string,
  messageText: string,
  db: admin.firestore.Firestore
): Promise<boolean> {
  const SESSION_WINDOW_MS = 30000; // 30 seconds
  const guardKey = `bot_msg_guard_${lineUserId}`;
  
  try {
    // Create hash of message text (simple but effective)
    const crypto = await import("crypto");
    const messageHash = crypto.createHash("sha256").update(messageText).digest("hex").substring(0, 16);
    
    const guardRef = db.collection("_temp_bot_msg_guard").doc(guardKey);
    const guardDoc = await guardRef.get();
    
    if (guardDoc.exists) {
      const lastHash = guardDoc.get("lastHash") as string | undefined;
      const lastBotAt = guardDoc.get("lastBotAt")?.toMillis() || 0;
      const elapsed = Date.now() - lastBotAt;
      
      // Same message within session window = duplicate (loop detected)
      if (lastHash === messageHash && elapsed < SESSION_WINDOW_MS) {
        return false; // Don't send - it's a loop
      }
    }
    
    // Update guard (fire-and-forget)
    guardRef.set({
      lastHash: messageHash,
      lastBotAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 120000), // 2 min TTL
    }).catch(() => { /* Non-blocking */ });
    
    return true; // OK to send
  } catch (err) {
    // Fail-open: allow message if guard check fails
    console.warn("[ANTI_LOOP_GUARD_FAILED]", err);
    return true;
  }
}

function verifyLineSignature(
  rawBody: Buffer,
  channelSecret: string,
  signature?: string
): boolean {
  if (!signature) return false;

  const hmac = crypto.createHmac("sha256", channelSecret);
  hmac.update(rawBody);

  const expected = hmac.digest(); // Buffer
  const received = Buffer.from(signature, "base64");

  if (expected.length !== received.length) return false;
  return crypto.timingSafeEqual(expected, received);
}

function getRawBody(req: functions.https.Request): Buffer | null {
  // runtime มี rawBody แต่ typings อาจไม่ declare → ใช้ unknown แบบปลอดภัย (ไม่ใช้ any)
  const candidate = (req as unknown as { rawBody?: unknown }).rawBody;
  return Buffer.isBuffer(candidate) ? candidate : null;
}

export const lineWebhookV1 = functions
  .region("asia-southeast1")
  .runWith({ secrets: ["LINE_CHANNEL_SECRET", "LINE_CHANNEL_ACCESS_TOKEN", "WEB_URL", "LINE_LINK_STATE_SECRET"] })
  .https.onRequest(async (req: functions.https.Request, res: functions.Response) => {
    const t0 = Date.now(); // Start timing

    // Support GET for connectivity check
    if (req.method === "GET") {
      res.status(200).send("OK");
      return;
    }

    if (req.method !== "POST") {
      res.status(405).send("Method Not Allowed");
      return;
    }

    const secret = process.env.LINE_CHANNEL_SECRET?.trim();
    if (!secret) {
      console.error("LINE_CHANNEL_SECRET missing in runtime env");
      res.status(500).send("Server misconfigured");
      return;
    }

    const raw = getRawBody(req);
    const sig = req.header("x-line-signature") || "";

    if (!raw) {
      console.warn("rawBody missing (cannot verify LINE signature)");
      res.status(400).send("Bad Request");
      return;
    }

    if (!verifyLineSignature(raw, secret, sig)) {
      console.warn("LINE signature invalid");
      res.status(401).send("Unauthorized");
      return;
    }

    // Parse and process webhook events
    const body = req.body || {};
    const events = body.events || [];

    console.log("[lineWebhookV1] Received", events.length, "events");

    // ✅ CRITICAL: Validate required secrets at startup (fail fast)
    const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN?.trim();
    if (!accessToken) {
      console.error("[CRITICAL] LINE_CHANNEL_ACCESS_TOKEN missing in runtime env");
      res.status(500).json({ error: "Server misconfigured: missing LINE_CHANNEL_ACCESS_TOKEN" });
      return;
    }

    // Create LINE client (Pushed-based)
    const lineClient = {
      // ✅ PUSH only (standard)
      pushMessage: async (params: {
        to: string;
        messages: Array<{
          type: string;
          text?: string;
          quickReply?: { items: unknown[] };
        }>;
      }) => {
        const body = JSON.stringify(params);
        console.log(`[lineClient] Sending PUSH to LINE API:`, body.substring(0, 300));
        const response = await fetch(LINE_API.PUSH, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body,
        });
        if (!response.ok) {
          const errorText = await response.text();
          console.error(`[lineClient] LINE API Status: ${response.status}`);
          console.error(`[lineClient] Response Body:`, errorText);
          throw new Error(`LINE API error: ${response.status} ${response.statusText}`);
        }
      },

      // ❌ KEEP OPTIONAL but DO NOT USE
      replyMessage: async (_params: any) => {
        throw new Error("replyMessage is disabled; use pushMessage instead.");
      },
    };

    const db = admin.firestore();

    // Process message events
    for (const event of events) {
      const userId = event.source?.userId;
      const eventType = event.type;

      if (userId) {
        console.log(
          `[lineWebhookV1] 🆔 userId detected: ${userId} (event: ${eventType})`
        );
      }

      // Handle FOLLOW event (user adds friend)
      if (event.type === "follow") {
        const lineUserId = event.source?.userId;
        if (lineUserId) {
          const traceId = generateTraceId();
          const eventId = extractEventId(event);
          const context: TraceContext = {
            traceId,
            eventId,
            lineUserId,
            eventType: "follow_event",
            stage: "webhook_received",
          };
          
          const webhookReceivedMs = Date.now() - t0;
          logWithTrace(
            "[WEBHOOK_RECEIVED]",
            context,
            `Follow event received`,
            { latency_ms: webhookReceivedMs }
          );
          
          // Apply idempotency lock (prevent duplicate welcome messages)
          if (eventId) {
            const lockAcquired = await acquireEventLock(eventId, { ...context, stage: "lock_acquire" });
            if (!lockAcquired) {
              logWithTrace(
                "[EVENT_DUPLICATE]",
                { ...context, stage: "lock_acquired" },
                "Follow event already processed, skipping",
                { latency_ms: Date.now() - t0 }
              );
              continue;
            }
            logWithTrace(
              "[LOCK_ACQUIRED]",
              { ...context, stage: "lock_acquired" },
              "Follow event lock acquired",
              { latency_ms: Date.now() - t0 }
            );
          }
          
          // Send proactive welcome message with buttons
          const { getWelcomeMessage, getWelcomeQuickReply } = await import("./services/uxCopy");
          const welcomeMessage = getWelcomeMessage();
          const quickReply = getWelcomeQuickReply();
          
          const ackResult = await sendReplyOrPush({
            replyToken: event.replyToken,
            to: lineUserId,
            messages: [{
              type: "text",
              text: welcomeMessage,
              quickReply: {
                items: quickReply,
              },
            }],
            accessToken,
            traceContext: { ...context, stage: "ack_sent" },
          });
          
          logWithTrace(
            "[FOLLOW_WELCOME_SENT]",
            { ...context, stage: "processing_done" },
            `Welcome message sent via ${ackResult.method}`,
            { 
              ack_latency_ms: ackResult.latencyMs,
              method: ackResult.method,
              success: ackResult.success,
            }
          );
        }
        continue;
      }

      // Handle TEXT message event
      if (event.type === "message" && event.message?.type === "text") {
        const lineUserId = event.source?.userId;
        const messageText = event.message.text;
        const replyToken = event.replyToken;

        // Generate trace ID for correlation (unique per processing attempt)
        const traceId = generateTraceId();
        
        // Extract eventId for idempotency (LINE's stable identifier)
        const eventId = extractEventId(event);
        
        const context: TraceContext = {
          traceId,
          eventId,
          lineUserId,
          eventType: "text_message",
          stage: "webhook_received",
        };

        // Sanitize messageText before logging (prevent PII leakage)
        const { sanitizeForLogging } = await import("./utils/logSanitization");
        const sanitizedMessage = sanitizeForLogging(messageText);
        const webhookReceivedMs = Date.now() - t0;
        logWithTrace(
          "[WEBHOOK_RECEIVED]",
          context,
          `Message: "${sanitizedMessage}"`,
          { latency_ms: webhookReceivedMs }
        );

        // Step 1: Check idempotency EARLY (before any side effects)
        if (eventId) {
          const lockAcquired = await acquireEventLock(eventId, { ...context, stage: "lock_acquire" });
          if (!lockAcquired) {
            logWithTrace(
              "[EVENT_DUPLICATE]",
              { ...context, stage: "lock_acquired" },
              "Event already processed, skipping",
              { latency_ms: Date.now() - t0 }
            );
            continue; // Skip this event - already processed
          }
          logWithTrace(
            "[LOCK_ACQUIRED]",
            { ...context, stage: "lock_acquired" },
            "Event lock acquired",
            { latency_ms: Date.now() - t0 }
          );
        }

        // Step 2: Send Smart ACK (context-aware, with cooldown)
        try {
          if (lineUserId) {
            const { getButtonAction } = await import("./core/buttonActionMap");
            const { recognizeIntent, Intent } = await import("./core/conversationOrchestrator");
            const buttonAction = getButtonAction(messageText);
            const intent = recognizeIntent(messageText);
            
            // Only send ACK if NOT a button action AND NOT LINK_ACCOUNT
            // Button actions and LINK_ACCOUNT get immediate meaningful response
            if (!buttonAction && intent !== Intent.LINK_ACCOUNT) {
              const ackMessage = await getSmartAckMessage(messageText, intent, lineUserId, db);
              
              if (ackMessage) {
                const ackResult = await sendReplyOrPush({
                  replyToken,
                  to: lineUserId,
                  messages: [{ type: "text", text: ackMessage }],
                  accessToken,
                  traceContext: { ...context, stage: "ack_sent" },
                });
                
                logWithTrace(
                  "[ACK_SENT]",
                  { ...context, stage: "ack_sent" },
                  `Smart ACK sent via ${ackResult.method}`,
                  { 
                    ack_latency_ms: ackResult.latencyMs,
                    method: ackResult.method,
                    success: ackResult.success,
                  }
                );
              }
            }
          }

          // Step 3: Process asynchronously with full safety wrapper
          const asyncStartMs = Date.now() - t0;
          logWithTrace(
            "[ASYNC_DISPATCH]",
            { ...context, stage: "async_dispatch" },
            `Dispatching async processing`,
            { async_dispatch_ms: asyncStartMs }
          );

          // Process async with idempotency already checked
          withAsyncSafety(
            { ...context, stage: "async_processing" },
            accessToken,
            () => processMessageAsync(lineUserId, messageText, lineClient as any, db, accessToken, context),
            { fallbackMessage: FALLBACK_MESSAGES.GENERIC, skipIdempotencyCheck: true }
          ).catch((err) => {
            // This should never happen (withAsyncSafety catches everything)
            // But just in case, log it
            logWithTrace(
              "[ASYNC_WRAPPER_LEAKED]",
              { ...context, stage: "catastrophic" },
              "Error leaked from async safety wrapper (should never happen)",
              { error: err instanceof Error ? err.message : String(err) }
            );
          });

        } catch (error) {
          logWithTrace(
            "[ACK_FAILED]",
            { ...context, stage: "ack_error" },
            "Failed to send ACK",
            { error: error instanceof Error ? error.message : String(error) }
          );

          // Fallback: Try simple push
          const { safePushMessage } = await import("./utils/asyncSafety");
          await safePushMessage(
            lineUserId,
            `ระบบขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้ง\n\nรหัสอ้างอิง: ${traceId}`,
            accessToken,
            context
          );
        }
      }

      // Handle IMAGE message event (payment slip OR logo/signature/stamp upload)
      // Support all LINE image message types: 'image', 'file', 'imageSet'
      const isImageMessage = event.type === "message" && 
        (event.message?.type === "image" || 
         event.message?.type === "file" || 
         event.message?.type === "imageSet");
      
      if (isImageMessage) {
        const lineUserId = event.source?.userId;
        const messageId = event.message.id;
        const messageType = event.message?.type || 'unknown';
        const replyToken = event.replyToken;

        // Generate trace ID for correlation (unique per processing attempt)
        const traceId = generateTraceId();
        
        // Extract eventId for idempotency (LINE's stable identifier)
        const eventId = extractEventId(event);
        
        const context: TraceContext = {
          traceId,
          eventId,
          lineUserId,
          eventType: "image_message",
          stage: "webhook_received",
        };

        const webhookReceivedMs = Date.now() - t0;
        logWithTrace(
          "[WEBHOOK_RECEIVED]",
          context,
          `Image messageId: ${messageId}, messageType: ${messageType}, hasReplyToken=${!!replyToken}`,
          { latency_ms: webhookReceivedMs }
        );

        // Step 1: Check idempotency EARLY (before any side effects like storePendingImage, setUserImageMode, enqueue OCR)
        if (eventId) {
          const lockAcquired = await acquireEventLock(eventId, { ...context, stage: "lock_acquire" });
          if (!lockAcquired) {
            logWithTrace(
              "[EVENT_DUPLICATE]",
              { ...context, stage: "lock_acquired" },
              "Image event already processed, skipping",
              { latency_ms: Date.now() - t0 }
            );
            continue; // Skip - already processed
          }
          logWithTrace(
            "[LOCK_ACQUIRED]",
            { ...context, stage: "lock_acquired" },
            "Image event lock acquired",
            { latency_ms: Date.now() - t0 }
          );
        }

        if (lineUserId) {
          try {
            const { 
              storePendingImage,
            } = await import("./services/imageUploadService");
            
            // Get Firebase UID from line_links
            const lineLink = await getLineLink(lineUserId);
            
            // Validate lineLink status and uid (must be ACTIVE and have uid)
            if (!lineLink || lineLink.status !== 'ACTIVE' || !lineLink.uid || lineLink.uid.trim() === '') {
              // User not linked or link is invalid - send linking prompt
              const LIFF_ID = "2008406529-t10C3ftD";
              const linkUrl = `https://liff.line.me/${LIFF_ID}`;
              
              const ackResult = await sendReplyOrPush({
                replyToken,
                to: lineUserId,
                messages: [{
                  type: "template",
                  altText: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน",
                  template: {
                    type: "buttons",
                    text: "🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nคลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบ",
                    actions: [{
                      type: "uri",
                      label: "🔗 เชื่อมต่อบัญชี",
                      uri: linkUrl,
                    }],
                  },
                }],
                accessToken,
                traceContext: { ...context, stage: "ack_sent" },
              });
              
              logWithTrace(
                "[IMAGE_LINK_PROMPT_SENT]",
                { ...context, stage: "processing_done" },
                `Link prompt sent via ${ackResult.method}`,
                { ack_latency_ms: ackResult.latencyMs, method: ackResult.method }
              );
              continue; // Stop processing - user needs to link first
            }
            
            const firebaseUid = lineLink.uid;
            
            if (firebaseUid) {
              const { getUserImageMode, setUserImageMode } = await import("./services/userStateService");
              const { hasRecentPendingPurchase } = await import("./services/purchaseService");
              
              // ✅ OPTIMIZATION: Parallelize Firestore queries to reduce latency
              // Get current image mode and recent purchase in parallel
              const [imageMode, recentPurchase] = await Promise.all([
                getUserImageMode(firebaseUid),
                hasRecentPendingPurchase(firebaseUid, 15),
              ]);
              
              // PRIORITY: If user has explicit image_mode (LOGO/SIGNATURE/STAMP), process immediately
              // User intent overrides SLIP heuristic
              if (imageMode === 'LOGO' || imageMode === 'SIGNATURE' || imageMode === 'STAMP') {
                // lineLink already fetched above, reuse it
                if (!lineLink) {
                  await sendReplyOrPush({
                    replyToken,
                    to: lineUserId,
                    messages: [{ type: "text", text: "❌ กรุณาเชื่อมต่อบัญชี LINE กับระบบก่อน" }],
                    accessToken,
                    traceContext: { ...context, stage: "ack_sent" },
                  });
                  continue;
                }
                
                const businessId = lineLink.businessId || 'default';
                const { processImageWithMode } = await import("./services/imageUploadService");
                const thaiName = imageMode === 'LOGO' ? 'โลโก้' : imageMode === 'SIGNATURE' ? 'ลายเซ็น' : 'ตราประทับ';
                
                const logoAckResult = await sendReplyOrPush({
                  replyToken,
                  to: lineUserId,
                  messages: [{ type: "text", text: `📸 รับรูปแล้ว กำลังตั้งค่า${thaiName}บริษัท` }],
                  accessToken,
                  traceContext: { ...context, stage: "ack_sent" },
                });
                
                logWithTrace(
                  "[IMAGE_LOGO_ACK_SENT]",
                  { ...context, stage: "ack_sent" },
                  `Logo/signature/stamp ACK sent via ${logoAckResult.method}`,
                  { ack_latency_ms: logoAckResult.latencyMs, method: logoAckResult.method }
                );
                
                withAsyncSafety(
                  { ...context, stage: "async_image_upload" },
                  accessToken,
                  async () => {
                    await processImageWithMode(firebaseUid, businessId, imageMode.toLowerCase() as 'logo' | 'signature' | 'stamp', messageId, accessToken);
                    await setUserImageMode(firebaseUid, null);
                  },
                  { fallbackMessage: (traceId: string) => `❌ เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ\n\n📋 รหัสอ้างอิง: ${traceId}` }
                );
                
                continue;
              }
              
              // If recent purchase exists but no explicit image_mode, store as pending
              // NEVER process slip on image receive - only store and set hint
              // Wait for user intent (text command) before processing as slip
              // This allows user to type "โลโก้" to override SLIP detection
              if (recentPurchase) {
                // ✅ FIX 1: Deterministic slip mode - force SLIP mode if recent purchase pending (<= 15 min)
                await setUserImageMode(firebaseUid, 'SLIP');
                logWithTrace("[IMAGE_MODE=SLIP]", context, `Forced SLIP mode: purchaseId=${recentPurchase.purchaseId}`);
                
                // Store image as pending
                storePendingImage(firebaseUid, messageId);
                logWithTrace("[IMAGE_RECEIVED]", context, `Image stored as pending: messageId=${messageId}, purchaseId=${recentPurchase.purchaseId}`);
                
                // Send immediate ACK (via sendReplyOrPush with timeout guard)
                const { getSlipReceivedMessage } = await import("./services/paymentUXCopy");
                const ackResult = await sendReplyOrPush({
                  replyToken,
                  to: lineUserId,
                  messages: [{ type: "text", text: getSlipReceivedMessage() }],
                  accessToken,
                  traceContext: { ...context, stage: "ack_sent" },
                });
                
                logWithTrace(
                  "[IMAGE_SLIP_ACK_SENT]",
                  { ...context, stage: "ack_sent" },
                  `Slip ACK sent via ${ackResult.method}`,
                  { ack_latency_ms: ackResult.latencyMs, method: ackResult.method, success: ackResult.success }
                );
                
                // ✅ FIX: Mark purchase as PENDING_REVIEW and enqueue OCR job
                // This prevents "waiting for slip" loop and ensures OCR processing
                try {
                  const { markPurchasePendingReview } = await import("./services/purchaseService");
                  const { enqueueSlipOcrTask } = await import("./services/slipOcrTaskService");
                  
                  // Mark purchase as PENDING_REVIEW (idempotent)
                  const wasUpdated = await markPurchasePendingReview(
                    recentPurchase.purchaseId,
                    messageId,
                    context.traceId
                  );
                  
                  if (wasUpdated) {
                    logWithTrace("[PURCHASE_MARKED_PENDING]", context, `Purchase marked as PENDING_REVIEW: purchaseId=${recentPurchase.purchaseId}`);
                  }
                  
                  // Enqueue OCR job (fire-and-forget, idempotent task name)
                  enqueueSlipOcrTask({
                    userId: firebaseUid,
                    lineUserId: lineUserId!,
                    messageId,
                    purchaseId: recentPurchase.purchaseId,
                  }).then((taskName) => {
                    logWithTrace("[OCR_JOB_ENQUEUED]", context, `OCR job enqueued: taskName=${taskName}, purchaseId=${recentPurchase.purchaseId}`);
                  }).catch((err) => {
                    console.error(`[lineWebhookV1] Failed to enqueue OCR job: purchaseId=${recentPurchase.purchaseId}`, err);
                    // Non-blocking: continue even if enqueue fails
                  });
                } catch (markErr) {
                  console.error(`[lineWebhookV1] Failed to mark purchase/enqueue OCR: purchaseId=${recentPurchase.purchaseId}`, markErr);
                  // Non-blocking: continue even if marking fails
                }
                
                continue;
              }
              
              // No recent purchase and no image_mode - store as pending and ask
              storePendingImage(firebaseUid, messageId);
              
              // ✅ FIX: Always send ACK even if no purchase - never stay silent
              // ✅ OPTIMIZATION: Parallelize imports and query to reduce latency
              const [
                { getWaitingForSlipPurchase }
              ] = await Promise.all([
                import("./services/purchaseService"),
              ]);
              
              // Check if user might be sending slip (has purchase but expired or different status)
              const waitingPurchase = await getWaitingForSlipPurchase(firebaseUid);
              
              if (waitingPurchase) {
                // User has purchase but not recent enough - still process as slip
                await setUserImageMode(firebaseUid, 'SLIP');
                logWithTrace("[IMAGE_MODE=SLIP_EXPIRED]", context, `Found expired purchase, treating as slip: purchaseId=${waitingPurchase.purchaseId}`);
                
                // Send ACK (via sendReplyOrPush)
                const { getSlipReceivedMessage } = await import("./services/paymentUXCopy");
                const expiredAckResult = await sendReplyOrPush({
                  replyToken,
                  to: lineUserId,
                  messages: [{ type: "text", text: getSlipReceivedMessage() }],
                  accessToken,
                  traceContext: { ...context, stage: "ack_sent" },
                });
                
                logWithTrace(
                  "[IMAGE_EXPIRED_SLIP_ACK_SENT]",
                  { ...context, stage: "ack_sent" },
                  `Expired purchase slip ACK sent via ${expiredAckResult.method}`,
                  { ack_latency_ms: expiredAckResult.latencyMs, method: expiredAckResult.method }
                );
                
                // ✅ FIX: Mark purchase as PENDING_REVIEW and enqueue OCR job (for expired purchase too)
                try {
                  const { markPurchasePendingReview } = await import("./services/purchaseService");
                  const { enqueueSlipOcrTask } = await import("./services/slipOcrTaskService");
                  
                  // Mark purchase as PENDING_REVIEW (idempotent)
                  const wasUpdated = await markPurchasePendingReview(
                    waitingPurchase.purchaseId,
                    messageId,
                    context.traceId
                  );
                  
                  if (wasUpdated) {
                    logWithTrace("[PURCHASE_MARKED_PENDING]", context, `Purchase marked as PENDING_REVIEW: purchaseId=${waitingPurchase.purchaseId}`);
                  }
                  
                  // Enqueue OCR job (fire-and-forget, idempotent task name)
                  enqueueSlipOcrTask({
                    userId: firebaseUid,
                    lineUserId: lineUserId!,
                    messageId,
                    purchaseId: waitingPurchase.purchaseId,
                  }).then((taskName) => {
                    logWithTrace("[OCR_JOB_ENQUEUED]", context, `OCR job enqueued: taskName=${taskName}, purchaseId=${waitingPurchase.purchaseId}`);
                  }).catch((err) => {
                    console.error(`[lineWebhookV1] Failed to enqueue OCR job: purchaseId=${waitingPurchase.purchaseId}`, err);
                    // Non-blocking: continue even if enqueue fails
                  });
                } catch (markErr) {
                  console.error(`[lineWebhookV1] Failed to mark purchase/enqueue OCR: purchaseId=${waitingPurchase.purchaseId}`, markErr);
                  // Non-blocking: continue even if marking fails
                }
                
                // Store image as pending for expired purchase too
                storePendingImage(firebaseUid, messageId);
                continue;
              }
              
              // No purchase at all - ask what image is for
              // Throttle image prompt (limit to once per 2 seconds)
              const { isActionAllowed } = await import("./services/userThrottleService");
              if (isActionAllowed(lineUserId || firebaseUid, 'image_prompt', 2000)) {
                // Send ACK (via sendReplyOrPush)
                const unknownAckResult = await sendReplyOrPush({
                  replyToken,
                  to: lineUserId,
                  messages: [{ 
                    type: "text", 
                    text: "รูปนี้คืออะไร?\n\nพิมพ์: โลโก้ / ลายเซ็น / ตราประทับ",
                  }],
                  accessToken,
                  traceContext: { ...context, stage: "ack_sent" },
                });
                
                logWithTrace(
                  "[IMAGE_UNKNOWN_ACK_SENT]",
                  { ...context, stage: "ack_sent" },
                  `Unknown image ACK sent via ${unknownAckResult.method}`,
                  { ack_latency_ms: unknownAckResult.latencyMs, method: unknownAckResult.method }
                );
              }
              
              logWithTrace("[IMAGE_STORED]", context, `Pending image stored for user ${firebaseUid}`);
              continue;
            }
          } catch (imgErr) {
            logWithTrace("[IMAGE_PROCESS_ERROR]", context, `Error processing image: ${imgErr}`);
          }
        }

        // For unlinked users, still send ACK - never stay silent
        if (lineUserId) {
          const unlinkedAckResult = await sendReplyOrPush({
            replyToken: event.replyToken,
            to: lineUserId,
            messages: [{ 
              type: "text", 
              text: "❌ กรุณาเชื่อมต่อบัญชี LINE กับระบบก่อน\n\nพิมพ์ \"เชื่อมต่อ\" เพื่อเริ่มต้น",
            }],
            accessToken,
            traceContext: { ...context, stage: "ack_sent" },
          });
          
          logWithTrace(
            "[IMAGE_UNLINKED_ACK_SENT]",
            { ...context, stage: "processing_done" },
            `Unlinked user ACK sent via ${unlinkedAckResult.method}`,
            { ack_latency_ms: unlinkedAckResult.latencyMs, method: unlinkedAckResult.method }
          );
        }
        
        logWithTrace("[IMAGE_STORED_UNLINKED]", context, `Image stored for unlinked user, ACK sent`);
      }
    }

    res.status(200).send("OK");
  });

/**
 * Process message asynchronously (after webhook returns 200)
 * Uses pushMessage instead of replyMessage for results
 */
async function processMessageAsync(
  lineUserId: string,
  messageText: string,
  lineClient: {
    pushMessage: (params: { to: string; messages: Array<{ type: string; text?: string; quickReply?: { items: unknown[] } }> }) => Promise<void>;
    replyMessage: (params: any) => Promise<void>;
  },
  db: admin.firestore.Firestore,
  accessToken: string,
  context: TraceContext
): Promise<void> {
  // ✅ OPTIMIZATION: Parallelize imports and Firestore query to reduce latency
  const [
    { safePushMessage: safePush },
    { sanitizeForLogging },
    { recognizeIntent, Intent },
    lineLinkResult
  ] = await Promise.all([
    import("./utils/asyncSafety"),
    import("./utils/logSanitization"),
    import("./core/conversationOrchestrator"),
    getLineLink(lineUserId), // Firestore query in parallel with imports
  ]);

  // Sanitize messageText before logging
  const sanitizedMessage = sanitizeForLogging(messageText);
  logWithTrace("[ASYNC_START]", { ...context, stage: "processing_start" }, `Processing message: "${sanitizedMessage}"`);

  // Helper: Safe push message (never throws) - wrapped to match expected signature
  const pushMessage = async (text: string): Promise<void> => {
    await safePush(lineUserId, text, accessToken, context);
    // Return void regardless of success/failure (errors handled by safePush)
  };

  // Detect intent early to provide context-aware linking message
  const intent = recognizeIntent(messageText);
  const isPurchaseIntent = intent === Intent.BUY_PACKAGE_99 || intent === Intent.BUY_PACKAGE_299;
  const packageType = isPurchaseIntent ? (intent === Intent.BUY_PACKAGE_99 ? 99 : 299) : undefined;

  // Resolve Firebase UID from line_links (NEW: OAuth-based linking)
  const lineLink = lineLinkResult;

  // ✅ FIX 2: Validate lineLink status and uid (must be ACTIVE and have uid)
  if (!lineLink || lineLink.status !== 'ACTIVE' || !lineLink.uid || lineLink.uid.trim() === '') {
    // ✅ GUARD: Block purchase flow if user is not linked
    if (isPurchaseIntent) {
      console.log(`[BUY_FLOW_BLOCKED] reason=account_not_linked, lineUserId=${lineUserId}, intent=${intent}`);
      
      // ✅ Analytics: Log purchase blocked event (fire-and-forget)
      (async () => {
        try {
          await db.collection('analytics_events').add({
            event: 'purchase_blocked_not_linked',
            lineUserId,
            packageType,
            reason: 'NOT_LINKED',
            source: 'LINE',
            traceId: context.traceId,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year TTL
          });
        } catch (err) {
          // Non-blocking: analytics failure should not affect flow
          console.warn(`[analytics] Failed to log purchase_blocked_not_linked:`, err);
        }
      })();
      
      // Send explicit message for purchase intent
      await pushMessage("🔐 กรุณาเชื่อมต่อบัญชี LINE ก่อนซื้อแพ็ค");
    }

    // ✅ FIX 3: Store original intent before linking (but NOT for LINK_ACCOUNT)
    // Don't store LINK_ACCOUNT intent - it causes loops when resumed into payment flow
    // Only store intents that have real effects (purchase, document creation, etc.)
    if (intent !== Intent.LINK_ACCOUNT && intent !== Intent.HELP && intent !== Intent.USAGE_GUIDE) {
      try {
        // Generate intent hash for idempotency
        const crypto = await import("crypto");
        const intentHash = crypto.createHash('sha256').update(messageText).digest('hex');
        await db.collection('pending_intents').doc(lineUserId).set({
          intent: messageText,
          intentHash, // ✅ Idempotency: Detect duplicate intents
          timestamp: admin.firestore.FieldValue.serverTimestamp(),
          expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 10 * 60 * 1000), // 10 min TTL
          traceId: context.traceId,
          status: 'PENDING', // ✅ Idempotency: Track resume state
          resumeCount: 0, // ✅ Idempotency: Prevent infinite retries
        });
        logWithTrace(
          "[INTENT_STORED]",
          { ...context, eventType: "intent_stored" },
          `Stored intent for resume after linking: "${messageText}"`
        );
      } catch (storeErr) {
        console.warn(`[INTENT_STORE_FAILED] Failed to store intent:`, storeErr);
        // Continue - linking is more important than intent resume
      }
    } else {
      logWithTrace(
        "[INTENT_SKIPPED]",
        { ...context, eventType: "intent_skipped" },
        `Skipped storing intent ${intent} (LINK_ACCOUNT/HELP/USAGE_GUIDE should not be resumed)`
      );
    }

    // User not linked yet - send LIFF linking prompt via push message
    // LIFF URL: Use LINE's native LIFF app instead of web redirect
    // LIFF ID: 2008406529-t10C3ftD (LINE Login channel)
    const LIFF_ID = "2008406529-t10C3ftD";
    const linkUrl = `https://liff.line.me/${LIFF_ID}`;

    logWithTrace(
      "[LINK_PROMPT_URL]",
      { traceId: "n/a", lineUserId, eventType: "account_linking", stage: "url_generated" },
      `Generated link URL: ${linkUrl}`
    );

    // Send button template message via push
    const buttonResponse = await fetch(LINE_API.PUSH, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        to: lineUserId,
        messages: [
          {
            type: "template",
            altText: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน",
            template: {
              type: "buttons",
              text: "🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nคลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบ",
              actions: [
                {
                  type: "uri",
                  label: "🔗 เชื่อมต่อบัญชี",
                  uri: linkUrl,
                },
              ],
            },
          },
        ],
      }),
    });

    if (!buttonResponse.ok) {
      const errorText = await buttonResponse.text();
      logWithTrace(
        "[ASYNC_LINK_PROMPT_FAILED]",
        { traceId: "n/a", lineUserId, eventType: "account_linking", stage: "button_push_failed" },
        `LINE API error: ${buttonResponse.status}`,
        { statusText: buttonResponse.statusText, body: errorText, linkUrl }
      );
      throw new Error(`LINE API error: ${buttonResponse.status} ${buttonResponse.statusText}`);
    }

    logWithTrace(
      "[LINK_PROMPT_SENT]",
      { traceId: "n/a", lineUserId, eventType: "account_linking", stage: "button_sent" },
      `Link button sent successfully`
    );

    return;
  }

  // ✅ GUARD: Check if lineLink exists but uid is missing/invalid
  if (!lineLink.uid || lineLink.uid.trim() === '') {
    console.log(`[BUY_FLOW_BLOCKED] reason=linked_but_missing_uid, lineUserId=${lineUserId}, lineLink=${JSON.stringify({ status: lineLink.status, hasUid: !!lineLink.uid })}`);
    
    if (isPurchaseIntent) {
      // ✅ Analytics: Log purchase blocked event (fire-and-forget)
      (async () => {
        try {
          await db.collection('analytics_events').add({
            event: 'purchase_blocked_not_linked',
            lineUserId,
            packageType,
            reason: 'NOT_LINKED',
            source: 'LINE',
            traceId: context.traceId,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year TTL
          });
        } catch (err) {
          // Non-blocking: analytics failure should not affect flow
          console.warn(`[analytics] Failed to log purchase_blocked_not_linked:`, err);
        }
      })();
      
      await pushMessage("🔐 กรุณาเชื่อมต่อบัญชี LINE ก่อนซื้อแพ็ค");
    }

    // Send LIFF linking prompt
    const LIFF_ID = "2008406529-t10C3ftD";
    const linkUrl = `https://liff.line.me/${LIFF_ID}`;

    const buttonResponse = await fetch(LINE_API.PUSH, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        to: lineUserId,
        messages: [
          {
            type: "template",
            altText: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน",
            template: {
              type: "buttons",
              text: "🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nคลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบ",
              actions: [
                {
                  type: "uri",
                  label: "🔗 เชื่อมต่อบัญชี",
                  uri: linkUrl,
                },
              ],
            },
          },
        ],
      }),
    });

    if (!buttonResponse.ok) {
      const errorText = await buttonResponse.text();
      console.error(`[LINK_PROMPT_FAILED] LINE API error: ${buttonResponse.status}`, errorText);
    }

    return;
  }

  // ✅ FIX 1: Check for pending intent and resume
  try {
    const pendingIntentRef = db.collection('pending_intents').doc(lineUserId);
    // ✅ Use transaction for atomic resume
    const storedIntent = await db.runTransaction(async (tx) => {
      const pendingIntentDoc = await tx.get(pendingIntentRef);
      if (!pendingIntentDoc.exists) {
        return null;
      }
      
      const intentData = pendingIntentDoc.data();
      if (!intentData) {
        return null;
      }
      
      // Check expiration
      const expiresAt = intentData.expiresAt as admin.firestore.Timestamp | undefined;
      if (!expiresAt || expiresAt.toMillis() <= Date.now()) {
        tx.delete(pendingIntentRef); // Clean up expired
        return null;
      }
      
      // Check status (idempotency)
      const status = intentData.status as string | undefined;
      if (status === 'RESUMED') {
        // Already resumed, skip
        return null;
      }
      
      // Check resume count (prevent infinite retries)
      const resumeCount = (intentData.resumeCount as number | undefined) || 0;
      if (resumeCount >= 3) {
        tx.delete(pendingIntentRef); // Max retries reached
        return null;
      }
      
      // Atomic update: Mark as RESUMED and increment count
      tx.update(pendingIntentRef, {
        status: 'RESUMED',
        resumedAt: admin.firestore.FieldValue.serverTimestamp(),
        resumeCount: resumeCount + 1,
      });
      
      return intentData.intent as string;
    });
    
    if (storedIntent) {
      logWithTrace(
        "[INTENT_RESUMED]",
        { ...context, eventType: "intent_resumed" },
        `Resuming stored intent: "${storedIntent}"`
      );
      // Delete after successful processing (not before)
      await pendingIntentRef.delete();
      await processMessageAsync(lineUserId, storedIntent, lineClient, db, accessToken, context);
      return;
    }
  } catch (resumeErr) {
    console.warn(`[INTENT_RESUME_FAILED] Failed to resume intent:`, resumeErr);
    // Continue - process current message normally
  }

  const firebaseUserId = lineLink.uid;
  const businessId = lineLink.businessId;
  console.log(
    `[LINK_CONFIRMED] ✅ ${lineUserId} → uid=${firebaseUserId}, business=${businessId}`
  );

  // Note: firebaseUserId validation is already done above (linked_but_missing_uid guard)
  // This check is redundant but kept for safety
  if (!firebaseUserId || firebaseUserId.trim() === '') {
    console.log(`[BUY_FLOW_ABORTED] reason=missing_firebaseUserId_after_link, lineUserId=${lineUserId}, lineLink=${JSON.stringify({ status: lineLink.status, hasUid: !!lineLink.uid })}`);
    await pushMessage("🔧 ไม่พบข้อมูลผู้ใช้ กรุณาเชื่อมต่อบัญชีอีกครั้ง");
    return;
  }

  // Check if user needs onboarding (first-time user)
  // Send proactive welcome if first message and no onboarding completed
  try {
    const { needsOnboarding } = await import("./services/onboardingService");
    const needsOnboard = await needsOnboarding(firebaseUserId);
    if (needsOnboard) {
      console.log(`[ONBOARDING] 🆕 First-time user detected: ${firebaseUserId}`);
      
      // Send welcome message with buttons (proactive, non-blocking)
      // Only send if user hasn't sent a command yet (this is checked in decideFirstMessageOrFallback)
      // The welcome will be sent by decideFirstMessageOrFallback if needed
    }
  } catch (onboardErr) {
    console.warn(`[ONBOARDING] Error checking onboarding status: ${onboardErr}`);
  }

  // Intent already detected above (for purchase intent blocking)
  // Re-use the same intent variable
  // Sanitize messageText before logging
  const { sanitizeForLogging: sanitizeMsg } = await import("./utils/logSanitization");
  const sanitizedMsg = sanitizeMsg(messageText);
  console.log(`[INTENT_RECOGNIZED] 🎯 intent=${intent}, message="${sanitizedMsg}"`);

  // Handle purchase intents (BUY_PACKAGE_99, BUY_PACKAGE_299)
  // ✅ GUARD: Only reachable if lineLink exists AND lineLink.uid is valid (checked above)
  if (intent === Intent.BUY_PACKAGE_99 || intent === Intent.BUY_PACKAGE_299) {
    console.log(`[PURCHASE_INTENT_DETECTED] 🎯 intent=${intent}, userId=${firebaseUserId}, lineUserId=${lineUserId}`);
    await handlePurchaseIntent(firebaseUserId, lineUserId, intent, pushMessage, accessToken);
    return;
  }

  // Check for active draft (placeholder)
  const hasActiveDraft = false; // TODO: Query conversations collection

  // Decide: welcome, fallback, or pass
  const decision = await decideFirstMessageOrFallback({
    db,
    userId: firebaseUserId || "",
    text: messageText,
    intent,
    hasActiveDraft,
  });

  // Handle decision
  if (decision.action === "REPLIED") {
    // Send via push message with quickReply support
    if (lineUserId) {
      const messages: Array<{
        type: string;
        text: string;
        quickReply?: { items: unknown[] };
      }> = decision.messages.map((text) => ({
        type: "text",
        text,
      }));
      
      // Add quickReply to last message if provided
      if (decision.quickReply && decision.quickReply.length > 0 && messages.length > 0) {
        messages[messages.length - 1].quickReply = {
          items: decision.quickReply.slice(0, 13),
        };
      }
      
      await lineClient.pushMessage({
        to: lineUserId,
        messages,
      });
    }
    console.log(
      `[ASYNC_REPLIED] 📤 Sent ${decision.kind} response to ${lineUserId}`
    );
    return;
  }

  if (decision.action === "FORWARD") {
    // Pass to main conversation handler
    console.log(
      `[ASYNC_FORWARDING] ➡️ Intent recognized, forwarding to conversation handler`
    );
    try {
      await handleConversationMessage({
        userId: firebaseUserId || "",
        businessId,
        messageText,
        replyToken: "", // Not used in async mode
        lineUserId: lineUserId || undefined, // For admin auth
        traceId: context.traceId, // ✅ FIX 6: Pass correlation ID
        lineClient: {
          replyMessage: async (params: {
            messages: Array<any>; // Allow any message type (text, template, etc.)
          }) => {
            // Convert to push message - support text, template, and other message types
            if (lineUserId && params.messages && params.messages.length > 0) {
              // Pass messages directly to pushMessage (supports all LINE message types)
              await lineClient.pushMessage({
                to: lineUserId,
                messages: params.messages,
              });
            }
          },
        },
      });
    } catch (err) {
      console.error("[ASYNC_CONVERSATION_ERROR] ❌ Error in conversation handler:", err);
      await pushMessage(
        "🔧 เกิดข้อผิดพลาดในการประมวลผล\n\nกรุณาลองใหม่อีกครั้ง"
      );
    }
  }

  // NOTE: Error handling is done by withAsyncSafety wrapper
  // No need for try-catch here - any error will be caught and fallback sent automatically
}

/**
 * Handle purchase intent (BUY_PACKAGE_99 or BUY_PACKAGE_299)
 * 
 * CRITICAL: Reply immediately (<300ms), then generate QR async
 * The purchaseService.createPurchase() handles async QR generation and push
 */
/**
 * Handle purchase intent (BUY_PACKAGE_99 or BUY_PACKAGE_299)
 * 
 * CRITICAL: 
 * - Reply immediately (<300ms)
 * - QR generation is fire-and-forget (async, no await)
 * - Never block webhook on QR generation
 */
async function handlePurchaseIntent(
  uid: string,
  lineUserId: string,
  intent: string,
  pushMessage: (text: string, quickReply?: unknown) => Promise<void>,
  _accessToken: string
): Promise<void> {
  const { Intent } = await import("./core/conversationOrchestrator");
  
  // ✅ GUARD 1: Validate userId
  if (!uid || uid.trim() === '') {
    console.log(`[BUY_FLOW_ABORTED] reason=missing_userId, lineUserId=${lineUserId}, intent=${intent}`);
    await pushMessage("🔧 ไม่พบข้อมูลผู้ใช้ กรุณาเชื่อมต่อบัญชีอีกครั้ง");
    return;
  }

  // ✅ GUARD 2: Validate lineUserId
  if (!lineUserId || lineUserId.trim() === '') {
    console.log(`[BUY_FLOW_ABORTED] reason=missing_lineUserId, userId=${uid}, intent=${intent}`);
    await pushMessage("🔧 ไม่พบข้อมูล LINE กรุณาลองใหม่อีกครั้ง");
    return;
  }

  try {
    // Determine package type
    const packageType = intent === Intent.BUY_PACKAGE_99 ? 99 : 299;
    
    console.log(`[BUY_FLOW_STARTED] 💰 userId=${uid}, lineUserId=${lineUserId}, package=${packageType}, intent=${intent}`);

    // Create purchase record and trigger async QR generation
    // This returns immediately - QR generation is fire-and-forget
    const { createPurchase } = await import("./services/purchaseService");
    const result = await createPurchase({
      userId: uid,
      lineUserId,
      packageType: packageType as 99 | 299,
    });

    // ✅ GUARD 3: Check if purchase creation failed
    if (!result.purchaseId || result.purchaseId === '') {
      console.log(`[BUY_FLOW_ABORTED] reason=purchase_creation_failed, userId=${uid}, message="${result.message}"`);
      await pushMessage(result.message || "🔧 ไม่สามารถสร้างรายการชำระเงินได้ กรุณาลองใหม่อีกครั้ง");
      return;
    }

    console.log(`[PURCHASE_CREATED] ✅ purchaseId=${result.purchaseId}, userId=${uid}, package=${packageType}`);

    // Reply immediately (QR will be pushed async via separate LINE push)
    await pushMessage(result.message);

    console.log(`[PURCHASE_INITIATED] 📤 purchaseId=${result.purchaseId}, lineUserId=${lineUserId}, message="${result.message}"`);
  } catch (error) {
    console.error(`[BUY_FLOW_ABORTED] reason=exception, userId=${uid}, lineUserId=${lineUserId}, error:`, error);
    await pushMessage(
      "🔧 เกิดข้อผิดพลาดในการสร้าง QR\n\nกรุณาลองใหม่อีกครั้ง"
    );
    // Don't re-throw - webhook should still return 200
  }
}

/**
 * Process slip image asynchronously (after webhook returns 200)
 * Download from LINE, upload to storage, mark purchase as PENDING_REVIEW
 */
// REMOVED: processSlipImageAsync
// Slip processing is NEVER allowed on image receive
// All slip processing happens in text handler (conversationHandler) only
