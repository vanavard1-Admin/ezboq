/**
 * EzDoc - Rich Menu Setup (Admin Function)
 * 
 * HTTP endpoint to create/update Rich Menu.
 * Call this once after deployment to set up the Rich Menu.
 * 
 * Usage:
 * POST /setupRichMenu
 * Headers: Authorization: Bearer <admin-token>
 */

import * as functions from 'firebase-functions/v1';
import { syncRichMenuWithQuickReply } from '../services/richMenuService';

export const setupRichMenu = functions
  .region('asia-southeast1')
  .runWith({ secrets: ['LINE_CHANNEL_ACCESS_TOKEN'] })
  .https.onRequest(async (req: functions.https.Request, res: functions.Response) => {
    // Basic auth check (can be enhanced)
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    try {
      const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN?.trim() || '';
      if (!accessToken) {
        res.status(500).json({ error: 'LINE_CHANNEL_ACCESS_TOKEN not configured' });
        return;
      }

      console.log('[SETUP_RICH_MENU] Starting Rich Menu setup...');
      const richMenuId = await syncRichMenuWithQuickReply(accessToken);
      
      res.json({
        success: true,
        richMenuId,
        message: 'Rich Menu created and set as default',
      });
    } catch (err) {
      console.error('[SETUP_RICH_MENU] Error:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to setup Rich Menu',
      });
    }
  });

