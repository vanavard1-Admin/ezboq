/**
 * Document API Endpoints
 * GET /v1/documents - List documents
 * POST /v1/documents - Create document draft
 * GET /v1/documents/:id - Get document with items
 * PATCH /v1/documents/:id - Update document
 * POST /v1/documents/:id/generate-pdf - Enqueue PDF generation
 */

import { Router, Response } from 'express';
import * as admin from 'firebase-admin';
import { CloudTasksClient } from '@google-cloud/tasks';
import {
    AuthenticatedRequest,
    verifyAuth,
    getActiveBusinessId,
    verifyBusinessOwnership,
} from './auth';
import { allocateDocNo, getYearBEFromISO } from '../core/sequences';
import { calcMoney } from '../core/money';
import { enqueuePdfJobWithTasks, enqueuePdfJobDirect } from '../core/tasks';
import { checkRequestRateLimit, checkDailyDocLimit } from '../core/ratelimit';
import { incrementDocStats } from '../core/statsMonthly';
import { assertTransition, logStatusTransition, getTransitionAction, DocumentState } from '../core/stateMachine';

const router = Router();
const USE_CLOUD_TASKS = process.env.USE_CLOUD_TASKS === 'true';

/**
 * GET /v1/documents
 * List documents for a business
 */
router.get('/documents', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;

        let businessId = req.query.businessId as string;
        if (!businessId) {
            businessId = (await getActiveBusinessId(uid)) || '';
        }

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        const limit = Math.min(Number(req.query.limit) || 50, 100);
        const docType = req.query.docType as string;
        const status = req.query.status as string;

        const query = db
            .collection(`users/${uid}/businesses/${businessId}/documents`)
            .orderBy('createdAt', 'desc')
            .limit(limit);

        const snapshot = await query.get();

        let documents = snapshot.docs.map((doc) => {
            const data = doc.data();
            return {
                id: doc.id,
                docNo: data.docNo,
                docType: data.docType,
                issueDate: data.issueDate,
                status: data.status,
                pdfReady: data.pdfReady || false,
                pdfUrl: data.pdfUrl || null,
                customerSnapshot: data.customerSnapshot,
                money: data.money,
                createdAt: data.createdAt,
            };
        });

        // Filter by docType if specified
        if (docType) {
            documents = documents.filter((d) => d.docType === docType);
        }

        // Filter by status if specified
        if (status) {
            documents = documents.filter((d) => d.status === status);
        }

        res.json({
            businessId,
            documents,
            count: documents.length,
        });
    } catch (error) {
        console.error('GET /v1/documents error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/documents
 * Create a new document draft
 */
router.post('/documents', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;

        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        // Rate Limit Check (Request)
        const { plan = 'FREE' } = await db.doc(`users/${uid}`).get().then(s => s.data() || {});
        const rateLimit = await checkRequestRateLimit(uid, plan);
        if (!rateLimit.allowed) {
            res.status(429).json({ error: 'Too many requests' });
            return;
        }

        const { docType, customerId, issueDate, items, supersedesId } = req.body;

        let version = 1;
        let originId: string | null = null;
        let supersedesIdValue: string | null = null;

        // Handle Version Chaining (Supersedes)
        if (supersedesId) {
            const prevSnap = await db.doc(`users/${uid}/businesses/${businessId}/documents/${supersedesId}`).get();
            if (prevSnap.exists) {
                const prev = prevSnap.data() || {};
                // Inherit origin or start chain
                originId = prev.origin_document_id || supersedesId;
                version = (prev.version || 1) + 1;
                supersedesIdValue = supersedesId;
            }
        }

        if (!docType || !['QUO', 'BILL', 'RECEIPT'].includes(docType)) {
            res.status(400).json({ error: 'Invalid docType (QUO, BILL, RECEIPT)' });
            return;
        }

        // Note: Daily Doc Limit check moved to CONFIRM step

        // Get issue date or use today
        const iso = issueDate || new Date().toISOString().slice(0, 10);
        // Note: YearBE/DocNo allocation moved to CONFIRM step

        // Load business for snapshot
        const bizSnap = await db.doc(`users/${uid}/businesses/${businessId}`).get();
        const biz = bizSnap.data() || {};

        const sanitizePaymentMethods = (value: unknown) => {
            if (!value || typeof value !== 'object') return undefined;
            const v = value as Record<string, unknown>;
            const toStringArray = (x: unknown): string[] | undefined => {
                if (!Array.isArray(x)) return undefined;
                const out = x.filter((it) => typeof it === 'string') as string[];
                return out.length ? out : undefined;
            };
            const banks = toStringArray(v.banks);
            const cards = toStringArray(v.cards);
            const wallets = toStringArray(v.wallets);
            if (!banks && !cards && !wallets) return undefined;
            return { ...(banks ? { banks } : {}), ...(cards ? { cards } : {}), ...(wallets ? { wallets } : {}) };
        };

        // Load customer for snapshot (if provided)
        let customerSnapshot = {
            displayName: '-',
            address: '',
            phone: '',
            email: '',
            taxId: '',
        };

        if (customerId) {
            const custSnap = await db
                .doc(`users/${uid}/businesses/${businessId}/customers/${customerId}`)
                .get();
            if (custSnap.exists) {
                const cust = custSnap.data() || {};
                customerSnapshot = {
                    displayName: (cust.displayName as string) || '-',
                    address: (cust.address as string) || '',
                    phone: (cust.phone as string) || '',
                    email: (cust.email as string) || '',
                    taxId: (cust.taxId as string) || '',
                };
            }
        }

        const paymentMethods = sanitizePaymentMethods((biz as Record<string, unknown>).paymentMethods);

        // Business snapshot
        const businessSnapshot = {
            name: (biz.name as string) || '',
            address: (biz.address as string) || '',
            phone: (biz.phone as string) || '',
            email: (biz.email as string) || '',
            taxId: (biz.taxId as string) || '',
            bankName: (biz.bankName as string) || '',
            bankAccountNo: (biz.bankAccountNo as string) || '',
            bankAccountName: (biz.bankAccountName as string) || '',
            ...(paymentMethods ? { paymentMethods } : {}),
        };

        // Tax snapshot with defaults
        const taxSnapshot = {
            vatEnabled: (biz.defaultVatEnabled as boolean) || false,
            vatRate: (biz.defaultVatRate as number) || 7,
            whtEnabled: (biz.defaultWhtEnabled as boolean) || false,
            whtRate: (biz.defaultWhtRate as number) || 3,
            whtBase: 'BEFORE_VAT',
        };

        // Process items
        const processedItems = (items || []).map((item: Record<string, unknown>, idx: number) => ({
            line_no: idx + 1,
            description_th: (item.description_th as string) || '',
            description_en: (item.description_en as string) || null,
            qty: Number(item.qty) || 1,
            unit: (item.unit as string) || 'รายการ',
            unit_price: Number(item.unit_price) || 0,
            amount: (Number(item.qty) || 1) * (Number(item.unit_price) || 0),
        }));

        // Calculate money
        const money = calcMoney({
            items: processedItems.map((it: { qty: number; unit_price: number }) => ({ qty: it.qty, unit_price: it.unit_price })),
            discount_amount: Number(req.body.discount_amount) || 0,
            extra_fee_amount: Number(req.body.extra_fee_amount) || 0,
            vat_enabled: taxSnapshot.vatEnabled,
            vat_rate: taxSnapshot.vatRate,
            wht_enabled: taxSnapshot.whtEnabled,
            wht_rate: taxSnapshot.whtRate,
        });

        const documentData = {
            docType,
            docNo: 'DRAFT', // Placeholder until CONFIRM
            issueDate: iso,
            status: DocumentState.DRAFT,
            customerId: customerId || null,
            customerSnapshot,
            businessSnapshot,
            taxSnapshot,
            subjectTh: (req.body.subjectTh as string) || null,
            subjectEn: (req.body.subjectEn as string) || null,
            items: processedItems,
            money,
            discount_amount: Number(req.body.discount_amount) || 0,
            extra_fee_amount: Number(req.body.extra_fee_amount) || 0,
            pdfReady: false,
            pdfUrl: null,
            revision: 0,

            // Versioning
            version,
            origin_document_id: originId,
            supersedes_document_id: supersedesIdValue,
            is_void: false,

            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        };

        const ref = await db
            .collection(`users/${uid}/businesses/${businessId}/documents`)
            .add(documentData);

        res.status(201).json({
            id: ref.id,
            businessId,
            ...documentData,
        });
    } catch (error) {
        console.error('POST /v1/documents error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /v1/documents/:id
 * Get a single document with all details
 */
router.get('/documents/:id', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;

        const businessId = (req.query.businessId as string) || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        const snap = await db
            .doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`)
            .get();

        if (!snap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        res.json({
            id: snap.id,
            businessId,
            ...snap.data(),
        });
    } catch (error) {
        console.error('GET /v1/documents/:id error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * PATCH /v1/documents/:id
 * Update a document
 * Note: Limited fields editable based on status
 */
router.patch('/documents/:id', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;

        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        // Rate Limit Check
        const { plan = 'FREE' } = await db.doc(`users/${uid}`).get().then(s => s.data() || {});
        const rateLimit = await checkRequestRateLimit(uid, plan);
        if (!rateLimit.allowed) {
            res.status(429).json({ error: 'Too many requests' });
            return;
        }

        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const snap = await docRef.get();

        if (!snap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        const currentData = snap.data() || {};
        const currentStatus = currentData.status;

        // Fields editable in DRAFT/READY status (User editable)
        // Spec Section 6: Editable Fields = ALL for DRAFT/READY. NONE for others.

        // Block editing if not in editable state
        if (currentStatus !== DocumentState.DRAFT && currentStatus !== DocumentState.READY) {
            // Exception: allow status change if it's a valid transition (e.g. marking PAID? NO, PAID is done via action)
            // Spec says "User voids" -> ANY -> VOID.
            // If this PATCH is receiving "status": "VOID", we should allow it IF it matches transition.
            // But usually VOID is an action endpoint.
            // For safety, we block regular field edits.
            // If ONLY status is being updated, we check transition in next block.

            const tryingToEditFields = Object.keys(req.body).filter(k => k !== 'status' && k !== 'businessId' && k !== 'revision');
            if (tryingToEditFields.length > 0) {
                res.status(400).json({ error: `Cannot edit document in ${currentStatus} state` });
                return;
            }
        }

        const draftEditableFields = [
            'customerId',
            'issueDate',
            'subjectTh',
            'subjectEn',
            'items',
            'discount_amount',
            'extra_fee_amount',
            'taxSnapshot',
            'status', // Allow status change via PATCH (e.g. READY -> DRAFT)
        ];

        const updates: Record<string, unknown> = {};

        // Determine which fields can be updated
        const editableFields = (currentStatus === DocumentState.DRAFT || currentStatus === DocumentState.READY)
            ? draftEditableFields
            : ['status']; // Only allow status updates (e.g. VOID) for other states

        for (const field of editableFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        // Optimistic Locking: Check revision if provided
        if (req.body.revision !== undefined) {
            const currentRev = (currentData.revision as number) || 0;
            const requestRev = Number(req.body.revision);
            if (currentRev !== requestRev) {
                res.status(409).json({
                    error: 'Document has been updated by another process',
                    currentRevision: currentRev,
                });
                return;
            }
        }

        // Handle status change - use strict state machine
        if (updates.status && updates.status !== currentStatus) {
            try {
                // Allows throwing InvalidStateTransitionError
                assertTransition(currentStatus as DocumentState, updates.status as DocumentState);
            } catch (error: any) {
                res.status(400).json({
                    error: error.message,
                    currentStatus,
                    requestedStatus: updates.status,
                });
                return;
            }

            // Log the transition for audit
            const action = getTransitionAction(currentStatus, updates.status as string);
            await logStatusTransition({
                docId: documentId,
                docPath: `users/${uid}/businesses/${businessId}/documents/${documentId}`,
                userId: uid,
                businessId,
                fromStatus: currentStatus,
                toStatus: updates.status as string,
                action,
                metadata: { source: 'PATCH_API', revision: req.body.revision },
            });
        }

        // Recalculate money if items changed
        if (updates.items || updates.discount_amount !== undefined || updates.extra_fee_amount !== undefined) {
            const items = (updates.items as unknown[]) || currentData.items || [];
            const taxSnapshot = (updates.taxSnapshot as Record<string, unknown>) || currentData.taxSnapshot || {};

            if (!Array.isArray(items)) {
                res.status(400).json({ error: 'items must be an array' });
                return;
            }

            const processedItems = items.map((item: unknown, idx: number) => {
                const it = item as Record<string, unknown>;
                return {
                    line_no: idx + 1,
                    description_th: (it.description_th as string) || '',
                    description_en: (it.description_en as string) || null,
                    qty: Number(it.qty) || 1,
                    unit: (it.unit as string) || 'รายการ',
                    unit_price: Number(it.unit_price) || 0,
                    amount: (Number(it.qty) || 1) * (Number(it.unit_price) || 0),
                };
            });

            const money = calcMoney({
                items: processedItems.map((it) => ({ qty: it.qty, unit_price: it.unit_price })),
                discount_amount: Number(updates.discount_amount ?? currentData.discount_amount ?? 0),
                extra_fee_amount: Number(updates.extra_fee_amount ?? currentData.extra_fee_amount ?? 0),
                vat_enabled: Boolean(taxSnapshot.vatEnabled ?? currentData.taxSnapshot?.vatEnabled),
                vat_rate: Number(taxSnapshot.vatRate ?? currentData.taxSnapshot?.vatRate ?? 7),
                wht_enabled: Boolean(taxSnapshot.whtEnabled ?? currentData.taxSnapshot?.whtEnabled),
                wht_rate: Number(taxSnapshot.whtRate ?? currentData.taxSnapshot?.whtRate ?? 3),
            });

            updates.items = processedItems;
            updates.money = money;
        }

        // Update customer snapshot if customerId changed
        if (updates.customerId && updates.customerId !== currentData.customerId) {
            const custSnap = await db
                .doc(`users/${uid}/businesses/${businessId}/customers/${updates.customerId}`)
                .get();
            if (custSnap.exists) {
                const cust = custSnap.data() || {};
                updates.customerSnapshot = {
                    displayName: (cust.displayName as string) || '-',
                    address: (cust.address as string) || '',
                    phone: (cust.phone as string) || '',
                    email: (cust.email as string) || '',
                    taxId: (cust.taxId as string) || '',
                };
            }
        }

        if (Object.keys(updates).length === 0) {
            res.status(400).json({ error: 'No valid fields to update' });
            return;
        }

        updates.updatedAt = admin.firestore.FieldValue.serverTimestamp();
        updates.revision = admin.firestore.FieldValue.increment(1);

        await docRef.update(updates);

        const updatedSnap = await docRef.get();

        res.json({
            id: updatedSnap.id,
            businessId,
            ...updatedSnap.data(),
        });
    } catch (error) {
        console.error('PATCH /v1/documents/:id error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/documents/:id/ready
 * Mark status DRAFT -> READY (Trigger: required fields complete)
 */
router.post('/documents/:id/ready', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;
        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const snap = await docRef.get();

        if (!snap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        const data = snap.data() || {};

        // Guard Status
        if (data.status !== DocumentState.DRAFT) {
            res.status(400).json({ error: `Document must be DRAFT to become READY (Current: ${data.status})` });
            return;
        }

        // Validate Required Fields (Minimally)
        if (!data.items || !Array.isArray(data.items) || data.items.length === 0) {
            res.status(400).json({ error: 'Document must have at least one item' });
            return;
        }

        // Apply Transition
        const updates = {
            status: DocumentState.READY,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        };

        await docRef.update(updates);

        // Audit Log
        logStatusTransition({
            docId: documentId,
            docPath: docRef.path,
            userId: uid,
            businessId,
            fromStatus: DocumentState.DRAFT,
            toStatus: DocumentState.READY,
            action: 'ready',
            metadata: { source: 'API' },
        }).catch(e => console.error(e));

        res.json({ id: documentId, status: DocumentState.READY });

    } catch (error) {
        console.error('POST /ready error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/documents/:id/void
 * Mark status ANY -> VOID
 */
router.post('/documents/:id/void', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;
        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const snap = await docRef.get();

        if (!snap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        const data = snap.data() || {};
        const currentStatus = data.status;

        if (currentStatus === DocumentState.VOID) {
            res.status(200).json({ message: 'Already VOID' });
            return;
        }

        // Use strict transition validator
        try {
            assertTransition(currentStatus as DocumentState, DocumentState.VOID);
        } catch (error: any) {
            res.status(400).json({ error: error.message });
            return;
        }

        // Apply Transition
        await docRef.update({
            status: DocumentState.VOID,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // Audit Log
        logStatusTransition({
            docId: documentId,
            docPath: docRef.path,
            userId: uid,
            businessId,
            fromStatus: currentStatus,
            toStatus: DocumentState.VOID,
            action: 'void',
            metadata: { source: 'API' },
        }).catch(e => console.error(e));

        res.json({ id: documentId, status: DocumentState.VOID });

    } catch (error) {
        console.error('POST /void error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
router.post('/documents/:id/confirm', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;

        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        // ✅ Plan-aware feature check: FREE users cannot create Invoice/Receipt
        // Check BEFORE transaction to avoid async import inside transaction
        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const preCheckSnap = await docRef.get();
        
        if (preCheckSnap.exists) {
            const preCheckData = preCheckSnap.data() || {};
            const { canCreateDocumentType } = await import('../core/planService');
            const docType = (preCheckData.docType as string) || 'QUO';
            const canCreate = await canCreateDocumentType(uid, docType as 'QUO' | 'INV' | 'REC');
            
            if (!canCreate) {
                const docTypeNames: Record<string, string> = {
                    INV: 'ใบวางบิล',
                    BILL: 'ใบวางบิล',
                    REC: 'ใบเสร็จรับเงิน',
                    RECEIPT: 'ใบเสร็จรับเงิน',
                };
                const docTypeName = docTypeNames[docType] || 'เอกสาร';
                res.status(403).json({ 
                    error: `${docTypeName} มีในแพ็ก Pro และ Team เท่านั้น กรุณาอัปเกรดเพื่อใช้งาน`,
                    requiresUpgrade: true,
                    docType
                });
                return;
            }
        }

        await db.runTransaction(async (tx) => {
            const snap = await tx.get(docRef);

            if (!snap.exists) {
                throw new Error('Document not found');
            }

            const data = snap.data() || {};
            // STRICT: confirm requires READY state (Spec v1.0 Section 2)
            if (data.status !== DocumentState.READY) {
                // If DRAFT, hint user to move to READY first
                if (data.status === DocumentState.DRAFT) {
                    throw new Error('Document must be READY before confirming');
                }
                throw new Error(`Cannot confirm document in ${data.status} status`);
            }

            // Daily Doc Limit Check (at confirmation) - This check is outside the transaction in the original,
            // but if it's critical to prevent docNo allocation, it should be here.
            // For now, keeping it outside as per the original structure, but noting this potential refactor.
            // If `checkDailyDocLimit` involves reading/writing to Firestore, it should be `tx.get` etc.
            // Assuming it's a simple read for now.
            const { plan = 'FREE' } = await db.doc(`users/${uid}`).get().then(s => s.data() || {});
            const docLimit = await checkDailyDocLimit(uid, businessId, plan);
            if (!docLimit.allowed) {
                throw new Error('Daily document limit exceeded');
            }

            // Allocate Doc No (Atomic within this transaction)
            const iso = data.issueDate || new Date().toISOString().slice(0, 10);
            const yearBE = getYearBEFromISO(iso);

            const { docNo } = await allocateDocNo({
                userId: uid,
                businessId,
                docType: data.docType,
                yearBE,
            }, tx); // Pass transaction object to allocateDocNo

            const updates = {
                docNo,
                status: DocumentState.ISSUED,
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            };

            tx.update(docRef, updates);
        });

        // Return updated document (Read after write)
        const updatedSnap = await docRef.get();
        const confirmedData = updatedSnap.data() || {};

        // ✅ Write-through stats update (non-blocking)
        const grandTotal = (confirmedData.money as { grand_total?: number })?.grand_total || 0;
        const issueDate = confirmedData.issueDate ? new Date(confirmedData.issueDate) : new Date();
        incrementDocStats(businessId, confirmedData.docType, grandTotal, issueDate).catch(err => {
            console.error('[confirm] Stats update failed (non-blocking):', err);
        });

        // ✅ Log status transition (non-blocking)
        logStatusTransition({
            docId: documentId,
            docPath: `users/${uid}/businesses/${businessId}/documents/${documentId}`,
            userId: uid,
            businessId,
            fromStatus: 'READY',
            toStatus: 'ISSUED',
            action: 'confirm',
            metadata: { source: 'CONFIRM_API' },
        }).catch(err => console.error('[confirm] Audit log failed:', err));

        res.json({
            id: updatedSnap.id,
            businessId,
            ...confirmedData
        });

    } catch (error: unknown) {
        console.error('POST /v1/documents/:id/confirm error:', error);

        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const status = errorMessage === 'Document not found' ? 404 :
            errorMessage.includes('Cannot confirm') ? 400 :
                errorMessage.includes('Daily document limit exceeded') ? 429 : 500;

        res.status(status).json({ error: errorMessage || 'Internal server error' });
    }
});

/**
 * POST /v1/documents/:id/generate-pdf
 * Enqueue PDF generation
 */
router.post('/documents/:id/generate-pdf', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;

        const businessId = req.body.businessId || (await getActiveBusinessId(uid));

        if (!businessId) {
            res.status(400).json({ error: 'No business specified or active' });
            return;
        }

        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        // Rate Limit Check
        const { plan = 'FREE' } = await db.doc(`users/${uid}`).get().then(s => s.data() || {});
        const rateLimit = await checkRequestRateLimit(uid, plan);
        if (!rateLimit.allowed) {
            res.status(429).json({ error: 'Too many requests' });
            return;
        }

        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const snap = await docRef.get();

        if (!snap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        const data = snap.data() || {};

        // Idempotency: don't regenerate if already valid state
        if (data.status === DocumentState.PDF_RENDERING) {
            console.log('PDF generation already in progress');
            res.json({ message: 'PDF generation in progress', state: DocumentState.PDF_RENDERING });
            return;
        }

        // Strict Transition Guard: ISSUED -> PDF_RENDERING
        try {
            assertTransition(data.status as DocumentState, DocumentState.PDF_RENDERING);
        } catch (e: any) {
            res.status(400).json({ error: e.message, status: data.status });
            return;
        }

        // Update PDF state and Document Status
        await docRef.update({
            status: DocumentState.PDF_RENDERING, // V1.0 Spec
            pdfState: 'QUEUED', // Legacy support
            pdfReady: false,
            pdfUrl: null,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // Audit Log
        await logStatusTransition({
            docId: documentId,
            docPath: docRef.path,
            userId: uid,
            businessId,
            fromStatus: data.status,
            toStatus: DocumentState.PDF_RENDERING,
            action: 'generate_pdf',
            metadata: { source: 'API' },
        });

        // Enqueue PDF job
        const payload = {
            userId: uid,
            businessId,
            docId: documentId,
            revision: (data.revision as number) || 0,
            // pdf-service currently requires a non-empty lineUserId field for validation,
            // even though delivery resolution is done server-side by userId.
            lineUserId: 'WEB',
        };

        try {
            if (USE_CLOUD_TASKS) {
                // Task ID based on docId for strict idempotency
                const taskId = `pdf-doc-${documentId}`;
                await enqueuePdfJobWithTasks(payload, taskId);
            } else {
                await enqueuePdfJobDirect(payload);
            }

            res.json({
                message: 'PDF generation queued',
                pdfState: 'QUEUED',
                documentId,
            });
        } catch (queueError) {
            // Revert state on queue failure
            await docRef.update({
                pdfState: 'FAILED',
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            });
            throw queueError;
        }
    } catch (error) {
        console.error('POST /v1/documents/:id/generate-pdf error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/documents/:id/deliver
 * Create or upsert a delivery job and enqueue a delivery task
 * SECURITY: lineUserId is resolved from DB profile, NOT from client request
 */
router.post('/documents/:id/deliver', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const documentId = req.params.id;
        const { businessId } = req.body || {};

        if (!businessId) {
            res.status(400).json({ error: 'Missing businessId' });
            return;
        }

        // Rate limit: Prevent spam/abuse on deliver endpoint (10 req/min for deliver specifically)
        const deliveryRateLimit = await checkRequestRateLimit(uid, 'FREE');
        if (!deliveryRateLimit.allowed) {
            res.status(429).json({
                error: 'Too many delivery requests',
                code: 'RATE_LIMIT_EXCEEDED',
                retryAfterSeconds: deliveryRateLimit.retryAfterSeconds || 60
            });
            return;
        }

        // AuthZ: Verify user owns business
        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        // AuthZ: Verify user owns document
        const docRef = db.doc(`users/${uid}/businesses/${businessId}/documents/${documentId}`);
        const docSnap = await docRef.get();
        if (!docSnap.exists) {
            res.status(404).json({ error: 'Document not found' });
            return;
        }

        const doc = docSnap.data() || {};
        if (doc.pdfState !== 'READY') {
            res.status(400).json({
                error: 'PDF not ready for delivery',
                code: 'PDF_NOT_READY',
                state: doc.pdfState || 'UNKNOWN',
                action: 'Wait for PDF generation to complete'
            });
            return;
        }

        // Security: Resolve lineUserId from user profile, NOT from client
        const userDoc = await db.collection('users').doc(uid).get();
        const profile = userDoc.data();
        const lineUserId = profile?.lineUserId;

        if (!lineUserId) {
            res.status(400).json({
                error: 'User has not connected LINE account',
                code: 'LINE_NOT_CONNECTED',
                action: 'User must send message to bot first'
            });
            return;
        }

        console.log('[postDocumentDeliver] Resolved lineUserId:', lineUserId);

        // Create delivery job (idempotent)
        const jobId = `line:${documentId}:${lineUserId}`;
        const jobRef = db.doc(`deliveryJobs/${jobId}`);
        const now = admin.firestore.FieldValue.serverTimestamp();

        await jobRef.set({
            docId: documentId,
            docPath: `users/${uid}/businesses/${businessId}/documents/${documentId}`,
            userId: uid,
            businessId,
            to: { lineUserId },
            status: 'PENDING',
            attempt: 0,
            createdAt: now,
            updatedAt: now,
            // TTL: PENDING jobs expire in 30 days, FAILED in 90 days (will be updated when status changes)
            expiresAt: admin.firestore.Timestamp.fromDate(
                new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days for PENDING
            ),
        }, { merge: true });

        console.log('[postDocumentDeliver] Job upserted:', jobId);

        // Enqueue Cloud Task (deterministic task name - idempotent)
        try {
            const tasksClient = new CloudTasksClient();
            const PROJECT_ID = process.env.GCP_PROJECT || 'ezdoc-v1-th';
            const parent = tasksClient.queuePath(PROJECT_ID, 'asia-southeast1', 'ezdoc-delivery-queue');
            const sanitizedJobId = jobId.replace(/[^a-zA-Z0-9_-]/g, '_');
            const taskName = tasksClient.taskPath(
                PROJECT_ID,
                'asia-southeast1',
                'ezdoc-delivery-queue',
                `deliver-line-${sanitizedJobId}`
            );

            await tasksClient.createTask({
                parent,
                task: {
                    name: taskName,
                    httpRequest: {
                        httpMethod: 'POST',
                        url: process.env.DELIVERY_TASK_URL || '',
                        headers: { 'Content-Type': 'application/json' },
                        body: Buffer.from(JSON.stringify({ jobId })).toString('base64'),
                        oidcToken: {
                            serviceAccountEmail: process.env.DELIVERY_SERVICE_ACCOUNT || '',
                            audience: process.env.DELIVERY_TASK_URL || ''
                        }
                    }
                }
            });
            console.log('[postDocumentDeliver] Task created:', taskName);
        } catch (err: unknown) {
            const error = err as Record<string, unknown>;
            if (error.code !== 6) {  // 6 = ALREADY_EXISTS
                throw err;
            }
            console.log('[postDocumentDeliver] Task already exists (idempotent)');
        }

        res.status(202).json({
            jobId,
            status: 'PENDING',
            message: 'Document delivery queued'
        });
    } catch (error) {
        console.error('POST /v1/documents/:id/deliver error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;
