/**
 * API Router
 * Main entry point for all HTTP API endpoints
 */

import * as admin from 'firebase-admin';
import express, { Request, Response } from 'express';
import cors from 'cors';
import { onRequest } from 'firebase-functions/v2/https';
import { v4 as uuidv4 } from 'uuid';

import businessRouter from './business';
import customersRouter from './customers';
import documentsRouter from './documents';
import documentsV1Router from './documentsV1';
import { lineLinkRouter } from './lineLink';

// Initialize Firebase Admin if not already initialized
if (!admin.apps.length) {
    admin.initializeApp();
}

// Create Express app
const app = express();

// Disable ETag globally for API responses (avoid 304s for auth-dependent endpoints)
app.disable('etag');

// --- CORS configuration ---
// Allowlist for production and local dev. Adjust as needed or drive from env.
const allowedOrigins = [
    'https://ezdoc-v1-th.web.app',
    'http://localhost:3000',
];

const corsOptions: cors.CorsOptions = {
    origin: (origin, callback) => {
        // Allow requests with no origin (e.g., curl, server-to-server)
        if (!origin) return callback(null, true);

        if (allowedOrigins.includes(origin)) {
            return callback(null, true);
        }

        // Deny other origins
        return callback(new Error('Not allowed by CORS'));
    },
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Authorization', 'Content-Type', 'X-Requested-With', 'Accept'],
    maxAge: 86400,
    optionsSuccessStatus: 204,
};

// Register CORS middleware BEFORE any auth middleware/routes
app.use(cors(corsOptions));
// Ensure body parsing after CORS so OPTIONS won't be blocked
app.use(express.json());

// Ensure every response has basic CORS headers (covers error responses too)
app.use((req: Request, res: Response, next: express.NextFunction) => {
    const origin = (req.headers.origin as string) || allowedOrigins[0] || '*';
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Requested-With, Accept');
    res.header('Access-Control-Max-Age', '86400');
    next();
});

// Reply to preflight explicitly
app.options('*', cors(corsOptions), (_req: Request, res: Response) => res.sendStatus(204));

// Request ID & Logger Middleware
app.use((req: Request, res: Response, next: express.NextFunction) => {
    const requestId = (req.headers['x-request-id'] as string) || uuidv4();
    req.headers['x-request-id'] = requestId;
    res.setHeader('X-Request-Id', requestId);

    // Initial log
    console.log(JSON.stringify({
        severity: 'INFO',
        message: `Incoming ${req.method} ${req.originalUrl}`,
        requestId,
        method: req.method,
        url: req.originalUrl,
        ip: req.ip,
        userAgent: req.get('user-agent'),
    }));

    // Wrap end to log response
    const originalEnd = res.end;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    res.end = function (...args: any[]): Response {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (originalEnd as any).apply(res, args);

        console.log(JSON.stringify({
            severity: res.statusCode >= 500 ? 'ERROR' : 'INFO',
            message: `Response ${res.statusCode} ${req.method} ${req.originalUrl}`,
            requestId,
            statusCode: res.statusCode,
        }));
        return res;
    };

    next();
});

// Health check - minimal response to avoid information leakage
app.get('/v1/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
});

// Mount routers
app.use('/v1', businessRouter);
app.use('/v1', customersRouter);
app.use('/v1', documentsRouter);
app.use('/v1', documentsV1Router); // Service-to-service endpoints
app.use('/v1/auth/line-link', lineLinkRouter);

// 404 handler
app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: 'Not found' });
});

// Error handler
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, req: Request, res: Response, _next: express.NextFunction) => {
    const requestId = req.headers['x-request-id'];
    console.error(JSON.stringify({
        severity: 'ERROR',
        message: `Unhandled Error: ${err.message}`,
        requestId,
        stack: err.stack,
    }));
    res.status(500).json({ error: 'Internal server error', requestId });
});

// Export as Cloud Function
export const api = onRequest(
    {
        region: 'asia-southeast1',
        timeoutSeconds: 60,
        memory: '256MiB',
    },
    app
);
