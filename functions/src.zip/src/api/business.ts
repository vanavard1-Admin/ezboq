/**
 * Business API Endpoints
 * GET /v1/me - Get current user with active business
 * GET /v1/business/:id - Get business details
 * PATCH /v1/business/:id - Update business
 */

import { Router, Response } from 'express';
import * as admin from 'firebase-admin';
import { createBusiness } from '../core/businesses';
import {
    AuthenticatedRequest,
    verifyAuth,
    ensureUserExists,
    verifyBusinessOwnership,
} from './auth';
import { checkRequestRateLimit } from '../core/ratelimit';

const router = Router();

/**
 * GET /v1/me
 * Get current user profile with active business
 */
router.get('/me', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;

        // Ensure user exists in Firestore
        const { activeBusinessId, plan } = await ensureUserExists(uid, req.user?.email);

        // Get all businesses for this user
        const bizQuery = await db.collection(`users/${uid}/businesses`).get();
        const businesses = bizQuery.docs.map((doc) => ({
            id: doc.id,
            name: doc.data().name,
        }));

        // Load active business if exists
        let business = null;
        if (activeBusinessId) {
            const bizSnap = await db.doc(`users/${uid}/businesses/${activeBusinessId}`).get();
            if (bizSnap.exists) {
                business = { id: bizSnap.id, ...bizSnap.data() };
            }
        }

        // Ensure profile responses are not cached by browsers or intermediaries
        res.set('Cache-Control', 'no-store');
        res.set('Pragma', 'no-cache');
        res.set('Expires', '0');

        res.json({
            userId: uid,
            email: req.user?.email || null,
            activeBusinessId,
            plan,
            roles: ['OWNER'], // Default role for now
            business,
            businesses,
        });
    } catch (error) {
        console.error('GET /v1/me error:', error);
        // Ensure error responses also do not get cached
        res.set('Cache-Control', 'no-store');
        res.set('Pragma', 'no-cache');
        res.set('Expires', '0');

        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/business/bootstrap
 * Explicit onboarding endpoint (no side effects in GET /me)
 * - If user has no business: create default business + set activeBusinessId
 * - If user has businesses but no activeBusinessId: set active to the first
 */
router.post('/business/bootstrap', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;

        const { activeBusinessId } = await ensureUserExists(uid, req.user?.email);

        const bizQuery = await db.collection(`users/${uid}/businesses`).get();
        const businesses = bizQuery.docs.map((doc) => ({
            id: doc.id,
            name: doc.data().name,
        }));

        // Case 1: create first business
        if (businesses.length === 0) {
            const defaultName = req.user?.email
                ? `Business (${String(req.user.email).split('@')[0]})`
                : 'My Business';

            const businessId = await createBusiness(uid, {
                name: defaultName,
                email: req.user?.email,
            });

            res.set('Cache-Control', 'no-store');
            res.json({
                success: true,
                created: true,
                businessId,
                activeBusinessId: businessId,
            });
            return;
        }

        // Case 2: businesses exist; ensure activeBusinessId is set
        if (!activeBusinessId) {
            const firstBusinessId = businesses[0].id;
            await db.doc(`users/${uid}`).update({
                activeBusinessId: firstBusinessId,
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            });

            res.set('Cache-Control', 'no-store');
            res.json({
                success: true,
                created: false,
                businessId: firstBusinessId,
                activeBusinessId: firstBusinessId,
            });
            return;
        }

        // Case 3: already bootstrapped
        res.set('Cache-Control', 'no-store');
        res.json({
            success: true,
            created: false,
            businessId: activeBusinessId,
            activeBusinessId,
        });
    } catch (error) {
        console.error('POST /v1/business/bootstrap error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /v1/business/:id
 * Get business details
 */
router.get('/business/:id', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const businessId = req.params.id;

        // Verify ownership
        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        const bizSnap = await db.doc(`users/${uid}/businesses/${businessId}`).get();
        const data = bizSnap.data();

        res.json({
            id: bizSnap.id,
            ...data,
            // Compute setup completeness
            isSetupComplete: Boolean(
                data?.name &&
                data?.address &&
                data?.taxId
            ),
        });
    } catch (error) {
        console.error('GET /v1/business/:id error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * PATCH /v1/business/:id
 * Update business details
 */
router.patch('/business/:id', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const businessId = req.params.id;

        // Verify ownership
        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            return;
        }

        // Rate Limit Check
        const { plan = 'FREE' } = await db.doc(`users/${uid}`).get().then(s => s.data() || {});
        const rateLimit = await checkRequestRateLimit(uid, plan);
        if (!rateLimit.allowed) {
            res.status(429).json({ error: 'Too many requests' });
            return;
        }

        // Allowed fields to update
        const allowedFields = [
            'name',
            'address',
            'phone',
            'email',
            'taxId',
            'defaultVatEnabled',
            'defaultVatRate',
            'defaultWhtEnabled',
            'defaultWhtRate',
            'bankName',
            'bankAccountNo',
            'bankAccountName',
            'paymentMethods',
        ];

        const updates: Record<string, unknown> = {};
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        if (Object.keys(updates).length === 0) {
            res.status(400).json({ error: 'No valid fields to update' });
            return;
        }

        updates.updatedAt = admin.firestore.FieldValue.serverTimestamp();

        await db.doc(`users/${uid}/businesses/${businessId}`).update(updates);

        // Return updated business
        const updatedSnap = await db.doc(`users/${uid}/businesses/${businessId}`).get();

        res.json({
            id: updatedSnap.id,
            ...updatedSnap.data(),
        });
    } catch (error) {
        console.error('PATCH /v1/business/:id error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /v1/business/:id/set-active
 * Set business as active
 */
router.post('/business/:id/set-active', verifyAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
        const db = admin.firestore();
        const uid = req.userId!;
        const businessId = req.params.id;

        // Verify ownership
        const owns = await verifyBusinessOwnership(uid, businessId);
        if (!owns) {
            res.status(404).json({ error: 'Business not found' });
            return;
        }

        await db.doc(`users/${uid}`).update({
            activeBusinessId: businessId,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        res.json({ success: true, activeBusinessId: businessId });
    } catch (error) {
        console.error('POST /v1/business/:id/set-active error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;
