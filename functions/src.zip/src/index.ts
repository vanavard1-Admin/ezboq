// EzDoc/functions/src/index.ts
// Minimal exports for Firebase Functions entrypoint

import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions/v1';

// Initialize Firebase Admin if not already initialized
if (!admin.apps.length) {
  admin.initializeApp({
    storageBucket: process.env.STORAGE_BUCKET || 'ezdoc-v1-th.firebasestorage.app',
  });
}

import { onPdfJobCompleted as onPdfJobCompletedHandler } from './workers/pdfDelivery';

export { lineWebhookV1 } from './lineWebhookV1';
export { deliverLineTaskHandler, deliverPdfTaskHandler } from './tasks';
export { api } from './api';
export { pdfWorkerScheduled, pdfWorkerManual } from './workers/pdfWorker';
export { pdfJobOnCreate } from './workers/pdfJobTrigger';
export { pdfTimeoutTaskHandler } from './workers/pdfTimeoutTask';
export { linkLineStart } from './linkLineStart';
export { linkLineConsume } from './linkLineConsume';
export { checkLineLink } from './checkLineLink';
export { unlinkLine } from './unlinkLine';
export { adminAuditLogs } from './adminAuditLogs';
export { authLineVerify } from './authLineVerify';
export { linkLineComplete } from './linkLineComplete';
export { pdfRedirect } from './pdfRedirect';
export { pushMonthlyReport } from './pushMonthlyReport';
export { cleanupStatsEvents } from './cleanupStatsEvents';
export { processAsyncFailures, cleanupOldFailures } from './scheduled/processAsyncFailures';
export { cleanupProcessedEvents } from './scheduled/cleanupProcessedEvents';
export { retryTimeoutPushesScheduled } from './scheduled/retryTimeoutPushes';
export { processSlipOcrTask } from './tasks/processSlipOcrTask';
export * from './automations/scheduler';
export * from './automations/receipts';

// Rich Menu setup (admin function)
export { setupRichMenu } from './admin/setupRichMenu';

// Credit purchase scheduled triggers
export * from './triggers/purchaseScheduled';

// UX lifecycle scheduled triggers
export { nudgeScheduled } from './triggers/nudgeScheduled';
export { retentionScheduled } from './triggers/retentionScheduled';

/**
 * Firestore trigger: When pdf_generation_jobs/{jobId} status changes to DONE
 * Delivers PDF link to user via LINE push API
 */
export const onPdfJobCompleted = functions
  .region('asia-southeast1')
  .runWith({
    secrets: ['LINE_CHANNEL_ACCESS_TOKEN'],
    memory: '256MB',
    timeoutSeconds: 60,
  })
  .firestore.document('pdf_generation_jobs/{jobId}')
  .onUpdate(async (change: functions.Change<admin.firestore.DocumentSnapshot>) => {
    const beforeData = change.before.data();
    const afterData = change.after.data();

    // ✅ PHASE 2: Check for PDF timeout (PROCESSING > 60-120s)
    const { checkPdfTimeout } = await import('./workers/pdfTimeout');
    await checkPdfTimeout(change).catch((err) => {
      console.error('[onPdfJobCompleted] PDF timeout check failed:', err);
      // Non-blocking - continue to completion handler
    });

    // Only trigger on transition to DONE
    if (beforeData?.status !== 'DONE' && afterData?.status === 'DONE') {
      await onPdfJobCompletedHandler(change.after as unknown as admin.firestore.DocumentSnapshot);
      }
  });
