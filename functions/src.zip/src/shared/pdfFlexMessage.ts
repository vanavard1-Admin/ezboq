/**
 * EzDoc - Shared PDF Flex Message Builder
 *
 * Provides consistent UI for PDF delivery across:
 * - onPdfJobCompleted (push)
 * - REQUEST_PDF (reply)
 * - deliverPdfTaskHandler (Cloud Tasks)
 */

import * as admin from 'firebase-admin';
import * as crypto from 'crypto';

// Short link configuration
const SHORT_URL_BASE = process.env.SHORT_URL_BASE || 'https://ezdoc-v1-th.web.app';
const SHORT_LINK_EXPIRY_DAYS = 90;

/**
 * Document type info for display
 */
export interface DocTypeInfo {
  label: string;
  emoji: string;
  color: string;
}

/**
 * Normalize document type to standard format and get display label
 */
export function getDocTypeInfo(docType: string | undefined): DocTypeInfo {
  const normalized = (docType || '').toUpperCase();

  // Quotation variants
  if (['QUOTATION', 'QUO', 'QT'].includes(normalized)) {
    return { label: 'ใบเสนอราคา', emoji: '📋', color: '#1DB446' };
  }

  // Invoice/Bill variants
  if (['INVOICE', 'INV', 'BILL', 'WB'].includes(normalized)) {
    return { label: 'ใบวางบิล', emoji: '📄', color: '#0066CC' };
  }

  // Receipt variants
  if (['RECEIPT', 'REC', 'RC'].includes(normalized)) {
    return { label: 'ใบเสร็จรับเงิน', emoji: '✅', color: '#00AA00' };
  }

  // Default
  return { label: 'เอกสาร', emoji: '📄', color: '#666666' };
}

/**
 * Generate a cryptographically secure token
 */
function generateSecureToken(): string {
  return crypto.randomBytes(16).toString('base64url');
}

/**
 * Get or create a short link token for a document
 *
 * Uses deterministic token based on docId to enable idempotent lookups
 * without requiring a composite index.
 */
export async function getOrCreateShortLink(params: {
  docId: string;
  docNo: string;
  docType: string;
  pdfPath: string;
  userId: string;
  businessId: string;
}): Promise<string> {
  const { docId, docNo, docType, pdfPath, userId, businessId } = params;
  const db = admin.firestore();

  // Use deterministic token ID based on docId for simple idempotent lookup
  // This avoids complex composite index requirements
  const deterministicId = `doc_${docId}`;
  const existingDoc = await db.collection('pdf_short_links').doc(deterministicId).get();

  if (existingDoc.exists) {
    const existing = existingDoc.data()!;
    const expiresAt = existing.expires_at?.toDate();

    // Return existing token if not expired (with 1 day buffer)
    // and pdf_path matches (in case file was regenerated)
    if (
      existing.pdf_path === pdfPath &&
      expiresAt &&
      expiresAt.getTime() > Date.now() + 24 * 60 * 60 * 1000
    ) {
      return existing.token;
    }
  }

  // Create or update short link
  const token = existingDoc.exists ? existingDoc.data()!.token : generateSecureToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SHORT_LINK_EXPIRY_DAYS);

  await db.collection('pdf_short_links').doc(deterministicId).set({
    token,
    doc_id: docId,
    doc_no: docNo,
    doc_type: docType,
    pdf_path: pdfPath,
    user_id: userId,
    business_id: businessId,
    document_ref: `users/${userId}/businesses/${businessId}/documents/${docId}`,
    created_at: existingDoc.exists
      ? existingDoc.data()!.created_at
      : admin.firestore.FieldValue.serverTimestamp(),
    updated_at: admin.firestore.FieldValue.serverTimestamp(),
    expires_at: admin.firestore.Timestamp.fromDate(expiresAt),
    revoked_at: null,
  });

  // Also ensure the token-based lookup document exists
  await db.collection('pdf_short_links').doc(token).set({
    token,
    doc_id: docId,
    doc_no: docNo,
    doc_type: docType,
    pdf_path: pdfPath,
    user_id: userId,
    business_id: businessId,
    document_ref: `users/${userId}/businesses/${businessId}/documents/${docId}`,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
    expires_at: admin.firestore.Timestamp.fromDate(expiresAt),
    revoked_at: null,
  });

  console.log(`[ShortLink] Created/Updated: /p/${token} -> ${pdfPath}`);
  return token;
}

/**
 * Build short URL from token
 */
export function buildShortUrl(token: string, download = false): string {
  const base = `${SHORT_URL_BASE}/p/${token}`;
  return download ? `${base}?download=1` : base;
}

/**
 * Build Flex message for PDF download
 * Used for both push (onPdfJobCompleted) and reply (REQUEST_PDF)
 */
export function buildPdfFlexMessage(params: {
  documentNo: string;
  downloadUrl: string;
  docTypeInfo: DocTypeInfo;
}): Record<string, unknown> {
  const { documentNo, downloadUrl, docTypeInfo } = params;

  return {
    type: 'flex',
    altText: `${docTypeInfo.emoji} ${docTypeInfo.label} ${documentNo} พร้อมแล้ว`,
    contents: {
      type: 'bubble',
      size: 'kilo',
      header: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: `${docTypeInfo.emoji} ${docTypeInfo.label}`,
            weight: 'bold',
            size: 'lg',
            color: docTypeInfo.color,
          },
        ],
        backgroundColor: '#F7F7F7',
        paddingAll: '15px',
      },
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: documentNo,
            weight: 'bold',
            size: 'xl',
            margin: 'none',
          },
          {
            type: 'text',
            text: 'เอกสารพร้อมดาวน์โหลดแล้ว',
            size: 'sm',
            color: '#666666',
            margin: 'md',
          },
        ],
        paddingAll: '15px',
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'button',
            style: 'primary',
            height: 'md',
            action: {
              type: 'uri',
              label: '📥 ดาวน์โหลด PDF',
              uri: downloadUrl,
            },
            color: docTypeInfo.color,
          },
        ],
        paddingAll: '15px',
      },
    },
  };
}

/**
 * Build Flex message with short link (preferred for security)
 */
export async function buildPdfFlexMessageWithShortLink(params: {
  docId: string;
  docNo: string;
  docType: string;
  pdfPath: string;
  userId: string;
  businessId: string;
}): Promise<Record<string, unknown>> {
  const { docNo, docType } = params;

  // Get or create short link
  const token = await getOrCreateShortLink(params);
  const downloadUrl = buildShortUrl(token);

  // Get doc type info
  const docTypeInfo = getDocTypeInfo(docType);

  return buildPdfFlexMessage({
    documentNo: docNo,
    downloadUrl,
    docTypeInfo,
  });
}

