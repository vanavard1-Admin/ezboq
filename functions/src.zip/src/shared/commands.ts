/**
 * EzDoc - Canonical Commands
 * 
 * Single Source of Truth for all command text (button text)
 * 
 * RULES:
 * - NO emoji in command text (emoji only in labels)
 * - Commands are lowercase, trimmed, normalized
 * - All aliases map to canonical commands
 * - Used by buttonActionMap and quickReplies
 */

/**
 * Document Creation Commands
 */
export const CMD_CREATE_QUOTATION = 'ทำใบเสนอราคา';
export const CMD_CREATE_INVOICE = 'ทำใบวางบิล';
export const CMD_CREATE_RECEIPT = 'ทำใบเสร็จ';
export const CMD_CREATE_INVOICE_FROM_QUOTATION = 'ใบวางบิล จากใบเสนอราคา';

/**
 * Navigation Commands
 */
export const CMD_MENU = 'เมนูหลัก';
export const CMD_BACK_TO_MENU = 'กลับเมนู';
export const CMD_HELP = 'ช่วยเหลือ';
export const CMD_USAGE_GUIDE = 'วิธีใช้งาน';

/**
 * Business Setup Commands
 */
export const CMD_BUSINESS_SETUP = 'ตั้งค่าธุรกิจ';
export const CMD_BUSINESS_SAVE = 'บันทึกข้อมูล';
export const CMD_BUSINESS_EDIT = 'แก้ไขอีกครั้ง';

/**
 * Draft Editing Commands
 */
export const CMD_ADD_ITEM = 'เพิ่มรายการ';
export const CMD_EDIT_ITEM = 'แก้ไขรายการ';
export const CMD_REMOVE_ITEM = 'ลบรายการ';
export const CMD_CONFIRM = 'ยืนยัน';
export const CMD_CONFIRM_DOCUMENT = 'ยืนยันออกเอกสาร';
export const CMD_CANCEL = 'ยกเลิก';
export const CMD_UNDO = 'ย้อนกลับ';

/**
 * Wizard Commands
 */
export const CMD_WIZARD_BACK = 'ย้อนกลับ';
export const CMD_WIZARD_SKIP = 'ข้าม';
export const CMD_WIZARD_CANCEL = 'ยกเลิก';

/**
 * Payment Commands
 */
export const CMD_PAID = 'ชำระแล้ว';
export const CMD_CONFIRM_PAYMENT = 'ยืนยันรับเงิน';
export const CMD_PAYMENT_CANCEL = 'ยังไม่ใช่';
export const CMD_RETRY_SLIP = 'ส่งสลิปอีกครั้ง';

/**
 * Report Commands
 */
export const CMD_REPORT = 'รายงาน';
export const CMD_REPORT_THIS_MONTH = 'รายงาน เดือนนี้';
export const CMD_REPORT_LAST_MONTH = 'รายงาน เดือนก่อน';
export const CMD_REPORT_CUSTOM = 'รายงาน เดือน 12/2568'; // Template

/**
 * View Commands
 */
export const CMD_VIEW_LATEST_DOCUMENT = 'ดูเอกสารล่าสุด';

/**
 * Credit Purchase Commands
 */
export const CMD_BUY_PACK_99 = 'ซื้อแพ็ค 99';
export const CMD_BUY_PACK_299 = 'ซื้อแพ็ค 299';
export const CMD_CREDIT_HISTORY = 'ประวัติการซื้อเครดิต';
export const CMD_CONFIRM_CREDIT_PAYMENT = 'ยืนยันการชำระเงิน';

/**
 * Settings Commands
 */
export const CMD_SETTINGS_PROMPTPAY = 'ตั้งค่าพร้อมเพย์';
export const CMD_SETTINGS_BANK = 'ตั้งค่าธนาคาร';
export const CMD_SETTINGS_LOGO = 'ตั้งค่าโลโก้';
export const CMD_SETTINGS_SIGNATURE = 'ตั้งค่าลายเซ็น';
export const CMD_SETTINGS_STAMP = 'ตั้งค่าตราประทับ';

/**
 * Command Aliases Map
 * Maps alternative text → canonical command
 * Used for backward compatibility and typo tolerance
 */
export const COMMAND_ALIASES: Record<string, string> = {
  // Document creation aliases
  'สร้างเอกสาร': CMD_CREATE_QUOTATION,
  'สร้างใบเสนอราคา': CMD_CREATE_QUOTATION,
  'เริ่มใหม่': CMD_CREATE_INVOICE,
  
  // Navigation aliases
  'เมนู': CMD_MENU,
  '🏠 เมนูหลัก': CMD_MENU,
  
  // Draft editing aliases
  '✅ ยืนยัน': CMD_CONFIRM,
  'ยืนยันอีกครั้ง': CMD_CONFIRM,
  
  // Wizard aliases (CMD_WIZARD_BACK uses CMD_UNDO - same text 'ย้อนกลับ')
  // Note: Wizard context is determined separately, not by command text
  
  // Credit purchase aliases (no space variants)
  'ซื้อแพ็ค99': CMD_BUY_PACK_99,
  'ซื้อแพ็ค299': CMD_BUY_PACK_299,
  'แพ็ค 99': CMD_BUY_PACK_99,
  'แพ็ค 299': CMD_BUY_PACK_299,
};

/**
 * Get canonical command from text (handles aliases)
 */
export function getCanonicalCommand(text: string): string {
  const normalized = text.trim().toLowerCase();
  
  // Check aliases first
  const aliasMatch = COMMAND_ALIASES[text.trim()];
  if (aliasMatch) {
    return aliasMatch;
  }
  
  // Case-insensitive alias check
  for (const [alias, canonical] of Object.entries(COMMAND_ALIASES)) {
    if (alias.toLowerCase() === normalized) {
      return canonical;
    }
  }
  
  // Return original if no alias found
  return text.trim();
}

/**
 * Check if text is a canonical command
 */
export function isCanonicalCommand(text: string): boolean {
  const canonical = getCanonicalCommand(text);
  const allCommands = [
    CMD_CREATE_QUOTATION,
    CMD_CREATE_INVOICE,
    CMD_CREATE_RECEIPT,
    CMD_CREATE_INVOICE_FROM_QUOTATION,
    CMD_MENU,
    CMD_BACK_TO_MENU,
    CMD_HELP,
    CMD_USAGE_GUIDE,
    CMD_BUSINESS_SETUP,
    CMD_BUSINESS_SAVE,
    CMD_BUSINESS_EDIT,
    CMD_ADD_ITEM,
    CMD_EDIT_ITEM,
    CMD_REMOVE_ITEM,
    CMD_CONFIRM,
    CMD_CONFIRM_DOCUMENT,
    CMD_CANCEL,
    CMD_UNDO,
    CMD_WIZARD_BACK,
    CMD_WIZARD_SKIP,
    CMD_WIZARD_CANCEL,
    CMD_PAID,
    CMD_CONFIRM_PAYMENT,
    CMD_PAYMENT_CANCEL,
    CMD_RETRY_SLIP,
    CMD_REPORT,
    CMD_REPORT_THIS_MONTH,
    CMD_REPORT_LAST_MONTH,
    CMD_REPORT_CUSTOM,
    CMD_VIEW_LATEST_DOCUMENT,
    CMD_BUY_PACK_99,
    CMD_BUY_PACK_299,
    CMD_CREDIT_HISTORY,
    CMD_CONFIRM_CREDIT_PAYMENT,
    CMD_SETTINGS_PROMPTPAY,
    CMD_SETTINGS_BANK,
    CMD_SETTINGS_LOGO,
    CMD_SETTINGS_SIGNATURE,
    CMD_SETTINGS_STAMP,
  ];
  
  return allCommands.includes(canonical);
}

