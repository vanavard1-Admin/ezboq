/**
 * EzDoc Configuration
 * Environment variables and constants
 */

// LINE Configuration
export const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET || '';
export const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';

// GCP/Firebase Configuration
export const GCP_PROJECT_ID = process.env.GCP_PROJECT_ID || '';

// PDF Service Configuration
export const PDF_SERVICE_URL = process.env.PDF_SERVICE_URL || 'http://localhost:8080/jobs/render-pdf';
export const PDF_SERVICE_AUDIENCE = process.env.PDF_SERVICE_AUDIENCE || '';
// PDF render-buffer endpoint used by pdfWorker (returns application/pdf bytes)
export const PDF_RENDER_URL =
  process.env.PDF_RENDER_URL ||
  process.env.PDF_SERVICE_URL ||
  'http://localhost:8080/jobs/render-buffer';

// Settings
export const DEFAULT_SIGNED_URL_EXPIRE_DAYS = Number(process.env.DEFAULT_SIGNED_URL_EXPIRE_DAYS || 7);

// Default Tax Settings
export const DEFAULT_VAT_RATE = 7; // %
export const DEFAULT_WHT_RATE = 3; // %

// Document Prefix
export const DOC_PREFIX = {
    QUO: 'QU',
    BILL: 'BL',
    RECEIPT: 'RC',
} as const;

// LINE API Endpoints
export const LINE_API = {
    REPLY: 'https://api.line.me/v2/bot/message/reply',
    PUSH: 'https://api.line.me/v2/bot/message/push',
    CONTENT: 'https://api-data.line.me/v2/bot/message',
} as const;

// Timeouts
export const DRAFT_EXPIRE_MINUTES = 30;

// Cloud Tasks Configuration
export const CLOUD_TASKS_QUEUE = process.env.CLOUD_TASKS_QUEUE || 'ezdoc-pdf-jobs';
export const CLOUD_TASKS_LOCATION = process.env.CLOUD_TASKS_LOCATION || 'asia-southeast1';
export const PDF_SERVICE_ACCOUNT = process.env.PDF_SERVICE_ACCOUNT || '';
export const USE_CLOUD_TASKS = process.env.USE_CLOUD_TASKS === 'true';
// Delivery worker endpoint (Cloud Tasks will POST here)
export const DELIVERY_TASK_URL = process.env.DELIVERY_TASK_URL || '';
export const DELIVERY_SERVICE_ACCOUNT = process.env.DELIVERY_SERVICE_ACCOUNT || PDF_SERVICE_ACCOUNT;
// Audience expected in OIDC token for delivery tasks. Defaults to DELIVERY_TASK_URL if not set.
export const DELIVERY_TASK_AUDIENCE = process.env.DELIVERY_TASK_AUDIENCE || process.env.DELIVERY_TASK_URL || '';

// Feature Flags
export const HUMAN_FIRST_UX_ENABLED = process.env.HUMAN_FIRST_UX === '1' || process.env.HUMAN_FIRST_UX === 'true';

// PDF Timeout Task Configuration (SECURITY SEV-0)
// Audience expected in OIDC token for timeout tasks. Must match function URL in production.
export const TIMEOUT_TASK_AUDIENCE = process.env.TIMEOUT_TASK_AUDIENCE || '';
// Service account email used by Cloud Tasks to sign OIDC token
export const TIMEOUT_TASK_SERVICE_ACCOUNT = process.env.TIMEOUT_TASK_SERVICE_ACCOUNT || '';
