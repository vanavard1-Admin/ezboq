/**
 * PDF Delivery Task Handler
 * Delivers PDF link to LINE user after generation
 */

import * as functions from 'firebase-functions/v2';
import * as admin from 'firebase-admin';
import fetch from 'node-fetch';
import * as crypto from 'crypto';
import { incrementPdfDelivery } from '../core/statsMonthly';
import { SIGNED_URL_DAYS, signPdfPath } from '../shared/pdfSigning';

// Initialize Firebase Admin if not already initialized
if (!admin.apps.length) {
  admin.initializeApp();
}

const LINE_API_URL = 'https://api.line.me/v2/bot/message/push';
// Note: LINE_CHANNEL_ACCESS_TOKEN must be read inside function, not at module level
// because secrets are injected at runtime, not build time

// Short link config
const SHORT_LINK_EXPIRY_DAYS = 90; // Links expire after 90 days
// Single source of truth for PDF signed URL policy (Option B)
const PDF_SIGNED_URL_DAYS = SIGNED_URL_DAYS;

/**
 * Generate cryptographically secure random token
 * 16 bytes = 128 bits = 22 characters base64url
 */
function generateSecureToken(): string {
  return crypto.randomBytes(16).toString('base64url');
}

// Document type titles in Thai
const DOC_TITLES: { [key: string]: string } = {
  QT: 'ใบเสนอราคา',
  WB: 'ใบวางบิล/ใบแจ้งหนี้',
  RC: 'ใบเสร็จรับเงิน',
};

interface PdfDeliveryPayload {
  userId: string;
  docId: string;
  docType: string;
  docNo: string;
  pdfUrl?: string;      // Optional - can generate from pdf_path
  businessId?: string;  // REQUIRED for nested system-of-record (legacy payloads will be rejected)
}

// ✅ Base URL for short links (Firebase Hosting)
const SHORT_URL_BASE = 'https://ezdoc-v1-th.web.app';

/**
 * Send PDF link via LINE Flex Message with View/Download buttons
 * ✅ Uses tokenized short URLs (secure + shareable)
 * ✅ Two buttons: View (inline) and Download (attachment)
 */
async function sendPdfToLine(
  lineUserId: string,
  docType: string,
  docNo: string,
  shortToken: string  // ← Secure random token (not docId)
): Promise<void> {
  // ✅ Read token at runtime (not module level) because secret is injected at runtime
  const lineToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
  
  // Log for debugging (don't log actual token!)
  console.log(`[LINE] token present: ${!!lineToken}, len: ${lineToken.length}`);
  
  if (!lineToken) {
    throw new Error('LINE_CHANNEL_ACCESS_TOKEN not configured');
  }
  
  const docTitle = DOC_TITLES[docType] || 'เอกสาร';
  const emoji = docType === 'QT' ? '📋' : docType === 'RC' ? '✅' : '📄';
  
  // ✅ Tokenized short URLs (secure + shareable)
  const viewUrl = `${SHORT_URL_BASE}/p/${shortToken}`;
  const downloadUrl = `${SHORT_URL_BASE}/p/${shortToken}?download=1`;
  
  // ✅ Flex Message with beautiful card + 2 buttons
  const flexMessage = {
    type: 'flex',
    altText: `${docTitle} ${docNo} พร้อมแล้ว - ${viewUrl}`,
    contents: {
      type: 'bubble',
      size: 'kilo',
      header: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: `${emoji} ${docTitle}`,
            weight: 'bold',
            size: 'lg',
            color: '#1DB446',
          },
        ],
        backgroundColor: '#F7F7F7',
        paddingAll: '15px',
      },
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: docNo,
            weight: 'bold',
            size: 'xl',
            margin: 'none',
          },
          {
            type: 'text',
            text: 'เอกสารพร้อมดาวน์โหลดแล้ว',
            size: 'sm',
            color: '#666666',
            margin: 'md',
          },
          {
            type: 'separator',
            margin: 'lg',
          },
          {
            type: 'box',
            layout: 'horizontal',
            margin: 'lg',
            contents: [
              {
                type: 'text',
                text: `⏰ ลิงก์หมดอายุใน ${PDF_SIGNED_URL_DAYS} วัน`,
                size: 'xs',
                color: '#999999',
                flex: 0,
              },
            ],
          },
        ],
        paddingAll: '15px',
      },
      footer: {
        type: 'box',
        layout: 'horizontal',
        spacing: 'sm',
        contents: [
          {
            type: 'button',
            style: 'secondary',
            height: 'sm',
            action: {
              type: 'uri',
              label: '👁️ เปิดดู',
              uri: viewUrl,
            },
            flex: 1,
          },
          {
            type: 'button',
            style: 'primary',
            height: 'sm',
            action: {
              type: 'uri',
              label: '📥 ดาวน์โหลด',
              uri: downloadUrl,
            },
            color: '#1DB446',
            flex: 1,
          },
        ],
        paddingAll: '15px',
      },
    },
  };
  
  const response = await fetch(LINE_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${lineToken}`,
    },
    body: JSON.stringify({
      to: lineUserId,
      messages: [flexMessage],
    }),
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`LINE API error ${response.status}: ${errorText}`);
  }
  
  console.log(`[PDF Delivery] Flex message sent to LINE user ${lineUserId}`);
}

/**
 * Send error notification via LINE push message
 * ✅ Safety net: inform user when PDF delivery fails
 */
async function sendErrorToLine(
  lineUserId: string,
  errorMessage: string
): Promise<void> {
  const token = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
  
  if (!token) {
    throw new Error('LINE_CHANNEL_ACCESS_TOKEN not configured');
  }
  
  const message = {
    type: 'text',
    text: errorMessage,
  };
  
  const response = await fetch(LINE_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({
      to: lineUserId,
      messages: [message],
    }),
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`LINE API error ${response.status}: ${errorText}`);
  }
}

/**
 * Cloud Function handler for PDF delivery tasks
 * 
 * Triggered by Cloud Tasks from deliveryQueueService
 * 
 * Payload:
 *   {
 *     userId: string,      // Firestore userId (not LINE userId)
 *     docId: string,
 *     docType: string,
 *     docNo: string,
 *     pdfUrl: string
 *   }
 */
export const deliverPdfTaskHandler = functions.https.onRequest(
  {
    region: 'asia-southeast1',
    timeoutSeconds: 60,
    memory: '256MiB',
    secrets: ['LINE_CHANNEL_ACCESS_TOKEN'], // ← Add secret access
  },
  async (req, res) => {
    try {
      // Only accept POST
      if (req.method !== 'POST') {
        res.status(405).json({ error: 'Method not allowed' });
        return;
      }
      
      const payload = req.body as PdfDeliveryPayload;
      const { userId, docId, docType, docNo, businessId } = payload;
      const { pdfUrl } = payload;
      
      console.log(`[PDF Delivery] Task received for doc ${docId}`);
      
      // Validate payload (pdfUrl is optional - can generate from pdf_path)
      if (!userId || !docId || !docType || !docNo) {
        res.status(400).json({ 
          error: 'INVALID_PAYLOAD',
          message: 'Missing required fields (userId, docId, docType, docNo)',
        });
        return;
      }
      
      // Get LINE userId from user account
      const db = admin.firestore();
      const userSnap = await db.collection('users').doc(userId).get();
      
      if (!userSnap.exists) {
        console.error(`[PDF Delivery] User ${userId} not found`);
        res.status(404).json({ 
          error: 'USER_NOT_FOUND',
          message: `User ${userId} not found`,
        });
        return;
      }
      
      const userData = userSnap.data()!;
      const lineUserId = userData.lineUserId;
      
      if (!lineUserId) {
        console.error(`[PDF Delivery] User ${userId} has no LINE account linked`);
        res.status(400).json({ 
          error: 'NO_LINE_ACCOUNT',
          message: 'User has no LINE account linked',
        });
        return;
      }
      
      // Send PDF link via LINE
      try {
        // ✅ System of Record: nested documents only
        if (!businessId) {
          res.status(400).json({
            error: 'MISSING_BUSINESS_ID',
            message: 'businessId is required (nested documents are the only source of truth)',
          });
          return;
        }

        const docRef = db.doc(`users/${userId}/businesses/${businessId}/documents/${docId}`);
        
        console.log(`[PDF Delivery] Document path: ${docRef.path}`);
        
        let canDeliver = false;
        let currentAttempts = 0;
        let shouldNotifyError = false;  // ✅ Safety net: flag to send error notification
        let errorNotifyMessage = '';    // ✅ Error message to send to user
        let finalPdfUrl = pdfUrl; // May be generated from pdf_path
        
        await db.runTransaction(async (transaction) => {
          const docSnap = await transaction.get(docRef);
          
          if (!docSnap.exists) {
            throw new Error(`Document ${docId} not found`);
          }
          
          const docData = docSnap.data()!;
          const status = docData.pdf_delivery_status;
          
          // ✅ If no pdfUrl provided, generate from pdf_path
          if (!finalPdfUrl && docData.pdf_path) {
            console.log(`[PDF Delivery] Generating signed URL from pdf_path: ${docData.pdf_path}`);
            const bucket = admin.storage().bucket();
            const file = bucket.file(docData.pdf_path);
            
            // ✅ HARD GUARD 1: Check if file exists before signing
            const [exists] = await file.exists();
            if (!exists) {
              const errorMsg = `PDF object not found: gs://${bucket.name}/${docData.pdf_path}`;
              console.error(`[PDF Delivery] ${errorMsg}`);
              
              // Update status to FAILED and exit transaction
              transaction.update(docRef, {
                pdf_delivery_status: 'FAILED',
                pdf_delivery_error: 'PDF_OBJECT_NOT_FOUND',
                pdf_delivery_error_detail: errorMsg,
                updated_at: admin.firestore.FieldValue.serverTimestamp(),
              });
              
              // ✅ SAFETY NET: Flag to send error notification to user
              shouldNotifyError = true;
              errorNotifyMessage = '⚠️ ขออภัย ไฟล์ PDF ยังไม่พร้อม กรุณาลองใหม่อีกครั้ง หรือติดต่อเจ้าหน้าที่';
              
              canDeliver = false;
              return; // Exit transaction - do NOT send LINE with dead link
            }
            
            // ✅ HARD GUARD 2: Check file size (must be > 1KB to be a valid PDF)
            // 1KB is enough to catch 68-byte placeholders while allowing small but valid PDFs
            const MIN_PDF_BYTES = 1000; // 1KB minimum for a real PDF
            const [metadata] = await file.getMetadata();
            const fileSize = parseInt(metadata.size as string, 10) || 0;
            
            console.log(`[PDF Delivery] File size: ${fileSize} bytes`);
            
            if (fileSize < MIN_PDF_BYTES) {
              const errorMsg = `PDF file too small (${fileSize} bytes < ${MIN_PDF_BYTES}): gs://${bucket.name}/${docData.pdf_path}`;
              console.error(`[PDF Delivery] ${errorMsg}`);
              
              // Update status to FAILED and exit transaction
              transaction.update(docRef, {
                pdf_delivery_status: 'FAILED',
                pdf_delivery_error: 'PDF_INVALID_SIZE',
                pdf_delivery_error_detail: errorMsg,
                updated_at: admin.firestore.FieldValue.serverTimestamp(),
              });
              
              // ✅ SAFETY NET: Flag to send error notification to user
              shouldNotifyError = true;
              errorNotifyMessage = '⚠️ ขออภัย ระบบสร้างไฟล์ PDF ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง หรือติดต่อเจ้าหน้าที่';
              
              canDeliver = false;
              return; // Exit transaction - do NOT send LINE with invalid PDF
            }
            
            // ✅ Safe to sign - file exists AND has valid size
            // Use shared helper (single source of truth)
            finalPdfUrl = await signPdfPath(String(docData.pdf_path), { days: PDF_SIGNED_URL_DAYS });
          }
          
          if (!finalPdfUrl) {
            throw new Error(`No pdfUrl and no pdf_path for document ${docId}`);
          }
          
          // ✅ Check if already delivered (idempotent)
          if (status === 'SENT') {
            console.log(`[PDF Delivery] Doc ${docId} already SENT - skipping`);
            canDeliver = false;
            return;
          }
          
          // ✅ Check if stale SENDING (stuck for > 5 minutes)
          if (status === 'SENDING') {
            const claimedAt = docData.pdf_delivery_claimed_at?.toDate();
            const now = new Date();
            const staleThresholdMs = 5 * 60 * 1000; // 5 minutes
            
            // ✅ ถ้าไม่มี claimed_at → skip (อาจเป็น concurrent claim)
            if (!claimedAt) {
              console.log(`[PDF Delivery] Doc ${docId} SENDING without claimed_at - skipping (concurrent claim)`);
              canDeliver = false;
              return;
            }
            
            // ✅ Check if fresh claim (< 5 min)
            if ((now.getTime() - claimedAt.getTime()) < staleThresholdMs) {
              console.log(`[PDF Delivery] Doc ${docId} already SENDING by another task (fresh < 5min) - skipping`);
              canDeliver = false;
              return;
            }
            
            // ✅ Stale claim (> 5 min) → takeover
            console.log(`[PDF Delivery] Doc ${docId} has stale SENDING (> 5 min) - taking over`);
            // Fall through to claim SENDING again (override stale)
          }
          
          // ✅ Claim SENDING status (atomic lock) - use Timestamp.now() for immediate value
          currentAttempts = (docData.pdf_delivery_attempts || 0) + 1;
          const claimTime = admin.firestore.Timestamp.now();
          transaction.update(docRef, {
            pdf_delivery_status: 'SENDING',
            pdf_delivery_claimed_at: claimTime, // ← Use Timestamp.now() - immediate value
            pdf_delivery_attempts: currentAttempts,
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          canDeliver = true;
        });
        
        // ✅ SAFETY NET: Send error notification to user if file was missing
        if (shouldNotifyError && errorNotifyMessage) {
          console.log(`[PDF Delivery] Sending error notification to user`);
          try {
            await sendErrorToLine(lineUserId, errorNotifyMessage);
            console.log(`[PDF Delivery] Error notification sent successfully`);
          } catch (notifyErr) {
            console.error(`[PDF Delivery] Failed to send error notification:`, notifyErr);
            // Don't fail the whole request - error is already logged
          }
        }
        
        // ✅ If transaction failed to claim, return early
        if (!canDeliver) {
          res.json({
            success: true,
            message: 'PDF already delivered or being delivered (idempotent)',
            docId,
          });
          return;
        }
        
        // ✅ Check DRY_RUN mode (for testing without actual LINE delivery)
        const isDryRun = req.query.dryRun === '1' || req.headers['x-dry-run'] === '1';
        
        if (isDryRun) {
          console.log(`[PDF Delivery] DRY_RUN mode - skipping LINE API call`);
          
          // ✅ Update status to SENT immediately (no actual delivery)
          await docRef.update({
            pdf_delivered_at: admin.firestore.FieldValue.serverTimestamp(),
            pdf_delivery_status: 'SENT',
            pdf_delivery_error: admin.firestore.FieldValue.delete(),
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          res.json({
            success: true,
            message: 'PDF delivery simulated (DRY_RUN)',
            docId,
            dryRun: true,
          });
          return;
        }
        
        // ✅ Now safe to send LINE message (only 1 task reaches here)
        console.log(`[PDF Delivery] Sending to LINE (attempt ${currentAttempts})`);
        
        // Final guard: ensure we have a valid PDF path (URL generation verified earlier)
        if (!finalPdfUrl) {
          console.error(`[PDF Delivery] No PDF URL available for doc ${docId}`);
          await docRef.update({
            pdf_delivery_status: 'FAILED',
            pdf_delivery_error: 'NO_PDF_URL',
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          });
          res.status(500).json({
            error: 'NO_PDF_URL',
            message: 'Failed to generate PDF URL',
          });
          return;
        }
        
        try {
          // ✅ Get document data for short link
          const docSnap = await docRef.get();
          const docData = docSnap.data();
          const pdfPath = docData?.pdf_path;
          
          // ✅ Generate secure random token for short link
          const shortToken = generateSecureToken();
          
          // ✅ Calculate expiry date
          const expiresAt = new Date();
          expiresAt.setDate(expiresAt.getDate() + SHORT_LINK_EXPIRY_DAYS);
          
          // ✅ Create tokenized short link mapping
          const db = admin.firestore();
          await db.collection('pdf_short_links').doc(shortToken).set({
            token: shortToken,
            doc_id: docId,
            doc_no: docNo,
            doc_type: docType,
            pdf_path: pdfPath,
            user_id: userId,
            business_id: businessId || null,
            document_ref: docRef.path,
            created_at: admin.firestore.FieldValue.serverTimestamp(),
            expires_at: admin.firestore.Timestamp.fromDate(expiresAt),
            revoked_at: null,
          });
          
          console.log(`[PDF Delivery] Created secure short link: /p/${shortToken} → ${pdfPath} (expires: ${expiresAt.toISOString()})`);
          
          // ✅ Send LINE message with tokenized short URL
          await sendPdfToLine(lineUserId, docType, docNo, shortToken);
          
          console.log(`[PDF Delivery] Successfully delivered doc ${docId} to user ${userId}`);
          
          // ✅ Update status to SENT + store token reference
          await docRef.update({
            pdf_delivered_at: admin.firestore.FieldValue.serverTimestamp(),
            pdf_delivery_status: 'SENT',
            pdf_short_token: shortToken,  // Store token for reference
            pdf_delivery_error: admin.firestore.FieldValue.delete(), // Clear any previous error
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          // ✅ Write-through stats update (non-blocking, idempotent by docId)
          if (businessId) {
            incrementPdfDelivery(businessId, true, docId).catch(err => {
              console.error('[PDF Delivery] Stats update failed (non-blocking):', err);
            });
          }
          
          res.json({
            success: true,
            message: 'PDF delivered successfully',
            docId,
            shortUrl: `${SHORT_URL_BASE}/p/${shortToken}`,
          });
          
        } catch (lineError: any) {
          console.error(`[PDF Delivery] LINE API error:`, lineError);
          
          // ✅ Update status to FAILED (so it can be retried)
          await docRef.update({
            pdf_delivery_status: 'FAILED',
            pdf_delivery_error: lineError.message,
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          // ✅ Write-through stats update for failure (non-blocking, idempotent by docId)
          if (businessId) {
            incrementPdfDelivery(businessId, false, docId).catch(err => {
              console.error('[PDF Delivery] Stats update failed (non-blocking):', err);
            });
          }
          
          // Return 500 to trigger retry by Cloud Tasks
          res.status(500).json({
            error: 'LINE_API_ERROR',
            message: lineError.message,
          });
        }
        
      } catch (transactionError: any) {
        console.error(`[PDF Delivery] Transaction error:`, transactionError);
        res.status(500).json({
          error: 'TRANSACTION_ERROR',
          message: transactionError.message,
        });
      }
      
    } catch (error: any) {
      console.error('[PDF Delivery] Task handler error:', error);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: error.message,
      });
    }
  }
);
