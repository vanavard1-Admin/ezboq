import * as functions from 'firebase-functions/v1';
import admin from 'firebase-admin';
import fetch from 'node-fetch';
import { LINE_CHANNEL_ACCESS_TOKEN, DELIVERY_TASK_AUDIENCE } from '../shared/config';
import { buildLineDeliveryMessage, BusinessData, DocData } from '../line/messages';
import { OAuth2Client } from 'google-auth-library';
import { assertTransition, logStatusTransition, DocumentState } from '../core/stateMachine'; // Spec v1.0

// Initialize Firebase Admin SDK if not already initialized
if (!admin.apps.length) {
  admin.initializeApp();
}

// Backoff schedule (seconds)
const BACKOFF = [10, 60, 5 * 60, 30 * 60, 60 * 60]; // upto 5 attempts recommended

function getBackoffForAttempt(attempt: number) {
  return BACKOFF[Math.min(attempt - 1, BACKOFF.length - 1)] || 60;
}

// Error classification for LINE API responses
type LineErrorReason = 'INVALID_TO' | 'BLOCKED' | 'INVALID_PAYLOAD' | 'AUTH_ERROR' | 'UNKNOWN';

interface LineErrorClassification {
  reason: LineErrorReason;
  message: string;
  isRetryable: boolean;
}

function classifyLineError(status: number, text: string): LineErrorClassification {
  // 400 Bad Request - multiple causes
  if (status === 400) {
    // Invalid 'to' field (user doesn't exist or invalid format)
    if (text.includes('The property') && text.includes('\'to\'')) {
      return {
        reason: 'INVALID_TO',
        message: 'Recipient userId is invalid, expired, or no longer exists',
        isRetryable: false
      };
    }
    // User blocked bot or is not a friend
    if (text.match(/blocked|not found|target/i)) {
      return {
        reason: 'BLOCKED',
        message: 'User blocked bot or is no longer a friend',
        isRetryable: false
      };
    }
    // Message payload is malformed
    if (text.includes('Message') || text.includes('message')) {
      return {
        reason: 'INVALID_PAYLOAD',
        message: 'Message template or content is malformed',
        isRetryable: false
      };
    }
  }

  // 401/403 Unauthorized - token issue
  if (status === 401 || status === 403) {
    return {
      reason: 'AUTH_ERROR',
      message: 'Channel Access Token is invalid or expired',
      isRetryable: true
    };
  }

  // Unknown error
  return {
    reason: 'UNKNOWN',
    message: `HTTP ${status}: ${text.slice(0, 100)}`,
    isRetryable: status >= 500 || status === 429
  };
}

export const deliverLineTaskHandler = functions
  .region('asia-southeast1')
  .runWith({
    timeoutSeconds: 300,
    memory: '256MB',
    // Bind secrets to ensure DELIVERY_* and LINE token are present in runtime
    secrets: [
      'DELIVERY_TASK_URL',
      'DELIVERY_TASK_AUDIENCE',
      'DELIVERY_SERVICE_ACCOUNT',
      'LINE_CHANNEL_ACCESS_TOKEN',
    ],
  })
  .https.onRequest(async (req: functions.https.Request, res: functions.Response) => {
    try {
      if (req.method !== 'POST') {
        res.status(405).send('Method not allowed');
        return;
      }

      // Verify OIDC token from Cloud Tasks (Authorization: Bearer <token>) if configured
      try {
        const authHeader = (req.get('authorization') || req.get('Authorization') || '') as string;
        if (!authHeader) {
          console.warn('Missing Authorization header on delivery task');
          res.status(401).send('Unauthorized');
          return;
        }
        const match = authHeader.match(/^Bearer\s+(.*)$/i);
        if (!match) {
          console.warn('Invalid Authorization header format');
          res.status(401).send('Unauthorized');
          return;
        }
        const idToken = match[1];
        const audience = DELIVERY_TASK_AUDIENCE || '';
        if (!audience) {
          console.warn('No DELIVERY_TASK_AUDIENCE configured; skipping token verification');
        } else {
          const client = new OAuth2Client();
          try {
            await client.verifyIdToken({ idToken, audience });
          } catch (e) {
            console.warn('OIDC token verification failed', e);
            res.status(401).send('Unauthorized');
            return;
          }
        }
      } catch (e) {
        console.warn('Token verification error', e);
        res.status(401).send('Unauthorized');
        return;
      }

      const body = req.body || {};
      const jobId = body.jobId as string | undefined;
      const traceId = body.traceId as string | undefined; // ✅ Extract traceId from payload
      if (!jobId) {
        res.status(400).send('Missing jobId');
        return;
      }

      // Log with correlation ID
      console.log(`[deliverLine] Processing delivery: jobId=${jobId}, traceId=${traceId || 'n/a'}`);
      const db = admin.firestore();
      const jobRef = db.doc(`deliveryJobs/${jobId}`);
      console.log('[deliverLine] Fetching job document...');
      const jobSnap = await jobRef.get();
      console.log('[deliverLine] Job snapshot exists:', jobSnap.exists);
      if (!jobSnap.exists) {
        // Nothing to do
        console.log('[deliverLine] Job not found, returning 200');
        res.status(200).send('Job not found');
        return;
      }

      type DeliveryJob = {
        status?: string;
        docPath?: string;
        docId?: string;
        userId?: string;
        businessId?: string;
        attempt?: number;
        to?: { lineUserId?: string } | null;
        lineUserId?: string | null;
      };

      // Atomic status check and claim (prevent duplicate delivery)
      type TransactionResult = {
        canSend: boolean;
        job: DeliveryJob;
        docRef: admin.firestore.DocumentReference;
      } | null;
      
      const result: TransactionResult = await db.runTransaction(async (tx) => {
        const jobSnap = await tx.get(jobRef);
        if (!jobSnap.exists) {
          return null;
        }
        
        const job = jobSnap.data() as DeliveryJob;
        
        // Check status INSIDE transaction
        if (job.status === 'SENT') {
          return null; // Already sent
        }
        
        // Resolve docRef
        let resolvedDocRef: admin.firestore.DocumentReference | null = null;
        if (job.docPath) {
          resolvedDocRef = db.doc(job.docPath);
        } else if (job.userId && job.businessId && job.docId) {
          const possibleRef = db.doc(`users/${job.userId}/businesses/${job.businessId}/documents/${job.docId}`);
          const possibleSnap = await tx.get(possibleRef);
          if (possibleSnap.exists) {
            resolvedDocRef = possibleRef;
          }
        }
        
        if (!resolvedDocRef) {
          // Mark as FAILED
          tx.update(jobRef, {
            status: 'FAILED',
            attempt: (job.attempt || 0) + 1,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            lastError: { message: 'Document not found' },
            expiresAt: admin.firestore.Timestamp.fromDate(
              new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
            ),
          });
          return null;
        }
        
        // Claim SENDING status (atomic)
        tx.update(jobRef, {
          status: 'SENDING',
          attempt: (job.attempt || 0) + 1,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        
        return {
          canSend: true,
          job: { ...job },
          docRef: resolvedDocRef,
        };
      });
      
      if (!result || !result.canSend) {
        res.status(200).send('Already sent or processing');
        return;
      }
      
      const { job, docRef } = result;
      
      console.log('[deliverLine] Fetching document...');
      const docSnap = await docRef.get();
      console.log('[deliverLine] Document exists:', docSnap.exists);
      type DocumentData = {
        docNo?: string;
        status?: string; // Spec v1.0
        pdfState?: string;
        pdfUrl?: string;
        pdfPath?: string;
        pdf_path?: string;
        supersedes_document_id?: string | null;
        origin_document_id?: string | null;
      };
      const doc = docSnap.data() as DocData & DocumentData;

      console.log('[deliverLine] Document status:', doc?.status);

      // Spec v1.0: Transition Guard using DocumentStatus (Source of Truth)
      // Check if document is in PDF_READY state
      // (Legacy fallback: check pdfState if status is missing?)
      const currentStatus = (doc.status as DocumentState) || (doc.pdfState === 'READY' ? DocumentState.PDF_READY : undefined);

      if (currentStatus !== DocumentState.PDF_READY && currentStatus !== DocumentState.DELIVERED) {
        // Strict Abort: If document is in a state that cannot progress to PDF_READY/DELIVERED (e.g. VOID, DRAFT), we MUST abort.
        // Spec Section 7: "abort if state mismatch" (Strict Determinism)
        if (currentStatus === DocumentState.VOID || currentStatus === DocumentState.DRAFT) {
          console.warn(`[deliverLine] ABORTING: State mismatch. Document is ${currentStatus}.`);
          // Mark job FAILED, no retry
          await jobRef.set({
            status: 'FAILED',
            lastError: { message: `Aborted: Document is in ${currentStatus} state` },
            updatedAt: admin.firestore.Timestamp.now()
          }, { merge: true });
          res.status(200).send(`Aborted: State mismatch (${currentStatus})`);
          return;
        }

        // Not ready yet (e.g. PDF_RENDERING lag): schedule next run
        console.log(`[deliverLine] Document not in PDF_READY state (current: ${currentStatus}), scheduling retry`);
        const nextAttempt = (job.attempt || 0) + 1;
        const backoff = getBackoffForAttempt(nextAttempt);
        const nextRun = admin.firestore.Timestamp.fromMillis(Date.now() + backoff * 1000);
        await jobRef.set({ nextRunAt: nextRun, attempt: nextAttempt, status: 'PENDING', updatedAt: admin.firestore.Timestamp.now() }, { merge: true });
        res.status(200).send('Not ready');
        return;
      }

      // Strict Guard: Can we transition to DELIVERED?
      try {
        assertTransition(currentStatus, DocumentState.DELIVERED);
      } catch (e: any) {
        console.error(`[deliverLine] Invalid transition attempt: ${e.message}`);
        // Permanent failure if state is wrong? Or maybe it's already DELIVERED?
        // If already DELIVERED, we can process implementation logic (send duplicate?) or skip?
        // User spec: "DELIVERED: []" (allowed targets).
        // So if it is DELIVERED, assertTransition(DELIVERED, DELIVERED) is VALID (no-op).
        // Wait, Spec Section 4 `DELIVERED: []`.
        // So `DELIVERED` cannot go to `DELIVERED`?
        // `validateStatusTransition` logic: "Same status is always valid (no-op)".
        // `assertTransition` uses `ALLOWED[from].includes(to)`.
        // If `ALLOWED['DELIVERED']` is empty, then `assertTransition('DELIVERED', 'DELIVERED')` throws Error!
        // UNLESS I handle self-transition in `assertTransition` or caller.
        // `stateMachine.ts`: "Same status is always valid" check was in `validateStatusTransition`.
        // In `assertTransition` implementation in Step 306:
        /*
          export function assertTransition(from: DocumentState, to: DocumentState): void {
              const targets = ALLOWED[from];
              if (!targets || !targets.includes(to)) {
                  throw new InvalidStateTransitionError(from, to);
              }
          }
        */
        // It does NOT check `from === to`.
        // So `DELIVERED -> DELIVERED` throws.
        // I MUST check strict equality here, or update `stateMachine.ts` to allow self-transition (idempotency).
        // Spec Section 8: "LINE Delivery Failed ... Retry allowed".
        // If we are retrying, we are still in PDF_READY.
        // If we succeeded once but job status update failed?

        if (currentStatus === DocumentState.DELIVERED) {
          console.log('[deliverLine] Document already DELIVERED, skipping logic?');
          // If already delivered, maybe we shouldn't send again?
          // Idempotency: "job.status === 'SENT'" check happens earlier (line 162).
          // So if job isn't SENT, we assume we haven't sent it.
          // But what if document is DELIVERED (by another job)?
          // We should probably abort.
          res.status(200).send('Already delivered');
          return;
        }

        // If we are here, we are PDF_READY.
        // Rethrow if assert fails.
        throw e;
      }

      // Load business snapshot for language selection
      const businessRef = job.businessId ? db.doc(`users/${job.userId}/businesses/${job.businessId}`) : null;
      const businessSnap = businessRef ? await businessRef.get() : null;
      const business = businessSnap?.exists ? (businessSnap.data() as BusinessData) : ({} as BusinessData);

      // Send message via LINE push API
      const to = job.to?.lineUserId || job.lineUserId;
      console.log('[deliverLine] Recipient:', to);
      if (!to) {
        console.log('[deliverLine] No recipient found');
        await jobRef.set({
          status: 'FAILED',
          attempt: (job.attempt || 0) + 1,
          updatedAt: admin.firestore.Timestamp.now(),
          lastError: { message: 'No recipient' },
          expiresAt: admin.firestore.Timestamp.fromDate(
            new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
          )
        }, { merge: true });
        res.status(400).send('No recipient');
        return;
      }

      // Determine previous docNo if this doc supersedes another
      let prevDocNo: string | undefined = undefined;
      const supersedesId = doc.supersedes_document_id || doc.origin_document_id;
      if (supersedesId && job.userId && job.businessId) {
        try {
          const prevRef = db.doc(`users/${job.userId}/businesses/${job.businessId}/documents/${supersedesId}`);
          const prevSnap = await prevRef.get();
          if (prevSnap.exists) prevDocNo = (prevSnap.data() as DocumentData).docNo;
        } catch {
          // ignore
        }
      }

      // Build messages using template builder
      const messages = buildLineDeliveryMessage(doc, business, prevDocNo);
      // console.log('[deliverLine] Built messages:', JSON.stringify(messages)); // Too verbose

      try {
        console.log('[deliverLine] Sending to LINE...');
        const resp = await fetch('https://api.line.me/v2/bot/message/push', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
          },
          body: JSON.stringify({ to, messages }),
        });
        console.log('[deliverLine] LINE response status:', resp.status);

        if (!resp.ok) {
          const text = await resp.text();
          console.log('[deliverLine] LINE error response:', text);

          // Classify the error for better observability
          const errorClassification = classifyLineError(resp.status, text);
          console.log('[deliverLine] Error classified as:', errorClassification.reason);

          // If not retryable, mark as FAILED and stop
          if (!errorClassification.isRetryable) {
            console.log(`[deliverLine] Permanent failure (${errorClassification.reason}): ${errorClassification.message}`);
            const now = admin.firestore.Timestamp.now();
            await jobRef.set({
              status: 'FAILED',
              attempt: (job.attempt || 0) + 1,
              lastError: {
                reason: errorClassification.reason,
                message: errorClassification.message,
                details: text.slice(0, 500)  // Store first 500 chars of LINE response
              },
              updatedAt: now,
              // TTL: Keep FAILED jobs for 90 days for debugging
              expiresAt: admin.firestore.Timestamp.fromDate(
                new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
              )
            }, { merge: true });
            await docRef.set({ deliveryState: 'FAILED', updatedAt: now }, { merge: true });
            res.status(200).send(`Delivery failed: ${errorClassification.reason}`);
            return;
          }

          // If retryable, throw to let Cloud Tasks handle retry
          console.log('[deliverLine] Transient error, will retry');
          throw new Error(`LINE push ${errorClassification.reason}: ${errorClassification.message}`);
        }

        // Success: mark job SENT and update document deliveryState
        console.log('[deliverLine] LINE push successful!');
        // Success: mark job SENT and update document deliveryState AND Status
        console.log('[deliverLine] LINE push successful!');
        const now = admin.firestore.Timestamp.now();
        await jobRef.set({
          status: 'SENT',
          sentAt: now,
          updatedAt: now,
          // TTL: Keep SENT jobs for 30 days for audit/debugging
          expiresAt: admin.firestore.Timestamp.fromDate(
            new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          )
        }, { merge: true });
        await docRef.update({
          status: DocumentState.DELIVERED, // Spec v1.0
          deliveryState: 'SENT', // Legacy
          updatedAt: now
        });

        // Audit Log
        if (job.docId && job.userId && job.businessId) {
          await logStatusTransition({
            docId: job.docId,
            docPath: docRef.path,
            userId: job.userId,
            businessId: job.businessId,
            fromStatus: DocumentState.PDF_READY,
            toStatus: DocumentState.DELIVERED,
            action: 'deliver',
            metadata: { source: 'LINE_WORKER', jobId }
          }).catch(e => console.error('Audit log failed', e));
        }

        res.status(200).send('OK');
        return;
      } catch (err: unknown) {
        // On failure, increment attempt and set nextRunAt for retry; throw to allow Cloud Tasks retry if desired
        const attempt = (job.attempt || 0) + 1;
        const backoff = getBackoffForAttempt(attempt);
        const nextRun = admin.firestore.Timestamp.fromMillis(Date.now() + backoff * 1000);
        await jobRef.set({
          attempt,
          status: 'FAILED',
          nextRunAt: nextRun,
          lastError: { message: String((err as Error)?.message ?? err) },
          updatedAt: admin.firestore.Timestamp.now(),
          // TTL: Keep FAILED jobs for 90 days for debugging
          expiresAt: admin.firestore.Timestamp.fromDate(
            new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
          )
        }, { merge: true });
        await docRef.set({ deliveryState: 'FAILED', updatedAt: admin.firestore.Timestamp.now() }, { merge: true });
        console.error('Delivery failed for job', jobId, err);
        // Throw so Cloud Tasks can apply retry policy if configured
        res.status(500).send('Delivery failed');
        return;
      }
    } catch (error) {
      console.error('deliverLineTaskHandler error', error);
      res.status(500).send('Internal error');
    }
  });
