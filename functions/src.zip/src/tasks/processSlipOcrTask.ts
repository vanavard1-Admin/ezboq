/**
 * Cloud Task Handler: Process Slip OCR
 * 
 * Called by Cloud Tasks to process slip image OCR asynchronously
 */

import * as functions from 'firebase-functions/v1';
import { processSlipUpload } from '../services/imageUploadService';
import { logWithTrace } from '../utils/asyncSafety';

interface SlipOcrTaskPayload {
  userId: string;
  lineUserId: string;
  messageId: string;
  purchaseId: string;
}

export const processSlipOcrTask = functions
  .region('asia-southeast1')
  .runWith({
    secrets: ['LINE_CHANNEL_ACCESS_TOKEN'],
    timeoutSeconds: 540,
  })
  .https.onRequest(async (req, res) => {
    // Verify OIDC token from Cloud Tasks
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing or invalid authorization' });
      return;
    }

    const traceId = `ocr-${Date.now()}-${Math.random().toString(36).substring(7)}`;
    const context = {
      traceId,
      lineUserId: 'system',
      eventType: 'slip_ocr_task',
      stage: 'task_received',
    };

    logWithTrace("[OCR_STARTED]", context, "OCR task received");

    try {
      const payload = req.body as SlipOcrTaskPayload;
      const { userId, lineUserId, messageId, purchaseId } = payload;

      if (!userId || !lineUserId || !messageId || !purchaseId) {
        throw new Error('Missing required fields in payload');
      }

      const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
      if (!accessToken) {
        throw new Error('LINE_CHANNEL_ACCESS_TOKEN not configured');
      }

      logWithTrace("[OCR_STARTED]", { ...context, lineUserId, stage: 'processing' }, 
        `Processing OCR: userId=${userId}, purchaseId=${purchaseId}, messageId=${messageId}`);

      // Process slip upload (downloads image, uploads to storage, triggers OCR)
      const result = await processSlipUpload(userId, lineUserId, messageId, accessToken);

      if (result.success) {
        logWithTrace("[OCR_DONE]", { ...context, lineUserId, stage: 'completed' }, 
          `OCR completed successfully: purchaseId=${purchaseId}`);
      } else {
        logWithTrace("[OCR_FAILED]", { ...context, lineUserId, stage: 'failed' }, 
          `OCR failed: purchaseId=${purchaseId}, message=${result.message}`);
      }

      // Clear SLIP mode after processing
      const { setUserImageMode } = await import('../services/userStateService');
      await setUserImageMode(userId, null);

      res.status(200).json({ success: result.success, message: result.message });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      logWithTrace("[OCR_FAILED]", { ...context, stage: 'error' }, 
        `OCR task error: ${errorMsg}`);
      res.status(500).json({ error: errorMsg });
    }
  });

