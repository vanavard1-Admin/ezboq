import * as admin from 'firebase-admin';
import { getLineUserIdFromFirebaseUid } from '../core/lineUserMapping';
import {
  getDocTypeInfo,
  buildPdfFlexMessageWithShortLink,
} from '../shared/pdfFlexMessage';

/**
 * Deliver PDF to LINE user via push message
 * Called after pdf_generation_jobs reaches DONE status
 * Sends PDF link to user via LINE push or reply
 *
 * Security: Uses short links (pdfRedirect tokens) instead of raw signed URLs
 * Idempotency: Skips if delivery_status == DONE
 */

const LINE_API_PUSH = 'https://api.line.me/v2/bot/message/push';
const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN?.trim() || '';

export interface PdfDeliveryPayload {
  userId: string; // Firebase UID
  businessId: string;
  documentNo: string;
  documentId: string;
  pdfPath: string;
  documentType?: string;
  traceId?: string; // ✅ Add traceId to payload
}

/**
 * Push PDF link to LINE user via Flex message with short link
 */
export async function deliverPdfToLine(payload: PdfDeliveryPayload): Promise<void> {
  const { userId, documentNo, documentId, pdfPath, documentType, businessId } = payload;

  try {
    // Get LINE user ID from Firebase UID
    const lineUserId = await getLineUserIdFromFirebaseUid(userId);
    if (!lineUserId) {
      console.warn(`[pdfDelivery] No LINE user ID linked to Firebase UID ${userId}`);
      return;
    }

    // Get document type info (no URL logged)
    const docTypeInfo = getDocTypeInfo(documentType);

    // Build Flex message with short link (secure, no signed URL exposed)
    const flexMessage = await buildPdfFlexMessageWithShortLink({
      docId: documentId,
      docNo: documentNo,
      docType: documentType || '',
      pdfPath,
      userId,
      businessId,
    });

    const requestBody = {
      to: lineUserId,
      messages: [flexMessage],
    };

    // Security: Log only doc_no and pdf_path, NOT the signed URL
    console.log(`[pdfDelivery] Pushing ${docTypeInfo.label} to LINE: doc_no=${documentNo}, pdf_path=${pdfPath}`);

    // Send to LINE API
    const response = await fetch(LINE_API_PUSH, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`LINE API error: ${response.status} ${errorBody}`);
    }

    console.log(`[pdfDelivery] Successfully delivered ${docTypeInfo.label}: doc_no=${documentNo}`);
  } catch (err) {
    console.error('[pdfDelivery] Error:', err);
    throw err;
  }
}

/**
 * Cloud Firestore trigger: When pdf_generation_jobs.status → DONE
 * Automatically send notification to LINE user
 *
 * Idempotency: Skips if delivery_status == DONE
 */
export async function onPdfJobCompleted(
  snap: admin.firestore.DocumentSnapshot
): Promise<void> {
  const job = snap.data() as Record<string, unknown>;
  const jobId = snap.id;

  if (job.status !== 'DONE') {
    return;
  }

  // Idempotency guard: skip if already delivered
  if (job.delivery_status === 'DONE') {
    console.log(`[onPdfJobCompleted] Job ${jobId} already delivered, skipping`);
    return;
  }

  const db = admin.firestore();
  const jobRef = db.collection('pdf_generation_jobs').doc(jobId);

  try {
    // Mark as delivering (prevent duplicate deliveries)
    await jobRef.update({
      delivery_status: 'DELIVERING',
      delivery_started_at: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Get pdf_path (required for short link)
    const pdfPath = (job.pdf_path as string | undefined) || null;
    if (!pdfPath) {
      console.warn(`[onPdfJobCompleted] Job ${jobId} DONE but no pdf_path; skip delivery`);
      await jobRef.update({ delivery_status: 'SKIPPED', delivery_error: 'NO_PDF_PATH' });
      return;
    }

    // Extract doc_type from job or infer from document_no prefix
    let docType = (job.doc_type as string | undefined) || (job.document_type as string | undefined);
    if (!docType) {
      const docNo = job.document_no as string;
      const prefix = docNo?.split('-')[0]?.toUpperCase();
      if (prefix) {
        docType = prefix;
      }
    }

    // ✅ FIX 6: Log correlation ID
    const traceId = (job.traceId || job.correlationId) as string | undefined;
    // Security: Log only identifiers, not URLs
    console.log(`[onPdfJobCompleted] Delivering: jobId=${jobId}, doc_no=${job.document_no}, doc_type=${docType || 'inferred'}, traceId=${traceId || 'n/a'}`);

    await deliverPdfToLine({
      userId: job.user_id as string,
      businessId: job.business_id as string,
      documentNo: job.document_no as string,
      documentId: job.document_id as string,
      pdfPath,
      documentType: docType,
      traceId, // ✅ Pass traceId to delivery function
    });

    // Mark as delivered
    await jobRef.update({
      delivery_status: 'DONE',
      delivered_at: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(`[onPdfJobCompleted] Delivery complete: jobId=${jobId}`);
  } catch (err) {
    console.error(`[onPdfJobCompleted] Error for job ${jobId}:`, err);

    // Mark as failed (don't throw - job is DONE, delivery is best-effort)
    await jobRef.update({
      delivery_status: 'FAILED',
      delivery_error: String(err),
    }).catch(() => {});
  }
}
