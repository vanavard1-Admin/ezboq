import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions/v1';
import { GoogleAuth } from 'google-auth-library';
import { PDF_RENDER_URL, PDF_SERVICE_AUDIENCE } from '../shared/config';

/**
 * PDF Generation Worker
 * Scheduled function that processes PENDING PDF jobs:
 * 1. Fetch job from pdf_generation_jobs
 * 2. Call pdf-service to render PDF
 * 3. Upload to Cloud Storage
 * 4. Update job: PENDING → DONE (+ pdfUrl)
 * 5. Trigger LINE delivery notification
 */

// Initialize Firebase Admin SDK if not already initialized
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();
const storage = admin.storage();
const JOBS_COLLECTION = 'pdf_generation_jobs';
// const BUCKET_NAME is removed; using default bucket from initializeApp

const auth = new GoogleAuth();

interface PdfJob {
  id: string;
  user_id: string;
  business_id: string;
  document_id: string;
  document_no: string;
  doc_type?: string;
  status: 'PENDING' | 'PROCESSING' | 'DONE' | 'FAILED';
  created_at: admin.firestore.Timestamp;
  attempts: number;
  max_attempts: number;
  error?: string;
  pdfUrl?: string;
  pdf_path?: string;
  completedAt?: admin.firestore.Timestamp;
  traceId?: string; // For correlation (optional)
  correlationId?: string; // Alias for traceId (optional)
}

/**
 * Process single PDF generation job
 * Fetches document, calls pdf-service, uploads result
 */
export async function processPdfJob(jobId: string): Promise<void> {
  const jobRef = db.collection(JOBS_COLLECTION).doc(jobId);
  // Atomically "claim" the job only if status == PENDING.
  // This prevents double-processing between:
  // - Firestore onCreate fast-path trigger
  // - Scheduled polling worker
  // - Manual trigger
  const claimResult = await db.runTransaction(async (tx) => {
    const snap = await tx.get(jobRef);
    if (!snap.exists) {
      console.warn(`[PDF_JOB_NOT_FOUND] ⚠️ jobId=${jobId}`);
      return { claimed: false as const };
    }

    const job = snap.data() as PdfJob;

    if (job.status !== 'PENDING') {
      console.log(`[PDF_JOB_SKIPPED] ℹ️ jobId=${jobId}, status=${job.status}`);
      return { claimed: false as const };
    }

    const attemptNumber = (job.attempts || 0) + 1;

    tx.update(jobRef, {
      status: 'PROCESSING',
      attempts: attemptNumber,
      processing_started_at: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { claimed: true as const, job, attemptNumber };
  });

  if (!claimResult.claimed) return;

  const { job, attemptNumber } = claimResult;

  // ✅ FIX 1: Enqueue timeout task when job transitions to PROCESSING
  // This ensures timeout notification is sent even if job gets stuck and doesn't trigger onUpdate
  try {
    const { enqueuePdfTimeoutTask } = await import('./pdfTimeoutEnqueue');
    await enqueuePdfTimeoutTask(jobId).catch((err) => {
      // Non-blocking: Log but continue processing
      console.warn(`[PDF_WORKER] Failed to enqueue timeout task: ${err}`);
    });
  } catch (importErr) {
    // Non-blocking: Continue even if import fails
    console.warn(`[PDF_WORKER] Failed to import timeout enqueue: ${importErr}`);
  }

  // ✅ FIX 6: Log correlation ID
  const traceId = job.traceId || job.correlationId || 'n/a';
  console.log(
    `[PDF_JOB_PROCESSING] 🔄 jobId=${jobId}, doc_no=${job.document_no}, attempt=${attemptNumber}, traceId=${traceId}`
  );

  try {
    // Fetch document from Firestore (contains all snapshot data)
    const docRef = db
      .collection('users')
      .doc(job.user_id)
      .collection('businesses')
      .doc(job.business_id)
      .collection('documents')
      .doc(job.document_id);

    const docSnap = await docRef.get();
    if (!docSnap.exists) {
      throw new Error(`Document not found: ${job.document_id}`);
    }

    const docData = docSnap.data()!;

    // ✅ Get user plan for watermark control
    const { getUserPlan } = await import('../core/planService');
    const userPlan = await getUserPlan(job.user_id);

    // ✅ Get business profile for pdfTheme
    const businessRef = db
      .collection('users')
      .doc(job.user_id)
      .collection('businesses')
      .doc(job.business_id);
    const businessSnap = await businessRef.get();
    const businessData = businessSnap.exists ? businessSnap.data() : {};
    const pdfTheme = businessData?.pdfTheme || null;

    // Build full payload for PDF service (no Firestore access needed in pdf-service)
    const pdfPayload = buildPdfPayload(docData, job, userPlan, pdfTheme);
    
    // Theme resolution for logging
    const themeCandidate = (docData.theme as string) || pdfTheme || 'green';
    const themeResolved = (['green', 'red', 'blue', 'mono'].includes(themeCandidate) ? themeCandidate : 'green');
    
    // Log PDF render start with theme info
    console.log(JSON.stringify({
      tag: "[PDF_RENDER_START]",
      trace_id: traceId,
      doc_id: job.document_id,
      doc_type: docData.doc_type || job.doc_type,
      doc_no: job.document_no,
      theme_candidate: themeCandidate,
      theme_resolved: themeResolved,
      render_version: "2026-01-15",
      render_url: PDF_RENDER_URL,
      timestamp: new Date().toISOString(),
    }));

    // Generate PDF by calling the real PDF service (Cloud Run).
    // This keeps webhook async-safety and centralizes rendering in pdf-service.
    const pdfBuffer = await renderPdfViaService({
      payload: pdfPayload,
      jobId,
    });

    // Upload to Cloud Storage
    // Option B: store deterministic object path (source of truth)
    const storagePath = `users/${job.user_id}/businesses/${job.business_id}/documents/${job.document_id}.pdf`;
    const bucket = storage.bucket();
    const file = bucket.file(storagePath);

    await file.save(pdfBuffer, {
      metadata: {
        contentType: 'application/pdf',
        metadata: {
          documentNo: job.document_no,
          userId: job.user_id,
          businessId: job.business_id,
          docId: job.document_id,
          jobId,
        },
      },
      resumable: false,
    });

    console.log(`[pdfWorker] PDF uploaded: ${storagePath} (${pdfBuffer.length} bytes)`);

    // Update job: PENDING → DONE
    await jobRef.update({
      status: 'DONE',
      pdf_path: storagePath,
      completedAt: admin.firestore.Timestamp.now(),
    });

    // Write-through: Option B source of truth is pdf_path (signed URLs expire).
    await docRef.set(
      {
        pdf_path: storagePath,
        pdf_generated_at: admin.firestore.Timestamp.now(),
      },
      { merge: true }
    );

    console.log(
      `[PDF_JOB_DONE] ✅ jobId=${jobId}, doc_no=${job.document_no}, pdf_path=${storagePath}, traceId=${traceId}`
    );

    // Delivery is handled by Firestore trigger `onPdfJobCompleted` (best-effort LINE push).
  } catch (err) {
    console.error(`[PDF_JOB_FAILED] ❌ jobId=${jobId}, error:`, err);

    const attempts = attemptNumber || (job.attempts || 0);
    const maxAttempts = job.max_attempts || 3;

    if (attempts >= maxAttempts) {
      // Give up
      await jobRef.update({
        status: 'FAILED',
        error: String(err),
        attempts,
        completedAt: admin.firestore.Timestamp.now(),
      });
      console.error(`[pdfWorker] Job exhausted retries: ${jobId}`);
    } else {
      // Retry next time
      await jobRef.update({
        status: 'PENDING',
        error: String(err),
        attempts,
      });
      console.warn(`[pdfWorker] Job will retry (${attempts}/${maxAttempts}): ${jobId}`);
    }
  }
}

/**
 * Build complete PDF payload from document data
 * This is sent to pdf-service so it doesn't need to read Firestore
 * 
 * @param userPlan - User's plan (FREE, PRO, TEAM) for watermark control
 */
function buildPdfPayload(
  docData: Record<string, unknown>,
  job: PdfJob,
  userPlan: string = 'FREE',
  pdfTheme?: string | null
): Record<string, unknown> {
  // Extract or default snapshots
  const businessSnapshot = (docData.business_snapshot as Record<string, unknown>) || {};
  const customerSnapshot = (docData.customer_snapshot as Record<string, unknown>) || {};
  const taxSnapshot = (docData.tax_snapshot as Record<string, unknown>) || {};
  const paymentSnapshot = (docData.payment_snapshot as Record<string, unknown>) || null;
  const termsSnapshot = (docData.terms as Record<string, unknown>) || {};

  // Get document type for terms
  const docType = String(docData.doc_type || job.doc_type || 'QUOTATION').toUpperCase();

  // Resolve terms based on document type
  let documentTerms = termsSnapshot.custom_terms || '';
  if (!documentTerms) {
    if (docType === 'QUOTATION' || docType === 'QUO') {
      documentTerms = termsSnapshot.quotation_terms || 'ราคานี้มีอายุ 30 วันนับจากวันที่ออกเอกสาร';
    } else if (docType === 'INVOICE' || docType === 'BILL') {
      documentTerms = termsSnapshot.invoice_terms || 'กรุณาชำระเงินภายในวันที่กำหนด';
    } else if (docType === 'RECEIPT') {
      documentTerms = termsSnapshot.receipt_terms || 'ขอบคุณที่ใช้บริการ';
    }
  }

  // Build standardized payload
  return {
    // Document metadata
    doc: {
      id: job.document_id,
      type: docType,
      no: docData.doc_no || job.document_no,
      status: docData.status,
      issue_date: docData.issued_at || docData.issue_date || docData.created_at,
      due_date: docData.due_date || null,
      created_at: docData.created_at,
      notes: docData.notes || '',
      terms: documentTerms,
      // ✅ Plan info for watermark control
      user_plan: userPlan,
    },

    // Business snapshot (frozen at issuance) - includes signature/stamp
    business: {
      id: businessSnapshot.id || job.business_id,
      name: businessSnapshot.name || docData.businessName || 'ไม่ระบุ',
      address: businessSnapshot.address || null,
      tax_id: businessSnapshot.tax_id || null,
      branch: businessSnapshot.branch || null,
      phone: businessSnapshot.phone || null,
      email: businessSnapshot.email || null,
      logo_url: businessSnapshot.logo_url || null,
      // Signature and stamp
      signature_url: businessSnapshot.signature_url || null,
      stamp_url: businessSnapshot.stamp_url || null,
      signatory_name: businessSnapshot.signatory_name || null,
      signatory_title: businessSnapshot.signatory_title || null,
      // ✅ PDF theme from business profile
      pdfTheme: pdfTheme || null,
    },

    // Customer snapshot (frozen at issuance)
    customer: {
      id: customerSnapshot.id || docData.customer_id || null,
      name: customerSnapshot.name || docData.customer_name || 'ไม่ระบุ',
      address: customerSnapshot.address || null,
      tax_id: customerSnapshot.tax_id || docData.customer_tax_id || null,
      phone: customerSnapshot.phone || null,
      email: customerSnapshot.email || null,
    },

    // Line items
    items: (docData.items as Array<Record<string, unknown>>) || [],

    // Totals
    totals: {
      sub_total: docData.sub_total_amount || docData.subtotal || 0,
      vat: docData.vat_amount || docData.vat || 0,
      vat_percent: taxSnapshot.vat_percent || docData.vat_percent || 7,
      discount: docData.discount_amount || 0,
      wht: docData.wht || 0,
      total: docData.total_amount || docData.total || 0,
    },

    // Payment info (for rendering payment section + QR code)
    payment: paymentSnapshot ? {
      method: paymentSnapshot.method,
      promptpay_account: paymentSnapshot.promptpay_account || null,
      promptpay_name: paymentSnapshot.promptpay_name || null,
      promptpay_logo_url: paymentSnapshot.promptpay_logo_url || null,
      bank_code: paymentSnapshot.bank_code || null,
      bank_name: paymentSnapshot.bank_name || null,
      bank_account: paymentSnapshot.bank_account || null,
      bank_account_name: paymentSnapshot.bank_account_name || null,
      bank_logo_url: paymentSnapshot.bank_logo_url || null,
      // Amount for QR code generation
      amount: docData.total_amount || docData.total || 0,
    } : null,

    // Asset URLs for rendering
    assets: {
      business_logo_url: businessSnapshot.logo_url || null,
      signature_url: businessSnapshot.signature_url || null,
      stamp_url: businessSnapshot.stamp_url || null,
      bank_logo_url: paymentSnapshot?.bank_logo_url || null,
      promptpay_logo_url: paymentSnapshot?.promptpay_logo_url || null,
    },
  };
}

/**
 * Call PDF service with full payload (no Firestore access in pdf-service)
 */
async function renderPdfViaService(params: {
  payload: Record<string, unknown>;
  jobId: string;
}): Promise<Buffer> {
  const { payload, jobId } = params;

  // PDF_SERVICE_URL should point to the Cloud Run endpoint that returns PDF bytes
  // e.g. https://<cloud-run-service>/jobs/render-buffer
  if (!PDF_RENDER_URL) {
    throw new Error('PDF_RENDER_URL not configured');
  }

  // Audience should match Cloud Run URL for OIDC auth; fallback to URL if not provided
  const audience = PDF_SERVICE_AUDIENCE || PDF_RENDER_URL;
  const client = await auth.getIdTokenClient(audience);

  // Security: Log only identifiers, not full payload
  const docNo = (payload.doc as Record<string, unknown>)?.no || 'unknown';
  console.log(`[pdfWorker] Calling PDF service: jobId=${jobId}, doc_no=${docNo}`);

  const resp = await client.request<ArrayBuffer>({
    url: PDF_RENDER_URL,
    method: 'POST',
    data: payload,
    responseType: 'arraybuffer',
    timeout: 120_000,
  });

  const buf = Buffer.from(resp.data);
  if (buf.length < 1000) {
    // Safety: reject obviously invalid PDFs (prevents uploading placeholders)
    throw new Error(`PDF buffer too small (${buf.length} bytes) from PDF service`);
  }
  
  // ✅ FIX: Log PDF render success
  console.log(JSON.stringify({
    tag: "[PDF_RENDER_DONE]",
    status_code: resp.status,
    pdf_bytes: buf.length,
    trace_id: params.jobId,
    timestamp: new Date().toISOString(),
  }));
  
  return buf;
}

/**
 * Pubsub trigger: Process all PENDING jobs
 * Run on schedule (e.g., every 5 minutes)
 */
export const pdfWorkerScheduled = functions
  .region('asia-southeast1')
  .runWith({
    secrets: ['PDF_RENDER_URL', 'PDF_SERVICE_AUDIENCE'],
    memory: '512MB',
    timeoutSeconds: 300,
  })
  .pubsub.schedule('every 5 minutes')
  .onRun(async () => {
    console.log('[pdfWorkerScheduled] Starting PDF worker');

    try {
      const jobsSnap = await db
        .collection(JOBS_COLLECTION)
        .where('status', '==', 'PENDING')
        .limit(10)
        .get();

      console.log(`[pdfWorkerScheduled] Found ${jobsSnap.docs.length} pending jobs`);

      if (jobsSnap.docs.length === 0) {
        // Debug: check all jobs summary
        const allJobsSnap = await db.collection(JOBS_COLLECTION).limit(50).get();
        const stats: Record<string, number> = {};
        allJobsSnap.docs.forEach(d => {
          const s = d.data().status || 'N/A';
          stats[s] = (stats[s] || 0) + 1;
        });
        console.log(`[pdfWorkerScheduled] Debug Stats (limit 50):`, JSON.stringify(stats));
      }

      for (const jobDoc of jobsSnap.docs) {
        try {
          await processPdfJob(jobDoc.id);
        } catch (err) {
          console.error(`[pdfWorkerScheduled] Error processing job ${jobDoc.id}:`, err);
        }
      }

      console.log('[pdfWorkerScheduled] Completed');
    } catch (err) {
      console.error('[pdfWorkerScheduled] Error:', err);
    }
  });

/**
 * HTTP trigger: Manually process a specific job
 * For testing/debugging
 */
export const pdfWorkerManual = functions
  .region('asia-southeast1')
  .runWith({
    secrets: ['PDF_RENDER_URL', 'PDF_SERVICE_AUDIENCE'],
    memory: '512MB',
    timeoutSeconds: 120,
  })
  .https.onRequest(async (req, res) => {
    const { jobId } = req.query;

    if (!jobId || typeof jobId !== 'string') {
      res.status(400).send('Missing jobId parameter');
      return;
    }

    try {
      await processPdfJob(jobId);
      res.json({ success: true, jobId });
    } catch (err) {
      console.error('[pdfWorkerManual] Error:', err);
      res.status(500).json({ error: String(err) });
    }
  });
