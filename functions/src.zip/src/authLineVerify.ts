import * as functions from "firebase-functions/v1";
import * as admin from "firebase-admin";
import fetch from "node-fetch";

/**
 * Cloud Function: Verify LINE ID token and mint Firebase custom token
 * Uses LINE Login channel (not Messaging API channel)
 * 
 * POST /auth/line/verify
 * Body: { idToken: string }
 * Returns: { ok: true, lineUserId: string, customToken: string }
 */
export const authLineVerify = functions
  .region("asia-southeast1")
  .runWith({
    secrets: ["LINE_LOGIN_CHANNEL_ID"],
  })
  .https.onRequest(async (req: functions.https.Request, res: functions.Response) => {
    // CORS
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
      res.status(204).send("");
      return;
    }

    if (req.method !== "POST") {
      res.status(405).json({ ok: false, error: "Method not allowed" });
      return;
    }

    try {
      // Read idToken from body (support both idToken and id_token keys)
      const idToken = req.body?.idToken ?? req.body?.id_token ?? "";
      
      // Log request keys for debugging
      const bodyKeys = Object.keys(req.body || {});
      console.log("[AUTH_LINE_VERIFY_DEBUG] Request body keys:", bodyKeys);

      // Detailed validation
      const idTokenLength = idToken ? String(idToken).length : 0;
      const dotCount = idToken ? (String(idToken).match(/\./g) || []).length : 0;
      
      // Token preview (safe - first/last 10 chars)
      const tokenPreview = idToken 
        ? `${String(idToken).substring(0, 10)}...${String(idToken).substring(idTokenLength - 10)}`
        : "empty";

      if (!idToken) {
        console.error("[AUTH_LINE_VERIFY_FAIL] Missing idToken", { 
          bodyKeys,
          receivedLength: idTokenLength 
        });
        res.status(400).json({ 
          ok: false, 
          error: "Missing idToken",
          details: { idTokenLength: 0, dotCount: 0, bodyKeys }
        });
        return;
      }

      // JWT must have exactly 2 dots (3 segments: header.payload.signature)
      if (dotCount !== 2) {
        console.error("[AUTH_LINE_VERIFY_FAIL] Invalid idToken format - not JWT", {
          idTokenLength,
          dotCount,
          expected: 2,
          tokenPreview,
        });
        res.status(400).json({ 
          ok: false, 
          error: "Invalid ID token format (not JWT)",
          details: { 
            idTokenLength, 
            dotCount, 
            expected: 2,
            tokenPreview 
          }
        });
        return;
      }

      // Get LINE Login channel ID (not Messaging API channel)
      const clientId = process.env.LINE_LOGIN_CHANNEL_ID;
      if (!clientId) {
        console.error("[AUTH_LINE_VERIFY_FAIL] LINE_LOGIN_CHANNEL_ID secret not set");
        res.status(500).json({ ok: false, error: "Server configuration error" });
        return;
      }

      // Mask client_id for logging (show first 4 and last 2 digits)
      const maskedClientId = clientId.length > 6 
        ? `${clientId.substring(0, 4)}****${clientId.substring(clientId.length - 2)}`
        : "****";

      console.log("[AUTH_LINE_VERIFY_START] Starting verification", {
        client_id: maskedClientId,
        idTokenLength,
        dotCount,
        tokenPreview: `${String(idToken).substring(0, 10)}...${String(idToken).substring(idTokenLength - 10)}`,
      });

      // Verify LINE ID token with LINE Login channel
      // IMPORTANT: Use application/x-www-form-urlencoded as per LINE API spec
      const verifyParams = new URLSearchParams();
      verifyParams.append('id_token', idToken);
      verifyParams.append('client_id', clientId);

      const verifyResponse = await fetch(
        'https://api.line.me/oauth2/v2.1/verify',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: verifyParams.toString(),
        }
      );

      if (!verifyResponse.ok) {
        const errorText = await verifyResponse.text();
        console.error("[AUTH_LINE_VERIFY_FAIL] LINE verify API failed:", {
          status: verifyResponse.status,
          statusText: verifyResponse.statusText,
          error: errorText,
          idTokenLength,
          dotCount,
        });
        res.status(401).json({ 
          ok: false, 
          error: "LINE verify API rejected token",
          details: {
            status: verifyResponse.status,
            lineVerifyError: errorText,
            idTokenLength,
            dotCount,
          }
        });
        return;
      }

      const verifyData = await verifyResponse.json() as { sub?: string; error_description?: string };
      const lineUserId = verifyData.sub;

      if (!lineUserId) {
        console.error("[AUTH_LINE_VERIFY_FAIL] No sub in verify response", verifyData);
        res.status(401).json({ ok: false, error: "Invalid token payload" });
        return;
      }

      console.log("[AUTH_LINE_VERIFY_OK] LINE user verified", {
        lineUserId,
        client_id: maskedClientId,
      });

      // Create Firebase custom token with LINE user ID
      const uid = `line:${lineUserId}`;
      const customToken = await admin.auth().createCustomToken(uid, {
        lineUserId,
        provider: "line_liff",
      });

      console.log("[AUTH_LINE_VERIFY_OK] Custom token created for uid:", uid);

      res.status(200).json({
        ok: true,
        lineUserId,
        customToken,
      });
    } catch (err) {
      console.error("[AUTH_LINE_VERIFY_FAIL] Error:", err);
      res.status(500).json({ 
        ok: false, 
        error: err instanceof Error ? err.message : "Internal error" 
      });
    }
  });
