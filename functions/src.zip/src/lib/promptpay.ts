/**
 * PromptPay QR Code Generator
 * Generates PromptPay QR codes for payment
 */

import generatePayload from "promptpay-qr";
import QRCode from "qrcode";

/**
 * Generate PromptPay QR code as PNG Buffer
 * @param bankAccount - PromptPay bank account number (10 digits)
 * @param amount - Amount in THB
 * @returns PNG Buffer of QR code image
 */
export async function generatePromptPayQRBuffer(
  bankAccount: string,
  amount: number
): Promise<Buffer> {
  const payload = generatePayload(bankAccount, { amount });
  return QRCode.toBuffer(payload, {
    type: "png",
    width: 400,
    margin: 2,
  });
}

/**
 * Generate PromptPay QR code as Data URL (for web display)
 * @param bankAccount - PromptPay bank account number (10 digits)
 * @param amount - Amount in THB
 * @returns Data URL of QR code image
 */
export async function generatePromptPayQR(
  bankAccount: string,
  amount: number
): Promise<string> {
  const payload = generatePayload(bankAccount, { amount });
  return QRCode.toDataURL(payload);
}

/**
 * System PromptPay account for receiving payments
 * Set via environment variable
 */
export const SYSTEM_PROMPTPAY_ACCOUNT = process.env.PROMPTPAY_ACCOUNT || "0000000000";

/**
 * Plan pricing configuration
 */
export const PLANS = {
  MONTHLY_99: {
    id: "MONTHLY_99",
    name: "แพ็คมาตรฐาน",
    price: 99,
    credits: 100,
    duration: 30, // days
  },
  MONTHLY_299: {
    id: "MONTHLY_299",
    name: "แพ็คโปร",
    price: 299,
    credits: 500,
    duration: 30, // days
  },
} as const;

export type PlanId = keyof typeof PLANS;
