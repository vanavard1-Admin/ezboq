/**
 * Forgiving Parser - Human-First UX
 * 
 * Core principle: "Try to parse everything before asking"
 * 
 * Parsing order (critical - try parse before asking):
 * 1. Detect special commands (ออกเอกสาร|ยืนยัน|ลบ|เริ่มใหม่)
 * 2. Split multiline → parse line-by-line
 * 3. Phone detection (รองรับขีด เว้นวรรค คำว่า โทร)
 * 4. Item detection: "คำ + ตัวเลข" (qty optional: x2, 2x, จำนวน 2)
 * 5. Pure short text (<50) no digits → customer name
 * 6. Price-only number → SET_PENDING_PRICE หรือ require context
 */

export enum ParsedActionType {
  SET_CUSTOMER_NAME = 'SET_CUSTOMER_NAME',
  SET_PHONE = 'SET_PHONE',
  ADD_ITEM = 'ADD_ITEM',
  UNDO_LAST = 'UNDO_LAST',
  RESET = 'RESET',
  CONFIRM = 'CONFIRM',
  SET_PENDING_PRICE = 'SET_PENDING_PRICE', // Price-only number (needs context)
  UNKNOWN = 'UNKNOWN',
}

export interface ParsedAction {
  type: ParsedActionType;
  confidence: number; // 0-1
  payload?: {
    customerName?: string;
    phone?: string;
    item?: {
      name: string;
      qty: number;
      price: number;
    };
  };
}

export interface ParsingContext {
  hasActiveDraft: boolean;
  hasCustomer: boolean;
  hasItems: boolean;
  lastItemName?: string; // For SET_PENDING_PRICE context
}

/**
 * ✅ Normalize Thai input without spaces
 * Inserts spaces between letters and digits, and after keywords
 * 
 * Rules:
 * - Insert space between Thai/English letters and digits
 * - Insert space after known keywords when glued to next char
 * - Preserve URLs and emails (normalize segments separately)
 * - Collapse multiple spaces to single
 */
export function normalizeThaiInput(raw: string): string {
  if (!raw || raw.length === 0) return raw;
  
  // ✅ Step 1: Split into segments (URL/email segments vs. normal text)
  // Pattern for URLs and emails
  const urlEmailPattern = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
  const segments: Array<{ text: string; isProtected: boolean }> = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  
  // Reset regex lastIndex
  urlEmailPattern.lastIndex = 0;
  
  while ((match = urlEmailPattern.exec(raw)) !== null) {
    // Add text before protected segment
    if (match.index > lastIndex) {
      segments.push({ text: raw.substring(lastIndex, match.index), isProtected: false });
    }
    // Add protected segment
    segments.push({ text: match[0], isProtected: true });
    lastIndex = match.index + match[0].length;
  }
  
  // Add remaining text after last match
  if (lastIndex < raw.length) {
    segments.push({ text: raw.substring(lastIndex), isProtected: false });
  }
  
  // If no URL/email found, treat entire string as one segment
  if (segments.length === 0) {
    segments.push({ text: raw, isProtected: false });
  }
  
  // ✅ Step 2: Normalize each non-protected segment
  const normalizedSegments = segments.map(segment => {
    if (segment.isProtected) {
      return segment.text; // Keep URLs/emails as-is
    }
    
    let normalized = segment.text;
    
    // Insert spaces between letters (Thai/English) and digits
    normalized = normalized.replace(/([\u0E00-\u0E7FA-Za-z])(\d)/g, '$1 $2');
    normalized = normalized.replace(/(\d)([\u0E00-\u0E7FA-Za-z])/g, '$1 $2');
    
    // ✅ Step 3: Insert spaces after keywords when glued to next char
    // Support keyword variations: "ลูกค้า:", "รายการ:", "ออกเอกสารครับ", etc.
    // ✅ CRITICAL: Handle glued keywords FIRST (before general keyword spacing)
    // Patterns: "ลูกค้าแมวน้อย" → "ลูกค้า แมวน้อย"
    const gluedKeywordPatterns = [
      /^ลูกค้า(\S+)/,
      /^เพิ่มรายการ(\S+)/,
      /^ที่อยู่(\S+)/,
      /^เลขผู้เสียภาษี(\S+)/,
      /^ธนาคาร(\S+)/,
      /^พร้อมเพย์(\S+)/,
      /^ชื่อบริษัท(\S+)/,
      /^ชื่อธุรกิจ(\S+)/,
    ];
    
    for (const pattern of gluedKeywordPatterns) {
      normalized = normalized.replace(pattern, (match, rest) => {
        const keyword = match.substring(0, match.length - rest.length);
        return `${keyword} ${rest}`;
      });
    }
    
    const keywords = [
      'ลูกค้า',
      'เพิ่มรายการ',
      'รายการ',
      'ออกเอกสาร',
      'ยืนยัน',
      'ลบ',
      'ลบรายการ',
      'เริ่มใหม่',
      'ใบเสนอราคา',
      'ใบวางบิล',
      'ใบเสร็จ',
    ];
    
    // Sort by length (longest first) to avoid partial matches
    const sortedKeywords = [...keywords].sort((a, b) => b.length - a.length);
    
    for (const keyword of sortedKeywords) {
      // ✅ Enhanced: Handle keyword variations
      // - "ลูกค้าABC" -> "ลูกค้า ABC"
      // - "ลูกค้า:ABC" -> "ลูกค้า: ABC" (keep colon, add space)
      // - "รายการ:ขนส่ง" -> "รายการ: ขนส่ง"
      // - "ออกเอกสารครับ" -> "ออกเอกสาร ครับ"
      // Pattern 1: keyword followed directly by non-whitespace, non-punctuation
      const pattern1 = new RegExp(`(${keyword})([^\\s:：\\.,!?\\d])`, 'g');
      normalized = normalized.replace(pattern1, '$1 $2');
      
      // Pattern 2: keyword followed by colon/punctuation then non-whitespace
      const pattern2 = new RegExp(`(${keyword})([:：])([^\\s])`, 'g');
      normalized = normalized.replace(pattern2, '$1$2 $3');
    }
    
    return normalized;
  });
  
  // ✅ Step 4: Join segments and collapse spaces
  let normalized = normalizedSegments.join('').replace(/\s+/g, ' ').trim();
  
  return normalized;
}

/**
 * Normalize number string (handle commas, dots, Thai format)
 */
function normalizeNumber(text: string): number | null {
  // Remove currency symbols
  let normalized = text.replace(/[฿$€£¥บาท\s]/gi, '').trim();
  
  // Handle Thai format: 1.500 (thousands separator) vs 1.50 (decimal)
  // Assume comma = thousands, dot = decimal (Thai/US format)
  normalized = normalized.replace(/,/g, '');
  
  // Convert to number
  const num = parseFloat(normalized);
  return isNaN(num) || num <= 0 ? null : num;
}

/**
 * Detect phone number (Thai format)
 */
function detectPhone(text: string): string | null {
  // Remove common prefixes and normalize
  let cleaned = text.replace(/^(โทร|เบอร์|เบอร์โทร|tel|phone)[:：]?\s*/i, '').trim();
  
  // Remove all non-digits
  const digits = cleaned.replace(/\D/g, '');
  
  // Thai mobile: 10 digits (08x, 09x, 06x)
  // Thai landline: 9-10 digits
  if (digits.length >= 9 && digits.length <= 10 && /^[0-9]+$/.test(digits)) {
    // Format: 08x-xxx-xxxx or 08xxxxxxxx
    if (digits.startsWith('0')) {
      return digits;
    }
  }
  
  return null;
}

/**
 * Parse item line: "name price" or "name qty x price" or "name qty price" (NATURAL_ITEM_3TOKENS)
 * ✅ Now handles both spaced and unspaced forms (after normalization)
 */
function parseItemLine(line: string): { name: string; qty: number; price: number } | null {
  // Normalize
  const normalized = line.trim();
  if (!normalized || normalized.length < 2) return null;
  
  // Try pattern: "name qty x price" or "name qty* price"
  const qtyPattern = /(.+?)\s+(\d+(?:[,\.]\d+)*)\s*[xX×*]\s*(\d+(?:[,\.]\d+)*)\s*(?:บาท|฿)?/i;
  const qtyMatch = normalized.match(qtyPattern);
  
  if (qtyMatch) {
    const name = qtyMatch[1].trim();
    const qty = normalizeNumber(qtyMatch[2]);
    const price = normalizeNumber(qtyMatch[3]);
    
    if (name && qty && price) {
      return { name, qty, price };
    }
  }
  
  // ✅ NATURAL_ITEM_3TOKENS: "name qty price" (without x)
  // Pattern: "บริการออกแบบ 1 5000" → name="บริการออกแบบ", qty=1, price=5000
  const tokens = normalized.split(/\s+/);
  if (tokens.length >= 3) {
    const lastToken = tokens[tokens.length - 1];
    const secondLastToken = tokens[tokens.length - 2];
    const price = normalizeNumber(lastToken);
    const qty = normalizeNumber(secondLastToken);
    
    // If last 2 tokens are numbers, treat as qty + price
    if (price && qty) {
      const name = tokens.slice(0, -2).join(' ').trim();
      const cleanName = name.replace(/\s+(บาท|฿|baht)$/i, '').trim();
      
      if (cleanName && cleanName.length >= 2) {
        return { name: cleanName, qty, price };
      }
    }
  }
  
  // ✅ NATURAL_ITEM_2TOKENS: "name price" (simple) - works with normalized spacing
  // Split by space, last token should be price
  if (tokens.length >= 2) {
    const lastToken = tokens[tokens.length - 1];
    const price = normalizeNumber(lastToken);
    
    if (price) {
      const name = tokens.slice(0, -1).join(' ').trim();
      // Remove common suffixes
      const cleanName = name.replace(/\s+(บาท|฿|baht)$/i, '').trim();
      
      if (cleanName && cleanName.length >= 2) {
        return { name: cleanName, qty: 1, price };
      }
    }
  }
  
  // ✅ Enhanced: Try pattern without spaces (e.g., "ขนส่ง82749" after normalization should become "ขนส่ง 82749")
  // But if normalization didn't work, try direct pattern: letters followed by digits
  const directPattern = /^([\u0E00-\u0E7FA-Za-z]+)(\d+(?:[,\.]\d+)*)\s*(?:บาท|฿)?$/i;
  const directMatch = normalized.match(directPattern);
  if (directMatch) {
    const name = directMatch[1].trim();
    const price = normalizeNumber(directMatch[2]);
    if (name && price) {
      return { name, qty: 1, price };
    }
  }
  
  return null;
}

/**
 * Check if text is a special command
 * ✅ Enhanced to detect commands even with punctuation or extra words
 */
function isSpecialCommand(text: string): ParsedActionType | null {
  const normalized = text.trim().toLowerCase();
  
  // Remove trailing punctuation for command detection
  const cleaned = normalized.replace(/[.,!?。，！？]+$/, '').trim();
  
  if (cleaned === 'ออกเอกสาร' || cleaned === 'ยืนยัน' || cleaned === 'confirm' || cleaned.startsWith('ออกเอกสาร')) {
    return ParsedActionType.CONFIRM;
  }
  
  if (cleaned === 'ลบ' || cleaned === 'undo' || cleaned === 'ย้อนกลับ' || cleaned.startsWith('ลบรายการ')) {
    return ParsedActionType.UNDO_LAST;
  }
  
  if (cleaned === 'เริ่มใหม่' || cleaned === 'reset' || cleaned === 'ยกเลิก') {
    return ParsedActionType.RESET;
  }
  
  return null;
}

/**
 * Parse forgiving input - Human-First UX
 * 
 * ✅ Enhanced with Thai input normalization
 * 
 * @param rawText - Raw user input (preserved for logging)
 * @param context - Parsing context (hasActiveDraft, hasCustomer, etc.)
 * @returns Array of parsed actions (multiple actions for multiline)
 */
export function parseForgivingInput(
  rawText: string,
  context: ParsingContext
): ParsedAction[] {
  const actions: ParsedAction[] = [];
  
  // ✅ Normalize Thai input (insert spaces)
  const text = normalizeThaiInput(rawText.trim());
  
  if (!text || text.length === 0) {
    return [{ type: ParsedActionType.UNKNOWN, confidence: 0 }];
  }
  
  // ✅ Log both raw and normalized (for debugging, but don't expose normalized to user)
  // This will be logged by the caller (humanFirstHandler) with structured logging
  
  // RULE 1: Check special commands first
  const specialCommand = isSpecialCommand(text);
  if (specialCommand) {
    return [{ type: specialCommand, confidence: 1.0 }];
  }
  
  // RULE 2: Split multiline
  const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  
  if (lines.length > 1) {
    // Multiline input - parse line by line
    for (const line of lines) {
      const lineActions = parseForgivingInput(line, context);
      actions.push(...lineActions);
    }
    return actions;
  }
  
  // Single line parsing
  
  // RULE 3: Phone detection
  const phone = detectPhone(text);
  if (phone) {
    actions.push({
      type: ParsedActionType.SET_PHONE,
      confidence: 0.9,
      payload: { phone },
    });
    // Continue parsing for other parts if any
    const withoutPhone = text.replace(/^(โทร|เบอร์|เบอร์โทร|tel|phone)[:：]?\s*/i, '').replace(/\d+/g, '').trim();
    if (withoutPhone && withoutPhone.length > 0) {
      const remainingActions = parseForgivingInput(withoutPhone, context);
      actions.push(...remainingActions);
    }
    return actions;
  }
  
  // ✅ RULE 4: Item detection - "คำ + ตัวเลข" (now handles unspaced forms after normalization)
  const item = parseItemLine(text);
  if (item) {
    actions.push({
      type: ParsedActionType.ADD_ITEM,
      confidence: 0.85,
      payload: { item },
    });
    return actions;
  }
  
  // ✅ RULE 5: Customer detection - "ลูกค้า<name>" now works after normalization
  // Check if starts with "ลูกค้า" keyword (after normalization, should have space)
  const customerMatch = text.match(/^ลูกค้า\s+(.+)$/i);
  if (customerMatch) {
    const customerName = customerMatch[1].trim();
    if (customerName && customerName.length >= 2) {
      actions.push({
        type: ParsedActionType.SET_CUSTOMER_NAME,
        confidence: 0.9,
        payload: { customerName },
      });
      return actions;
    }
  }
  
  // RULE 6: Pure short text (<50 char, no digits) → customer name
  const hasDigits = /\d/.test(text);
  if (!hasDigits && text.length < 50 && text.length >= 2) {
    // Check if it looks like a name (not a command)
    const isCommand = /^(เพิ่ม|แก้|ลบ|ยืนยัน|ออก|เริ่ม)/i.test(text);
    if (!isCommand) {
      actions.push({
        type: ParsedActionType.SET_CUSTOMER_NAME,
        confidence: 0.7,
        payload: { customerName: text },
      });
      return actions;
    }
  }
  
  // RULE 7: Price-only number
  const priceOnly = normalizeNumber(text);
  if (priceOnly !== null && text.trim().replace(/[^\d,.\s]/g, '').trim() === text.trim().replace(/\s/g, '')) {
    // If we have context (last item name), this is likely a price
    if (context.lastItemName) {
      actions.push({
        type: ParsedActionType.SET_PENDING_PRICE,
        confidence: 0.6,
        payload: { item: { name: context.lastItemName, qty: 1, price: priceOnly } },
      });
    } else {
      // Price-only without context - lower confidence
      actions.push({
        type: ParsedActionType.SET_PENDING_PRICE,
        confidence: 0.4,
        payload: { item: { name: '', qty: 1, price: priceOnly } },
      });
    }
    return actions;
  }
  
  // Fallback: UNKNOWN
  return [{ type: ParsedActionType.UNKNOWN, confidence: 0.1 }];
}
