/**
 * Human Interaction Runtime
 * 
 * A production-grade, human-first conversational engine for document creation.
 * 
 * Architecture:
 * - InputPipeline: Normalizes and parses user input
 * - DraftEngine: Applies actions to draft state (pure, sequential)
 * - UXDirector: Decides what to say (all user-facing language)
 * - DocumentOrchestrator: Handles document issuance workflow
 * - Telemetry: Structured logging for observability
 * 
 * Principles:
 * 1. Human-first language: Professional, calm, helpful, never error language
 * 2. Deterministic: Same input + same state → same result
 * 3. Backward compatible: Feature flag gates all behavior
 */

import { HUMAN_FIRST_UX_ENABLED } from '../shared/config';
import {
  parseForgivingInput,
  normalizeThaiInput,
  ParsedActionType,
  type ParsingContext,
  type ParsedAction,
} from './forgivingParser';
import {
  determineHumanFirstState,
  getHumanFirstButtons,
} from './humanFirstStateMachine';
import { getDraft, updateDraft, clearDraft, type LineDraft } from './draftStore';
import type { QuickReplyAction } from '../shared/lineQuickReply';

export interface HumanFirstResponse {
  message: string;
  buttons: QuickReplyAction[];
}

// ============================================================================
// TELEMETRY
// ============================================================================

/**
 * Structured logging for observability
 */
function logRuntimeEvent(
  userId: string,
  businessId: string,
  traceId: string | undefined,
  action: string,
  context: Record<string, unknown>,
  draft?: { docType?: string; id?: string } | null,
  latencyMs?: number
): void {
  if (HUMAN_FIRST_UX_ENABLED) {
    // Calculate confidence average if actions are present
    const actions = context.parsed_actions as Array<{ confidence?: number }> | undefined;
    const confidenceAvg = actions && actions.length > 0
      ? actions.reduce((sum, a) => sum + (a.confidence || 0), 0) / actions.length
      : undefined;

    console.log(JSON.stringify({
      human_first_enabled: true,
      handler_version: 'human_interaction_runtime_v1',
      trace_id: traceId || null,
      user_id: userId,
      business_id: businessId,
      action,
      doc_type: draft?.docType || null,
      draft_id: draft?.id || null,
      draft_exists: draft !== null && draft !== undefined,
      latency_ms: latencyMs || null,
      confidence_avg: confidenceAvg,
      was_normalized: context.was_normalized,
      ...context,
      timestamp: new Date().toISOString(),
    }));
  }
}

// ============================================================================
// INPUT PIPELINE
// ============================================================================

/**
 * Input Pipeline: Normalize and parse user input
 */
interface PipelineResult {
  actions: ParsedAction[];
  normalizedText: string;
  wasNormalized: boolean;
  confidence: number;
}

function processInput(rawText: string, context: ParsingContext): PipelineResult {
  // Normalize Thai input (insert spaces, protect URLs/emails)
  const normalizedText = normalizeThaiInput(rawText.trim());
  const wasNormalized = normalizedText !== rawText;

  // Parse into actions
  const actions = parseForgivingInput(normalizedText, context);

  // Calculate average confidence
  const confidence = actions.length > 0
    ? actions.reduce((sum, a) => sum + a.confidence, 0) / actions.length
    : 0;

  return {
    actions,
    normalizedText,
    wasNormalized,
    confidence,
  };
}

// ============================================================================
// DRAFT ENGINE
// ============================================================================

/**
 * Draft Engine: Pure functions that apply actions to draft state
 * No UX copy here - only state transformations
 */

interface DraftChange {
  customerName?: string;
  items?: LineDraft['items'];
  needsRecalculation: boolean;
}

/**
 * Apply a single action to a working draft (pure function)
 */
function applyActionToDraft(
  draft: LineDraft,
  action: ParsedAction,
  context: ParsingContext
): DraftChange | null {
  switch (action.type) {
    case ParsedActionType.RESET:
      // Reset is handled at orchestration level (clears draft)
      return null;

    case ParsedActionType.UNDO_LAST:
      if (draft.items && draft.items.length > 0) {
        return {
          items: draft.items.slice(0, -1),
          needsRecalculation: true,
        };
      }
      return null; // Nothing to undo

    case ParsedActionType.SET_CUSTOMER_NAME:
      if (action.payload?.customerName) {
        return {
          customerName: action.payload.customerName,
          needsRecalculation: false,
        };
      }
      return null;

    case ParsedActionType.ADD_ITEM:
      if (action.payload?.item) {
        const newItems = [...(draft.items || []), action.payload.item];
        return {
          items: newItems,
          needsRecalculation: true,
        };
      }
      return null;

    case ParsedActionType.SET_PENDING_PRICE:
      // Update price of last item
      if (action.payload?.item && draft.items && draft.items.length > 0) {
        const lastIndex = draft.items.length - 1;
        const updatedItems = [...draft.items];
        updatedItems[lastIndex] = {
          ...updatedItems[lastIndex],
          price: action.payload.item.price,
          qty: action.payload.item.qty || updatedItems[lastIndex].qty || 1,
        };
        return {
          items: updatedItems,
          needsRecalculation: true,
        };
      }
      return null;

    case ParsedActionType.SET_PHONE:
      // Phone is not stored in draft (transparency handled in UX layer)
      return null;

    case ParsedActionType.CONFIRM:
    case ParsedActionType.UNKNOWN:
      // These are handled at orchestration level
      return null;

    default:
      return null;
  }
}

/**
 * Validate draft completeness
 */
function validateDraftCompleteness(draft: LineDraft): {
  isValid: boolean;
  missing: Array<'customer' | 'items'>;
} {
  const missing: Array<'customer' | 'items'> = [];
  
  if (!draft.customerName || draft.customerName.trim().length === 0) {
    missing.push('customer');
  }
  
  if (!draft.items || draft.items.length === 0) {
    missing.push('items');
  }

  return {
    isValid: missing.length === 0,
    missing,
  };
}

/**
 * Sanitize item names for PDF generation (remove UI/system phrases)
 */
function sanitizeItemNamesForPdf(draft: LineDraft): LineDraft {
  const uiPhrases = [
    'เพิ่มรายการ',
    'ลูกค้า',
    'ยกเลิก',
    'ออกเอกสาร',
    'ยืนยัน',
    'เริ่มใหม่',
    'ลบรายการ',
  ];

  return {
    ...draft,
    items: draft.items.map(item => {
      let sanitized = item.name.trim();
      
      // Remove UI phrases (case-insensitive, whole word only)
      for (const phrase of uiPhrases) {
        const regex = new RegExp(`^${phrase}\\s*[:：]?\\s*`, 'i');
        sanitized = sanitized.replace(regex, '').trim();
      }
      
      return {
        ...item,
        name: sanitized || item.name, // Fallback to original if empty
      };
    }),
  };
}

// ============================================================================
// UX DIRECTOR
// ============================================================================

/**
 * UX Director: All user-facing language lives here
 * Professional, calm, helpful, human-first
 */

type DocType = 'QUO' | 'BILL' | 'RECEIPT';

/**
 * Detect document creation commands from raw text
 */
function detectCreateCommand(rawText: string): 'QUO' | 'BILL' | 'RECEIPT' | null {
  const normalized = rawText.toLowerCase().trim();
  
  // Create Quotation
  if (
    normalized.includes('ทำใบเสนอราคา') ||
    normalized.includes('ใบเสนอราคา') ||
    normalized.includes('quotation')
  ) {
    return 'QUO';
  }
  
  // Create Invoice
  if (
    normalized.includes('ทำใบวางบิล') ||
    normalized.includes('ใบวางบิล') ||
    normalized.includes('ทำ invoice') ||
    normalized.includes('invoice') ||
    normalized.includes('วางบิล')
  ) {
    return 'BILL';
  }
  
  // Create Receipt
  if (
    normalized.includes('ทำใบเสร็จ') ||
    normalized.includes('ใบเสร็จ') ||
    normalized.includes('receipt') ||
    normalized.includes('ใบเสร็จรับเงิน')
  ) {
    return 'RECEIPT';
  }
  
  return null;
}

/**
 * Get acknowledgment message for document creation
 */
function getCreateAcknowledgmentMessage(docType: 'QUO' | 'BILL' | 'RECEIPT'): string {
  switch (docType) {
    case 'QUO':
      return `รับทราบครับ 👍 ผมเริ่มใบเสนอราคาให้แล้ว`;
    case 'BILL':
      return `รับทราบครับ 👍 ผมเริ่มใบวางบิลให้แล้ว`;
    case 'RECEIPT':
      return `รับทราบครับ 👍 ผมเริ่มใบเสร็จให้แล้ว`;
  }
}

/**
 * Get human-first message for no draft state (when no CREATE command detected)
 */
function getNoDraftMessage(): string {
  return `ยังไม่มีเอกสารนะครับ
เริ่มได้เลย แค่พิมพ์
"ทำใบเสนอราคา" หรือ "ทำใบวางบิล"`;
}

/**
 * Get message for CONFIRM without draft
 */
function getConfirmWithoutDraftMessage(): string {
  return `ตอนนี้ยังไม่มีเอกสารให้ยืนยันครับ

เดี๋ยวผมเริ่มใบเสนอราคาให้ได้เลย แค่พิมพ์ 'ทำใบเสนอราคา'`;
}

/**
 * Get message for customer set
 */
function getCustomerSetMessage(customerName: string): string {
  return `👤 ตั้งชื่อลูกค้าเป็น ${customerName} แล้ว
ต่อไปพิมพ์รายการ + ราคาได้เลย
เช่น \`ค่าขนส่ง 3000\``;
}

/**
 * Get message for item added
 */
function getItemAddedMessage(itemName: string, price: number, qty: number = 1): string {
  const total = price * qty;
  const qtyText = qty > 1 ? ` x${qty} = ${total.toLocaleString('th-TH')}` : '';
  return `➕ เพิ่มรายการแล้ว
${itemName}${qtyText} ${total.toLocaleString('th-TH')} บาท

พิมพ์รายการต่อได้เลย
หรือพิมพ์ "ออกเอกสาร" เมื่อพร้อม`;
}

/**
 * Get message for price-only input (set to last item)
 */
function getPriceSetMessage(itemName: string, price: number): string {
  return `💰 ตั้งราคาให้รายการล่าสุดแล้ว
${itemName}: ${price.toLocaleString('th-TH')} บาท

ถ้ามีรายการอื่น พิมพ์ต่อได้เลย`;
}

/**
 * Get message for missing info (before confirm)
 */
function getMissingInfoMessage(draft: LineDraft, missing: Array<'customer' | 'items'>): string {
  const missingText = missing.map(m => m === 'customer' ? 'ลูกค้า' : 'รายการ').join(' / ');
  
  // Generate summary
  const customerLine = draft.customerName 
    ? `ลูกค้า: ${draft.customerName}`
    : 'ลูกค้า: (ยังไม่ได้ระบุ)';
  
  const itemsText = draft.items && draft.items.length > 0
    ? draft.items.slice(-5).map((item, idx) => 
        `  ${idx + 1}. ${item.name} ${item.qty > 1 ? `x${item.qty}` : ''} ${(item.price * item.qty).toLocaleString('th-TH')} บาท`
      ).join('\n')
    : '  (ยังไม่มีรายการ)';
  
  const totalText = `รวม: ${(draft.total || 0).toLocaleString('th-TH')} บาท`;
  
  return `ยังออกเอกสารไม่ได้ครับ เพราะข้อมูลยังไม่ครบ

ตอนนี้ขาด: ${missingText}

${customerLine}
${itemsText}
${totalText}

ใส่เพิ่มอีกนิด เดี๋ยวผมจัดให้ต่อเลย`;
}

/**
 * Get message for ready to confirm (chain-aware)
 */
function getReadyToConfirmMessage(docType: DocType): string {
  switch (docType) {
    case 'QUO':
      return `ทุกอย่างพร้อมแล้วครับ
พิมพ์ "ออกเอกสาร" เพื่อออกใบเสนอราคา

💡 ถัดไปสามารถทำใบวางบิลต่อได้ทันที`;

    case 'BILL':
      return `ใบวางบิลพร้อมแล้ว
พิมพ์ "ออกเอกสาร"

💡 เมื่อรับเงินแล้ว ทำใบเสร็จต่อได้`;

    case 'RECEIPT':
      return `พร้อมออกใบเสร็จแล้วครับ
พิมพ์ "ออกเอกสาร" เพื่อยืนยัน`;

    default:
      return `พร้อมออกเอกสารแล้ว
พิมพ์ "ออกเอกสาร" เพื่อยืนยัน`;
  }
}

/**
 * Get message for ambiguous input
 */
function getAmbiguousMessage(draft: LineDraft): string {
  // Generate summary
  const customerLine = draft.customerName 
    ? `ลูกค้า: ${draft.customerName}`
    : 'ลูกค้า: (ยังไม่ได้ระบุ)';
  
  const itemsText = draft.items && draft.items.length > 0
    ? draft.items.slice(-5).map((item, idx) => 
        `  ${idx + 1}. ${item.name} ${item.qty > 1 ? `x${item.qty}` : ''} ${(item.price * item.qty).toLocaleString('th-TH')} บาท`
      ).join('\n')
    : '  (ยังไม่มีรายการ)';
  
  const totalText = `รวม: ${(draft.total || 0).toLocaleString('th-TH')} บาท`;

  return `ผมอาจเข้าใจไม่ตรงกันนิดหน่อย
ตอนนี้เอกสารของคุณเป็นแบบนี้ครับ 👇

${customerLine}
${itemsText}
${totalText}

ลองพิมพ์แบบนี้ดูได้ครับ
• \`ค่าขนส่ง 3000\`
• หรือ \`ลูกค้า บริษัท ABC\``;
}

/**
 * Get message for reset
 */
function getResetMessage(): string {
  return `เริ่มใหม่เรียบร้อยครับ
เอกสารก่อนหน้าถูกยกเลิกแล้ว

พิมพ์ "ทำใบเสนอราคา" เพื่อเริ่มใหม่ได้เลย`;
}

/**
 * Get message for undo
 */
function getUndoMessage(hasItem: boolean): string {
  if (hasItem) {
    return `ลบรายการล่าสุดให้แล้วครับ
ถ้ายังไม่ใช่ พิมพ์ลบอีกครั้งได้`;
  } else {
    return `ตอนนี้ยังไม่มีรายการให้ลบครับ`;
  }
}

/**
 * Get message for phone transparency
 */
function getPhoneTransparencyMessage(phone: string): string {
  return `📞 เห็นเบอร์โทรแล้วนะครับ
${phone}

ตอนนี้ยังไม่ได้บันทึกลงเอกสาร
(ใช้เพื่อช่วยตรวจสอบเฉย ๆ)`;
}

/**
 * Build draft summary text (for context in messages)
 */
function buildDraftSummary(draft: LineDraft): string {
  const customerLine = draft.customerName 
    ? `ลูกค้า: ${draft.customerName}`
    : 'ลูกค้า: (ยังไม่ได้ระบุ)';
  
  const itemsText = draft.items && draft.items.length > 0
    ? draft.items.slice(-5).map((item, idx) => 
        `  ${idx + 1}. ${item.name} ${item.qty > 1 ? `x${item.qty}` : ''} ${(item.price * item.qty).toLocaleString('th-TH')} บาท`
      ).join('\n')
    : '  (ยังไม่มีรายการ)';
  
  const totalText = `รวม: ${(draft.total || 0).toLocaleString('th-TH')} บาท`;

  return `${customerLine}
${itemsText}
${totalText}`;
}

// ============================================================================
// DOCUMENT ORCHESTRATOR
// ============================================================================

/**
 * Document Orchestrator: Handles document issuance workflow
 */
async function issueDocument(
  userId: string,
  businessId: string,
  draft: LineDraft,
  replyFn: (msg: string, quickReply?: QuickReplyAction[]) => Promise<void>,
  lineUserId?: string,
  traceId?: string
): Promise<void> {
  // Preflight: Sanitize item names
  const sanitizedDraft = sanitizeItemNamesForPdf(draft);

  // Issue document
  const { confirmAndIssueDraft } = await import('./conversationHandler');
  await confirmAndIssueDraft(userId, businessId, sanitizedDraft, replyFn, lineUserId);

  // Clear draft after successful issuance
  await clearDraft(userId);
}

// ============================================================================
// MAIN ORCHESTRATOR
// ============================================================================

/**
 * Human Interaction Runtime: Main entry point
 * 
 * Orchestrates the entire human-first flow:
 * 1. Process input (normalize, parse)
 * 2. Apply actions to draft (pure transformations)
 * 3. Decide what to say (human-first language)
 * 4. Handle document issuance (if confirm)
 */
export async function handleHumanFirstEdit(
  userId: string,
  businessId: string,
  messageText: string,
  replyFn?: (msg: string, quickReply?: QuickReplyAction[]) => Promise<void>,
  lineUserId?: string,
  traceId?: string
): Promise<HumanFirstResponse | null> {
  const tStart = Date.now();

  // Feature flag gate
  if (!HUMAN_FIRST_UX_ENABLED) {
    return null; // Fall back to legacy handler
  }

  // Get draft
  let draft = await getDraft(userId);

  // ✅ FIX 1: Zero-friction document start - Handle CREATE commands when no draft exists
  if (!draft) {
    // Detect if user is trying to create a document
    const createCommand = detectCreateCommand(messageText);
    
    if (createCommand) {
      // ✅ FIX 2: Acknowledge user action before guidance
      // Create the draft first
      const { getOrCreateDraft } = await import('./draftStore');
      draft = await getOrCreateDraft(userId, businessId, createCommand);
      
      const latencyMs = Date.now() - tStart;
      logRuntimeEvent(userId, businessId, traceId, 'create_document_no_draft', {
        doc_type: createCommand,
        message_text: messageText,
      }, draft, latencyMs);

      // Build acknowledgment + guidance message
      const ackMessage = getCreateAcknowledgmentMessage(createCommand);
      const summary = buildDraftSummary(draft);
      const state = determineHumanFirstState(true, false, false);
      
      let message = `${ackMessage}\n\n${summary}\n\n`;
      message += `ตอนนี้พิมพ์ได้ 3 แบบ:\n`;
      message += `1) ตั้งลูกค้า\n`;
      message += `2) เพิ่มรายการ\n`;
      message += `3) ออกเอกสาร\n\n`;
      
      // Add examples based on docType
      if (createCommand === 'QUO') {
        message += `ตัวอย่าง:\n`;
        message += `ลูกค้า บจก. ABC\n`;
        message += `บริการออกแบบ 1 5000\n`;
        message += `ออกเอกสาร\n\n`;
      } else if (createCommand === 'BILL') {
        message += `ตัวอย่าง:\n`;
        message += `ลูกค้า บจก. ABC\n`;
        message += `งวดงาน 1 25000\n`;
        message += `ออกเอกสาร\n\n`;
      } else {
        message += `ตัวอย่าง:\n`;
        message += `เลือกจากใบวางบิล INV-xxxx\n`;
        message += `รับเงินแล้ว 25000\n`;
        message += `ออกเอกสาร\n\n`;
      }
      
      message += `พิมพ์แบบธรรมดาก็ได้ เช่น "บริษัท ABC" หรือ "อาหารแมว 3000" ระบบจะพยายามจัดให้เอง`;

      return {
        message,
        buttons: getHumanFirstButtons(state),
      };
    }

    // ✅ FIX 3: CONFIRM without draft handling
    // Check if this is a CONFIRM command
    const pipelineResultForConfirm = processInput(messageText, {
      hasActiveDraft: false,
      hasCustomer: false,
      hasItems: false,
    });
    
    const isConfirmCommand = pipelineResultForConfirm.actions.some(
      a => a.type === ParsedActionType.CONFIRM
    ) || messageText.toLowerCase().includes('ออกเอกสาร') || messageText.toLowerCase().includes('ยืนยัน');

    if (isConfirmCommand) {
      const latencyMs = Date.now() - tStart;
      logRuntimeEvent(userId, businessId, traceId, 'confirm_without_draft', {
        message_text: messageText,
      }, null, latencyMs);

      return {
        message: getConfirmWithoutDraftMessage(),
        buttons: [],
      };
    }

    // No CREATE command and no CONFIRM - show no draft message
    const latencyMs = Date.now() - tStart;
    logRuntimeEvent(userId, businessId, traceId, 'no_draft', {
      message_text_length: messageText.length,
    }, null, latencyMs);

    return {
      message: getNoDraftMessage(),
      buttons: [],
    };
  }

  // Build parsing context
  const context: ParsingContext = {
    hasActiveDraft: true,
    hasCustomer: !!draft.customerName,
    hasItems: draft.items && draft.items.length > 0,
    lastItemName: draft.items && draft.items.length > 0 
      ? draft.items[draft.items.length - 1].name 
      : undefined,
  };

  // INPUT PIPELINE: Process input
  const pipelineResult = processInput(messageText, context);
  const tParsed = Date.now();

  // Log input processing
  logRuntimeEvent(userId, businessId, traceId, 'input_processed', {
    message_text_raw: messageText,
    message_text_normalized: pipelineResult.wasNormalized ? pipelineResult.normalizedText.substring(0, 200) : undefined,
    was_normalized: pipelineResult.wasNormalized,
    message_text_length: messageText.length,
    parsed_actions_count: pipelineResult.actions.length,
    parsed_actions: pipelineResult.actions.map(a => ({ type: a.type, confidence: a.confidence })),
  }, draft, tParsed - tStart);

  // Handle CONFIRM action (explicit state transition)
  // ✅ Note: Draft is guaranteed to exist here (checked above)
  const confirmAction = pipelineResult.actions.find(a => a.type === ParsedActionType.CONFIRM);
  if (confirmAction) {
    if (!replyFn) {
      logRuntimeEvent(userId, businessId, traceId, 'confirm_no_replyfn', {}, draft);
      throw new Error('CONFIRM action requires replyFn');
    }

    // Validate draft completeness
    const validation = validateDraftCompleteness(draft);
    if (!validation.isValid) {
      const latencyMs = Date.now() - tStart;
      logRuntimeEvent(userId, businessId, traceId, 'confirm_validation_failed', {
        missing: validation.missing,
      }, draft, latencyMs);

      const state = determineHumanFirstState(true, context.hasCustomer, context.hasItems);
      return {
        message: getMissingInfoMessage(draft, validation.missing),
        buttons: getHumanFirstButtons(state),
      };
    }

    // DOCUMENT ORCHESTRATOR: Issue document
    const tIssueStart = Date.now();
    logRuntimeEvent(userId, businessId, traceId, 'confirm_issuing', {
      items_count: draft.items.length,
      total: draft.total,
    }, draft, tIssueStart - tStart);

    await issueDocument(userId, businessId, draft, replyFn, lineUserId, traceId);

    const latencyMs = Date.now() - tStart;
    logRuntimeEvent(userId, businessId, traceId, 'confirm_issued', {}, null, latencyMs);

    // Return null to indicate handler completed (response already sent via replyFn)
    return null;
  }

  // Handle RESET action
  const resetAction = pipelineResult.actions.find(a => a.type === ParsedActionType.RESET);
  if (resetAction) {
    await clearDraft(userId);
    const latencyMs = Date.now() - tStart;
    logRuntimeEvent(userId, businessId, traceId, 'reset_draft', {}, draft, latencyMs);

    return {
      message: getResetMessage(),
      buttons: [],
    };
  }

  // DRAFT ENGINE: Apply actions to working draft
  const workingDraft: LineDraft = JSON.parse(JSON.stringify(draft)); // Deep clone
  const responseMessages: string[] = [];
  let hasChanges = false;

  for (const action of pipelineResult.actions) {
    // Skip CONFIRM, RESET, UNKNOWN (handled separately)
    if (
      action.type === ParsedActionType.CONFIRM ||
      action.type === ParsedActionType.RESET ||
      action.type === ParsedActionType.UNKNOWN
    ) {
      continue;
    }

    // Apply action to draft
    const change = applyActionToDraft(workingDraft, action, context);

    if (change) {
      // Merge changes into working draft
      if (change.customerName !== undefined) {
        workingDraft.customerName = change.customerName;
        responseMessages.push(getCustomerSetMessage(change.customerName));
        hasChanges = true;
      }

      if (change.items) {
        workingDraft.items = change.items;
        
        // Generate appropriate message
        if (action.type === ParsedActionType.ADD_ITEM && action.payload?.item) {
          responseMessages.push(
            getItemAddedMessage(
              action.payload.item.name,
              action.payload.item.price,
              action.payload.item.qty
            )
          );
        } else if (action.type === ParsedActionType.SET_PENDING_PRICE && action.payload?.item) {
          const lastItem = workingDraft.items[workingDraft.items.length - 1];
          responseMessages.push(
            getPriceSetMessage(lastItem.name, action.payload.item.price)
          );
        } else if (action.type === ParsedActionType.UNDO_LAST) {
          responseMessages.push(
            getUndoMessage(workingDraft.items.length > 0)
          );
        }
        
        hasChanges = true;
      }

      // Recalculate totals if needed (updateDraft will handle this)
      if (change.needsRecalculation) {
        // Totals will be recalculated by updateDraft
      }
    }

    // Handle SET_PHONE (transparency message, no draft change)
    if (action.type === ParsedActionType.SET_PHONE && action.payload?.phone) {
      responseMessages.push(getPhoneTransparencyMessage(action.payload.phone));
    }
  }

  // Handle UNKNOWN action (ambiguous input)
  const unknownAction = pipelineResult.actions.find(a => a.type === ParsedActionType.UNKNOWN);
  if (unknownAction && pipelineResult.confidence < 0.3) {
    const state = determineHumanFirstState(true, context.hasCustomer, context.hasItems);
    const latencyMs = Date.now() - tStart;
    logRuntimeEvent(userId, businessId, traceId, 'ambiguous_response', {
      confidence: unknownAction.confidence,
    }, draft, latencyMs);

    return {
      message: getAmbiguousMessage(draft),
      buttons: getHumanFirstButtons(state),
    };
  }

  // Persist draft changes if any
  if (hasChanges) {
    const updates: Partial<LineDraft> = {};
    if (workingDraft.items !== draft.items) {
      updates.items = workingDraft.items;
    }
    if (workingDraft.customerName !== draft.customerName) {
      updates.customerName = workingDraft.customerName;
    }

    await updateDraft(userId, updates);

    // Refresh draft to get updated totals
    const updatedDraft = await getDraft(userId);
    if (updatedDraft) {
      const hasCustomer = !!updatedDraft.customerName;
      const hasItems = updatedDraft.items && updatedDraft.items.length > 0;
      const state = determineHumanFirstState(true, hasCustomer, hasItems);

      // Build response message
      let message = '';
      if (responseMessages.length > 0) {
        message = responseMessages.join('\n\n') + '\n\n';
      }

      // Add summary
      const summary = buildDraftSummary(updatedDraft);
      message += summary + '\n\n';

      // Add next steps based on readiness
      const validation = validateDraftCompleteness(updatedDraft);
      if (validation.isValid) {
        message += getReadyToConfirmMessage(updatedDraft.docType as DocType);
      } else {
        // Still missing info - show what's needed
        const missingText = validation.missing.map(m => m === 'customer' ? 'ลูกค้า' : 'รายการ').join(' / ');
        message += `ยังขาด: ${missingText}\n`;
        message += `พิมพ์เพิ่มต่อได้เลยครับ`;
      }

      const latencyMs = Date.now() - tStart;
      logRuntimeEvent(userId, businessId, traceId, 'draft_updated', {
        updates_count: Object.keys(updates).length,
        items_count: updatedDraft.items.length,
      }, updatedDraft, latencyMs);

      return {
        message,
        buttons: getHumanFirstButtons(state),
      };
    }
  }

  // No changes - show current state with guidance
  const state = determineHumanFirstState(true, context.hasCustomer, context.hasItems);
  const validation = validateDraftCompleteness(draft);
  
  let message = buildDraftSummary(draft) + '\n\n';
  
  if (validation.isValid) {
    message += getReadyToConfirmMessage(draft.docType as DocType);
  } else {
    const missingText = validation.missing.map(m => m === 'customer' ? 'ลูกค้า' : 'รายการ').join(' / ');
    message += `ยังขาด: ${missingText}\n`;
    message += `พิมพ์เพิ่มต่อได้เลยครับ`;
  }

  const latencyMs = Date.now() - tStart;
  logRuntimeEvent(userId, businessId, traceId, 'no_updates_response', {}, draft, latencyMs);

  return {
    message,
    buttons: getHumanFirstButtons(state),
  };
}
