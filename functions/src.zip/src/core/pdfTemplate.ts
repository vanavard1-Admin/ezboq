// functions/src/core/pdfTemplate.ts

export type DocType = "QT" | "WB" | "RC";

export type DiscountType = "AMOUNT" | "PERCENT";

export type LineItem = {
  name: string;
  qty: number;
  unitPrice: number;
};

export type Customer = {
  name: string;
  address?: string;
  taxId?: string;
  phone?: string;
  email?: string;
};

export type PaymentInfo = {
  method?: string;
  paidAt?: string;
  refNo?: string;
};

export type Totals = {
  subtotal: number;
  discountAmount: number;
  vatAmount: number;
  grandTotal: number;
};

export type Draft = {
  draftId: string;
  docType: DocType;
  docNo: string;
  docDate: string;
  status: "DRAFT" | "PENDING_CONFIRM" | "CONFIRMED" | "EXPORTED";
  customer?: Customer;
  items: LineItem[];
  vatRate: number;
  discountType?: DiscountType;
  discountValue?: number;
  dueDate?: string;
  payment?: PaymentInfo;
  totals: Totals;
  company?: {
    name: string;
    address?: string;
    taxId?: string;
    phone?: string;
    email?: string;
  };
};

type RenderOptions = {
  currencySuffix?: string;
  locale?: string;
};

const DEFAULT_COMPANY = {
  name: "EzDoc",
  address: "ประเทศไทย",
  taxId: "",
  phone: "",
  email: "",
};

function esc(s: unknown): string {
  const str = String(s ?? "");
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function fmtMoney(n: number, opts: RenderOptions): string {
  const locale = opts.locale ?? "th-TH";
  const suffix = opts.currencySuffix ?? "฿";
  const value = Number.isFinite(n) ? n : 0;
  return `${value.toLocaleString(locale, { maximumFractionDigits: 2 })}${suffix}`;
}

function fmtQty(n: number, opts: RenderOptions): string {
  const locale = opts.locale ?? "th-TH";
  const value = Number.isFinite(n) ? n : 0;
  return value.toLocaleString(locale, { maximumFractionDigits: 2 });
}

function docTitle(docType: DocType): string {
  switch (docType) {
    case "QT": return "ใบเสนอราคา";
    case "WB": return "ใบวางบิล";
    case "RC": return "ใบเสร็จรับเงิน";
    default: return "เอกสาร";
  }
}

function buildMetaInfo(draft: Draft): string {
  const lines: string[] = [];
  if (draft.docType === "QT") {
    lines.push("ใช้ได้ภายใน: 30 วัน");
  }
  if (draft.docType === "WB") {
    if (draft.dueDate) lines.push(`ครบกำหนดชำระ: ${draft.dueDate}`);
  }
  if (draft.docType === "RC") {
    if (draft.payment?.method) lines.push(`ชำระโดย: ${draft.payment.method}`);
    if (draft.payment?.paidAt) lines.push(`วันที่รับเงิน: ${draft.payment.paidAt}`);
    if (draft.payment?.refNo) lines.push(`เลขอ้างอิง: ${draft.payment.refNo}`);
  }
  if (draft.customer?.taxId) lines.push(`เลขผู้เสียภาษีลูกค้า: ${draft.customer.taxId}`);
  return lines.map(esc).join("<br/>");
}

function buildFooterNote(draft: Draft): string {
  switch (draft.docType) {
    case "QT": return "หมายเหตุ: ราคานี้อาจมีการเปลี่ยนแปลงตามหน้างาน";
    case "WB": return "หมายเหตุ: กรุณาชำระเงินภายในกำหนด";
    case "RC": return "หมายเหตุ: ได้รับเงินครบถ้วนตามรายการข้างต้น";
    default: return "";
  }
}

function buildDiscountRow(draft: Draft, opts: RenderOptions): string {
  const t = draft.totals;
  if (!t || !t.discountAmount || t.discountAmount <= 0) return "";
  return `<tr><td>ส่วนลด</td><td class="right">-${fmtMoney(t.discountAmount, opts)}</td></tr>`;
}

function buildItemRows(draft: Draft, opts: RenderOptions): string {
  const items = Array.isArray(draft.items) ? draft.items : [];
  if (items.length === 0) {
    return `<tr><td style="text-align:center">-</td><td colspan="4" style="text-align:center; color:#666">ยังไม่มีรายการ</td></tr>`;
  }
  return items.map((it, idx) => {
    const qty = Number.isFinite(it.qty) ? it.qty : 0;
    const unit = Number.isFinite(it.unitPrice) ? it.unitPrice : 0;
    const total = qty * unit;
    return `<tr><td style="text-align:center">${idx + 1}</td><td>${esc(it.name)}</td><td class="right">${fmtQty(qty, opts)}</td><td class="right">${fmtMoney(unit, opts)}</td><td class="right">${fmtMoney(total, opts)}</td></tr>`;
  }).join("\n");
}

export function renderPdfHtml(draft: Draft, opts: RenderOptions = {}): string {
  const company = { ...DEFAULT_COMPANY, ...(draft.company ?? {}) };
  const DOC_TITLE = docTitle(draft.docType);
  const DOC_NO = esc(draft.docNo);
  const DOC_DATE = esc(draft.docDate);
  const CUSTOMER_NAME = esc(draft.customer?.name ?? "-");
  const CUSTOMER_ADDRESS = esc(draft.customer?.address ?? "-");
  const META_INFO = buildMetaInfo(draft) || "-";
  const ITEM_ROWS = buildItemRows(draft, opts);
  const SUBTOTAL = fmtMoney(draft.totals?.subtotal ?? 0, opts);
  const VAT_RATE = esc(draft.vatRate ?? 0);
  const VAT_AMOUNT = fmtMoney(draft.totals?.vatAmount ?? 0, opts);
  const DISCOUNT_ROW = buildDiscountRow(draft, opts);
  const GRAND_TOTAL = fmtMoney(draft.totals?.grandTotal ?? 0, opts);
  const FOOTER_NOTE = esc(buildFooterNote(draft));

  return `<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="utf-8" />
<style>
body{font-family:"TH Sarabun New","Sarabun",Arial,sans-serif;font-size:14px;color:#111;margin:32px}
.header{display:flex;justify-content:space-between;border-bottom:2px solid #000;padding-bottom:8px;margin-bottom:16px}
.company{font-size:16px;font-weight:700;line-height:1.2}
.doc-title{text-align:right;line-height:1.4}
.doc-title h1{margin:0;font-size:20px}
.meta{margin:16px 0;display:flex;justify-content:space-between;gap:12px}
.box{border:1px solid #000;padding:8px;width:50%}
table{width:100%;border-collapse:collapse;margin-top:16px}
th,td{border:1px solid #000;padding:6px;vertical-align:top}
th{background:#f2f2f2;text-align:center}
td.right{text-align:right}
.summary{margin-top:16px;display:flex;justify-content:flex-end}
.summary table{width:320px;margin-top:0}
.footer{margin-top:24px;font-size:12px;color:#111}
.sign{margin-top:42px;display:flex;justify-content:space-between}
.sign>div{width:45%;text-align:center}
.sign .line{border-top:1px solid #000;margin-top:48px;padding-top:4px}
.muted{color:#666;font-weight:400}
</style>
</head>
<body>
<div class="header">
<div class="company">${esc(company.name)}<br/><span class="muted">${esc(company.address ?? "")}</span>${company.taxId ? `<br/><span class="muted">เลขผู้เสียภาษี: ${esc(company.taxId)}</span>` : ""}</div>
<div class="doc-title"><h1>${DOC_TITLE}</h1>เลขที่เอกสาร: ${DOC_NO}<br/>วันที่: ${DOC_DATE}</div>
</div>
<div class="meta">
<div class="box"><b>ลูกค้า</b><br/>${CUSTOMER_NAME}<br/>${CUSTOMER_ADDRESS}</div>
<div class="box"><b>ข้อมูลเอกสาร</b><br/>${META_INFO}</div>
</div>
<table>
<thead><tr><th style="width:5%">#</th><th>รายการ</th><th style="width:10%">จำนวน</th><th style="width:15%">ราคา/หน่วย</th><th style="width:15%">รวม</th></tr></thead>
<tbody>${ITEM_ROWS}</tbody>
</table>
<div class="summary">
<table>
<tr><td>รวม</td><td class="right">${SUBTOTAL}</td></tr>
${DISCOUNT_ROW}
<tr><td>VAT ${VAT_RATE}%</td><td class="right">${VAT_AMOUNT}</td></tr>
<tr><th>รวมสุทธิ</th><th class="right">${GRAND_TOTAL}</th></tr>
</table>
</div>
<div class="footer">${FOOTER_NOTE}</div>
<div class="sign">
<div><div class="line">ผู้ออกเอกสาร</div></div>
<div><div class="line">ผู้รับเอกสาร</div></div>
</div>
</body>
</html>`;
}
