/**
 * Human-First UX State Machine
 * 
 * Simplified 3-state model:
 * - IDLE: No draft
 * - IN_DOCUMENT: Has draft (editing)
 * - WAITING_CONFIRM: Draft ready (has customer + at least 1 item)
 */

import type { QuickReplyAction } from '../shared/lineQuickReply';
import { getMainMenuButtons } from '../ui/quickReplies';
import { HUMAN_FIRST_UX_ENABLED } from '../shared/config';

export enum HumanFirstState {
  IDLE = 'IDLE',
  IN_DOCUMENT = 'IN_DOCUMENT',
  WAITING_CONFIRM = 'WAITING_CONFIRM',
}

/**
 * Determine state from draft status
 */
export function determineHumanFirstState(
  hasDraft: boolean,
  hasCustomer: boolean,
  hasItems: boolean
): HumanFirstState {
  if (!hasDraft) {
    return HumanFirstState.IDLE;
  }
  
  if (hasCustomer && hasItems) {
    return HumanFirstState.WAITING_CONFIRM;
  }
  
  return HumanFirstState.IN_DOCUMENT;
}

/**
 * Get buttons for human-first state
 */
export function getHumanFirstButtons(state: HumanFirstState): QuickReplyAction[] {
  if (!HUMAN_FIRST_UX_ENABLED) {
    return []; // Fallback to old system
  }
  
  switch (state) {
    case HumanFirstState.IDLE:
      // Main menu
      return getMainMenuButtons();
      
    case HumanFirstState.IN_DOCUMENT:
      // Minimal buttons while editing
      return [
        { type: 'action', action: { type: 'message', label: 'ออกเอกสาร', text: 'ออกเอกสาร' } },
        { type: 'action', action: { type: 'message', label: 'ลบ', text: 'ลบ' } },
        { type: 'action', action: { type: 'message', label: 'เริ่มใหม่', text: 'เริ่มใหม่' } },
      ];
      
    case HumanFirstState.WAITING_CONFIRM:
      // Ready to confirm
      return [
        { type: 'action', action: { type: 'message', label: 'ออกเอกสาร', text: 'ออกเอกสาร' } },
        { type: 'action', action: { type: 'message', label: 'กลับไปแก้', text: 'ลบ' } },
        { type: 'action', action: { type: 'message', label: 'เริ่มใหม่', text: 'เริ่มใหม่' } },
      ];
      
    default:
      return [];
  }
}

