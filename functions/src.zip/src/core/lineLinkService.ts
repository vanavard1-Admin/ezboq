/**
 * LINE Account Linking Service
 * Manages bidirectional mapping between LINE userId and Firebase UID
 * Generates and verifies cryptographically signed state for OAuth flow
 */

import * as crypto from 'crypto';
import { FieldValue, getFirestore, Timestamp } from 'firebase-admin/firestore';

/**
 * Firestore schema for line_links/{lineUserId}
 */
export interface LineLink {
  lineUserId: string;
  uid: string; // Firebase UID
  businessId: string; // Default business for this user
  linkedAt: Timestamp;
  provider: 'line-login';
  status: 'ACTIVE' | 'REVOKED';
}

/**
 * State payload structure for OAuth flow
 */
export interface LinkState {
  lineUserId: string;
  nonce: string;
  iat: number; // Issued at (seconds)
  exp: number; // Expires at (seconds)
  sig: string; // HMAC-SHA256 signature
}

const STATE_EXPIRE_SECONDS = 600; // 10 minutes
const NONCE_STORE_MINUTES = 15; // Store used nonces for 15 minutes

/**
 * Generate a cryptographically signed state for LINE linking
 * Returns: state string (base64 encoded)
 */
export function generateLinkState(lineUserId: string, secret: string): string {
  const nonce = crypto.randomBytes(16).toString('hex');
  const now = Math.floor(Date.now() / 1000);
  const exp = now + STATE_EXPIRE_SECONDS;

  const payload = {
    lineUserId,
    nonce,
    iat: now,
    exp,
  };

  // Create signature from payload (without sig field)
  const payloadStr = JSON.stringify(payload);
  const sig = crypto.createHmac('sha256', secret).update(payloadStr).digest('hex');

  const stateObj: LinkState = {
    ...payload,
    sig,
  };

  return Buffer.from(JSON.stringify(stateObj)).toString('base64');
}

/**
 * Verify a signed state and check expiration
 * Returns: { valid: boolean, payload?: LinkState, error?: string }
 */
export function verifyLinkState(
  stateBase64: string,
  secret: string
): { valid: boolean; payload?: LinkState; error?: string } {
  try {
    const stateStr = Buffer.from(stateBase64, 'base64').toString('utf-8');
    const state: LinkState = JSON.parse(stateStr);

    // Check expiration
    const now = Math.floor(Date.now() / 1000);
    if (now > state.exp) {
      return { valid: false, error: 'State expired' };
    }

    // Verify signature
    const payloadForSig = {
      lineUserId: state.lineUserId,
      nonce: state.nonce,
      iat: state.iat,
      exp: state.exp,
    };
    const payloadStr = JSON.stringify(payloadForSig);
    const expectedSig = crypto.createHmac('sha256', secret).update(payloadStr).digest('hex');

    if (state.sig !== expectedSig) {
      return { valid: false, error: 'Invalid signature' };
    }

    return { valid: true, payload: state };
  } catch (err) {
    return { valid: false, error: `State parsing failed: ${err}` };
  }
}

/**
 * Record a used nonce to prevent replay attacks
 */
export async function recordUsedNonce(nonce: string): Promise<void> {
  const db = getFirestore();
  const nonceRef = db.collection('_line_link_nonces').doc(nonce);
  const ttl = Math.floor(Date.now() / 1000) + NONCE_STORE_MINUTES * 60;

  await nonceRef.set(
    {
      usedAt: Timestamp.now(),
      expiresAt: Timestamp.fromDate(new Date(ttl * 1000)),
    },
    { merge: true }
  );
}

/**
 * Check if nonce was already used
 */
export async function checkNonceUsed(nonce: string): Promise<boolean> {
  const db = getFirestore();
  const nonceRef = db.collection('_line_link_nonces').doc(nonce);
  const snap = await nonceRef.get();
  return snap.exists;
}

/**
 * Create or update line_links entry
 */
export async function linkLineUserToFirebase(
  lineUserId: string,
  uid: string,
  businessId: string
): Promise<LineLink> {
  const db = getFirestore();
  const linkRef = db.collection('line_links').doc(lineUserId);
  const userRef = db.collection('users').doc(uid);

  const link: LineLink = {
    lineUserId,
    uid,
    businessId,
    linkedAt: Timestamp.now(),
    provider: 'line-login',
    status: 'ACTIVE',
  };

  await db.runTransaction(async (tx) => {
    // Primary requirement: always persist to users/{uid}.lineUserId
    tx.set(
      userRef,
      {
        lineUserId,
        lineLinkedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // Keep existing index doc for reverse lookup/audit
    tx.set(
      linkRef,
      {
        ...link,
        linkedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  });
  return link;
}

/**
 * Get line link by lineUserId
 * Only returns ACTIVE links (soft unlink support)
 */
export async function getLineLink(lineUserId: string): Promise<LineLink | null> {
  const db = getFirestore();
  const linkRef = db.collection('line_links').doc(lineUserId);
  const snap = await linkRef.get();

  if (!snap.exists) {
    return null;
  }

  const data = snap.data() as LineLink;
  
  // Return null if link is not active (soft unlink)
  if (data.status !== 'ACTIVE') {
    return null;
  }

  return data;
}

/**
 * Get line link by Firebase UID (reverse lookup)
 */
export async function getLineLinkByUid(uid: string): Promise<LineLink | null> {
  const db = getFirestore();
  const snapshot = await db
    .collection('line_links')
    .where('uid', '==', uid)
    .where('status', '==', 'ACTIVE')
    .limit(1)
    .get();

  if (snapshot.empty) {
    return null;
  }

  return snapshot.docs[0].data() as LineLink;
}

/**
 * Revoke line link
 */
export async function revokeLinkLineUser(lineUserId: string): Promise<void> {
  const db = getFirestore();
  const linkRef = db.collection('line_links').doc(lineUserId);
  await linkRef.update({ status: 'REVOKED' });
}
