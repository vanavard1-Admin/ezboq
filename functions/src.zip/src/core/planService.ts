/**
 * Plan Service
 * 
 * Centralized plan-aware feature gating and authorization
 * 
 * CORE PRINCIPLES:
 * - PRO (99฿) = Complete flow for solo users
 * - TEAM (299฿) = Scale & collaboration features
 * - Never gate core flow (Invoice/Receipt) behind TEAM
 * - Credits are for cost-based features only, not document flow
 */

import * as admin from "firebase-admin";
import type { PlanId } from "../lib/promptpay";

const db = admin.firestore();

// ============================================================================
// PLAN DEFINITIONS
// ============================================================================

export type Plan = "FREE" | "PRO" | "TEAM";

export interface PlanFeatures {
  // Document flow
  canCreateQuotation: boolean;
  canCreateInvoice: boolean;
  canCreateReceipt: boolean;
  canCreateInstallments: boolean;
  
  // Limits
  maxDocumentsPerMonth: number; // 0 = unlimited
  maxDocumentsPerDay: number;
  maxRequestsPerMinute: number;
  
  // Branding
  hasWatermark: boolean;
  canUseLogo: boolean;
  canUseSignature: boolean;
  
  // Users & roles
  maxUsers: number; // 0 = unlimited
  canHaveMultipleUsers: boolean;
  canHaveRoles: boolean;
  
  // Data & operations
  canExportDocuments: boolean;
  canViewReports: boolean;
  canViewAuditLogs: boolean;
  canHaveMultiBusiness: boolean;
  
  // Cost-based features (credits)
  ocrQuotaPerMonth: number;
  aiQuotaPerMonth: number;
  canPurchaseCredits: boolean;
  
  // Support
  hasEmailSupport: boolean;
  hasPrioritySupport: boolean;
}

// ============================================================================
// PLAN CONFIGURATION
// ============================================================================

const PLAN_CONFIG: Record<Plan, PlanFeatures> = {
  FREE: {
    // Document flow
    canCreateQuotation: true,
    canCreateInvoice: false,
    canCreateReceipt: false,
    canCreateInstallments: false,
    
    // Limits
    maxDocumentsPerMonth: 5, // 5 documents/month
    maxDocumentsPerDay: 5,
    maxRequestsPerMinute: 10,
    
    // Branding
    hasWatermark: true,
    canUseLogo: false,
    canUseSignature: false,
    
    // Users & roles
    maxUsers: 1,
    canHaveMultipleUsers: false,
    canHaveRoles: false,
    
    // Data & operations
    canExportDocuments: false,
    canViewReports: false,
    canViewAuditLogs: false,
    canHaveMultiBusiness: false,
    
    // Cost-based features
    ocrQuotaPerMonth: 5,
    aiQuotaPerMonth: 0,
    canPurchaseCredits: false,
    
    // Support
    hasEmailSupport: false,
    hasPrioritySupport: false,
  },
  
  PRO: {
    // Document flow - COMPLETE FLOW FOR SOLO USERS
    canCreateQuotation: true,
    canCreateInvoice: true,
    canCreateReceipt: true,
    canCreateInstallments: true,
    
    // Limits
    maxDocumentsPerMonth: 0, // 0 = unlimited
    maxDocumentsPerDay: 100,
    maxRequestsPerMinute: 60,
    
    // Branding
    hasWatermark: false,
    canUseLogo: true,
    canUseSignature: true,
    
    // Users & roles
    maxUsers: 1,
    canHaveMultipleUsers: false,
    canHaveRoles: false,
    
    // Data & operations
    canExportDocuments: true,
    canViewReports: false,
    canViewAuditLogs: false,
    canHaveMultiBusiness: false,
    
    // Cost-based features
    ocrQuotaPerMonth: 50,
    aiQuotaPerMonth: 10,
    canPurchaseCredits: true,
    
    // Support
    hasEmailSupport: true,
    hasPrioritySupport: false,
  },
  
  TEAM: {
    // Document flow - Everything in PRO
    canCreateQuotation: true,
    canCreateInvoice: true,
    canCreateReceipt: true,
    canCreateInstallments: true,
    
    // Limits
    maxDocumentsPerMonth: 0, // 0 = unlimited (null not allowed in number type)
    maxDocumentsPerDay: 100,
    maxRequestsPerMinute: 60,
    
    // Branding
    hasWatermark: false,
    canUseLogo: true,
    canUseSignature: true,
    
    // Users & roles - TEAM FEATURES
    maxUsers: 0, // 0 = unlimited (null not allowed in number type)
    canHaveMultipleUsers: true,
    canHaveRoles: true,
    
    // Data & operations - TEAM FEATURES
    canExportDocuments: true,
    canViewReports: true,
    canViewAuditLogs: true,
    canHaveMultiBusiness: true, // Future-ready
    
    // Cost-based features
    ocrQuotaPerMonth: 200,
    aiQuotaPerMonth: 50,
    canPurchaseCredits: true,
    
    // Support
    hasEmailSupport: true,
    hasPrioritySupport: true,
  },
};

// ============================================================================
// PLAN DETECTION & MIGRATION
// ============================================================================

/**
 * Normalize plan from subscription data
 * Handles migration from old plan IDs (MONTHLY_99, MONTHLY_299) to new plans (PRO, TEAM)
 */
export function normalizePlan(plan: string | PlanId | Plan): Plan {
  // New plan format
  if (plan === "FREE" || plan === "PRO" || plan === "TEAM") {
    return plan;
  }
  
  // Legacy plan IDs
  if (plan === "MONTHLY_99") {
    return "PRO";
  }
  
  if (plan === "MONTHLY_299") {
    return "TEAM";
  }
  
  // Default to FREE
  return "FREE";
}

/**
 * Get user's current plan
 * 
 * Error handling: If Firestore fails, defaults to FREE plan to avoid blocking user operations
 */
export async function getUserPlan(uid: string): Promise<Plan> {
  try {
  const subRef = db.collection("subscriptions").doc(uid);
  const subSnap = await subRef.get();
  
  if (!subSnap.exists) {
    return "FREE";
  }
  
  const subscription = subSnap.data();
  const plan = subscription?.plan || "FREE";
  
  return normalizePlan(plan);
  } catch (error) {
    // Log error but don't block user operations - default to FREE plan
    console.error(`[getUserPlan] Failed to fetch plan for uid=${uid}, defaulting to FREE:`, error);
    return "FREE";
  }
}

/**
 * Get plan features for a user
 */
export async function getUserPlanFeatures(uid: string): Promise<PlanFeatures> {
  const plan = await getUserPlan(uid);
  return PLAN_CONFIG[plan];
}

/**
 * Get plan features directly from plan string
 */
export function getPlanFeatures(plan: Plan | string): PlanFeatures {
  const normalized = normalizePlan(plan);
  return PLAN_CONFIG[normalized];
}

// ============================================================================
// FEATURE CHECKS
// ============================================================================

/**
 * Check if user can create a specific document type
 */
export async function canCreateDocumentType(
  uid: string,
  docType: "QUO" | "INV" | "REC"
): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  
  switch (docType) {
    case "QUO":
      return features.canCreateQuotation;
    case "INV":
      return features.canCreateInvoice;
    case "REC":
      return features.canCreateReceipt;
    default:
      return false;
  }
}

/**
 * Check if user can create installments
 */
export async function canCreateInstallments(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canCreateInstallments;
}

/**
 * Check if document should have watermark
 */
export async function shouldAddWatermark(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.hasWatermark;
}

/**
 * Check if user can use branding features (logo, signature)
 */
export async function canUseBranding(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canUseLogo && features.canUseSignature;
}

/**
 * Check if user can export documents
 */
export async function canExportDocuments(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canExportDocuments;
}

/**
 * Check if user can view reports
 */
export async function canViewReports(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canViewReports;
}

/**
 * Check if user can have multiple users (TEAM feature)
 */
export async function canHaveMultipleUsers(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canHaveMultipleUsers;
}

/**
 * Check if user can have roles (TEAM feature)
 */
export async function canHaveRoles(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canHaveRoles;
}

// ============================================================================
// RATE LIMITS
// ============================================================================

/**
 * Get rate limit configuration for a plan
 */
export function getRateLimits(plan: Plan | string) {
  const features = getPlanFeatures(plan);
  
  return {
    maxRequestsPerMinute: features.maxRequestsPerMinute,
    maxDocsPerDay: features.maxDocumentsPerDay,
    maxDocsPerMonth: features.maxDocumentsPerMonth === 0 ? null : features.maxDocumentsPerMonth,
  };
}

// ============================================================================
// CREDITS (COST-BASED FEATURES)
// ============================================================================

/**
 * Get OCR quota for a plan
 */
export function getOcrQuota(plan: Plan | string): number {
  const features = getPlanFeatures(plan);
  return features.ocrQuotaPerMonth;
}

/**
 * Get AI quota for a plan
 */
export function getAiQuota(plan: Plan | string): number {
  const features = getPlanFeatures(plan);
  return features.aiQuotaPerMonth;
}

/**
 * Check if user can purchase credits
 */
export async function canPurchaseCredits(uid: string): Promise<boolean> {
  const features = await getUserPlanFeatures(uid);
  return features.canPurchaseCredits;
}

