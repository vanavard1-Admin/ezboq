// functions/src/core/conversationHandler.ts
// EzDoc - Main conversation handler (5B-0 intent routing)
// Phase 5B-0.1: Quick reply integration
// Phase 5B-1: Payment confirmation integration

import * as admin from "firebase-admin";
import {
  type QuickReplyAction,
} from "../shared/lineQuickReply";
import {
  handlePaymentNotification,
  handlePaymentConfirmation,
} from "./paymentConfirmation";
import { getOrCreateDraft, updateDraft, getDraft, clearDraft, formatDraftForDisplay, type LineDraft } from "./draftStore";
import { buildDraftEditorQuickReply } from "../shared/lineDraftReply";
import {
  DraftToIssuedDocTypeMap,
  UnpaidStatuses,
  DocStatusIssued,
  DocNumberPrefixes,
} from "../shared/schemas";
import { buildPdfFlexMessageWithShortLink } from "../shared/pdfFlexMessage";
import { buildDocumentSnapshots } from "../shared/documentSnapshots";

/**
 * HELPER: Resolve invoice docId from message text or fallback to latest unpaid
 * Priority:
 * 1. Parse "INV-xxxx" from message → query by doc_no + doc_type=BILL + status in [ISSUED, UNPAID, AWAITING_PAYMENT]
 * 2. Fallback: Get latest BILL with any unpaid status
 * Returns null if not found
 */
async function resolveInvoiceDocId(
  userId: string,
  businessId: string,
  messageText: string
): Promise<string | null> {
  const db = admin.firestore();
  const unPaidStatuses = UnpaidStatuses;

  // Priority 1: Extract INV-xxxx from message
  const invNoMatch = messageText.match(/INV-\d+-\d+/i);
  if (invNoMatch) {
    const invNo = invNoMatch[0];
    try {
      // Try to find by doc_no + status in unpaid list
      const snapshot = await db
        .collection("users")
        .doc(userId)
        .collection("businesses")
        .doc(businessId)
        .collection("documents")
        .where("doc_no", "==", invNo)
        .where("doc_type", "==", "BILL")
        .get();

      const validDocs = snapshot.docs.filter((doc) => {
        const status = (doc.data()?.status as string) || "";
        return UnpaidStatuses.includes(status as typeof UnpaidStatuses[number]);
      });

      if (validDocs.length > 0) {
        const doc = validDocs[0];
        const status = (doc.data()?.status as string) || "?";
      // ✅ FIX 5: Use secure logging (migrate info logs with PII)
      // Note: secureLog imported at top level, no need to redeclare
      const { secureLog: logSecure } = await import('../utils/secureConsole');
      logSecure({
        tag: '[RESOLVE_INVOICE_FOUND]',
        trace_id: 'n/a',
        doc_id: doc.id,
        status: status,
        timestamp: new Date().toISOString(),
      });
        return doc.id;
      } else {
        // ✅ FIX 5: Use secure logging
        const { secureLog: logSecure } = await import('../utils/secureConsole');
        logSecure({
          tag: '[RESOLVE_INVOICE_STATUS_MISMATCH]',
          trace_id: 'n/a',
          expected_statuses: unPaidStatuses,
          found_statuses: snapshot.docs.map((d) => d.data()?.status).filter(Boolean),
          timestamp: new Date().toISOString(),
        });
        return null;
      }
    } catch (err) {
      // ✅ FIX 5: Use secure error logging (migrate error logs first)
      const { secureError } = await import('../utils/secureConsole');
      secureError({
        tag: '[RESOLVE_INVOICE_ERROR]',
        trace_id: 'n/a',
        doc_no: invNo,
        user_id: userId,
        business_id: businessId,
        timestamp: new Date().toISOString(),
      }, err);
      return null;
    }
  }

  // Priority 2: Fallback to latest BILL with unpaid status
  try {
    const snapshot = await db
      .collection("users")
      .doc(userId)
      .collection("businesses")
      .doc(businessId)
      .collection("documents")
      .where("doc_type", "==", "BILL")
      .orderBy("created_at", "desc")
      .limit(10)
      .get();

    const validDocs = snapshot.docs.filter((doc) => {
      const status = (doc.data()?.status as string) || "";
      return UnpaidStatuses.includes(status as typeof UnpaidStatuses[number]);
    });

    if (validDocs.length > 0) {
      const doc = validDocs[0];
      const status = (doc.data()?.status as string) || "?";
      // ✅ FIX 5: Use secure logging
      const { secureLog: logSecure } = await import('../utils/secureConsole');
      logSecure({
        tag: '[RESOLVE_INVOICE_FALLBACK]',
        trace_id: 'n/a',
        doc_id: doc.id,
        status: status,
        timestamp: new Date().toISOString(),
      });
      return doc.id;
    }
  } catch (err) {
    // ✅ FIX 5: Use secure error logging
    const { secureError } = await import('../utils/secureConsole');
    secureError({
      tag: '[RESOLVE_INVOICE_ERROR]',
      trace_id: 'n/a',
      user_id: userId,
      business_id: businessId,
      error_type: 'latest_bill_query',
      timestamp: new Date().toISOString(),
    }, err);
  }

  console.log(
    `[resolveInvoice] No unpaid BILL found for user=${userId}, business=${businessId}`
  );
  return null;
}

/**
 * Helper: Create Invoice from existing Quotation
 * Flow: QUO → INV (copy data, create as DRAFT)
 * 
 * Supports multi-installment billing:
 * - "สร้างใบวางบิลจาก QUO-xxxx" → full amount
 * - "สร้างใบวางบิลจาก QUO-xxxx งวด 1 50000" → installment with amount
 * 
 * Rules:
 * - QUO must exist and status = ISSUED (not CLOSED)
 * - Copies: customer_snapshot, items, totals, business_snapshot, payment_snapshot
 * - Uses invoice_terms (not quotation_terms)
 * - Does NOT generate PDF or deduct credits
 * - Creates INV as DRAFT for confirmation
 */
async function createInvoiceFromQuotation(
  userId: string,
  businessId: string,
  messageText: string,
  replyFn: (msg: string) => Promise<void>
): Promise<string | null> {
  const db = admin.firestore();

  // Parse QUO number and optional installment from message
  // Pattern: "สร้างใบวางบิลจาก QUO-2569-001" or "สร้างใบวางบิลจาก QUO-2569-001 งวด 1 50000"
  const quoMatch = messageText.match(/(?:QUO|QOU)[\s-]*(\d+)[\s-]*(\d+)/i);
  if (!quoMatch) {
    await replyFn("❌ กรุณาระบุเลขที่ใบเสนอราคา\nตัวอย่าง: สร้างใบวางบิลจาก QUO-2569-001\nหรือ: สร้างใบวางบิลจาก QUO-2569-001 งวด 1 50000");
    return null;
  }

  const quoNo = `QUO-${quoMatch[1]}-${quoMatch[2]}`;
  
  // Parse installment info (optional)
  const installmentMatch = messageText.match(/งวด\s*(\d+)(?:\s+(\d+))?/i);
  let installmentNo: number | null = null;
  let installmentAmount: number | null = null;
  
  if (installmentMatch) {
    installmentNo = parseInt(installmentMatch[1], 10);
    if (installmentMatch[2]) {
      installmentAmount = parseInt(installmentMatch[2], 10);
    }
  }

  // ✅ FIX 5: Use secure logging (migrate info logs with PII)
  const { secureLog: logSecure1 } = await import('../utils/secureConsole');
  logSecure1({
    tag: '[CREATE_INV_FROM_QUO_START]',
    trace_id: 'n/a',
    installment_no: installmentNo,
    timestamp: new Date().toISOString(),
  });

  // Find the QUO document
  const quoQuery = await db
    .collection("users")
    .doc(userId)
    .collection("businesses")
    .doc(businessId)
    .collection("documents")
    .where("doc_no", "==", quoNo)
    .where("doc_type", "==", "QUOTATION")
    .limit(1)
    .get();

  if (quoQuery.empty) {
    await replyFn(`❌ ไม่พบใบเสนอราคา ${quoNo}\nกรุณาตรวจสอบเลขที่เอกสาร`);
    return null;
  }

  const quoDoc = quoQuery.docs[0];
  const quoData = quoDoc.data();
  const quoTotal = quoData.total || quoData.total_amount || 0;

  // Validate QUO status
  if (quoData.status === "CLOSED") {
    await replyFn(`❌ ${quoNo} ปิดแล้ว (ออกบิลครบ)\nไม่สามารถสร้างใบวางบิลเพิ่มได้`);
    return null;
  }
  
  if (quoData.status !== "ISSUED") {
    await replyFn(`❌ ใบเสนอราคา ${quoNo} ยังไม่ได้ออก (สถานะ: ${quoData.status})\nสามารถสร้างใบวางบิลได้จากใบเสนอราคาที่ออกแล้วเท่านั้น`);
    return null;
  }

  // Get installment summary for validation
  const { getInstallmentSummary, getNextInstallmentNo, validateInstallment } = await import("../services/installmentService");
  const summary = await getInstallmentSummary(userId, businessId, quoNo);
  const remainingBalance = summary?.remainingBalance ?? quoTotal;

  // Validate installment if specified
  if (installmentNo !== null) {
    // Auto-assign installment number if not provided
    if (!installmentNo) {
      installmentNo = await getNextInstallmentNo(userId, businessId, quoDoc.id);
    }

    // Auto-set amount to remaining if final installment or not specified
    if (!installmentAmount || installmentAmount > remainingBalance) {
      installmentAmount = remainingBalance;
    }

    // Validate (installmentNo and installmentAmount are guaranteed to be numbers here)
    const validation = await validateInstallment(userId, businessId, quoDoc.id, installmentNo!, installmentAmount!);
    if (!validation.valid) {
      await replyFn(`❌ ${validation.error}`);
      return null;
    }
  } else {
    // No installment specified - check if there are existing installments
    if (summary && summary.installments.length > 0) {
      // QUO already has installments, require explicit installment number
      const nextNo = await getNextInstallmentNo(userId, businessId, quoDoc.id);
      const remainingFmt = remainingBalance.toLocaleString("th-TH");
      await replyFn(
        `⚠️ ${quoNo} มีงวดอยู่แล้ว ${summary.installments.length} งวด\n` +
        `คงเหลือ: ${remainingFmt} บาท\n\n` +
        `กรุณาระบุงวด:\nสร้างใบวางบิลจาก ${quoNo} งวด ${nextNo} ${remainingBalance}`
      );
      return null;
    }
    // No existing installments - use full amount (installment 1)
    installmentNo = 1;
    installmentAmount = quoTotal;
  }

  // Check if remaining is 0
  if (remainingBalance <= 0) {
    await replyFn(`❌ ${quoNo} ออกบิลครบแล้ว\nไม่มียอดคงเหลือ`);
    return null;
  }

  // ✅ FIX 5: Use secure logging (redact customer name, amounts)
  const { secureLog: logSecure2 } = await import('../utils/secureConsole');
  logSecure2({
    tag: '[CREATE_INV_FROM_QUO_FOUND]',
    trace_id: 'n/a',
    quo_id: quoDoc.id,
    installment_no: installmentNo,
    timestamp: new Date().toISOString(),
  });

  // Load invoice_terms from settings (if any)
  let invoiceTerms = "กรุณาชำระเงินภายในวันที่กำหนด";
  try {
    const termsDoc = await db
      .doc(`users/${userId}/businesses/${businessId}/settings/terms`)
      .get();
    if (termsDoc.exists) {
      const termsData = termsDoc.data();
      invoiceTerms = termsData?.invoice_terms || invoiceTerms;
    }
  } catch (e) {
    // ✅ FIX 5: Use secure error logging
    const { secureWarn } = await import('../utils/secureConsole');
    secureWarn({
      tag: '[CREATE_INV_FROM_QUO_ERROR]',
      trace_id: 'n/a',
      user_id: userId,
      business_id: businessId,
      error_type: 'terms_loading',
      timestamp: new Date().toISOString(),
    });
  }

  // Create INV draft (in draftStore)
  // For installments, we don't copy items - just use amount
  const invDraft: LineDraft = {
    docType: "BILL",
    customerName: quoData.customer_name || quoData.customer_snapshot?.name || "",
    customerId: quoData.customer_id || quoData.customer_snapshot?.id || null,
    items: installmentNo === 1 && installmentAmount === quoTotal
      ? (quoData.items || []).map((item: { name?: string; description?: string; qty?: number; quantity?: number; price?: number; unit_price?: number }) => ({
          name: item.name || item.description || "",
          qty: item.qty || item.quantity || 1,
          price: item.price || item.unit_price || 0,
        }))
      : [{ name: `งวดที่ ${installmentNo} (${quoNo})`, qty: 1, price: installmentAmount || 0 }],
    subtotal: installmentAmount || 0,
    vat: 0, // VAT calculated on issuance
    wht: 0,
    total: installmentAmount || 0,
    notes: "",
    // Source document link
    source_doc_type: "QUO",
    source_doc_id: quoDoc.id,
    source_doc_no: quoNo,
    // Installment info
    installment_no: installmentNo,
    installment_total: installmentAmount,
    // Lock items and customer (cannot edit)
    locked_fields: ["items", "customerName", "customerId"],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  // Store draft
  const { getOrCreateDraft, updateDraft } = await import("./draftStore");
  await getOrCreateDraft(userId, businessId, "BILL"); // Initialize draft structure
  await updateDraft(userId, invDraft); // Override with QUO data

  // ✅ FIX 5: Use secure logging
  const { secureLog: logSecure3 } = await import('../utils/secureConsole');
  logSecure3({
    tag: '[CREATE_INV_FROM_QUO_CREATED]',
    trace_id: 'n/a',
    installment_no: installmentNo,
    timestamp: new Date().toISOString(),
  });

  // Format response
  const amountFormatted = (installmentAmount || 0).toLocaleString("th-TH", { minimumFractionDigits: 2 });
  const remainingAfter = remainingBalance - (installmentAmount || 0);
  const remainingFormatted = remainingAfter.toLocaleString("th-TH", { minimumFractionDigits: 2 });
  const customerDisplay = invDraft.customerName || "ไม่ระบุ";

  let response = `📄 สร้างใบวางบิลจาก ${quoNo}\n\n`;
  response += `👤 ลูกค้า: ${customerDisplay}\n`;
  response += `📝 งวดที่: ${installmentNo}\n`;
  response += `💰 ยอดงวดนี้: ${amountFormatted} บาท\n`;
  response += `📍 คงเหลือหลังออกบิล: ${remainingFormatted} บาท\n\n`;
  response += `⚠️ ลูกค้าล็อกจากใบเสนอราคา\n`;
  response += `📝 เพิ่มหมายเหตุได้: พิมพ์ "หมายเหตุ [ข้อความ]"\n\n`;
  response += `พิมพ์ "ยืนยัน" เพื่อออกเอกสาร`;

  return response;
}

/**
 * Helper: Create Receipt from existing Invoice
 * Flow: INV → REC (copy data, create as DRAFT)
 * 
 * Rules:
 * - INV must exist and status = ISSUED
 * - One INV → One REC only
 * - Copies: customer_snapshot, items, totals, business_snapshot, payment_snapshot
 * - Uses receipt_terms
 * - Does NOT generate PDF or deduct credits
 * - Creates REC as DRAFT for confirmation
 */
async function createReceiptFromInvoice(
  userId: string,
  businessId: string,
  messageText: string,
  replyFn: (msg: string) => Promise<void>
): Promise<string | null> {
  const db = admin.firestore();

  // Parse INV number from message
  // Pattern: "สร้างใบเสร็จจาก INV-2569-001"
  const invMatch = messageText.match(/(?:INV|INVOICE|บิล)[\s-]*(\d+)[\s-]*(\d+)/i);
  if (!invMatch) {
    await replyFn("❌ กรุณาระบุเลขที่ใบวางบิล\nตัวอย่าง: สร้างใบเสร็จจาก INV-2569-001");
    return null;
  }

  const invNo = `INV-${invMatch[1]}-${invMatch[2]}`;
  // ✅ FIX 5: Use secure logging
  const { secureLog: logSecure } = await import('../utils/secureConsole');
  logSecure({
    tag: '[CREATE_REC_FROM_INV_START]',
    trace_id: 'n/a',
    timestamp: new Date().toISOString(),
  });

  // Find the INV document
  // ✅ FIX: Query for "INVOICE" (not "BILL") - documents are stored as "INVOICE" after issuance
  const invQuery = await db
    .collection("users")
    .doc(userId)
    .collection("businesses")
    .doc(businessId)
    .collection("documents")
    .where("doc_no", "==", invNo)
    .where("doc_type", "==", "INVOICE")
    .limit(1)
    .get();

  if (invQuery.empty) {
    await replyFn(`❌ ไม่พบใบวางบิล ${invNo}\nกรุณาตรวจสอบเลขที่เอกสาร`);
    return null;
  }

  const invDoc = invQuery.docs[0];
  const invData = invDoc.data();

  // Validate INV status
  if (invData.status !== "ISSUED" && invData.status !== "PAID") {
    await replyFn(`❌ ใบวางบิล ${invNo} ยังไม่ได้ออก (สถานะ: ${invData.status})\nสามารถสร้างใบเสร็จได้จากใบวางบิลที่ออกแล้วเท่านั้น`);
    return null;
  }

  // Check if REC already exists for this INV
  const { hasReceiptFromInvoice } = await import("../services/installmentService");
  const hasRec = await hasReceiptFromInvoice(userId, businessId, invDoc.id);
  if (hasRec) {
    await replyFn(`❌ ใบวางบิล ${invNo} มีใบเสร็จแล้ว\nหนึ่งใบวางบิลสร้างใบเสร็จได้เพียงใบเดียว`);
    return null;
  }

  // ✅ FIX 5: Use secure logging (redact customer name, total)
  const { secureLog } = await import('../utils/secureConsole');
  secureLog({
    tag: '[CREATE_REC_FROM_INV_FOUND]',
    trace_id: 'n/a',
    inv_id: invDoc.id,
    timestamp: new Date().toISOString(),
  });

  // Load receipt_terms from settings
  let receiptTerms = "ขอบคุณที่ใช้บริการ";
  try {
    const termsDoc = await db
      .doc(`users/${userId}/businesses/${businessId}/settings/terms`)
      .get();
    if (termsDoc.exists) {
      const termsData = termsDoc.data();
      receiptTerms = termsData?.receipt_terms || receiptTerms;
    }
  } catch (e) {
    // ✅ FIX 5: Use secure error logging
    const { secureWarn } = await import('../utils/secureConsole');
    secureWarn({
      tag: '[CREATE_REC_FROM_INV_ERROR]',
      trace_id: 'n/a',
      user_id: userId,
      business_id: businessId,
      error_type: 'terms_loading',
      timestamp: new Date().toISOString(),
    });
  }

  // Create REC draft
  const recDraft: LineDraft = {
    docType: "RECEIPT",
    customerName: invData.customer_name || invData.customer_snapshot?.name || "",
    customerId: invData.customer_id || invData.customer_snapshot?.id || null,
    items: (invData.items || []).map((item: { name?: string; description?: string; qty?: number; quantity?: number; price?: number; unit_price?: number }) => ({
      name: item.name || item.description || "",
      qty: item.qty || item.quantity || 1,
      price: item.price || item.unit_price || 0,
    })),
    subtotal: invData.subtotal || invData.sub_total_amount || 0,
    vat: invData.vat || invData.vat_amount || 0,
    wht: invData.wht || 0,
    total: invData.total || invData.total_amount || 0,
    notes: "",
    // Source document link
    source_doc_type: "BILL",
    source_doc_id: invDoc.id,
    source_doc_no: invNo,
    // Lock items and customer
    locked_fields: ["items", "customerName", "customerId"],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  // Store draft
  const { getOrCreateDraft, updateDraft } = await import("./draftStore");
  await getOrCreateDraft(userId, businessId, "RECEIPT");
  await updateDraft(userId, recDraft);

  console.log(`[CREATE_REC_FROM_INV] REC draft created from ${invNo}, customer=${recDraft.customerName}, total=${recDraft.total}`);

  // Format response
  const totalFormatted = (recDraft.total || 0).toLocaleString("th-TH", { minimumFractionDigits: 2 });
  const customerDisplay = recDraft.customerName || "ไม่ระบุ";

  return (
    `✅ สร้างใบเสร็จจาก ${invNo}\n\n` +
    `👤 ลูกค้า: ${customerDisplay}\n` +
    `📦 รายการ: ${recDraft.items.length} รายการ\n` +
    `💰 ยอดรวม: ${totalFormatted} บาท\n\n` +
    `⚠️ รายการและลูกค้าล็อกจากใบวางบิล\n` +
    `📝 เพิ่มหมายเหตุได้: พิมพ์ "หมายเหตุ [ข้อความ]"\n\n` +
    `พิมพ์ "ยืนยัน" เพื่อออกเอกสาร`
  );
}

/**
 * Helper: Handle installment summary command
 */
async function handleInstallmentSummary(
  userId: string,
  businessId: string,
  messageText: string
): Promise<string> {
  // Parse QUO number
  const quoMatch = messageText.match(/(?:QUO|QOU)[\s-]*(\d+)[\s-]*(\d+)/i);
  if (!quoMatch) {
    return "❌ กรุณาระบุเลขที่ใบเสนอราคา\nตัวอย่าง: สรุปงวดของ QUO-2569-001";
  }

  const quoNo = `QUO-${quoMatch[1]}-${quoMatch[2]}`;
  
  const { getInstallmentSummary, formatInstallmentSummary } = await import("../services/installmentService");
  const summary = await getInstallmentSummary(userId, businessId, quoNo);

  if (!summary) {
    return `❌ ไม่พบใบเสนอราคา ${quoNo}`;
  }

  return formatInstallmentSummary(summary);
}

/**
 * Helper: Handle installment dashboard command
 */
async function handleInstallmentDashboard(
  userId: string,
  businessId: string,
  messageText: string
): Promise<string> {
  // Parse QUO number
  const quoMatch = messageText.match(/(?:QUO|QOU)[\s-]*(\d+)[\s-]*(\d+)/i);
  if (!quoMatch) {
    return "❌ กรุณาระบุเลขที่ใบเสนอราคา\nตัวอย่าง: แดชบอร์ด QUO-2569-001";
  }

  const quoNo = `QUO-${quoMatch[1]}-${quoMatch[2]}`;
  
  const { getInstallmentSummary, formatInstallmentDashboard } = await import("../services/installmentService");
  const summary = await getInstallmentSummary(userId, businessId, quoNo);

  if (!summary) {
    return `❌ ไม่พบใบเสนอราคา ${quoNo}`;
  }

  return formatInstallmentDashboard(summary);
}

/**
 * Helper: Confirm and issue document from LINE draft
 * 1. Create document in Firestore
 * 2. Generate PDF
 * 3. Deliver PDF (email/LINE)
 */
export async function confirmAndIssueDraft(
  userId: string,
  businessId: string,
  draft: LineDraft,
  replyFn: (msg: string, quickReply?: QuickReplyAction[]) => Promise<void>,
  lineUserId?: string
): Promise<void> {
  const db = admin.firestore();

  console.log(`[DRAFT_CONFIRMING] 📝 userId=${userId}, business=${businessId}, docType=${draft.docType}`);

  // Validate draft before issuance
  if (!draft.customerName || draft.items.length === 0) {
    console.error(`[DRAFT_VALIDATION_FAILED] ❌ Missing customer or items`);
    throw new Error("Draft incomplete: missing customer or items");
  }

  // CHECK CREDITS BEFORE ISSUING
  const { hasCredits, getOrCreateSubscription, deductCredit, getUpsellMessage } = await import("./subscriptionService");

  const hasEnoughCredits = await hasCredits(userId);
  if (!hasEnoughCredits) {
    const subscription = await getOrCreateSubscription(userId);
    const upsellMsg = getUpsellMessage(subscription.creditsRemaining);
    console.log(`[CREDIT_CHECK_FAILED] ❌ userId=${userId}, credits=${subscription.creditsRemaining}`);
    // Credit upsell - use contextual buttons (auto-detect: GLOBAL)
    await replyFn(upsellMsg);
    return;
  }

  try {
    // 1. Create document in Firestore
    // Document type mapping: QUO → QUOTATION, BILL → INVOICE, RECEIPT → RECEIPT

    // Create document record with generated number
    const docRef = db
      .collection("users")
      .doc(userId)
      .collection("businesses")
      .doc(businessId)
      .collection("documents")
      .doc(); // Auto-generate ID

    // Build audit-safe snapshots (frozen at issuance time)
    const snapshots = await buildDocumentSnapshots({
      userId,
      businessId,
      customerName: draft.customerName,
      customerId: draft.customerId,
    });

    // Calculate totals
    const subTotal = draft.subtotal;
    const vatPercent = snapshots.tax_snapshot.vat_enabled ? snapshots.tax_snapshot.vat_percent : 0;
    const vatAmount = draft.vat || 0;
    const discountAmount = 0; // TODO: Add discount support
    const totalAmount = draft.total;

    const docRecord = {
      id: docRef.id,
      doc_type: DraftToIssuedDocTypeMap[draft.docType as keyof typeof DraftToIssuedDocTypeMap],
      doc_no: await generateDocumentNumber(businessId, draft.docType),
      
      // Customer info (legacy + snapshot)
      customer_name: draft.customerName,
      customer_id: draft.customerId || null,
      
      // Items with standardized structure
      items: draft.items.map((item: { name: string; qty: number; price: number; description?: string }) => ({
        name: item.name,
        qty: item.qty,
        price: item.price,
        amount: item.qty * item.price,
        description: item.description || "",
      })),
      
      // Totals (standardized naming for pdf-service)
      subtotal: subTotal,
      sub_total_amount: subTotal,
      vat: vatAmount,
      vat_amount: vatAmount,
      vat_percent: vatPercent,
      discount_amount: discountAmount,
      wht: draft.wht || 0,
      total: totalAmount,
      total_amount: totalAmount,
      
      // Status & timestamps
      status: DocStatusIssued,
      created_at: admin.firestore.Timestamp.now(),
      updated_at: admin.firestore.Timestamp.now(),
      issued_at: admin.firestore.Timestamp.now(),
      issued_by_user_id: userId,
      user_id: userId,
      business_id: businessId,
      
      // Notes & tags
      notes: draft.notes || "",
      tags: [],
      
      // Source document link (for QUO → INV → RECEIPT chain)
      source_doc_type: draft.source_doc_type || null,
      source_doc_id: draft.source_doc_id || null,
      source_doc_no: draft.source_doc_no || null,
      
      // Installment info (for multi-installment billing)
      installment_no: draft.installment_no || null,
      installment_total: draft.installment_total || draft.total || null,
      
      // ✅ AUDIT-SAFE SNAPSHOTS (immutable at issuance)
      business_snapshot: snapshots.business_snapshot,
      customer_snapshot: snapshots.customer_snapshot,
      tax_snapshot: snapshots.tax_snapshot,
      payment_snapshot: snapshots.payment_snapshot,
    };

    await docRef.set(docRecord);
    console.log(
      `[DOC_ISSUED] ✅ docId=${docRef.id}, doc_no=${docRecord.doc_no}, doc_type=${docRecord.doc_type}, customer=${docRecord.customer_name}, total=${docRecord.total}฿`
    );

    // 2. Deduct credit (IMPORTANT: Only after document is created successfully)
    try {
      await deductCredit(userId);
      const updatedSub = await getOrCreateSubscription(userId);
      console.log(`[CREDIT_DEDUCTED] 💳 userId=${userId}, remaining=${updatedSub.creditsRemaining}`);

      // Show low credit warning if needed
      const warningMsg = getUpsellMessage(updatedSub.creditsRemaining);
      if (warningMsg) {
        console.log(`[LOW_CREDIT_WARNING] ⚠️ userId=${userId}, credits=${updatedSub.creditsRemaining}`);
      }
    } catch (creditErr) {
      // ✅ FIX 5: Use secure error logging
      const { secureError } = await import('../utils/secureConsole');
      secureError({
        tag: '[CREDIT_DEDUCT_FAILED]',
        trace_id: 'n/a',
        user_id: userId,
        business_id: businessId,
        timestamp: new Date().toISOString(),
      }, creditErr);
      // Don't fail the whole operation - document is already created
    }

    // 3. Generate PDF (queue task)
    try {
      // Note: traceId not available in this context, using docId as correlation
      const { jobId, action } = await queuePdfGeneration(userId, businessId, docRef.id, docRecord.doc_no, docRecord.doc_type);
      console.log(
        `[PDF_JOB_QUEUED] 📤 docId=${docRef.id}, doc_no=${docRecord.doc_no}, doc_type=${docRecord.doc_type}, jobId=${jobId}, action=${action}`
      );
    } catch (pdfErr) {
      // ✅ FIX 5: Use secure error logging
      const { secureError } = await import('../utils/secureConsole');
      secureError({
        tag: '[PDF_JOB_FAILED]',
        trace_id: 'n/a',
        doc_id: docRef.id,
        user_id: userId,
        business_id: businessId,
        timestamp: new Date().toISOString(),
      }, pdfErr);
      // Continue anyway - document is created
    }

    // 3.5. Auto-close QUO if this is an INV from QUO (multi-installment)
    if (docRecord.doc_type === "INVOICE" && docRecord.source_doc_type === "QUO" && docRecord.source_doc_id) {
      try {
        const { checkAndCloseQuo } = await import("../services/installmentService");
        // Get LINE user ID for notifications
        const userDoc = await db.collection("users").doc(userId).get();
        const lineUserId = userDoc.data()?.lineUserId || null;
        await checkAndCloseQuo(userId, businessId, docRecord.source_doc_id, lineUserId);
      } catch (closeErr) {
        console.warn(`[AUTO_CLOSE_QUO] Warning: ${closeErr}`);
        // Non-blocking - document is already created
      }
    }

    // 4. Reply with success (+ low credit warning if needed)
    const subscription = await getOrCreateSubscription(userId);
    const lowCreditWarning = getUpsellMessage(subscription.creditsRemaining);

    const typeEmojiMap: Record<string, string> = {
      QUOTATION: "📋",
      INVOICE: "📄",
      RECEIPT: "✅",
    };
    const typeEmoji = typeEmojiMap[docRecord.doc_type] || "📝";

    // Check for missing business fields (warning only, does not block)
    let missingFieldsWarning = "";
    try {
      const { getMissingFieldsWarning } = await import("../services/businessService");
      const warning = await getMissingFieldsWarning(userId, businessId);
      if (warning) {
        missingFieldsWarning = warning;
      }
    } catch (warnErr) {
      console.warn("[confirmAndIssueDraft] Error checking missing fields:", warnErr);
    }

    let successMessage =
      `${typeEmoji} ออกเอกสารสำเร็จ\n\n` +
      `เลขที่: ${docRecord.doc_no}\n` +
      `ลูกค้า: ${docRecord.customer_name}\n` +
      `รวม: ${docRecord.total.toLocaleString("th-TH")}฿\n\n` +
      `✅ บันทึกเสร็จแล้ว`;

    if (missingFieldsWarning) {
      successMessage += `\n\n${missingFieldsWarning}`;
    }

    if (lowCreditWarning) {
      successMessage += `\n\n${lowCreditWarning}`;
    }

    // Check and celebrate milestone (first-time only)
    let milestoneCelebrated = false;
    if (lineUserId) {
      try {
        const { checkAndCelebrateMilestone } = await import("../services/milestoneService");
        const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
        const docType = docRecord.doc_type?.toUpperCase() || '';
        
        if (docType === 'QUOTATION' || docType === 'QUO') {
          milestoneCelebrated = await checkAndCelebrateMilestone(
            userId,
            lineUserId,
            'firstQuotation',
            accessToken
          );
        } else if (docType === 'INVOICE' || docType === 'INV' || docType === 'BILL') {
          milestoneCelebrated = await checkAndCelebrateMilestone(
            userId,
            lineUserId,
            'firstInvoice',
            accessToken
          );
        }
      } catch (milestoneErr) {
        console.warn('[MILESTONE] Error checking milestone:', milestoneErr);
        // Non-blocking - continue with regular success message
      }
    }
    
    // If milestone was celebrated, skip regular success message
    if (!milestoneCelebrated) {
      // Document issued successfully - show SUCCESS context buttons
      const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
      const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
      await replyFn(successMessage, successButtons);
    }
  } catch (err) {
    // ✅ FIX 5: Use secure error logging
    const { secureError } = await import('../utils/secureConsole');
    secureError({
      tag: '[CONFIRM_AND_ISSUE_DRAFT_ERROR]',
      trace_id: 'n/a',
      user_id: userId,
      business_id: businessId,
      timestamp: new Date().toISOString(),
    }, err);
    throw err;
  }
}

/**
 * Helper: Generate document number (INV-YYYY-NNN)
 */
async function generateDocumentNumber(businessId: string, docType: string): Promise<string> {
  const db = admin.firestore();
  const today = new Date();
  const year = today.getFullYear() + 543; // Thai Buddhist year
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  const dateSuffix = `${year}${month}${day}`;

  // Type prefix
  const typePrefix = DocNumberPrefixes[docType as keyof typeof DocNumberPrefixes] || "DOC";

  // Counter
  const counterDoc = db
    .collection("counters")
    .doc(`${businessId}_${docType}_${dateSuffix}`);

  const result = await db.runTransaction(async (transaction) => {
    const docSnap = await transaction.get(counterDoc);
    const current = (docSnap.get("count") as number) || 0;
    const next = current + 1;
    transaction.set(counterDoc, { count: next, lastUpdated: admin.firestore.Timestamp.now() });
    return next;
  });

  const number = String(result).padStart(3, "0");
  return `${typePrefix}-${year}-${number}`;
}

/**
 * Helper: Queue PDF generation job
 */
async function queuePdfGeneration(
  userId: string,
  businessId: string,
  docId: string,
  docNo: string,
  docType?: string,
  traceId?: string // ✅ FIX 6: Correlation ID
): Promise<{ jobId: string; action: 'CREATED' | 'IN_PROGRESS' | 'DONE' | 'REQUEUED' }> {
  const db = admin.firestore();
  // Deterministic job ID => 1 docId = 1 job (idempotent)
  const deterministicJobId = `${businessId}_${docId}`;
  const jobRef = db.collection("pdf_generation_jobs").doc(deterministicJobId);

  let action: 'CREATED' | 'IN_PROGRESS' | 'DONE' | 'REQUEUED' = 'CREATED';

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(jobRef);
    if (!snap.exists) {
      tx.set(jobRef, {
        id: jobRef.id,
        user_id: userId,
        business_id: businessId,
        document_id: docId,
        document_no: docNo,
        doc_type: docType || null,
        status: "PENDING",
        created_at: admin.firestore.Timestamp.now(),
        attempts: 0,
        max_attempts: 3,
        traceId: traceId || null, // ✅ FIX 6: Store correlation ID
        correlationId: traceId || null, // ✅ FIX 6: Alias for clarity
      });
      action = 'CREATED';
      return;
    }

    const data = snap.data() as any;
    const status = String(data?.status || '');

    if (status === 'PENDING' || status === 'PROCESSING') {
      action = 'IN_PROGRESS';
      return;
    }

    if (status === 'DONE') {
      action = 'DONE';
      return;
    }

    // FAILED or unknown => requeue (preserve attempts; worker will handle retry cap)
    tx.set(
      jobRef,
      {
        user_id: userId,
        business_id: businessId,
        document_id: docId,
        document_no: docNo,
        doc_type: docType || data?.doc_type || null,
        status: 'PENDING',
        error: admin.firestore.FieldValue.delete(),
        created_at: data?.created_at || admin.firestore.Timestamp.now(),
        max_attempts: data?.max_attempts || 3,
      },
      { merge: true }
    );
    action = 'REQUEUED';
  });

  console.log(`[PDF_JOB_ENQUEUE] 📤 jobId=${jobRef.id} docNo=${docNo} action=${action}`);
  return { jobId: jobRef.id, action };
}

/**
 * Main entry point: Handle conversation message from LINE
 * Routes to intent-specific UX flows
 */
export async function handleConversationMessage(params: {
  userId: string;
  businessId: string;
  messageText: string;
  replyToken: string;
  lineUserId?: string; // Optional: for admin auth
  traceId?: string; // ✅ FIX 6: Correlation ID
  lineClient: {
    replyMessage(p: {
      replyToken: string;
      messages: Array<any>; // Allow any message type (text, template, etc.)
    }): Promise<void>;
  };
}): Promise<void> {
  const t0 = Date.now(); // ✅ Latency tracking: Handler start time
  
  const { userId, messageText, replyToken, lineUserId, traceId, lineClient } = params;

  // ✅ FIX 2: Track reply attempt and success separately
  // didReplySuccess = true only AFTER successful send
  let didReplySuccess = false;
  let didAttemptReply = false;
  
  // ✅ Allowlist check BEFORE intent routing (for all draft-editing intents)
  // This ensures allowlisted users NEVER see legacy flow (cached import)
  const { getConfig } = await import("../utils/cachedHotPathImports");
  const { HUMAN_FIRST_UX_ENABLED } = await getConfig();
  const { isUserInAllowlist } = await import("./humanFirstAllowlist");
  const isAllowlisted = HUMAN_FIRST_UX_ENABLED && lineUserId 
    ? await isUserInAllowlist(lineUserId)
    : false;

  // Helper: Get contextual quick reply (auto-detect if not provided)
  const getContextualButtons = async (override?: QuickReplyAction[]): Promise<QuickReplyAction[]> => {
    // If explicit override provided, use it
    if (override && override.length > 0) {
      return override;
    }
    
    // Auto-detect context (cached imports for hot path)
    try {
      const { getContextualQuickReply: getCachedContextualQuickReply, getPaymentStateMapper, getDraftStore } = await import("../utils/cachedHotPathImports");
      const { determineQuickReplyContext, getContextualQuickReply } = await getCachedContextualQuickReply();
      
      // CRITICAL: Get payment state to ensure deterministic payment flow
      const { getPaymentStateParam } = await getPaymentStateMapper();
      const paymentStateParam = await getPaymentStateParam(userId);
      
      // ✅ FIX 4: Check for active draft (don't hardcode false)
      const { getDraft } = await getDraftStore();
      const draft = await getDraft(userId).catch(() => null);
      const hasActiveDraft = !!draft;
      
      const contextParams = await determineQuickReplyContext({
        userId,
        businessId: params.businessId,
        hasActiveDraft, // ✅ FIX 4: Use actual draft check
        paymentState: paymentStateParam, // CRITICAL: Send payment state
        traceId, // HARDENING v3: Pass traceId for logging
      });
      return getContextualQuickReply(contextParams);
    } catch (err) {
      console.warn("[conversationHandler] Error determining context, using global:", err);
      // Fallback to global (cached import)
      const { getContextualQuickReply: getCachedContextualQuickReply } = await import("../utils/cachedHotPathImports");
      const { getContextualQuickReply } = await getCachedContextualQuickReply();
      return getContextualQuickReply({ context: 'GLOBAL' });
    }
  };

  // ✅ FIX 4: Reply function with hard deadline enforcement (25s)
  const replyFn = async (msg: string, quickReplyActions?: QuickReplyAction[]) => {
    // Validate message before sending
    if (!msg || msg.trim().length === 0) {
      const { getSecureConsole } = await import("../utils/cachedHotPathImports");
      const { secureError } = await getSecureConsole();
      secureError({
        tag: "[REPLY_EMPTY_MESSAGE]",
        trace_id: traceId,
        user_id: userId,
        line_user_id: lineUserId,
        timestamp: new Date().toISOString(),
      });
      msg = "ไม่เป็นไรเลยค่ะ 😊\n\nเลือกทำต่อได้จากด้านล่างนะคะ";
    }

    if (!lineUserId) {
      // Cannot use replyWithDeadline without lineUserId
      // Fallback to direct reply (shouldn't happen in normal flow)
      await lineClient.replyMessage({
        replyToken,
        messages: [{ type: "text", text: msg }],
      });
      didReplySuccess = true;
      didAttemptReply = true;
      return;
    }

    // Get contextual buttons
    const buttons = await getContextualButtons(quickReplyActions);
    const quickReply = buttons && buttons.length > 0
      ? buttons.slice(0, 13)
      : undefined;

    // ✅ Use replyWithDeadline for hard deadline enforcement (cached import)
    const { getReplyWithDeadline } = await import("../utils/cachedHotPathImports");
    const { replyWithDeadline } = await getReplyWithDeadline();
    const replyState = await replyWithDeadline({
      replyToken,
      lineUserId,
      traceId: traceId || 'n/a',
      stage: 'CONVERSATION_HANDLER',
      message: msg,
      quickReplyActions: quickReply ? quickReply.map(btn => ({
        type: 'action',
        action: btn.action,
      })) : undefined,
      replyFn: async (params) => {
        await lineClient.replyMessage(params);
      },
    });

    // ✅ Update state from replyWithDeadline result
    didAttemptReply = replyState.didAttemptReply;
    didReplySuccess = replyState.didReplySuccess;
  };

  // ✅ FIX 3: Reply with Flex message (with hard deadline + fallback)
  const replyWithFlex = async (flexMessage: Record<string, unknown>) => {
    if (!lineUserId) {
      // Cannot use replyWithDeadline without lineUserId
      await lineClient.replyMessage({
        replyToken,
        messages: [flexMessage as any],
      });
      return;
    }

    // ✅ Use replyWithDeadline for hard deadline enforcement
    const { getReplyWithDeadline } = await import("../utils/cachedHotPathImports");
    const { replyWithDeadline } = await getReplyWithDeadline();
    
    // Convert flex message to text for fallback
    const flexText = (flexMessage as any).altText || 'เอกสารพร้อมแล้ว';
    
    const replyState = await replyWithDeadline({
      replyToken,
      lineUserId,
      traceId: traceId || 'n/a',
      stage: 'REPLY_FLEX',
      message: flexText, // Fallback text if timeout
      replyFn: async (params) => {
        // Override messages with flex message (ignore params.messages from replyWithDeadline)
        await lineClient.replyMessage({
          replyToken: params.replyToken,
          messages: [flexMessage as any],
        });
      },
    });

    // Update state
    if (replyState.didReplySuccess) {
      didReplySuccess = true;
      didAttemptReply = true;
    }
    
    // If failed, error already logged by replyWithDeadline
    if (!replyState.didReplySuccess && !replyState.didFallbackPush) {
      // Fallback push also failed - log final error
      const { getSecureConsole } = await import("../utils/cachedHotPathImports");
      const { secureError } = await getSecureConsole();
      secureError({
        tag: "[REPLY_FLEX_COMPLETE_FAILURE]",
        trace_id: traceId,
        user_id: userId,
        line_user_id: lineUserId,
        timestamp: new Date().toISOString(),
      });
    }
  };

  try {
    // ✅ Latency tracking: Import overhead measurement
    const tImport0 = Date.now();
    
    // ✅ CRITICAL: Payment State Guard - Check BEFORE intent parsing
    // If user is in payment flow, respond with payment status and block fallback
    // ✅ Cached imports for hot path
    const { getPaymentStateService, getConversationOrchestrator } = await import("../utils/cachedHotPathImports");
    const { getPaymentState, getPaymentStatusMessage, isInPaymentFlow } = await getPaymentStateService();
    const { recognizeIntent, Intent } = await getConversationOrchestrator();
    
    const tImport1 = Date.now();
    const importMs = tImport1 - tImport0;
    
    // ✅ NEW: Command Router (highest priority routing, cached import)
    const { getCommandRouter } = await import("../utils/cachedHotPathImports");
    const { routeIncomingText, RouteType } = await getCommandRouter();
    const db = admin.firestore();
    const draft = await getDraft(userId).catch(() => null);
    const routeResult = routeIncomingText({
      text: messageText,
      hasActiveDraft: !!draft,
      db,
    });
    
    console.log(JSON.stringify({
      tag: "[ROUTE_TAKEN]",
      trace_id: traceId,
      user_id: userId,
      line_user_id: lineUserId,
      route: routeResult.route,
      doc_type: routeResult.docType,
      normalized_text: routeResult.normalizedText,
      original_text: messageText,
      has_active_draft: !!draft,
      timestamp: new Date().toISOString(),
    }));
    
    // Route by RouteType (precedence handled in router)
    if (routeResult.route === RouteType.ROUTE_SETTINGS) {
      // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
      const { handleSettingsCommand } = await import("./businessSettings");
      const response = await handleSettingsCommand(userId, params.businessId, messageText);
      await replyFn(response);
      return;
    }
    
    if (routeResult.route === RouteType.ROUTE_CREATE_DOC && routeResult.docType) {
      // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
      const { startDoc } = await import("../services/humanFirstCopy");
      // ✅ FIX: Clear draft first (prevent old draft from interfering)
      await clearDraft(userId).catch(() => { /* Non-blocking */ });
      // Map INVOICE to BILL (they're the same in draft system)
      const draftDocType = routeResult.docType === 'INVOICE' ? 'BILL' : routeResult.docType;
      // ✅ FIX: Create new draft (getOrCreateDraft will create fresh draft after clear)
      await getOrCreateDraft(userId, params.businessId, draftDocType);
      await replyFn(startDoc(routeResult.docType));
      return;
    }
    
    // ✅ PHASE 1: Trust Commands (SEV-0)
    if (routeResult.route === RouteType.ROUTE_TRUST_COMMAND && routeResult.trustCommand) {
      // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
      const { getLatestDocument, resendPdf, getCreditBalance, getSlipOcrStatus } = await import("../services/trustCommands");
      const { getLineUserIdFromFirebaseUid } = await import("../core/lineUserMapping");
      
      let response: string;
      
      switch (routeResult.trustCommand) {
        case 'LATEST_DOC': {
          const latest = await getLatestDocument(userId, params.businessId);
          if (!latest) {
            response = 'ยังไม่มีเอกสาร\nพิมพ์ "ทำใบเสนอราคา" หรือ "ทำใบวางบิล" เพื่อเริ่มสร้าง';
          } else {
            const statusText = latest.status === 'PDF_READY' ? 'พร้อม' : 
                              latest.pdf_status === 'PROCESSING' ? 'กำลังสร้าง PDF' :
                              latest.pdf_status === 'FAILED' ? 'สร้าง PDF ล้มเหลว' :
                              latest.status || 'ไม่ทราบ';
            response = `เอกสารล่าสุด: ${latest.doc_no}\nสถานะ: ${statusText}`;
            
            if (latest.pdf_status === 'PROCESSING') {
              response += '\n\nยังทำอยู่นะครับ ถ้าเกิน 2 นาทีพิมพ์ "เอกสารล่าสุด" อีกครั้ง';
            } else if (latest.pdf_short_token && latest.pdf_path) {
              // PDF is ready - user can use "ส่ง PDF อีกครั้ง" to get link
              response += '\n\nพิมพ์ "ส่ง PDF อีกครั้ง" เพื่อรับลิงก์ PDF';
            }
          }
          break;
        }
        
        case 'RESEND_PDF': {
          const lineUserId = await getLineUserIdFromFirebaseUid(userId);
          if (!lineUserId) {
            response = 'ไม่พบ LINE user ID';
          } else {
            const result = await resendPdf(userId, params.businessId, lineUserId);
            response = result.message;
          }
          break;
        }
        
        case 'CREDIT_BALANCE': {
          const balance = await getCreditBalance(userId);
          const balanceText = balance.creditsRemaining.toLocaleString('th-TH');
          response = `เครดิตคงเหลือ: ${balanceText} บาท`;
          if (balance.lastSource) {
            const dateText = balance.lastSourceDate?.toDate().toLocaleDateString('th-TH') || '';
            response += `\nล่าสุดได้จาก: ${balance.lastSource}${dateText ? ` (${dateText})` : ''}`;
          }
          break;
        }
        
        case 'CHECK_SLIP': {
          const ocrStatus = await getSlipOcrStatus(userId);
          response = ocrStatus.message;
          break;
        }
        
        default:
          response = 'คำสั่งไม่ถูกต้อง';
      }
      
      await replyFn(response);
      return;
    }
    
    // ✅ PHASE 3: Main menu command
    if (routeResult.route === RouteType.ROUTE_MENU) {
      // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
      const { getPlanAwareMainMenu } = await import("../services/planAwareUI");
      const quickReply = await getPlanAwareMainMenu(userId);
      await replyFn("เลือกทำต่อได้เลย:", quickReply);
      return;
    }
    
    if (routeResult.route === RouteType.ROUTE_HELP) {
      // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
      // ✅ PHASE 3: Help with real examples + theme command
      const { getHelpMessage } = await import("../services/helpCopy");
      const { getPlanAwareMainMenu } = await import("../services/planAwareUI");
      const quickReply = await getPlanAwareMainMenu(userId);
      await replyFn(getHelpMessage(), quickReply);
      return;
    }
    
    // Continue to intent-based routing for ROUTE_EDIT_DRAFT and ROUTE_FALLBACK
    const intent = recognizeIntent(messageText);
    
    // ✅ Log import overhead
    console.log(JSON.stringify({
      tag: "[IMPORT_OVERHEAD]",
      trace_id: traceId,
      user_id: userId,
      import_ms: importMs,
      timestamp: new Date().toISOString(),
    }));
    
    // ✅ PRIORITY OVERRIDE: LINK_ACCOUNT always wins (before payment guards)
    // This ensures "เชื่อมต่อ" command works even during payment flows
    if (intent === Intent.LINK_ACCOUNT) {
      try {
        // ✅ FIX 2: Remove pre-emptive didSend - replyFn will set didReplySuccess after successful send
        const LIFF_ID = "2008406529-t10C3ftD";
        const linkUrl = `https://liff.line.me/${LIFF_ID}`;
        
        // Clear image state to prevent re-triggering slip checks after linking prompt
        try {
          const { clearUserImageMode } = await import("../services/userStateService");
          const { markPendingImageUsed } = await import("../services/imageUploadService");
          await clearUserImageMode(userId).catch(() => {});
          markPendingImageUsed(userId); // Clear pending image state
        } catch (clearErr) {
          // Non-blocking: continue even if clearing fails
          const { getSecureConsole } = await import("../utils/cachedHotPathImports");
          const { secureError } = await getSecureConsole();
          secureError({
            tag: "[LINK_ACCOUNT_CLEAR_STATE_ERROR]",
            trace_id: traceId,
            user_id: userId,
            line_user_id: lineUserId,
            timestamp: new Date().toISOString(),
          }, clearErr);
        }
        
        // ✅ Send template message with hard deadline enforcement
        if (lineUserId) {
          const { getReplyWithDeadline } = await import("../utils/cachedHotPathImports");
          const { replyWithDeadline } = await getReplyWithDeadline();
          
          const templateMessage = {
            type: "template",
            altText: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน",
            template: {
              type: "buttons",
              text: "🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nคลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบ",
              actions: [
                {
                  type: "uri",
                  label: "🔗 เชื่อมต่อบัญชี",
                  uri: linkUrl,
                },
              ],
            },
          };
          
          const replyState = await replyWithDeadline({
            replyToken,
            lineUserId,
            traceId: traceId || 'n/a',
            stage: 'LINK_ACCOUNT',
            message: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน", // Fallback text
            replyFn: async (params) => {
              // Override with template message
              await lineClient.replyMessage({
                replyToken: params.replyToken,
                messages: [templateMessage as any],
              });
            },
          });
          
          if (replyState.didReplySuccess) {
            didReplySuccess = true;
            didAttemptReply = true;
          }
          
          const { getSecureConsole: getSecureConsole2 } = await import("../utils/cachedHotPathImports");
          const { secureLog } = await getSecureConsole2();
          secureLog({
            tag: "[LINK_ACCOUNT_SENT]",
            trace_id: traceId,
            user_id: userId,
            line_user_id: lineUserId,
            did_reply_success: replyState.didReplySuccess,
            did_fallback_push: replyState.didFallbackPush,
            timestamp: new Date().toISOString(),
          });
        } else {
          // Fallback if no lineUserId
          await lineClient.replyMessage({
            replyToken,
            messages: [
              {
                type: "template",
                altText: "กรุณาเชื่อมต่อบัญชีก่อนใช้งาน",
                template: {
                  type: "buttons",
                  text: "🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nคลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบ",
                  actions: [
                    {
                      type: "uri",
                      label: "🔗 เชื่อมต่อบัญชี",
                      uri: linkUrl,
                    },
                  ],
                },
              },
            ],
          });
          didReplySuccess = true;
          didAttemptReply = true;
        }
        
        return; // Exit early - do not run payment guards or other handlers
      } catch (err) {
        console.error("[conversationHandler] LINK_ACCOUNT error:", err);
        // Fallback to text message if template fails
        await replyFn("🔐 กรุณาเชื่อมต่อบัญชีก่อนใช้งาน\n\nกรุณาเปิดลิงก์เพื่อเชื่อมต่อบัญชี");
        return;
      }
    }
    
    const paymentState = await getPaymentState(userId);
    const inPaymentFlow = await isInPaymentFlow(userId);
    
    console.log(`[conversationHandler] intent=${intent}, user=${userId}, paymentState=${paymentState}`);

    // ✅ PATCH 3: Early payment guard for PENDING_REVIEW state
    // ✅ FIX 3: Allowlist for critical intents (CANCEL, HELP, CANCEL_PAYMENT, LINK_ACCOUNT)
    if (paymentState === 'PENDING_REVIEW') {
      // Allow critical intents to bypass guard (LINK_ACCOUNT handled above, but keep here for safety)
      const allowedIntents = [
        Intent.CANCEL,
        Intent.HELP,
        Intent.CANCEL_PAYMENT,
        Intent.WIZARD_CANCEL,
        Intent.USAGE_GUIDE,
        Intent.LINK_ACCOUNT, // ✅ SAFETY: Allow LINK_ACCOUNT (though already handled above)
      ];
      
      if (!allowedIntents.includes(intent)) {
        console.log(`[conversationHandler] 🔍 Payment in review, blocking intent ${intent}: userId=${userId}`);
        await replyFn('🔍 กำลังตรวจสอบการชำระเงิน\n\n⏱️ รอสักครู่...');
        return; // Block all processing during review (except allowlisted intents)
      }
      // Allow allowlisted intents to proceed
      console.log(`[conversationHandler] ✅ Payment in review, allowing intent ${intent}: userId=${userId}`);
    }

    // If in payment flow and intent is UNKNOWN or not payment-related, respond with payment status
    // This prevents fallback during payment
    if (inPaymentFlow) {
      // ALWAYS clear conflicting states when in payment flow (before any checks)
      const { clearConversationState } = await import("../services/conversationStateService");
      const { clearDraft } = await import("./draftStore");
      const { clearBusinessSetupState } = await import("../services/businessSetupCopyPaste");
      await clearConversationState(userId);
      await clearDraft(userId);
      await clearBusinessSetupState(userId);
      
      // Allow payment-related intents to proceed
      const paymentRelatedIntents = [
        Intent.BUY_PACKAGE_99,
        Intent.BUY_PACKAGE_299,
        Intent.CREDIT_PURCHASE_HISTORY,
        Intent.CONFIRM_CREDIT_PAYMENT,
        Intent.LINK_ACCOUNT, // ✅ SAFETY: Allow LINK_ACCOUNT (though already handled above)
      ];
      
      // If not payment-related intent, respond with payment status
      if (!paymentRelatedIntents.includes(intent) && intent !== Intent.IMAGE_LABEL) {
        const paymentMessage = await getPaymentStatusMessage(userId);
        if (paymentMessage) {
          console.log(`[conversationHandler] Payment state guard: userId=${userId}, state=${paymentState}, responding with payment status`);
          await replyFn(paymentMessage);
          return; // Block further processing - user is in payment flow
        }
      }
    }
    
    // Clear business setup state when switching to document creation or payment
    const documentCreationIntents = [
      Intent.CREATE_QUOTATION,
      Intent.CREATE_INVOICE,
      Intent.CREATE_RECEIPT,
    ];
    const paymentRelatedIntents = [
      Intent.BUY_PACKAGE_99,
      Intent.BUY_PACKAGE_299,
      Intent.CREDIT_PURCHASE_HISTORY,
      Intent.CONFIRM_CREDIT_PAYMENT,
    ];
    
    if (documentCreationIntents.includes(intent) || paymentRelatedIntents.includes(intent)) {
      const { clearBusinessSetupState } = await import("../services/businessSetupCopyPaste");
      await clearBusinessSetupState(userId);
    }

    // ✅ PRIORITY: Check for pending slip image (if user is in SLIP mode and no intent command)
    // This handles the case where user sent image (with recent purchase) but didn't type intent
    // User intent commands (IMAGE_LABEL) will override this in their handler
    // CRITICAL: Also check if in payment flow - process slip immediately
    if (intent !== Intent.IMAGE_LABEL) {
      // ✅ FIX 4: Load imports once (outside hot path condition checks)
      const { getUserImageMode, clearUserImageMode } = await import("../services/userStateService");
      const { hasPendingImage, getPendingImage, markPendingImageUsed } = await import("../services/imageUploadService");
      const { processSlipUpload } = await import("../services/imageUploadService");
      
      const imageMode = await getUserImageMode(userId);
      const hasPending = hasPendingImage(userId);
      
      // Process slip if:
      // 1. User is in SLIP mode AND has pending image, OR
      // 2. User is in payment flow (WAITING_FOR_SLIP) AND has pending image
      if ((imageMode === 'SLIP' && hasPending) || (inPaymentFlow && paymentState === 'WAITING_FOR_SLIP' && hasPending)) {
        const pendingMessageId = getPendingImage(userId);
        if (pendingMessageId && lineUserId) {
          // ✅ PATCH 1: IDEMPOTENCY GUARD - Check if slip already processed
          const { getRecentPendingPurchase } = await import("../services/imageUploadService");
          const recentPurchase = await getRecentPendingPurchase(userId);
          
          if (recentPurchase) {
            const db = admin.firestore();
            const purchaseRef = db.collection('credit_purchases').doc(recentPurchase.purchaseId);
            const purchaseDoc = await purchaseRef.get();
            const purchaseData = purchaseDoc.data();
            
            // Skip if already processed (status is PENDING_REVIEW or slip_image_url exists)
            if (purchaseData?.status === 'PENDING_REVIEW' || purchaseData?.slip_image_url) {
              console.log(`[conversationHandler] ⏭️  Slip already processed, skipping: purchaseId=${recentPurchase.purchaseId}, status=${purchaseData?.status}, hasSlipUrl=${!!purchaseData?.slip_image_url}`);
              
              // ✅ FIX 1: Clear pending image state to prevent infinite loop
              // Mark image as used AND clear image mode to prevent re-entry
              markPendingImageUsed(userId);
              await clearUserImageMode(userId).catch(err => {
                console.warn(`[conversationHandler] Failed to clear image mode:`, err);
              });
              
              await replyFn('✅ รับสลิปแล้ว กำลังตรวจสอบ\n\nรอสักครู่...');
              return; // Skip processing - state cleared to prevent loop
            }
          }
          
          // User has pending slip image - process immediately
          markPendingImageUsed(userId);
          const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
          
          console.log(`[conversationHandler] Processing pending slip: userId=${userId}, messageId=${pendingMessageId}, paymentState=${paymentState}`);
          
          // Process slip asynchronously (don't block reply)
          // But send acknowledgment immediately
          const { getSlipReceivedMessage } = await import("../services/paymentUXCopy");
          await replyFn(getSlipReceivedMessage());
          
          // ✅ Telemetry: Log payment acknowledgment sent
          try {
            const { getRecentPendingPurchase } = await import("../services/imageUploadService");
            const recentPurchaseForTelemetry = await getRecentPendingPurchase(userId);
            if (recentPurchaseForTelemetry) {
              const { logPaymentAckSent } = await import("../services/paymentTelemetry");
              const slipUploadedAt = admin.firestore.Timestamp.now();
              await logPaymentAckSent(
                userId,
                recentPurchaseForTelemetry.purchaseId,
                lineUserId || '',
                slipUploadedAt
              );
            }
          } catch (telemetryError) {
            // Don't block on telemetry failure
            console.warn(`[conversationHandler] Failed to log payment ack:`, telemetryError);
          }
          
          (async () => {
            try {
              const result = await processSlipUpload(userId, lineUserId, pendingMessageId, accessToken);
              console.log(`[conversationHandler] Processed pending slip image for user ${userId}, success=${result.success}`);
              
              // If processing failed, user already got acknowledgment, so no need to send error
              // The OCR process will handle final notification
            } catch (err) {
              console.error(`[conversationHandler] Error processing pending slip:`, err);
              // Error is logged but user already got acknowledgment
              // OCR will handle final status
            }
          })();
          
          // Clear SLIP mode
          const { setUserImageMode } = await import("../services/userStateService");
          await setUserImageMode(userId, null);
          
          // Return early - slip is being processed
          return;
        }
      }
    }

    // ✅ ALLOWLIST GATE: Route draft-editing intents to human-first if allowlisted
    // This ensures allowlisted users NEVER see legacy flow
    const draftEditingIntents = [
      Intent.CREATE_QUOTATION,
      Intent.CREATE_INVOICE,
      Intent.CREATE_RECEIPT,
      Intent.EDIT,
      Intent.CREATE_INV_FROM_QUO,
      Intent.CREATE_REC_FROM_INV,
    ];
    
    if (isAllowlisted && draftEditingIntents.includes(intent)) {
      // Route to human-first handler (which will handle all draft-editing intents)
      const { handleHumanFirstEdit } = await import("./humanFirstHandler");
      const humanFirstResponse = await handleHumanFirstEdit(
        userId,
        params.businessId,
        messageText,
        replyFn,
        params.lineUserId,
        params.traceId
      );
      
      if (humanFirstResponse) {
        await replyFn(humanFirstResponse.message, humanFirstResponse.buttons);
        // ✅ Log latency before return
        const durationMs = Date.now() - t0;
        console.log(JSON.stringify({
          tag: "[HANDLER_LATENCY]",
          trace_id: traceId,
          user_id: userId,
          intent,
          duration_ms: durationMs,
          did_reply_success: didReplySuccess,
        }));
        return;
      }
      // If humanFirstResponse is null, CONFIRM was handled (already replied)
      // Log latency and return (no legacy fallback for allowlisted users)
      const durationMs = Date.now() - t0;
      console.log(JSON.stringify({
        tag: "[HANDLER_LATENCY]",
        trace_id: traceId,
        user_id: userId,
        intent,
        duration_ms: durationMs,
        did_reply_success: didReplySuccess,
        human_first_confirm: true,
      }));
      return;
    }

    // Route by intent
    switch (intent) {
      case Intent.CREATE_QUOTATION:
        // Initialize draft for quotation
        {
          try {
            const draft = await getOrCreateDraft(userId, params.businessId, "QUO");
            
            // ✅ HUMAN-FIRST UX: Use simple message when flag enabled (but not allowlisted - already handled above)
            const { HUMAN_FIRST_UX_ENABLED } = await import("../shared/config");
            if (HUMAN_FIRST_UX_ENABLED && !isAllowlisted) {
              const { renderDraftSummary, renderNextSteps } = await import("./humanFirstDraftRenderer");
              const { determineHumanFirstState, getHumanFirstButtons } = await import("./humanFirstStateMachine");
              
              const hasItems = draft.items.length > 0;
              const hasCustomer = !!draft.customerName;
              const state = determineHumanFirstState(true, hasCustomer, hasItems);
              const buttons = getHumanFirstButtons(state);
              const renderCtx = {
                docType: 'QUO' as const,
                state,
                isStartMessage: true,
              };
              const guidanceResult = renderNextSteps(draft, renderCtx);
              const summary = renderDraftSummary(draft);
              const message = `📄 กำลังทำใบเสนอราคา\n\n${summary}\n\n${guidanceResult.text}`;
              
              await replyFn(message, buttons);
              return;
            }
            
            // Legacy flow (when flag=0)
            const summary = formatDraftForDisplay(draft);
            
            // ✅ BUTTON-FIRST: Set state and show buttons (NO text syntax)
            const { setConversationState } = await import("../services/conversationStateService");
            const { getButtonsForState, ButtonState } = await import("./conversationStateMachine");
            
            const hasItems = draft.items.length > 0;
            const hasCustomer = !!draft.customerName;
            const initialState = hasItems ? ButtonState.ITEMS_EXIST : ButtonState.DRAFT_EMPTY;
            await setConversationState(userId, initialState);
            
            const buttons = getButtonsForState(initialState, hasItems, hasCustomer);
            
            // ✅ FIX 2: Send guided message with copy-paste templates when draft is empty
            let message = `📋 เริ่มสร้างใบเสนอราคา\n\n${summary}`;
            if (!hasItems && !hasCustomer) {
              message = `📋 เริ่มสร้างใบเสนอราคา\n\n` +
                `คุณสามารถ:\n` +
                `• เพิ่มรายการสินค้า/บริการ\n` +
                `• เพิ่มข้อมูลลูกค้า\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `💡 หรือก๊อปปี้ข้อความด้านล่างนี้ แล้วแก้ไขข้อมูลของคุณ:\n\n` +
                `ชื่อลูกค้า:\n` +
                `ที่อยู่:\n` +
                `เบอร์โทร:\n\n` +
                `รายการสินค้า:\n` +
                `1. [ชื่อสินค้า] [จำนวน] [ราคา]\n` +
                `2. [ชื่อสินค้า] [จำนวน] [ราคา]\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `เลือกทำต่อได้เลยค่ะ 😊`;
            } else if (!hasCustomer) {
              message = `📋 เริ่มสร้างใบเสนอราคา\n\n${summary}\n\n` +
                `💡 ยังไม่มีข้อมูลลูกค้า\n` +
                `กรุณาเพิ่มข้อมูลลูกค้าก่อนออกเอกสารค่ะ\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `💡 หรือก๊อปปี้ข้อความด้านล่างนี้ แล้วแก้ไข:\n\n` +
                `ชื่อลูกค้า:\n` +
                `ที่อยู่:\n` +
                `เบอร์โทร:\n` +
                `━━━━━━━━━━━━━━━━━━━━`;
            } else if (!hasItems) {
              message = `📋 เริ่มสร้างใบเสนอราคา\n\n${summary}\n\n` +
                `💡 ยังไม่มีรายการสินค้า/บริการ\n` +
                `กรุณาเพิ่มรายการก่อนออกเอกสารค่ะ\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `💡 หรือก๊อปปี้ข้อความด้านล่างนี้ แล้วแก้ไข:\n\n` +
                `รายการสินค้า:\n` +
                `1. [ชื่อสินค้า] [จำนวน] [ราคา]\n` +
                `2. [ชื่อสินค้า] [จำนวน] [ราคา]\n` +
                `━━━━━━━━━━━━━━━━━━━━`;
            }
            
            await replyFn(message, buttons);
          } catch (err) {
            console.error("[conversationHandler] CREATE_QUOTATION error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREATE_INVOICE:
        // Initialize draft for invoice
        {
          try {
            const draft = await getOrCreateDraft(userId, params.businessId, "BILL");
            
            // ✅ HUMAN-FIRST UX: Use simple message when flag enabled
            const { HUMAN_FIRST_UX_ENABLED } = await import("../shared/config");
            if (HUMAN_FIRST_UX_ENABLED) {
              const { renderDraftSummary, renderNextSteps } = await import("./humanFirstDraftRenderer");
              const { determineHumanFirstState, getHumanFirstButtons } = await import("./humanFirstStateMachine");
              
              const hasItems = draft.items.length > 0;
              const hasCustomer = !!draft.customerName;
              const state = determineHumanFirstState(true, hasCustomer, hasItems);
              const buttons = getHumanFirstButtons(state);
              const renderCtx = {
                docType: 'BILL' as const,
                state,
                isStartMessage: true,
              };
              const guidanceResult = renderNextSteps(draft, renderCtx);
              const summary = renderDraftSummary(draft);
              const message = `📄 กำลังทำใบวางบิล\n\n${summary}\n\n${guidanceResult.text}`;
              
              await replyFn(message, buttons);
              return;
            }
            
            // Legacy flow (when flag=0)
            const summary = formatDraftForDisplay(draft);
            
            // ✅ BUTTON-FIRST: Set state and show buttons (NO text syntax)
            const { setConversationState } = await import("../services/conversationStateService");
            const { getButtonsForState, ButtonState } = await import("./conversationStateMachine");
            
            const hasItems = draft.items.length > 0;
            const hasCustomer = !!draft.customerName;
            const initialState = hasItems ? ButtonState.ITEMS_EXIST : ButtonState.DRAFT_EMPTY;
            await setConversationState(userId, initialState);
            
            const buttons = getButtonsForState(initialState, hasItems, hasCustomer);
            await replyFn(
              `📄 เริ่มสร้างใบวางบิล\n\n${summary}`,
              buttons
            );
          } catch (err) {
            console.error("[conversationHandler] CREATE_INVOICE error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREATE_RECEIPT:
        // Initialize draft for receipt
        {
          try {
            const draft = await getOrCreateDraft(userId, params.businessId, "RECEIPT");
            
            // ✅ HUMAN-FIRST UX: Use simple message when flag enabled
            const { HUMAN_FIRST_UX_ENABLED } = await import("../shared/config");
            if (HUMAN_FIRST_UX_ENABLED) {
              const { renderDraftSummary, renderNextSteps } = await import("./humanFirstDraftRenderer");
              const { determineHumanFirstState, getHumanFirstButtons } = await import("./humanFirstStateMachine");
              
              const hasItems = draft.items.length > 0;
              const hasCustomer = !!draft.customerName;
              const state = determineHumanFirstState(true, hasCustomer, hasItems);
              const buttons = getHumanFirstButtons(state);
              const renderCtx = {
                docType: 'RECEIPT' as const,
                state,
                isStartMessage: true,
              };
              const guidanceResult = renderNextSteps(draft, renderCtx);
              const summary = renderDraftSummary(draft);
              const message = `💰 กำลังทำใบเสร็จ\n\n${summary}\n\n${guidanceResult.text}`;
              
              await replyFn(message, buttons);
              return;
            }
            
            // Legacy flow (when flag=0)
            const summary = formatDraftForDisplay(draft);
            
            // ✅ BUTTON-FIRST: Set state and show buttons (NO text syntax)
            const { setConversationState } = await import("../services/conversationStateService");
            const { getButtonsForState, ButtonState } = await import("./conversationStateMachine");
            
            const hasItems = draft.items.length > 0;
            const hasCustomer = !!draft.customerName;
            const initialState = hasItems ? ButtonState.ITEMS_EXIST : ButtonState.DRAFT_EMPTY;
            await setConversationState(userId, initialState);
            
            const buttons = getButtonsForState(initialState, hasItems, hasCustomer);
            await replyFn(
              `✅ เริ่มสร้างใบเสร็จ\n\n${summary}`,
              buttons
            );
          } catch (err) {
            console.error("[conversationHandler] CREATE_RECEIPT error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREATE_INV_FROM_QUO:
        // Create Invoice from existing Quotation (with optional installment)
        {
          try {
            const response = await createInvoiceFromQuotation(
              userId,
              params.businessId,
              messageText,
              replyFn
            );
            if (response) {
              await replyFn(response, buildDraftEditorQuickReply());
            }
          } catch (err) {
            console.error("[conversationHandler] CREATE_INV_FROM_QUO error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREATE_REC_FROM_INV:
        // Create Receipt from existing Invoice
        {
          try {
            const response = await createReceiptFromInvoice(
              userId,
              params.businessId,
              messageText,
              replyFn
            );
            if (response) {
              await replyFn(response, buildDraftEditorQuickReply());
            }
          } catch (err) {
            console.error("[conversationHandler] CREATE_REC_FROM_INV error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.INSTALLMENT_SUMMARY:
        // Show QUO installment summary
        {
          try {
            const response = await handleInstallmentSummary(userId, params.businessId, messageText);
            // Settings command - use contextual buttons (auto-detect)
          await replyFn(response);
          } catch (err) {
            console.error("[conversationHandler] INSTALLMENT_SUMMARY error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.INSTALLMENT_DASHBOARD:
        // Show QUO installment dashboard
        {
          try {
            const response = await handleInstallmentDashboard(userId, params.businessId, messageText);
            // Settings command - use contextual buttons (auto-detect)
          await replyFn(response);
          } catch (err) {
            console.error("[conversationHandler] INSTALLMENT_DASHBOARD error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CONFIRM_CREDIT_PAYMENT:
        // Confirm credit purchase payment
        {
          try {
            const { confirmPayment } = await import("../services/purchaseService");
            const result = await confirmPayment(userId);
            // Credit payment confirmed - show SUCCESS context buttons
            const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
            const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
            await replyFn(result.message, successButtons);
          } catch (err) {
            console.error("[conversationHandler] CONFIRM_CREDIT_PAYMENT error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREDIT_PURCHASE_HISTORY:
        // Show credit purchase history
        {
          try {
            const { getPurchaseHistory } = await import("../services/purchaseService");
            const history = await getPurchaseHistory(userId);
            // History shown - use contextual buttons (auto-detect: GLOBAL)
            await replyFn(history);
          } catch (err) {
            console.error("[conversationHandler] CREDIT_PURCHASE_HISTORY error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.USAGE_GUIDE:
        // Show usage guide (simplified, 3 steps)
        {
          try {
            const { getUsageGuideSimple } = await import("../services/uxCopy");
            // Use contextual buttons (auto-detect: GLOBAL)
            await replyFn(getUsageGuideSimple());
          } catch (err) {
            console.error("[conversationHandler] USAGE_GUIDE error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.HELP:
        // Show help summary (concise)
        {
          try {
            const { getHelpSummary } = await import("../services/uxCopy");
            // Use contextual buttons (auto-detect: GLOBAL)
            await replyFn(getHelpSummary());
          } catch (err) {
            console.error("[conversationHandler] HELP error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.BUSINESS_SETUP:
        // ✅ FIX 3: Clear overlapping states when entering business setup
        {
          try {
            const { clearConversationState } = await import("../services/conversationStateService");
            const { clearDraft } = await import("./draftStore");
            await clearConversationState(userId);
            await clearDraft(userId);
            console.log(`[conversationHandler] Cleared overlapping states for business setup`);
          } catch (clearErr) {
            console.warn(`[conversationHandler] Failed to clear states for business setup:`, clearErr);
            // Continue - business setup is more important
          }
        }
        
        // ✅ HUMAN-FIRST: Copy-paste business setup flow
        {
          try {
            const {
              getBusinessSetupState,
              setBusinessSetupState,
              getBusinessSetupTemplate,
              getBusinessSetupSummary,
              getParsedBusinessData,
              saveBusinessData,
              clearBusinessSetupState,
            } = await import("../services/businessSetupCopyPaste");
            const { parseBusinessData, validateBusinessData } = await import("../services/businessDataParser");
            const { getBusinessSetupSummaryQuickReply, getBusinessSetupSavedQuickReply } = await import("../shared/businessSetupQuickReply");
            
            const currentState = await getBusinessSetupState(userId);
            
            // STEP 1: Entry point - send template
            if (currentState === 'IDLE') {
              await setBusinessSetupState(userId, 'WAITING_FOR_DATA');
              await replyFn(getBusinessSetupTemplate());
              return;
            }
            
            // STEP 2: User sent data - parse and show summary
            if (currentState === 'WAITING_FOR_DATA') {
              // Check if user wants to cancel
              if (messageText.trim() === 'ยกเลิก' || messageText.trim() === 'cancel') {
                await clearBusinessSetupState(userId);
                await replyFn("ยกเลิกการตั้งค่าธุรกิจแล้วค่ะ");
                return;
              }
              
              // Parse user input (forgiving parser)
              const parsed = parseBusinessData(messageText);
              
              // Validate (but don't reject - just show what we have)
              const validation = validateBusinessData(parsed);
              
                // Convert ParsedBusinessData to Partial<BusinessData>
                const businessData: Partial<{ name?: string; address?: string; phone?: string; taxId?: string; email?: string }> = {
                  name: parsed.name || undefined,
                  address: parsed.address || undefined,
                  phone: parsed.phone || undefined,
                  taxId: parsed.taxId || undefined,
                  email: parsed.email || undefined,
                };
              
              // Store parsed data and show summary
              await setBusinessSetupState(userId, 'SHOWING_SUMMARY', businessData);
              
              const summary = getBusinessSetupSummary(businessData);
              const buttons = getBusinessSetupSummaryQuickReply();
              
              // If missing required fields, add gentle note (not error)
              if (!validation.valid) {
                await replyFn(
                  `${summary}\n\n💡 หมายเหตุ: ยังไม่มี${validation.missingFields.join(', ')} แต่สามารถบันทึกได้ก่อนนะคะ`,
                  buttons
                );
              } else {
                await replyFn(summary, buttons);
              }
              return;
            }
            
            // STEP 3: User confirmed or wants to edit
            if (currentState === 'SHOWING_SUMMARY') {
              if (messageText === 'บันทึกข้อมูล' || messageText === 'ยืนยัน') {
                // Save business data
                const parsed = await getParsedBusinessData(userId);
                if (!parsed) {
                  await replyFn("ไม่พบข้อมูลที่ต้องการบันทึก กรุณาลองใหม่อีกครั้ง");
                  await clearBusinessSetupState(userId);
                  return;
                }
                
                const result = await saveBusinessData(userId, params.businessId, parsed);
                
                if (result.success) {
                  const buttons = getBusinessSetupSavedQuickReply();
                  await replyFn(result.message, buttons);
                } else {
                  await replyFn(result.message);
                }
                return;
              } else if (messageText === 'แก้ไขอีกครั้ง' || messageText === 'แก้ไข') {
                // Go back to waiting for data
                await setBusinessSetupState(userId, 'WAITING_FOR_DATA');
                await replyFn(getBusinessSetupTemplate());
                return;
              } else {
                // Unknown input during summary - show summary again
                const parsed = await getParsedBusinessData(userId);
                if (parsed) {
                  const summary = getBusinessSetupSummary(parsed);
                  const buttons = getBusinessSetupSummaryQuickReply();
                  await replyFn(`${summary}\n\nกรุณาเลือก "บันทึกข้อมูล" หรือ "แก้ไขอีกครั้ง" นะคะ`, buttons);
                } else {
                  // Lost state - restart
                  await setBusinessSetupState(userId, 'WAITING_FOR_DATA');
                  await replyFn(getBusinessSetupTemplate());
                }
                return;
              }
            }
            
            // Fallback: restart flow
            await setBusinessSetupState(userId, 'WAITING_FOR_DATA');
            await replyFn(getBusinessSetupTemplate());
          } catch (err) {
            console.error("[conversationHandler] BUSINESS_SETUP error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREDIT_REPORT:
        // Credit report (admin-only for reconciliation)
        {
          try {
            // Check if this is an admin command (starts with "admin ")
            if (messageText.toLowerCase().startsWith('admin ')) {
              const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
              const { generateDailyReconciliation, formatReconciliationReport } = await import("../services/reconciliationService");
              
              if (!lineUserId) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }

              try {
                await assertAdmin(lineUserId);
              } catch (err) {
                if (err instanceof AdminAuthorizationError) {
                  await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                  break;
                }
                throw err;
              }

              let date: Date;
              if (messageText.includes('เมื่อวาน') || messageText.includes('yesterday')) {
                date = new Date();
                date.setDate(date.getDate() - 1);
              } else {
                date = new Date(); // Today
              }

              const metrics = await generateDailyReconciliation(date);
              const report = formatReconciliationReport(metrics, date);
              await replyFn(report);
            } else {
              // Non-admin users: show simple daily report
              const { generateDailyReport } = await import("../services/reportService");
              const report = await generateDailyReport();
              // Report shown - use contextual buttons (auto-detect: GLOBAL)
              await replyFn(report);
            }
          } catch (err) {
            console.error("[conversationHandler] CREDIT_REPORT error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CREDIT_INVOICE:
        // Get latest credit invoice
        {
          try {
            const { getLatestCreditInvoice } = await import("../services/adminReportService");
            const result = await getLatestCreditInvoice(userId);
            
            if (!result.found) {
              // No purchase history - use contextual buttons (auto-detect: GLOBAL)
              await replyFn("❌ ไม่พบรายการซื้อเครดิต\n\nกรุณาซื้อเครดิตก่อน");
            } else if (result.pdfPath) {
              // Has PDF - generate short link
              const { getOrCreateShortLink } = await import("../shared/pdfFlexMessage");
              const shortToken = await getOrCreateShortLink({
                docId: result.invoiceId!,
                docNo: result.invoiceNo || "CINV",
                docType: "CREDIT_INVOICE",
                pdfPath: result.pdfPath,
                userId,
                businessId: params.businessId,
              });
              // Credit invoice shown - use contextual buttons (auto-detect: GLOBAL)
              await replyFn(
                `📄 ใบกำกับภาษีเครดิต: ${result.invoiceNo}\n\n🔗 https://ezdoc-v1-th.web.app/p/${shortToken}`
              );
            } else {
              // Credit invoice generating - use contextual buttons (auto-detect: GLOBAL)
              await replyFn(
                `📄 ใบกำกับภาษีเครดิต: ${result.invoiceNo}\n\n⏳ PDF กำลังสร้าง กรุณารอสักครู่`
              );
            }
          } catch (err) {
            console.error("[conversationHandler] CREDIT_INVOICE error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.IMAGE_LABEL:
        // Handle image label - USER INTENT ALWAYS OVERRIDES SLIP DETECTION
        {
          try {
            const { processImageWithKeyword, getPendingImage, markPendingImageUsed } = await import("../services/imageUploadService");
            const { setUserImageMode, getUserImageMode } = await import("../services/userStateService");
            
            // Determine intent from keyword
            const keywordLower = messageText.toLowerCase().trim();
            let imageMode: 'LOGO' | 'SIGNATURE' | 'STAMP' | null = null;
            let thaiName = '';
            
            if (keywordLower === 'โลโก้' || keywordLower === 'logo') {
              imageMode = 'LOGO';
              thaiName = 'โลโก้';
            } else if (keywordLower === 'ลายเซ็น' || keywordLower === 'signature') {
              imageMode = 'SIGNATURE';
              thaiName = 'ลายเซ็น';
            } else if (keywordLower === 'ตราประทับ' || keywordLower === 'stamp') {
              imageMode = 'STAMP';
              thaiName = 'ตราประทับ';
            }
            
            if (!imageMode) {
              await replyFn("❌ ไม่รู้จักคำสั่ง\n\nพิมพ์: โลโก้ / ลายเซ็น / ตราประทับ");
              break;
            }
            
            // PRIORITY: Override any SLIP mode when user explicitly types intent
            const currentMode = await getUserImageMode(userId);
            if (currentMode === 'SLIP') {
              // User intent overrides SLIP detection
              console.log(`[IMAGE_LABEL] Overriding SLIP mode with user intent: ${imageMode}`);
            }
            
            // Force image_mode to user intent
            await setUserImageMode(userId, imageMode);
            
            // Check for pending image
            const pendingMessageId = getPendingImage(userId);
            if (pendingMessageId) {
              // Bind pending image to user intent
              markPendingImageUsed(userId);
              
              const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
              const result = await processImageWithKeyword(userId, params.businessId, messageText, accessToken);
              
              // Clear image_mode after processing
              await setUserImageMode(userId, null);
              
              // Credit payment confirmed - show SUCCESS context buttons
            const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
            const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
            await replyFn(result.message, successButtons);
            } else {
              // No pending image - set mode for next image
              // Image label set - use contextual buttons (auto-detect: GLOBAL)
              await replyFn(`✅ ตั้งค่าแล้ว\n\nส่งรูป${thaiName}ได้เลย`);
            }
          } catch (err) {
            console.error("[conversationHandler] IMAGE_LABEL error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_LIST_PENDING:
        // List pending review purchases
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { listPendingReviews } = await import("../services/adminReviewService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Get both PENDING_REVIEW and max retry cases
            const { getAdminQueue, formatQueueEntryAsText, getQueueSummary } = await import("../services/adminPaymentQueueService");
            
            const pendingReviews = await listPendingReviews();
            const adminQueue = await getAdminQueue(10);
            const summary = await getQueueSummary();
            
            let message = pendingReviews;
            
            if (adminQueue.length > 0) {
              message += `\n\n━━━━━━━━━━━━━━━━━━━━\n`;
              message += `🚨 รายการที่ลองเกิน 3 ครั้ง (${summary.total} รายการ)\n\n`;
              
              for (const entry of adminQueue.slice(0, 5)) {
                message += formatQueueEntryAsText(entry);
                message += `\n━━━━━━━━━━━━━━━━━━━━\n\n`;
              }
              
              if (adminQueue.length > 5) {
                message += `... และอีก ${adminQueue.length - 5} รายการ\n`;
              }
            }
            
            await replyFn(message);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_LIST_PENDING error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_VIEW_SLIP:
        // View slip details ("admin ดู <purchaseId>")
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { getSlipDetails } = await import("../services/adminReviewService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Extract purchaseId from message (e.g., "admin ดู abc123")
            const match = messageText.match(/^admin\s+(?:ดู|view)\s+(\w+)/i);
            if (!match || !match[1]) {
              await replyFn("❌ กรุณาระบุ purchaseId\n\nเช่น: admin ดู abc123");
              break;
            }
            const purchaseId = match[1];
            const result = await getSlipDetails(purchaseId);
            await replyFn(result);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_VIEW_SLIP error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_APPROVE_SLIP:
        // Approve slip ("admin ยืนยัน <purchaseId>")
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { approveSlip } = await import("../services/adminReviewService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Extract purchaseId from message (e.g., "admin ยืนยัน abc123")
            const match = messageText.match(/^admin\s+(?:ยืนยัน|approve)\s+(\w+)/i);
            if (!match || !match[1]) {
              await replyFn("❌ กรุณาระบุ purchaseId\n\nเช่น: admin ยืนยัน abc123");
              break;
            }
            const purchaseId = match[1];
            const result = await approveSlip(purchaseId, lineUserId);
            await replyFn(result);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_APPROVE_SLIP error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_REJECT_SLIP:
        // Reject slip ("admin ปฏิเสธ <purchaseId> <reason>")
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { rejectSlip } = await import("../services/adminReviewService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Extract purchaseId and reason from message (e.g., "admin ปฏิเสธ abc123 สลิปไม่ชัด")
            const match = messageText.match(/^admin\s+(?:ปฏิเสธ|reject)\s+(\w+)(?:\s+(.+))?/i);
            if (!match || !match[1]) {
              await replyFn("❌ กรุณาระบุ purchaseId\n\nเช่น: admin ปฏิเสธ abc123 สลิปไม่ชัด");
              break;
            }
            const purchaseId = match[1];
            const reason = match[2] || 'ไม่ผ่านการตรวจสอบ';
            const result = await rejectSlip(purchaseId, lineUserId, reason);
            await replyFn(result);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_REJECT_SLIP error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_CONFIRM_EMAIL:
        // Confirm via email ("admin ยืนยันอีเมล <purchaseId> [email text]")
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { confirmViaEmail } = await import("../services/adminReviewService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Extract purchaseId and optional email text from message
            // Pattern: "admin ยืนยันอีเมล <purchaseId> [email text]"
            const match = messageText.match(/^admin\s+(?:ยืนยันอีเมล|confirm email)\s+(\w+)(?:\s+(.+))?/is);
            if (!match || !match[1]) {
              await replyFn("❌ กรุณาระบุ purchaseId\n\nเช่น: admin ยืนยันอีเมล abc123\n\nหรือ: admin ยืนยันอีเมล abc123 [วางข้อความอีเมลธนาคาร]");
              break;
            }
            const purchaseId = match[1];
            const emailText = match[2]?.trim();
            
            if (!emailText || emailText.length < 50) {
              await replyFn(`📧 กรุณาส่งข้อความอีเมลธนาคารที่ได้รับเพื่อยืนยันการชำระเงินสำหรับ ${purchaseId}\n\n(ส่งข้อความใหม่)`);
              break;
            }

            const result = await confirmViaEmail(purchaseId, lineUserId, emailText);
            await replyFn(result);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_CONFIRM_EMAIL error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.ADMIN_EXPORT_CSV:
        // Export CSV ("admin export เครดิต csv")
        {
          try {
            const { assertAdmin, AdminAuthorizationError } = await import("../services/adminAuthService");
            const { exportCreditPurchasesCSV } = await import("../services/reportService");
            
            if (!lineUserId) {
              await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
              break;
            }

            try {
              await assertAdmin(lineUserId);
            } catch (err) {
              if (err instanceof AdminAuthorizationError) {
                await replyFn("⛔ คำสั่งนี้สำหรับผู้ดูแลระบบเท่านั้น");
                break;
              }
              throw err;
            }

            // Check for date range (e.g., "admin export เครดิต csv เดือนนี้")
            let startDate: Date | null = null;
            let endDate: Date | null = null;
            if (messageText.includes('เดือนนี้') || messageText.includes('this month')) {
              const now = new Date();
              startDate = new Date(now.getFullYear(), now.getMonth(), 1);
              endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
            }
            const csvUrl = await exportCreditPurchasesCSV(startDate, endDate);
            await replyFn(`📥 CSV Export:\n\n${csvUrl}\n\n(URL หมดอายุใน 1 ชั่วโมง)`);
          } catch (err) {
            console.error("[conversationHandler] ADMIN_EXPORT_CSV error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.UNKNOWN:
        // ✅ FIX 4: State-aware fallback - Never reset state, always provide context-specific help
        {
          try {
            // Get current user state
            const { getConversationState } = await import("../services/conversationStateService");
            const draftStore = await import("./draftStore");
            const { getWizardState } = await import("../services/wizardService");
            const { getBusinessChecklist } = await import("../services/businessService");
            
            const conversationState = await getConversationState(userId);
            // Check if draft exists (getDraft returns null if no draft)
            const draft = await draftStore.getDraft(userId);
            const draftActive = !!draft;
            const wizardState = await getWizardState(userId);
            const checklist = await getBusinessChecklist(userId, params.businessId);
            
            const criticalFields = ['name', 'address', 'phone'];
            const missingFields = checklist.items
              .filter(item => criticalFields.includes(item.field) && !item.completed)
              .map(item => item.field === 'name' ? 'business_name' : item.field);
            
            // ✅ FIX 4: Use state-aware fallback
            const { getStateAwareFallback } = await import("../utils/stateAwareFallback");
            const fallback = await getStateAwareFallback(userId, {
              conversationState,
              hasActiveDraft: draftActive,
              paymentState,
              wizardStep: wizardState?.step || null,
              missingBusinessFields: missingFields,
            }, traceId); // HARDENING v3: Pass traceId for logging
            
            console.log(`[conversationHandler] UNKNOWN intent - state-aware fallback: conversationState=${conversationState}, hasDraft=${draftActive}, paymentState=${paymentState}`);
            await replyFn(fallback.message, fallback.quickReply);
            return; // State preserved, user got help
          } catch (err) {
            console.error("[conversationHandler] UNKNOWN error:", err);
            // ✅ FIX 4: Always reply, even on error
            const { getGlobalFallbackMessage } = await import("../services/paymentUXCopy");
            const { getPlanAwareMainMenu } = await import("../services/planAwareUI");
            const buttons = await getPlanAwareMainMenu(userId);
            await replyFn(getGlobalFallbackMessage(), buttons);
          }
        }
        break;
        
        // Legacy code below (kept for reference, but UNKNOWN now returns early)
        {
          try {
            const { getConversationState, usesButtons } = await import("../services/conversationStateService");
            const { getButtonsForState } = await import("./conversationStateMachine");
            const { getDraft } = await import("./draftStore");
            
            const currentState = await getConversationState(userId);
            
            if (usesButtons(currentState)) {
              // User is in button-capable state - show buttons, NO text syntax
              const draft = await getDraft(userId);
              const hasItems = (draft?.items?.length ?? 0) > 0;
              const hasCustomer = !!draft?.customerName;
              const buttons = getButtonsForState(currentState, hasItems, hasCustomer);
              
              console.log(`[conversationHandler] UNKNOWN in button state: ${currentState}, showing buttons`);
              await replyFn("ขอบคุณมากนะคะ 😊\n\nเลือกทำต่อได้เลยด้านล่างค่ะ", buttons);
              return;
            }
            
            // Check if this was a button action that somehow reached UNKNOWN
            const { detectInputSource, getButtonAction } = await import("../core/buttonActionMap");
            const inputSource = detectInputSource(messageText);
            const buttonAction = getButtonAction(messageText);
            
            if (buttonAction || inputSource !== 'TEXT_INPUT') {
              // This should not happen - button action should have been caught earlier
              console.warn(`[conversationHandler] Button action reached UNKNOWN: "${messageText}"`);
              // Route to the correct intent anyway
              const { recognizeIntent } = await import("./conversationOrchestrator");
              const correctIntent = recognizeIntent(messageText);
              if (correctIntent !== Intent.UNKNOWN) {
                console.log(`[conversationHandler] Re-routing button action to: ${correctIntent}`);
                // Fall through to handle the correct intent
              }
            }
            
            const { suggestTypoCorrection } = await import("../services/onboardingService");
            
            // Check for typo correction
            const typoSuggestion = suggestTypoCorrection(messageText);
            if (typoSuggestion) {
              // Typo suggestion - use contextual buttons (auto-detect: GLOBAL)
              await replyFn(typoSuggestion || 'ไม่เข้าใจคำสั่งนี้ค่ะ');
            } else {
              // ✅ BUTTON-FIRST: Use global fallback (not payment-specific)
              // Only use this if NOT in payment flow (payment flow is handled above)
              const { getGlobalFallbackMessage } = await import("../services/paymentUXCopy");
              await replyFn(getGlobalFallbackMessage());
            }
          } catch (err) {
            console.error("[conversationHandler] UNKNOWN error:", err);
            // ✅ FIX 2: Always reply, even on error
            const { getGlobalFallbackMessage } = await import("../services/paymentUXCopy");
            await replyFn(getGlobalFallbackMessage());
          }
        }
        break;

      case Intent.EDIT:
        // ✅ HUMAN-FIRST UX: Try new flow first (gated by flag)
        // Note: Allowlisted users already handled above, this is for non-allowlisted users
        {
          try {
            const { HUMAN_FIRST_UX_ENABLED } = await import("../shared/config");
            
            if (HUMAN_FIRST_UX_ENABLED && !isAllowlisted) {
              // Try human-first handler (non-allowlisted users can still use if flag is on)
              const { handleHumanFirstEdit } = await import("./humanFirstHandler");
              const humanFirstResponse = await handleHumanFirstEdit(
                userId,
                params.businessId,
                messageText,
                replyFn,
                params.lineUserId,
                params.traceId
              );
              
              if (humanFirstResponse) {
                await replyFn(humanFirstResponse.message, humanFirstResponse.buttons);
                return;
              }
              // If null, CONFIRM was handled - return
              return;
            }
            
            // Legacy handler (flag disabled or not allowlisted)
            
            // Fall back to legacy handler (when flag=0 or CONFIRM action)
            const draft = await getDraft(userId);
            if (!draft) {
              await replyFn("ไม่มีเอกสารที่กำลังแก้ไข กรุณาสร้างใหม่");
              break;
            }

            // ✅ Check if this is a button action
            const { getConversationState, setConversationState, getStateMetadata, setStateMetadata } = await import("../services/conversationStateService");
            const { getButtonsForState, ButtonState } = await import("./conversationStateMachine");
            const currentState = await getConversationState(userId);
            const metadata = await getStateMetadata(userId);
            
            // ✅ BUTTON: "ลูกค้า" - Transition to AWAITING_CUSTOMER_INPUT (FIX A1)
            if (messageText === "ลูกค้า" || messageText.trim() === "ลูกค้า") {
              const template = 
                '👤 กรุณาส่งข้อมูลลูกค้าค่ะ:\n\n' +
                '📝 ตัวอย่าง (ก๊อปไปแก้ได้):\n' +
                'ลูกค้า: บริษัท ABC\n' +
                'ที่อยู่: 123/4 ถนน...\n' +
                'เบอร์โทร: 0123456789\n' +
                'เลขผู้เสียภาษี: 0123456789012\n\n' +
                'หรือส่งแค่ชื่อ: ลูกค้า: [ชื่อ]';
              await setConversationState(userId, ButtonState.AWAITING_CUSTOMER_INPUT);
              const { getAwaitingCustomerInputButtons } = await import("../ui/quickReplies");
              const buttons = getAwaitingCustomerInputButtons();
              await replyFn(template, buttons);
              return;
            }
            
            // ✅ BUTTON: "เพิ่มรายการ" - Transition to AWAITING_ITEM_INPUT
            if (messageText === "เพิ่มรายการ" || messageText.trim() === "เพิ่มรายการ") {
              // Start item add flow (ask for name first)
              await setConversationState(userId, ButtonState.AWAITING_ITEM_INPUT, { step: 'name' });
              const buttons = getButtonsForState(ButtonState.AWAITING_ITEM_INPUT);
              await replyFn("ชื่อรายการคืออะไรคะ?", buttons);
              return;
            }
            
            // ✅ STATE: AWAITING_CUSTOMER_INPUT - Handle customer input (FIX A1)
            if (currentState === ButtonState.AWAITING_CUSTOMER_INPUT) {
              // Parse customer info from multiline or single line format
              const customerMatch = messageText.match(/ลูกค้า[:：]?\s*(.+?)(?:\n|$)/i);
              if (customerMatch) {
                const customerName = customerMatch[1].trim();
                if (customerName && customerName.length > 0) {
                  await updateDraft(userId, { customerName });
                  await setConversationState(userId, ButtonState.CUSTOMER_SET);
                  const buttons = getButtonsForState(ButtonState.CUSTOMER_SET);
                  await replyFn(`✅ อัปเดตลูกค้า: ${customerName}`, buttons);
                  return;
                }
              }
              // If no match, ask again
              const { getAwaitingCustomerInputButtons } = await import("../ui/quickReplies");
              await replyFn("กรุณาส่งข้อมูลลูกค้าตามรูปแบบ:\nลูกค้า: [ชื่อ]", getAwaitingCustomerInputButtons());
              return;
            }
            
            // ✅ STATE: AWAITING_ITEM_INPUT - Handle item name/price input
            if (currentState === ButtonState.AWAITING_ITEM_INPUT) {
              // ✅ FIX 7: Handle cancel command
              if (messageText === 'ยกเลิก' || messageText === 'cancel') {
                const { clearConversationState } = await import("../services/conversationStateService");
                await clearConversationState(userId);
                await setStateMetadata(userId, {});
                const buttons = getButtonsForState(ButtonState.IDLE);
                await replyFn("ยกเลิกการเพิ่มรายการแล้วค่ะ", buttons);
                return;
              }
              
              const step = metadata.step as string;
              
              if (step === 'name') {
                // User provided item name
                const itemName = messageText.trim();
                if (!itemName || itemName.length === 0) {
                  await replyFn("กรุณาระบุชื่อรายการค่ะ");
                  return;
                }
                await setStateMetadata(userId, { pendingItemName: itemName, step: 'price' });
                const buttons = getButtonsForState(ButtonState.AWAITING_ITEM_INPUT);
                await replyFn(`ชื่อรายการ: ${itemName}\n\nราคาเท่าไหร่คะ?`, buttons);
                return;
              } else if (step === 'price') {
                // User provided price
                const priceText = messageText.trim();
                const price = parseFloat(priceText.replace(/[^\d.]/g, ''));
                
                if (isNaN(price) || price <= 0) {
                  await replyFn("กรุณาระบุราคาที่ถูกต้องค่ะ");
                  return;
                }
                
                const itemName = metadata.pendingItemName as string;
                if (!itemName) {
                  // Fallback: treat as full command
                  await setConversationState(userId, ButtonState.DRAFT_EMPTY);
                  // Continue to legacy parsing below
                } else {
                  // Add item to draft
                  const updatedDraft = await getDraft(userId);
                  if (updatedDraft) {
                    updatedDraft.items.push({ name: itemName, qty: 1, price });
                    await updateDraft(userId, { items: updatedDraft.items });
                    
                    // Transition to ITEMS_EXIST state
                    await setConversationState(userId, ButtonState.ITEMS_EXIST);
                    await setStateMetadata(userId, {}); // Clear pending data
                    
                    const summary = formatDraftForDisplay(updatedDraft);
                    const buttons = getButtonsForState(ButtonState.ITEMS_EXIST);
                    await replyFn(`✅ เพิ่มรายการ: ${itemName} ${price.toLocaleString('th-TH')} บาท\n\n${summary}`, buttons);
                    return;
                  }
                }
              }
            }
            
            // ✅ MULTILINE: Parse form-style input (FIX B)
            if (messageText.includes('\n') && (messageText.includes(':') || messageText.includes('：'))) {
              try {
                const { parseEzDocText } = await import('./parse');
                const parsed = parseEzDocText(messageText);
                
                // Apply parsed data to draft
                const updatedDraft = await getDraft(userId);
                if (updatedDraft) {
                  const updates: Partial<typeof updatedDraft> = {};
                  
                  // Update customer name if parsed
                  if (parsed.customer_name) {
                    updates.customerName = parsed.customer_name;
                  }
                  
                  // Update items if parsed
                  if (parsed.items && parsed.items.length > 0) {
                    const newItems = parsed.items.map(item => ({
                      name: item.description_th || item.description_en || '',
                      qty: item.qty || 1,
                      price: item.unit_price || 0,
                    }));
                    updates.items = [...(updatedDraft.items || []), ...newItems];
                  }
                  
                  // Apply updates
                  if (Object.keys(updates).length > 0) {
                    await updateDraft(userId, updates);
                    
                    // Refresh draft for display
                    const finalDraft = await getDraft(userId);
                    if (finalDraft) {
                      const summary = formatDraftForDisplay(finalDraft);
                      const hasItems = finalDraft.items.length > 0;
                      const hasCustomer = !!finalDraft.customerName;
                      const state = hasItems ? ButtonState.ITEMS_EXIST : ButtonState.DRAFT_EMPTY;
                      const buttons = getButtonsForState(state, hasItems, hasCustomer);
                      
                      let responseMsg = '✅ อัปเดตข้อมูลแล้ว:\n\n';
                      if (parsed.customer_name) responseMsg += `👤 ลูกค้า: ${parsed.customer_name}\n`;
                      if (parsed.items && parsed.items.length > 0) {
                        responseMsg += `📦 เพิ่มรายการ: ${parsed.items.length} รายการ\n`;
                      }
                      responseMsg += `\n${summary}`;
                      
                      await replyFn(responseMsg, buttons);
                      return;
                    }
                  }
                }
              } catch (err) {
                console.warn('[conversationHandler] Multiline parse failed, falling back to legacy:', err);
                // Fall through to legacy parsing
              }
            }
            
            // ✅ LEGACY: Parse text commands (for backward compatibility)
            // "ลูกค้า ABC" -> set customerName
            // "เพิ่มรายการ ABC 1000" -> add item (full syntax)
            // "ลบรายการ 1" -> remove item
            const customerMatch = messageText.match(/ลูกค้า\s+(.+?)(?:\n|$)/i);
            if (customerMatch) {
              const customerName = customerMatch[1].trim();
              await updateDraft(userId, { customerName });
              await setConversationState(userId, ButtonState.CUSTOMER_SET);
              const buttons = getButtonsForState(ButtonState.CUSTOMER_SET);
              await replyFn(`✅ อัปเดตลูกค้า: ${customerName}`, buttons);
              return;
            }

            const addItemMatch = messageText.match(/เพิ่มรายการ\s+(.+?)(?:\s+|\|)(\d+)(?:\s|$)/i);
            if (addItemMatch) {
              const itemName = addItemMatch[1].trim();
              const price = parseInt(addItemMatch[2], 10);
              const updatedDraft = await getDraft(userId);
              if (updatedDraft) {
                updatedDraft.items.push({ name: itemName, qty: 1, price });
                await updateDraft(userId, { items: updatedDraft.items });
                await setConversationState(userId, ButtonState.ITEMS_EXIST);
                const buttons = getButtonsForState(ButtonState.ITEMS_EXIST);
                await replyFn(`✅ เพิ่มรายการ: ${itemName} ${price}฿`, buttons);
                return;
              }
            }

            // Show current summary with buttons
            const currentDraft = await getDraft(userId);
            if (currentDraft) {
              const summary = formatDraftForDisplay(currentDraft);
              const hasItems = currentDraft.items.length > 0;
              const hasCustomer = !!currentDraft.customerName;
              const state = hasItems ? ButtonState.ITEMS_EXIST : ButtonState.DRAFT_EMPTY;
              const buttons = getButtonsForState(state, hasItems, hasCustomer);
              await replyFn(`📝 สถานะปัจจุบัน:\n\n${summary}`, buttons);
            }
          } catch (err) {
            console.error("[conversationHandler] EDIT error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CONFIRM:
        // Finalize and issue document
        {
          try {
            const draft = await getDraft(userId);
            if (!draft) {
              await replyFn("ไม่มีเอกสารที่กำลังสร้าง");
              break;
            }

            if (draft.items.length === 0) {
              await replyFn("⚠️ ยังไม่มีรายการสินค้า/บริการ โปรดเพิ่มรายการก่อน");
              break;
            }

            if (!draft.customerName) {
              await replyFn("⚠️ ยังไม่ได้ระบุลูกค้า โปรดระบุลูกค้าก่อน");
              break;
            }

            // Call document creation pipeline
            await confirmAndIssueDraft(userId, params.businessId, draft, replyFn, lineUserId);

            // Clear draft after successful issuance
            await clearDraft(userId);
          } catch (err) {
            console.error("[CONFIRM_ERROR] ❌ Error issuing document:", err);
            // Error creating PDF - use contextual buttons (auto-detect: GLOBAL)
            await replyFn(
              "📄 สร้าง PDF ไม่สำเร็จ\n\n" +
              "กรุณาลองใหม่อีกครั้ง หรือติดต่อฝ่ายสนับสนุน"
            );
          }
        }
        break;

      case Intent.CANCEL:
        // ✅ BUTTON-FIRST: Clear draft and state
        {
          try {
            const draft = await getDraft(userId);
            if (!draft) {
              await replyFn("ไม่มีเอกสารที่กำลังสร้าง");
              break;
            }

            // ✅ BUTTON-FIRST: Clear state when cancelling
            const { clearConversationState } = await import("../services/conversationStateService");
            await clearConversationState(userId);
            
            await clearDraft(userId);
            // Draft cancelled - use contextual buttons (auto-detect: GLOBAL)
            await replyFn("❌ ยกเลิกการสร้างเอกสาร");
          } catch (err) {
            console.error("[conversationHandler] CANCEL error:", err);
            await replyFn("เกิดข้อผิดพลาด");
          }
        }
        break;

      case Intent.PAID:
        // Step 1: User says "ชำระแล้ว INV-xxx"
        // Resolve invoice docId from message
        {
          const invoiceDocId = await resolveInvoiceDocId(userId, params.businessId, messageText);
          if (!invoiceDocId) {
            await replyFn(
              "ไม่พบใบวางบิล กรุณาระบุเลขเอกสาร เช่น:\nชำระแล้ว INV-2568-001"
            );
            break;
          }

          // Call payment notification handler
          try {
            await handlePaymentNotification(
              "", // conversationId (not used in this version)
              userId,
              params.businessId,
              invoiceDocId,
              replyFn
            );
          } catch (err) {
            console.error("[conversationHandler] Payment notification error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.CONFIRM_PAYMENT:
        // Step 2: User says "ยืนยันรับเงิน INV-xxx"
        // Resolve invoice docId from message
        {
          const invoiceDocId = await resolveInvoiceDocId(userId, params.businessId, messageText);
          if (!invoiceDocId) {
            await replyFn(
              "ไม่พบใบวางบิล กรุณาระบุเลขเอกสาร เช่น:\nยืนยันรับเงิน INV-2568-001"
            );
            break;
          }

          // Call payment confirmation handler
          try {
            await handlePaymentConfirmation(
              "", // conversationId (not used in this version)
              userId,
              params.businessId,
              invoiceDocId,
              replyFn
            );
          } catch (err) {
            console.error("[conversationHandler] Payment confirmation error:", err);
            await replyFn("เกิดข้อผิดพลาด ไม่สามารถบันทึกการชำระได้");
          }
        }
        break;

      case Intent.REQUEST_PDF: {
        const db = admin.firestore();

        // ✅ Robust doc_no parsing:
        // - PREFIX: 2-10 letters (case-insensitive)
        // - YEAR: 4 digits (supports Thai BE e.g., 2568)
        // - SEQ: 1-10 digits
        const docNoMatch = messageText.match(/\b([A-Z]{2,10})-(\d{4})-(\d{1,10})\b/i);
        if (!docNoMatch) {
          await replyFn("โปรดระบุเลขเอกสาร เช่น:\nขอ PDF QUO-2568-001");
          break;
        }
        const docNo = docNoMatch[0].toUpperCase();

        // หาจาก documents
        try {
          const snap = await db
            .collection("users")
            .doc(userId)
            .collection("businesses")
            .doc(params.businessId)
            .collection("documents")
            .where("doc_no", "==", docNo)
            .limit(1)
            .get();

          if (snap.empty) {
            await replyFn(`ไม่พบเอกสารเลขที่ ${docNo}`);
            break;
          }

          const doc = snap.docs[0];
          const data = doc.data() as any;

          // ✅ Production-safe: use pdf_path as source of truth
          // Generate short link for security (no signed URL exposed in logs/messages)
          const pdfPath = data.pdf_path || data.pdfPath || null;
          if (pdfPath) {
            try {
              const bucket = admin.storage().bucket();
              const file = bucket.file(String(pdfPath));
              const [exists] = await file.exists();
              if (!exists) {
                // ✅ If pdf_path exists but the object is missing, DO NOT return legacy URL.
                // Re-enqueue to regenerate and auto-push to user.
                console.warn(`[REQUEST_PDF] pdf_path exists but object missing -> requeue: ${pdfPath}`);
              } else {
                // Build Flex message with short link (secure, consistent UI)
                const flexMessage = await buildPdfFlexMessageWithShortLink({
                  docId: doc.id,
                  docNo,
                  docType: data.doc_type || '',
                  pdfPath: String(pdfPath),
                  userId,
                  businessId: params.businessId,
                });

                // Security: Log only identifiers, not URLs
                console.log(`[REQUEST_PDF] Replying with Flex: doc_no=${docNo}, pdf_path=${pdfPath}`);

                // Reply with Flex message
                await replyWithFlex(flexMessage);
                break;
              }
            } catch (signErr) {
              console.error("[REQUEST_PDF] Error building Flex message:", signErr);
              // fall through to re-queue below (safety net)
            }
          }

          // Legacy fallback removed - always use short links or enqueue

          // ยังไม่มี pdf -> enqueue idempotently (deterministic job ID)
          const { action } = await queuePdfGeneration(
            userId,
            params.businessId,
            doc.id,
            docNo,
            data.doc_type,
            traceId
          );

          if (action === 'DONE') {
            // Should be rare (document write-through should have populated pdfUrl already)
            await replyFn(`กำลังส่งไฟล์ PDF สำหรับ ${docNo} ให้คุณทาง LINE อัตโนมัติ`);
            break;
          }

          // If CREATED / IN_PROGRESS / REQUEUED -> rely on auto-push when DONE
          await replyFn(`รับแล้ว กำลังสร้าง PDF สำหรับ ${docNo}\n\nระบบจะส่งให้ทาง LINE อัตโนมัติเมื่อพร้อม`);
        } catch (err) {
          console.error("[conversationHandler] REQUEST_PDF error:", err);
          await replyFn("เกิดข้อผิดพลาดในการดึงข้อมูล โปรดลองใหม่");
        }
        break;
      }

      // ✅ FIX 5: Delivery retry commands
      case Intent.RESEND_DOCUMENT: {
        try {
          const db = admin.firestore();
          
          // ✅ Authorization: Verify business exists and user has access
          const businessRef = db.collection('users').doc(userId).collection('businesses').doc(params.businessId);
          const businessDoc = await businessRef.get();
          if (!businessDoc.exists) {
            await replyFn("ไม่พบธุรกิจที่ระบุ");
            break;
          }
          
          // ✅ Authorization: Verify business belongs to user (implicit via path, but explicit check for clarity)
          const businessData = businessDoc.data();
          if (!businessData) {
            await replyFn("ไม่พบข้อมูลธุรกิจ");
            break;
          }
          
          // Get last document for user
          const docsQuery = await db
            .collection('users')
            .doc(userId)
            .collection('businesses')
            .doc(params.businessId)
            .collection('documents')
            .orderBy('created_at', 'desc')
            .limit(1)
            .get();
          
          if (docsQuery.empty) {
            await replyFn("ไม่พบเอกสารล่าสุด");
            break;
          }
          
          const doc = docsQuery.docs[0];
          const docData = doc.data();
          const docNo = docData.doc_no || doc.id;
          const pdfPath = docData.pdf_path;
          
          if (!pdfPath) {
            await replyFn(`เอกสาร ${docNo} ยังไม่มี PDF\n\nกรุณารอสักครู่แล้วลองใหม่`);
            break;
          }
          
          // Build Flex message and send
          const { buildPdfFlexMessageWithShortLink } = await import("../shared/pdfFlexMessage");
          const flexMessage = await buildPdfFlexMessageWithShortLink({
            docId: doc.id,
            docNo,
            docType: docData.doc_type || '',
            pdfPath: String(pdfPath),
            userId,
            businessId: params.businessId,
          });
          
          await replyWithFlex(flexMessage);
          console.log(`[RESEND_DOCUMENT] Resent document: ${docNo}, traceId=${traceId || 'n/a'}`);
        } catch (err) {
          console.error("[conversationHandler] RESEND_DOCUMENT error:", err);
          await replyFn("เกิดข้อผิดพลาดในการส่งเอกสาร โปรดลองใหม่");
        }
        break;
      }

      // ✅ FIX 1: Payment status commands
      case Intent.CHECK_PAYMENT_STATUS: {
        try {
          const { getRecentPendingPurchase } = await import("../services/imageUploadService");
          const { getPaymentStatusMessage } = await import("../services/paymentStateService");
          
          const recentPurchase = await getRecentPendingPurchase(userId);
          if (!recentPurchase) {
            await replyFn("ไม่พบรายการชำระเงินที่รอตรวจสอบค่ะ");
            break;
          }
          
          const statusMessage = await getPaymentStatusMessage(userId);
          if (statusMessage) {
            await replyFn(statusMessage);
          } else {
            await replyFn("ไม่พบรายการชำระเงินที่รอตรวจสอบค่ะ");
          }
        } catch (err) {
          console.error("[conversationHandler] CHECK_PAYMENT_STATUS error:", err);
          await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
        }
      }
      break;

      case Intent.RESEND_SLIP: {
        try {
          const { getRecentPendingPurchase } = await import("../services/imageUploadService");
          const recentPurchase = await getRecentPendingPurchase(userId);
          
          if (!recentPurchase) {
            await replyFn("ไม่พบรายการชำระเงินที่รอส่งสลิปค่ะ");
            break;
          }
          
          if (recentPurchase.purchase.status === 'PAID') {
            await replyFn("✅ รายการนี้ชำระเงินแล้วค่ะ");
            break;
          }
          
          // Reset to WAITING_FOR_SLIP and prompt for new slip
          const db = admin.firestore();
          const purchaseRef = db.collection('credit_purchases').doc(recentPurchase.purchaseId);
          await purchaseRef.update({
            status: 'WAITING_FOR_SLIP',
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          const { setUserImageMode } = await import("../services/userStateService");
          await setUserImageMode(userId, 'SLIP');
          
          await replyFn("กรุณาส่งสลิปการโอนเงินอีกครั้งค่ะ");
        } catch (err) {
          console.error("[conversationHandler] RESEND_SLIP error:", err);
          await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
        }
      }
      break;

      case Intent.CANCEL_PAYMENT: {
        try {
          const { getRecentPendingPurchase } = await import("../services/imageUploadService");
          const recentPurchase = await getRecentPendingPurchase(userId);
          
          if (!recentPurchase) {
            await replyFn("ไม่พบรายการชำระเงินที่สามารถยกเลิกได้ค่ะ");
            break;
          }
          
          if (recentPurchase.purchase.status === 'PAID') {
            await replyFn("❌ ไม่สามารถยกเลิกรายการที่ชำระเงินแล้วได้ค่ะ");
            break;
          }
          
          // Mark as expired/cancelled
          const db = admin.firestore();
          const purchaseRef = db.collection('credit_purchases').doc(recentPurchase.purchaseId);
          await purchaseRef.update({
            status: 'EXPIRED',
            cancelled_at: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          const { setUserImageMode } = await import("../services/userStateService");
          await setUserImageMode(userId, null);
          
          await replyFn("✅ ยกเลิกรายการชำระเงินแล้วค่ะ");
        } catch (err) {
          console.error("[conversationHandler] CANCEL_PAYMENT error:", err);
          await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
        }
      }
      break;

      case Intent.GET_DOCUMENT_LINK: {
        try {
          const db = admin.firestore();
          
          // ✅ Authorization: Verify business exists and user has access
          const businessRef = db.collection('users').doc(userId).collection('businesses').doc(params.businessId);
          const businessDoc = await businessRef.get();
          if (!businessDoc.exists) {
            await replyFn("ไม่พบธุรกิจที่ระบุ");
            break;
          }
          
          // ✅ Authorization: Verify business belongs to user
          const businessData = businessDoc.data();
          if (!businessData) {
            await replyFn("ไม่พบข้อมูลธุรกิจ");
            break;
          }
          
          // Get last document for user
          const docsQuery = await db
            .collection('users')
            .doc(userId)
            .collection('businesses')
            .doc(params.businessId)
            .collection('documents')
            .orderBy('created_at', 'desc')
            .limit(1)
            .get();
          
          if (docsQuery.empty) {
            await replyFn("ไม่พบเอกสารล่าสุด");
            break;
          }
          
          const doc = docsQuery.docs[0];
          const docData = doc.data();
          const docNo = docData.doc_no || doc.id;
          const pdfPath = docData.pdf_path;
          
          if (!pdfPath) {
            await replyFn(`เอกสาร ${docNo} ยังไม่มี PDF\n\nกรุณารอสักครู่แล้วลองใหม่`);
            break;
          }
          
          // Generate signed URL
          const storage = admin.storage();
          const bucket = storage.bucket();
          const file = bucket.file(String(pdfPath));
          const [signedUrl] = await file.getSignedUrl({
            action: 'read',
            expires: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
          });
          
          await replyFn(`🔗 ลิงก์เอกสาร ${docNo}:\n\n${signedUrl}\n\n(หมดอายุใน 7 วัน)`);
          console.log(`[GET_DOCUMENT_LINK] Generated link for document: ${docNo}, traceId=${traceId || 'n/a'}`);
        } catch (err) {
          console.error("[conversationHandler] GET_DOCUMENT_LINK error:", err);
          await replyFn("เกิดข้อผิดพลาดในการสร้างลิงก์ โปรดลองใหม่");
        }
        break;
      }

      case Intent.SETTINGS: {
        // Handle business/payment settings commands
        try {
          const { handleSettingsCommand } = await import("./businessSettings");
          const response = await handleSettingsCommand(userId, params.businessId, messageText);
          // Settings command - use contextual buttons (auto-detect)
          await replyFn(response);
        } catch (err) {
          console.error("[conversationHandler] SETTINGS error:", err);
          await replyFn("เกิดข้อผิดพลาดในการบันทึกข้อมูล โปรดลองใหม่");
        }
        break;
      }

      case Intent.WIZARD_BACK:
      case Intent.WIZARD_SKIP:
      case Intent.WIZARD_CANCEL:
        // Wizard navigation buttons (handled explicitly to ensure they work)
        {
          try {
            const { getWizardState, goBackWizardStep, skipWizardStep, setWizardState, completeWizard } = await import("../services/wizardService");
            const { getWizardQuestion } = await import("../services/wizardService");
            const { getBusinessSetupCompleteMessage, getBusinessSetupCancelMessage } = await import("../services/uxCopy");
            
            const wizardState = await getWizardState(userId);
            if (!wizardState || !wizardState.step || wizardState.step === 'COMPLETE') {
              // Not in wizard - show gentle guidance
              await replyFn("ขอบคุณนะคะ 😊\n\nถ้ายังไม่สะดวกพิมพ์ สามารถกด ข้าม หรือ ยกเลิก ได้เลยค่ะ");
              break;
            }

            if (intent === Intent.WIZARD_BACK) {
              const prevStep = await goBackWizardStep(userId, wizardState.step);
              if (prevStep && prevStep !== wizardState.step) {
                const question = getWizardQuestion(prevStep);
                const optionalSteps = ['TAX_ID', 'EMAIL'];
                const isOptional = optionalSteps.includes(prevStep);
                const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                const wizardButtons = getContextualQuickReply({
                  context: 'WIZARD',
                  wizardStep: prevStep,
                  isOptionalField: isOptional,
                });
                await replyFn(question, wizardButtons);
              } else {
                const optionalSteps = ['TAX_ID', 'EMAIL'];
                const isOptional = optionalSteps.includes(wizardState.step);
                const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                const wizardButtons = getContextualQuickReply({
                  context: 'WIZARD',
                  wizardStep: wizardState.step,
                  isOptionalField: isOptional,
                });
                await replyFn('⚠️ อยู่ขั้นตอนแรกแล้ว ไม่สามารถย้อนกลับได้', wizardButtons);
              }
            } else if (intent === Intent.WIZARD_SKIP) {
              const optionalSteps = ['TAX_ID', 'EMAIL'];
              const isOptional = optionalSteps.includes(wizardState.step);
              if (!isOptional) {
                const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                const wizardButtons = getContextualQuickReply({
                  context: 'WIZARD',
                  wizardStep: wizardState.step,
                  isOptionalField: false,
                });
                await replyFn('⚠️ ไม่สามารถข้ามขั้นตอนนี้ได้', wizardButtons);
                break;
              }
              const nextStep = await skipWizardStep(userId, wizardState.step);
              if (nextStep && nextStep !== wizardState.step) {
                if (nextStep === 'COMPLETE') {
                  await completeWizard(userId, params.businessId);
                  const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                  const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
                  await replyFn(getBusinessSetupCompleteMessage(), successButtons);
                } else {
                  const question = getWizardQuestion(nextStep);
                  const isOptional = optionalSteps.includes(nextStep);
                  const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                  const wizardButtons = getContextualQuickReply({
                    context: 'WIZARD',
                    wizardStep: nextStep,
                    isOptionalField: isOptional,
                  });
                  await replyFn(question, wizardButtons);
                }
              }
            } else if (intent === Intent.WIZARD_CANCEL) {
              await setWizardState(userId, { step: null, completed: [], data: {} });
              await replyFn(getBusinessSetupCancelMessage());
            }
          } catch (err) {
            console.error("[conversationHandler] Wizard navigation error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      case Intent.VIEW_LATEST_DOCUMENT:
        // View latest document
        {
          try {
            const db = admin.firestore();
            const docsSnapshot = await db
              .collection(`users/${userId}/businesses/${params.businessId}/documents`)
              .orderBy('created_at', 'desc')
              .limit(1)
              .get();

            if (docsSnapshot.empty) {
              await replyFn("ยังไม่มีเอกสารที่สร้างไว้\n\nลองสร้างเอกสารใหม่ได้เลยค่ะ");
              break;
            }

            const doc = docsSnapshot.docs[0];
            const data = doc.data();
            const docNo = data.doc_no || 'N/A';
            const docType = data.doc_type || 'DOCUMENT';
            const pdfPath = data.pdf_path || data.pdfPath;

            if (pdfPath) {
              const { buildPdfFlexMessageWithShortLink } = await import("../shared/pdfFlexMessage");
              const flexMessage = await buildPdfFlexMessageWithShortLink({
                docId: doc.id,
                docNo,
                docType,
                pdfPath: String(pdfPath),
                userId,
                businessId: params.businessId,
              });
              await replyWithFlex(flexMessage);
            } else {
              await replyFn(`เอกสารล่าสุด: ${docNo}\n\nPDF กำลังสร้าง กรุณารอสักครู่`);
            }
          } catch (err) {
            console.error("[conversationHandler] VIEW_LATEST_DOCUMENT error:", err);
            await replyFn("เกิดข้อผิดพลาดในการดึงข้อมูล โปรดลองใหม่");
          }
        }
        break;

      case Intent.REPORT:
        {
          try {
            const { handleReportRequest } = await import("../services/reportService");
            const { getReportButtons } = await import("../ui/quickReplies");

            const text = messageText || "";
            const reportText = await handleReportRequest(userId, params.businessId, text);

            await replyFn(reportText, getReportButtons());
          } catch (err) {
            console.error("[conversationHandler] REPORT error:", err);
            await replyFn("เกิดข้อผิดพลาด โปรดลองใหม่");
          }
        }
        break;

      default: // Intent.UNKNOWN, etc.
        // Check if wizard is in progress - handle wizard navigation
        {
          try {
            const { getWizardState, advanceWizardStep, skipWizardStep, goBackWizardStep, completeWizard, getWizardQuestion, getWizardQuickReply } = await import("../services/wizardService");
            const { getBusinessSetupCompleteMessage, getBusinessSetupCancelMessage, getWizardValidationError, getFieldSavedMessage } = await import("../services/uxCopy");
            
            const wizardState = await getWizardState(userId);
            
            if (wizardState && wizardState.step && wizardState.step !== 'COMPLETE') {
              // Wizard in progress - handle navigation commands
              const textLower = messageText.toLowerCase().trim();
              
              // Handle navigation commands
              if (textLower === 'ย้อนกลับ' || textLower === 'back') {
                const prevStep = await goBackWizardStep(userId, wizardState.step);
                if (prevStep && prevStep !== wizardState.step) {
                  const question = getWizardQuestion(prevStep);
                  const quickReply = getWizardQuickReply(prevStep); // HARDENING v2: Now sync function
                  await replyFn(question, quickReply);
                } else {
                  await replyFn('⚠️ อยู่ขั้นตอนแรกแล้ว ไม่สามารถย้อนกลับได้', getWizardQuickReply(wizardState.step)); // HARDENING v2: Now sync function
                }
                return;
              }
              
              if (textLower === 'ข้าม' || textLower === 'skip') {
                const nextStep = await skipWizardStep(userId, wizardState.step);
                if (nextStep && nextStep !== wizardState.step) {
                  if (nextStep === 'COMPLETE') {
                    await completeWizard(userId, params.businessId);
                    
                    // Check and celebrate milestone (first-time only)
                    const { checkAndCelebrateMilestone } = await import("../services/milestoneService");
                    const { getLineLink } = await import("../core/lineLinkService");
                    const lineLink = await getLineLink(params.lineUserId || '');
                    if (lineLink && lineUserId) {
                      const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
                      const celebrated = await checkAndCelebrateMilestone(
                        userId,
                        lineUserId,
                        'businessSetup',
                        accessToken
                      );
                      if (celebrated) {
                        // Milestone message already sent, skip regular message
                        return;
                      }
                    }
                    
                    // Business setup completed - show SUCCESS context buttons
                    const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                    const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
                    await replyFn(getBusinessSetupCompleteMessage(), successButtons);
                  } else {
                    const question = getWizardQuestion(nextStep);
                    const quickReply = getWizardQuickReply(nextStep); // HARDENING v2: Now sync function
                    await replyFn(question, quickReply);
                  }
                } else {
                  const optionalSteps = ['TAX_ID', 'EMAIL'];
                  const isOptional = optionalSteps.includes(wizardState.step);
                  const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                  const wizardButtons = getContextualQuickReply({
                    context: 'WIZARD',
                    wizardStep: wizardState.step,
                    isOptionalField: isOptional,
                  });
                  await replyFn('⚠️ ไม่สามารถข้ามขั้นตอนนี้ได้', wizardButtons);
                }
                return;
              }
              
              if (textLower === 'ยกเลิก' || textLower === 'cancel') {
                const { setWizardState } = await import("../services/wizardService");
                await setWizardState(userId, { step: null, completed: [], data: {} });
                // Wizard cancelled - show GLOBAL context buttons (default)
                await replyFn(getBusinessSetupCancelMessage());
                return;
              }
              
              // Process step input
              if (messageText.trim().length > 0) {
                // Validate input (light validation)
                let isValid = true;
                let errorReason = '';
                
                if (wizardState.step === 'PHONE') {
                  // Basic phone validation (Thai format)
                  const phoneRegex = /^[0-9\-\s\(\)]{8,15}$/;
                  if (!phoneRegex.test(messageText.trim())) {
                    isValid = false;
                    errorReason = 'รูปแบบเบอร์โทรไม่ถูกต้อง (ตัวอย่าง: 0812345678)';
                  }
                } else if (wizardState.step === 'EMAIL') {
                  // Basic email validation
                  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                  if (!emailRegex.test(messageText.trim())) {
                    isValid = false;
                    errorReason = 'รูปแบบอีเมลไม่ถูกต้อง (ตัวอย่าง: example@email.com)';
                  }
                }
                
                if (!isValid) {
                  const optionalSteps = ['TAX_ID', 'EMAIL'];
                  const isOptional = optionalSteps.includes(wizardState.step);
                  const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                  const wizardButtons = getContextualQuickReply({
                    context: 'WIZARD',
                    wizardStep: wizardState.step,
                    isOptionalField: isOptional,
                  });
                  await replyFn(getWizardValidationError(wizardState.step, errorReason), wizardButtons);
                  return;
                }
                
                // Advance to next step
                const nextStep = await advanceWizardStep(userId, wizardState.step, messageText.trim());
                
                if (nextStep === 'COMPLETE') {
                  await completeWizard(userId, params.businessId);
                  // Business setup completed - show SUCCESS context buttons
                const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                const successButtons = getContextualQuickReply({ context: 'SUCCESS' });
                await replyFn(getBusinessSetupCompleteMessage(), successButtons);
                } else if (nextStep) {
                  // Show saved confirmation and next question
                  const fieldMap: Record<string, string> = {
                    'BUSINESS_NAME': 'business_name',
                    'ADDRESS': 'address',
                    'TAX_ID': 'tax_id',
                    'PHONE': 'phone',
                    'EMAIL': 'email',
                  };
                  const fieldName = fieldMap[wizardState.step] || '';
                  const savedMsg = getFieldSavedMessage(fieldName);
                  const nextQuestion = getWizardQuestion(nextStep);
                  const optionalSteps = ['TAX_ID', 'EMAIL'];
                  const isOptional = optionalSteps.includes(nextStep);
                  const { getContextualQuickReply } = await import("../shared/contextualQuickReply");
                  const wizardButtons = getContextualQuickReply({
                    context: 'WIZARD',
                    wizardStep: nextStep,
                    isOptionalField: isOptional,
                  });
                  await replyFn(`${savedMsg}\n\n${nextQuestion}`, wizardButtons);
                }
                return;
              }
            }
            
            // ✅ STATE-AWARE FALLBACK: Check all active states before generic fallback
            // Priority: Payment > Business Setup > Button State > Generic
            
            // 1. Check payment state (already handled above in UNKNOWN intent)
            
            // 2. Check business setup state
            // ✅ CRITICAL: Allow payment intents to bypass business setup state
            const paymentIntents = [Intent.BUY_PACKAGE_99, Intent.BUY_PACKAGE_299, Intent.CREDIT_PURCHASE_HISTORY, Intent.CONFIRM_CREDIT_PAYMENT];
            const isPaymentIntent = paymentIntents.includes(intent);
            
            // Only check business setup state if NOT a payment intent
            if (!isPaymentIntent) {
              try {
                const { getBusinessSetupState } = await import("../services/businessSetupCopyPaste");
                const businessSetupState = await getBusinessSetupState(userId);
                
                if (businessSetupState === 'WAITING_FOR_DATA') {
                  // User sent something during business setup - parse it
                  const { parseBusinessData, validateBusinessData } = await import("../services/businessDataParser");
                  const { setBusinessSetupState, getBusinessSetupSummary } = await import("../services/businessSetupCopyPaste");
                  const { getBusinessSetupSummaryQuickReply } = await import("../shared/businessSetupQuickReply");
                  
                  const parsed = parseBusinessData(messageText);
                  const validation = validateBusinessData(parsed);
                  
                  // Convert ParsedBusinessData to Partial<BusinessData>
                  const businessData: Partial<{ name?: string; address?: string; phone?: string; taxId?: string; email?: string }> = {
                    name: parsed.name || undefined,
                    address: parsed.address || undefined,
                    phone: parsed.phone || undefined,
                    taxId: parsed.taxId || undefined,
                    email: parsed.email || undefined,
                  };
                  
                  await setBusinessSetupState(userId, 'SHOWING_SUMMARY', businessData);
                  
                  const summary = getBusinessSetupSummary(businessData);
                  const buttons = getBusinessSetupSummaryQuickReply();
                  
                  if (!validation.valid) {
                    await replyFn(
                      `${summary}\n\n💡 หมายเหตุ: ยังไม่มี${validation.missingFields.join(', ')} แต่สามารถบันทึกได้ก่อนนะคะ`,
                      buttons
                    );
                  } else {
                    await replyFn(summary, buttons);
                  }
                  return;
                } else if (businessSetupState === 'SHOWING_SUMMARY') {
                  // User sent something during summary - show summary again
                  const { getParsedBusinessData, getBusinessSetupSummary } = await import("../services/businessSetupCopyPaste");
                  const { getBusinessSetupSummaryQuickReply } = await import("../shared/businessSetupQuickReply");
                  
                  const parsed = await getParsedBusinessData(userId);
                  if (parsed) {
                    const summary = getBusinessSetupSummary(parsed);
                    const buttons = getBusinessSetupSummaryQuickReply();
                    await replyFn(`${summary}\n\nกรุณาเลือก "บันทึกข้อมูล" หรือ "แก้ไขอีกครั้ง" นะคะ`, buttons);
                  } else {
                    // Lost state - restart
                    const { getBusinessSetupTemplate, setBusinessSetupState } = await import("../services/businessSetupCopyPaste");
                    await setBusinessSetupState(userId, 'WAITING_FOR_DATA');
                    await replyFn(getBusinessSetupTemplate());
                  }
                return;
              }
              } catch (businessSetupError) {
                // Don't block on business setup check failure
                console.warn(`[conversationHandler] Business setup state check failed:`, businessSetupError);
              }
            }
            
            // 3. Check button state (already handled above in UNKNOWN intent)
            
            // 4. Generic fallback (only if no active state)
            const { getUnknownCommandMessage } = await import("../services/uxCopy");
            await replyFn(getUnknownCommandMessage());
          } catch (err) {
            console.error("[conversationHandler] Wizard/Unknown error:", err);
            const { getUnknownCommandMessage } = await import("../services/uxCopy");
            // Unknown command - use GLOBAL context (auto-detect)
            await replyFn(getUnknownCommandMessage());
          }
        }
        break;
    }
  } catch (error) {
    console.error("[CONVERSATION_HANDLER_ERROR] ❌ Fatal error:", error);
    // Fatal error - use contextual buttons (auto-detect: GLOBAL)
    try {
      await replyFn(
        "🔧 ระบบขัดข้องชั่วคราว\n\n" +
        "กรุณาลองใหม่อีกครั้ง หรือติดต่อฝ่ายสนับสนุน"
      );
    } catch (replyErr) {
      console.error("[CONVERSATION_HANDLER_ERROR] ❌ Failed to send error message:", replyErr);
      // Last resort: try to send via LINE API directly (with deadline if possible)
      if (lineUserId) {
        try {
          const { getReplyWithDeadline } = await import("../utils/cachedHotPathImports");
          const { replyWithDeadline } = await getReplyWithDeadline();
          
          const replyState = await replyWithDeadline({
            replyToken,
            lineUserId,
            traceId: traceId || 'n/a',
            stage: 'ERROR_HANDLER_FALLBACK',
            message: "เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง",
            replyFn: async (params) => {
              await lineClient.replyMessage(params);
            },
          });
          
          if (replyState.didReplySuccess) {
            didReplySuccess = true;
            didAttemptReply = true;
          }
        } catch (finalErr) {
          const { getSecureConsole } = await import("../utils/cachedHotPathImports");
          const { secureError } = await getSecureConsole();
          secureError({
            tag: "[CONVERSATION_HANDLER_ERROR]",
            trace_id: traceId,
            user_id: userId,
            line_user_id: lineUserId,
            timestamp: new Date().toISOString(),
          }, finalErr);
        }
      } else {
        // No lineUserId - direct reply (shouldn't happen in normal flow)
        try {
          await lineClient.replyMessage({
            replyToken,
            messages: [{
              type: "text",
              text: "เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง",
            }],
          });
          didReplySuccess = true;
          didAttemptReply = true;
        } catch (finalErr) {
          const { getSecureConsole } = await import("../utils/cachedHotPathImports");
          const { secureError } = await getSecureConsole();
          secureError({
            tag: "[CONVERSATION_HANDLER_ERROR]",
            trace_id: traceId,
            user_id: userId,
            timestamp: new Date().toISOString(),
          }, finalErr);
        }
      }
    }
  }
  
  // ✅ FIX 2: Final safety net: Ensure reply sent before function returns
  if (!didReplySuccess) {
    const { getGlobalFallbackMessage } = await import("../services/paymentUXCopy");
    await replyFn(getGlobalFallbackMessage());
  }
  
  // ✅ Latency tracking: Log handler total latency
  const durationMs = Date.now() - t0;
  console.log(JSON.stringify({
    tag: "[HANDLER_LATENCY]",
    trace_id: traceId,
    user_id: userId,
    line_user_id: lineUserId,
    duration_ms: durationMs,
    did_reply_success: didReplySuccess,
    did_attempt_reply: didAttemptReply,
    timestamp: new Date().toISOString(),
  }));
}




