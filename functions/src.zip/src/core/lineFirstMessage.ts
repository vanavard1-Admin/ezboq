// functions/src/core/lineFirstMessage.ts
// EzDoc - Phase 5B-0: First-message handler + fallback (PRODUCTION READY)
// Phase 5B-0.1: Quick reply integration

import * as admin from "firebase-admin";
import {
  type QuickReplyAction,
} from "../shared/lineQuickReply";
import { getPlanAwareMainMenu } from "../services/planAwareUI";

export type LineMessageEvent = {
  type: "message";
  message: { type: "text"; text: string };
  replyToken: string;
  source: { userId?: string };
};

export type FirstMessageDecision =
  | {
      kind: "WELCOME";
      action: "REPLIED";
      messages: string[];
      quickReply?: QuickReplyAction[];
    }
  | {
      kind: "FALLBACK";
      action: "REPLIED";
      messages: string[];
      quickReply?: QuickReplyAction[];
    }
  | {
      kind: "GREETING";
      action: "REPLIED";
      messages: string[];
      quickReply?: QuickReplyAction[];
    }
  | { kind: "PASS"; action: "FORWARD" };

type Options = {
  welcomeCooldownHours?: number; // default 24
};

type LineClient = {
  replyMessage(params: {
    replyToken: string;
    messages: Array<{
      type: string;
      text: string;
      quickReply?: {
        items: QuickReplyAction[];
      };
    }>;
  }): Promise<void>;
};

const DEFAULT_WELCOME_COOLDOWN_HOURS = 24;

function hoursToMs(h: number) {
  return h * 60 * 60 * 1000;
}

function nowMs() {
  return Date.now();
}

function normalizeText(s: string) {
  return (s || "").trim();
}

/**
 * Detect greeting (returns true if matched, doesn't consume intent slot)
 */
function detectGreeting(text: string): boolean {
  const normalized = text.toLowerCase().trim();
  return (
    normalized.includes("สวัสดี") ||
    normalized.includes("หวัดดี") ||
    normalized.includes("ดีครับ") ||
    normalized.includes("ดีค่ะ") ||
    normalized === "hi" ||
    normalized === "hello" ||
    normalized === "hey"
  );
}

/**
 * Local intent detection - matches common Thai keywords
 */
function detectLocalIntent(text: string): string | null {
  const normalized = text.toLowerCase().trim();
  
  // Quotation / Proposal
  if (
    normalized.includes("เสนอราคา") ||
    normalized.includes("quo") ||
    normalized.includes("quotation")
  ) {
    return "CREATE_QUOTATION";
  }
  
  // Invoice
  if (
    normalized.includes("วางบิล") ||
    normalized.includes("invoice") ||
    normalized.includes("inv")
  ) {
    return "CREATE_INVOICE";
  }
  
  // Payment notification
  if (
    normalized.includes("ชำระแล้ว") ||
    normalized.includes("จ่ายแล้ว") ||
    normalized.includes("โอนแล้ว")
  ) {
    return "PAYMENT_NOTIFICATION";
  }
  
  // Payment confirmation
  if (normalized.includes("ยืนยันรับเงิน")) {
    return "CONFIRM_PAYMENT";
  }
  
  // Report
  if (
    normalized.includes("รายงาน") ||
    normalized.includes("ยอดขาย") ||
    normalized.includes("ยอดค้าง") ||
    normalized.includes("report")
  ) {
    return "GET_REPORT";
  }
  
  return null;
}


async function buildWelcomeMessages(userId: string): Promise<{
  messages: string[];
  quickReply: QuickReplyAction[];
}> {
  // Use new UX copy for welcome message
  const { getWelcomeMessage } = require("../services/uxCopy");
  // Use plan-aware main menu
  const quickReply = await getPlanAwareMainMenu(userId);
  return {
    messages: [getWelcomeMessage()],
    quickReply,
  };
}

async function buildFallbackMessages(
  userId: string,
  hasActiveDraft: boolean
): Promise<{
  messages: string[];
  quickReply: QuickReplyAction[];
}> {
  const { getFallbackMessage } = require("../services/uxCopy");
  const message = getFallbackMessage(hasActiveDraft);
  // Use plan-aware main menu
  const quickReply = await getPlanAwareMainMenu(userId);

  return {
    messages: [message],
    quickReply,
  };
}

/**
 * Decide whether to welcome, fallback, or pass to main handler.
 *
 * @param db Firestore instance
 * @param userId Firebase UID
 * @param text Message text
 * @param intent Intent from orchestrator ("NONE" if not recognized)
 * @param hasActiveDraft Whether user has active draft
 * @param options Optional settings (welcomeCooldownHours)
 */
export async function decideFirstMessageOrFallback(params: {
  db: admin.firestore.Firestore;
  userId: string;
  text: string;
  intent: string | undefined;
  hasActiveDraft: boolean;
  options?: Options;
}): Promise<FirstMessageDecision> {
  const { db, userId, text, intent, hasActiveDraft } = params;
  const welcomeCooldownHours =
    params.options?.welcomeCooldownHours ??
    DEFAULT_WELCOME_COOLDOWN_HOURS;

  // A) Log input
  console.log(`[lineFirstMessage] text="${text}", intent="${intent}"`);

  const msg = normalizeText(text);
  if (!msg) {
    // empty message -> fallback
    const fallback = await buildFallbackMessages(userId, hasActiveDraft);
    return {
      kind: "FALLBACK",
      action: "REPLIED",
      messages: fallback.messages,
      quickReply: fallback.quickReply,
    };
  }

  // Check greeting first (don't forward, just reply with short greeting)
  if (detectGreeting(msg)) {
    console.log(`[lineFirstMessage] decision=GREETING`);
    return {
      kind: "GREETING",
      action: "REPLIED",
      messages: [
        "สวัสดีครับ ผมช่วยทำเอกสารได้เลย ต้องการทำใบเสนอราคา/ใบวางบิล/ใบเสร็จ หรือดูรายงานครับ?"
      ],
    };
  }

  // 1) If intent is recognized by orchestrator -> PASS (normal flow)
  if (intent && intent !== "NONE" && intent !== "") {
    console.log(`[lineFirstMessage] decision=FORWARD, intent=${intent}`);
    return { kind: "PASS", action: "FORWARD" };
  }

  // Try local intent detection
  const localIntent = detectLocalIntent(msg);
  if (localIntent) {
    console.log(`[lineFirstMessage] decision=FORWARD, localIntent=${localIntent}`);
    return { kind: "PASS", action: "FORWARD" };
  }

  // 2) Determine if user is "new" or "never greeted"
  const userRef = db.collection("users").doc(userId);
  const snap = await userRef.get();

  const userExists = snap.exists;
  const onboarding = snap.exists ? (snap.get("onboarding") as unknown) : undefined;
  const firstMessagedAt = onboarding && typeof onboarding === 'object' && 'firstMessagedAt' in onboarding
    ? ((onboarding as { firstMessagedAt?: { toDate?: () => Date } }).firstMessagedAt?.toDate?.()?.getTime?.() || undefined)
    : undefined;

  // If no user doc => treat as new (WELCOME)
  // If user exists but never greeted => WELCOME
  const isNewOrNeverGreeted = !userExists || !firstMessagedAt;

  if (isNewOrNeverGreeted) {
    // write firstMessagedAt (merge)
    await userRef.set(
      {
        onboarding: {
          firstMessagedAt: new Date(),
          lastHelpAt: new Date(),
        },
        updatedAt: new Date(),
      },
      { merge: true }
    );

    console.log(`[lineFirstMessage] Decision: WELCOME (reason: new or never greeted)`);
    const welcome = await buildWelcomeMessages(userId);
    return {
      kind: "WELCOME",
      action: "REPLIED",
      messages: welcome.messages,
      quickReply: welcome.quickReply,
    };
  }

  // 3) If greeted recently, do fallback instead of spamming welcome
  const cooldownMs = hoursToMs(welcomeCooldownHours);
  const inCooldown =
    firstMessagedAt && nowMs() - firstMessagedAt < cooldownMs;

  if (inCooldown) {
    await userRef.set(
      {
        onboarding: { lastHelpAt: new Date() },
        updatedAt: new Date(),
      },
      { merge: true }
    );
    const fallback = await buildFallbackMessages(userId, hasActiveDraft);
    return {
      kind: "FALLBACK",
      action: "REPLIED",
      messages: fallback.messages,
      quickReply: fallback.quickReply,
    };
  }

  // 4) Past cooldown -> fallback to reduce annoyance
  await userRef.set(
    {
      onboarding: { lastHelpAt: new Date() },
      updatedAt: new Date(),
    },
    { merge: true }
  );
  const fallback = await buildFallbackMessages(userId, hasActiveDraft);
  return {
    kind: "FALLBACK",
    action: "REPLIED",
    messages: fallback.messages,
    quickReply: fallback.quickReply,
  };
}

/**
 * Send multiple LINE reply messages with optional quick reply.
 *
 * @param lineClient LINE bot client
 * @param replyToken Token for replying
 * @param texts Message texts (max 5)
 * @param quickReplyActions Optional quick reply buttons (added to last message)
 */
export async function replyTexts(params: {
  lineClient: LineClient;
  replyToken: string;
  texts: string[];
  quickReplyActions?: QuickReplyAction[];
}): Promise<void> {
  const { lineClient, replyToken, texts, quickReplyActions } = params;

  // Build message objects with proper typing
  const messages: Array<{
    type: string;
    text: string;
    quickReply?: {
      items: QuickReplyAction[];
    };
  }> = texts.slice(0, 5).map((t) => ({
    type: "text",
    text: t,
  }));

  // Add quick reply to the last message if provided
  if (
    quickReplyActions &&
    quickReplyActions.length > 0 &&
    messages.length > 0
  ) {
    const lastMsg = messages[messages.length - 1];
    lastMsg.quickReply = {
      items: quickReplyActions.slice(0, 13),
    };
  }

  await lineClient.replyMessage({
    replyToken,
    messages,
  });
}
