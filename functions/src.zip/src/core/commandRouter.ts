/**
 * Command Router - Single Source of Truth for Message Routing
 * 
 * CRITICAL: Routes messages BEFORE any handler processing
 * Precedence (MUST NOT change order):
 * SETTINGS > CREATE_DOC > EDIT_DRAFT > HELP > FALLBACK
 * 
 * Purpose: Ensure correct routing so UX flows work as expected
 */

import * as admin from 'firebase-admin';

export enum RouteType {
  ROUTE_SETTINGS = 'ROUTE_SETTINGS',
  ROUTE_CREATE_DOC = 'ROUTE_CREATE_DOC',
  ROUTE_EDIT_DRAFT = 'ROUTE_EDIT_DRAFT',
  ROUTE_TRUST_COMMAND = 'ROUTE_TRUST_COMMAND',
  ROUTE_MENU = 'ROUTE_MENU',
  ROUTE_HELP = 'ROUTE_HELP',
  ROUTE_FALLBACK = 'ROUTE_FALLBACK',
}

export interface RouteResult {
  route: RouteType;
  docType?: 'QUO' | 'BILL' | 'INVOICE' | 'RECEIPT';
  trustCommand?: 'LATEST_DOC' | 'RESEND_PDF' | 'CREDIT_BALANCE' | 'CHECK_SLIP';
  normalizedText: string;
}

/**
 * Normalize text (Thai spacing, trim, lowercase for matching)
 * ✅ FIX: Preserve exact match for docType patterns (don't normalize too aggressively)
 */
function normalizeText(text: string): string {
  if (!text) return '';
  
  // Trim only
  let normalized = text.trim();
  
  // Insert space between Thai/English letters and digits (for "ลูกค้าแมวน้อย" → "ลูกค้า แมวน้อย")
  normalized = normalized.replace(/([\u0E00-\u0E7FA-Za-z])(\d)/g, '$1 $2');
  normalized = normalized.replace(/(\d)([\u0E00-\u0E7FA-Za-z])/g, '$1 $2');
  
  // Collapse multiple spaces
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  return normalized.toLowerCase();
}

/**
 * Route incoming text to appropriate handler
 * 
 * Precedence (checked in order):
 * 1. SETTINGS - ตั้งค่า... (theme, bank, tax, address, company, VAT, WHT, logo, signature, stamp)
 * 2. CREATE_DOC - ใบเสนอราคา/ทำใบเสนอราคา/ใบวางบิล/ทำใบวางบิล/ใบแจ้งหนี้/ใบเสร็จ
 * 3. EDIT_DRAFT - Has draft or looks like item/customer/confirm/cancel
 * 4. HELP - วิธีใช้งาน/ช่วยเหลือ
 * 5. FALLBACK - Everything else
 */
export function routeIncomingText(params: {
  text: string;
  hasActiveDraft?: boolean;
  db: admin.firestore.Firestore;
}): RouteResult {
  const { text, hasActiveDraft = false } = params;
  
  const normalized = normalizeText(text);
  
  // ========================================================================
  // 1. ROUTE_SETTINGS (HIGHEST PRIORITY)
  // ========================================================================
  // Settings keywords: ตั้งค่า... (theme, bank, tax, address, company, VAT, WHT, logo, signature, stamp)
  const settingsPatterns = [
    /^ตั้งค่าธีม/i,
    /^ตั้งค่าธนาคาร/i,
    /^ตั้งค่าเลขผู้เสียภาษี/i,
    /^ตั้งค่าที่อยู่/i,
    /^ตั้งค่าชื่อบริษัท/i,
    /^ตั้งค่าvat/i,
    /^ตั้งค่าwht/i,
    /^ตั้งค่าโลโก้/i,
    /^ตั้งค่าลายเซ็น/i,
    /^ตั้งค่าตราประทับ/i,
    /^ตั้งค่าพร้อมเพย์/i,
    /^ตั้งค่าธุรกิจ/i,
    /^ตั้งค่า/i, // Generic "ตั้งค่า" (must be last in settings patterns)
  ];
  
  for (const pattern of settingsPatterns) {
    if (pattern.test(normalized)) {
      return {
        route: RouteType.ROUTE_SETTINGS,
        normalizedText: normalized,
      };
    }
  }
  
  // ========================================================================
  // 2. ROUTE_CREATE_DOC
  // ========================================================================
  // Document creation keywords (must match before EDIT_DRAFT)
  // ✅ FIX: Explicit mapping (BILL vs INVOICE) - order matters (specific first)
  const createDocPatterns = [
    // Quotation (specific patterns first)
    { pattern: /^ทำใบเสนอราคา$/i, docType: 'QUO' as const },
    { pattern: /^ใบเสนอราคา$/i, docType: 'QUO' as const },
    { pattern: /^quotation$/i, docType: 'QUO' as const },
    { pattern: /^quo$/i, docType: 'QUO' as const },
    // Invoice/Bill - ใบวางบิล = BILL, ใบแจ้งหนี้ = INVOICE
    { pattern: /^ทำใบวางบิล$/i, docType: 'BILL' as const },
    { pattern: /^ใบวางบิล$/i, docType: 'BILL' as const },
    { pattern: /^ทำใบแจ้งหนี้$/i, docType: 'INVOICE' as const },
    { pattern: /^ใบแจ้งหนี้$/i, docType: 'INVOICE' as const },
    { pattern: /^invoice$/i, docType: 'INVOICE' as const },
    { pattern: /^inv$/i, docType: 'INVOICE' as const },
    // Receipt (specific patterns first)
    { pattern: /^ทำใบเสร็จ$/i, docType: 'RECEIPT' as const },
    { pattern: /^ใบเสร็จรับเงิน$/i, docType: 'RECEIPT' as const },
    { pattern: /^ใบเสร็จ$/i, docType: 'RECEIPT' as const },
    { pattern: /^receipt$/i, docType: 'RECEIPT' as const },
    { pattern: /^rec$/i, docType: 'RECEIPT' as const },
  ];
  
  for (const { pattern, docType } of createDocPatterns) {
    if (pattern.test(normalized)) {
      return {
        route: RouteType.ROUTE_CREATE_DOC,
        docType,
        normalizedText: normalized,
      };
    }
  }
  
  // ========================================================================
  // 3. ROUTE_EDIT_DRAFT
  // ========================================================================
  // Only route to EDIT_DRAFT if:
  // - Has active draft, OR
  // - Looks like edit command (confirm, cancel, item edit patterns)
  if (hasActiveDraft) {
    return {
      route: RouteType.ROUTE_EDIT_DRAFT,
      normalizedText: normalized,
    };
  }
  
  // Edit-like patterns (even without draft, route to EDIT_DRAFT handler which will handle "no draft" case)
  const editPatterns = [
    /^ยืนยัน|^ออกเอกสาร/i,
    /^ยกเลิก|^เริ่มใหม่|^ลบ/i,
    /^แก้ไข/i,
    /^เพิ่มรายการ/i,
    /^ลูกค้า/i, // "ลูกค้า..." is edit command
  ];
  
  for (const pattern of editPatterns) {
    if (pattern.test(normalized)) {
      return {
        route: RouteType.ROUTE_EDIT_DRAFT,
        normalizedText: normalized,
      };
    }
  }
  
  // ========================================================================
  // 4. ROUTE_TRUST_COMMANDS (PHASE 1 - SEV-0)
  // ========================================================================
  // Trust commands to prevent user panic
  const trustPatterns = [
    { pattern: /^เอกสารล่าสุด$/i, command: 'LATEST_DOC' as const },
    { pattern: /^ส่ง PDF อีกครั้ง$/i, command: 'RESEND_PDF' as const },
    { pattern: /^เครดิตคงเหลือ$/i, command: 'CREDIT_BALANCE' as const },
    { pattern: /^เช็คสลิป$/i, command: 'CHECK_SLIP' as const },
  ];
  
  for (const { pattern, command } of trustPatterns) {
    if (pattern.test(normalized)) {
      return {
        route: RouteType.ROUTE_TRUST_COMMAND,
        normalizedText: normalized,
        trustCommand: command,
      };
    }
  }
  
  // ========================================================================
  // 5. ROUTE_MENU (PHASE 3: Main menu command)
  // ========================================================================
  if (/^เมนู$/i.test(normalized)) {
    return {
      route: RouteType.ROUTE_MENU,
      normalizedText: normalized,
    };
  }
  
  // ========================================================================
  // 6. ROUTE_HELP
  // ========================================================================
  const helpPatterns = [
    /^วิธีใช้งาน/i,
    /^ช่วยเหลือ|^ช่วย/i,
    /^help/i,
  ];
  
  for (const pattern of helpPatterns) {
    if (pattern.test(normalized)) {
      return {
        route: RouteType.ROUTE_HELP,
        normalizedText: normalized,
      };
    }
  }
  
  // ========================================================================
  // 7. ROUTE_FALLBACK (DEFAULT)
  // ========================================================================
  return {
    route: RouteType.ROUTE_FALLBACK,
    normalizedText: normalized,
  };
}

