import * as admin from 'firebase-admin';

/**
 * LINE ↔ Firebase UID mapping service
 * Maintains bidirectional mapping: lineUserId ↔ uid
 * Also stores default businessId for convenience
 */

export interface LineUserMapping {
  lineUserId: string;
  firebaseUid: string; // Link to users/{uid}
  defaultBusinessId: string; // Default business for this user
  lineDisplayName?: string;
  linkedAt: admin.firestore.Timestamp;
  lastActiveAt: admin.firestore.Timestamp;
}

const db = () => admin.firestore();
const LINE_USERS_COLLECTION = 'lineUsers';
const USERS_COLLECTION = 'users';

/**
 * Link or update LINE user mapping
 * Creates/updates both directions:
 * - lineUsers/{lineUserId} → {firebaseUid, defaultBusinessId, ...}
 * - users/{firebaseUid} → {lineUserId}
 */
export async function linkLineUser(
  lineUserId: string,
  firebaseUid: string,
  defaultBusinessId: string,
  lineDisplayName?: string
): Promise<LineUserMapping> {
  const db_instance = db();
  
  const mapping: LineUserMapping = {
    lineUserId,
    firebaseUid,
    defaultBusinessId,
    lineDisplayName,
    linkedAt: admin.firestore.Timestamp.now(),
    lastActiveAt: admin.firestore.Timestamp.now(),
  };

  // Atomic: update both directions in transaction
  await db_instance.runTransaction(async (transaction) => {
    // 1. Update lineUsers/{lineUserId} → firebaseUid
    const lineUserRef = db_instance.collection(LINE_USERS_COLLECTION).doc(lineUserId);
    transaction.set(lineUserRef, mapping, { merge: true });

    // 2. Update users/{firebaseUid} → lineUserId
    const userRef = db_instance.collection(USERS_COLLECTION).doc(firebaseUid);
    transaction.update(userRef, {
      lineUserId,
      lineUserId_linkedAt: admin.firestore.Timestamp.now(),
    });
  });

  console.log(`[lineUserMapping] Linked ${lineUserId} ↔ ${firebaseUid}`);
  return mapping;
}

/**
 * Get Firebase UID from LINE user ID
 * Throws error if not linked
 */
export async function getFirebaseUidFromLineUserId(lineUserId: string): Promise<string> {
  const db_instance = db();
  const snap = await db_instance.collection(LINE_USERS_COLLECTION).doc(lineUserId).get();

  if (!snap.exists) {
    throw new Error(
      `[lineUserMapping] No Firebase UID found for LINE user ${lineUserId}. ` +
      `User must be linked first (via LINE login with OAuth).`
    );
  }

  const mapping = snap.data() as LineUserMapping;
  
  // Update lastActiveAt
  await snap.ref.update({
    lastActiveAt: admin.firestore.Timestamp.now(),
  });

  return mapping.firebaseUid;
}

/**
 * Get LINE user ID from Firebase UID
 * Returns null if not linked
 */
export async function getLineUserIdFromFirebaseUid(firebaseUid: string): Promise<string | null> {
  const db_instance = db();
  const snap = await db_instance.collection(USERS_COLLECTION).doc(firebaseUid).get();

  if (!snap.exists) {
    return null;
  }

  const userData = snap.data() as { lineUserId?: string };
  return userData?.lineUserId || null;
}

/**
 * Get LINE user mapping (full record)
 * Throws error if not found
 */
export async function getLineUserMapping(lineUserId: string): Promise<LineUserMapping> {
  const db_instance = db();
  const snap = await db_instance.collection(LINE_USERS_COLLECTION).doc(lineUserId).get();

  if (!snap.exists) {
    throw new Error(`[lineUserMapping] No mapping found for LINE user ${lineUserId}`);
  }

  return snap.data() as LineUserMapping;
}

/**
 * Get default business ID for LINE user
 * Returns businessId or throws error if not linked
 */
export async function getDefaultBusinessId(lineUserId: string): Promise<string> {
  const mapping = await getLineUserMapping(lineUserId);
  return mapping.defaultBusinessId;
}

/**
 * Update default business ID for LINE user
 */
export async function setDefaultBusinessId(lineUserId: string, businessId: string): Promise<void> {
  const db_instance = db();
  await db_instance
    .collection(LINE_USERS_COLLECTION)
    .doc(lineUserId)
    .update({ defaultBusinessId: businessId, lastActiveAt: admin.firestore.Timestamp.now() });
  
  console.log(`[lineUserMapping] Updated default business for ${lineUserId}: ${businessId}`);
}

/**
 * Unlink LINE user (cleanup)
 */
export async function unlinkLineUser(lineUserId: string): Promise<void> {
  const db_instance = db();
  const mapping = await getLineUserMapping(lineUserId);

  await db_instance.runTransaction(async (transaction) => {
    // 1. Delete lineUsers/{lineUserId}
    transaction.delete(db_instance.collection(LINE_USERS_COLLECTION).doc(lineUserId));

    // 2. Remove lineUserId from users/{uid}
    transaction.update(
      db_instance.collection(USERS_COLLECTION).doc(mapping.firebaseUid),
      { lineUserId: admin.firestore.FieldValue.delete() }
    );
  });

  console.log(`[lineUserMapping] Unlinked ${lineUserId}`);
}
