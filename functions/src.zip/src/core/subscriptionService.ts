/**
 * Subscription Service
 * Manages user subscriptions and credit checks
 * 
 * NOTE: Plan normalization handled by planService.ts
 * This service maintains backward compatibility with old plan IDs
 */

import * as admin from "firebase-admin";
import type { PlanId } from "../lib/promptpay";
import type { Plan } from "./planService";

const db = admin.firestore();

export interface Subscription {
  uid: string;
  plan: "FREE" | PlanId | Plan; // Supports old and new plan formats
  creditsRemaining: number; // For cost-based features (OCR, AI) only
  periodStart: admin.firestore.Timestamp;
  periodEnd: admin.firestore.Timestamp;
  createdAt: admin.firestore.Timestamp;
  updatedAt: admin.firestore.Timestamp;
}

/**
 * Get user subscription (or create FREE tier)
 */
export async function getOrCreateSubscription(uid: string): Promise<Subscription> {
  const subRef = db.collection("subscriptions").doc(uid);
  const subSnap = await subRef.get();

  if (subSnap.exists) {
    return subSnap.data() as Subscription;
  }

  // Create FREE tier subscription
  const now = admin.firestore.Timestamp.now();
  const periodEnd = new Date(now.toDate());
  periodEnd.setMonth(periodEnd.getMonth() + 1);

  const subscription: Subscription = {
    uid,
    plan: "FREE",
    creditsRemaining: 10, // Free tier: 10 documents/month
    periodStart: now,
    periodEnd: admin.firestore.Timestamp.fromDate(periodEnd),
    createdAt: now,
    updatedAt: now,
  };

  await subRef.set(subscription);
  console.log(`[SUBSCRIPTION_FREE_CREATED] 🆓 uid=${uid}, credits=10`);

  // Create ledger entry for initial credits
  const { addCreditsWithLedger } = await import("../services/creditsLedger");
  await addCreditsWithLedger(
    uid,
    10,
    "Initial FREE tier credits",
    `initial_${uid}`,
    { source: "FREE_TIER_CREATION" }
  ).catch((err) => {
    console.error(`[SUBSCRIPTION] Failed to create ledger entry for initial credits:`, err);
    // Non-blocking - subscription is created
  });

  return subscription;
}

/**
 * Check if user has enough credits (throws if not)
 */
export async function requireCredits(uid: string, count = 1): Promise<void> {
  const subscription = await getOrCreateSubscription(uid);
  
  if (subscription.creditsRemaining < count) {
    const error = new Error(`Insufficient credits: required=${count}, available=${subscription.creditsRemaining}`);
    (error as NodeJS.ErrnoException).code = "INSUFFICIENT_CREDITS";
    throw error;
  }
}

/**
 * Check if user has enough credits
 */
export async function hasCredits(uid: string): Promise<boolean> {
  const subscription = await getOrCreateSubscription(uid);
  return subscription.creditsRemaining > 0;
}

/**
 * Deduct credits using Firestore transaction (called when document is issued)
 * 
 * @deprecated Use deductCreditsWithLedger from creditsLedger service instead
 * This function is kept for backward compatibility but will be removed in future versions
 */
export async function deductCredit(uid: string, count = 1, docId?: string): Promise<void> {
  // Use ledger service for audit trail
  const { deductCreditsWithLedger } = await import("../services/creditsLedger");
  await deductCreditsWithLedger(
    uid,
    count,
    `Document issued${docId ? ` (${docId})` : ''}`,
    docId, // Use docId as referenceId for idempotency
    { legacy: true }
  );
}

/**
 * Add credits to subscription (called after payment confirmation in Phase 5)
 * 
 * @deprecated Use addCreditsWithLedger from creditsLedger service instead
 * This function is kept for backward compatibility but will be removed in future versions
 */
export async function addCredits(uid: string, credits: number): Promise<void> {
  // Use ledger service for audit trail
  const { addCreditsWithLedger } = await import("../services/creditsLedger");
  await addCreditsWithLedger(
    uid,
    credits,
    "Legacy addCredits call (migration in progress)",
    undefined, // No referenceId for legacy calls
    { legacy: true }
  );
}

/**
 * Get upsell message when credits are low
 */
export function getUpsellMessage(creditsRemaining: number): string {
  if (creditsRemaining === 0) {
    return (
      "❌ เครดิตหมดแล้ว\n\n" +
      "💰 ซื้อแพ็คเพื่อใช้งานต่อ:\n" +
      "• แพ็ค 99฿ = 100 เครดิต\n" +
      "• แพ็ค 299฿ = 500 เครดิต\n\n" +
      "พิมพ์: ซื้อแพ็ค 99 หรือ ซื้อแพ็ค 299"
    );
  } else if (creditsRemaining <= 5) {
    return (
      `⚠️ เครดิตเหลือ ${creditsRemaining} เครดิต\n\n` +
      "พิมพ์: ซื้อแพ็ค 99 หรือ ซื้อแพ็ค 299"
    );
  }
  return "";
}
