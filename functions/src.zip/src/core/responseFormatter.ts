/**
 * Response Formatter
 * 
 * Formats bot responses according to UX template
 * Ensures consistent user experience across all states
 * 
 * REFACTORED: Suggested commands now convert to safe QuickReplyAction[]
 */

import type { ConversationalDraft } from './draftManager';
import { DocumentType } from './conversationOrchestrator';
import type { QuickReplyAction } from '../shared/lineQuickReply';
import { commandsToButtons } from '../ui/quickReplies';

// ============================================================================
// FORMATTING HELPERS
// ============================================================================

function formatMoney(amount: number): string {
  return amount.toLocaleString('th-TH', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}

function getDocTypeEmoji(docType: DocumentType): string {
  switch (docType) {
    case DocumentType.QUOTATION:
      return '📋';
    case DocumentType.INVOICE:
      return '📄';
    case DocumentType.RECEIPT:
      return '🧾';
    default:
      return '📝';
  }
}

function getDocTypeName(docType: DocumentType): string {
  switch (docType) {
    case DocumentType.QUOTATION:
      return 'ใบเสนอราคา';
    case DocumentType.INVOICE:
      return 'ใบวางบิล';
    case DocumentType.RECEIPT:
      return 'ใบเสร็จรับเงิน';
    default:
      return 'เอกสาร';
  }
}

// ============================================================================
// DRAFT SUMMARY (SHORT VERSION)
// ============================================================================

export function formatDraftSummary(draft: ConversationalDraft): string {
  const emoji = getDocTypeEmoji(draft.docType);
  const docName = getDocTypeName(draft.docType);
  
  let summary = `${emoji} ${docName}\n\n`;
  
  // Customer (short)
  if (draft.customerName) {
    summary += `ลูกค้า: ${draft.customerName}\n`;
  } else {
    summary += `ยังไม่ได้เลือกลูกค้า\n`;
  }
  
  // Items (compact)
  if (draft.items.length === 0) {
    summary += `ยังไม่มีรายการ\n`;
  } else {
    summary += `รายการ:\n`;
    draft.items.forEach((item, idx) => {
      const amount = formatMoney(item.amount);
      if (item.quantity > 1) {
        summary += `• ${item.description_th} (${item.quantity} x ${formatMoney(item.unit_price)}) = ${amount}฿\n`;
      } else {
        summary += `• ${item.description_th} ${amount}฿\n`;
      }
    });
  }
  
  // Totals (compact)
  summary += `\nรวม: ${formatMoney(draft.subTotal)}฿\n`;
  
  if (draft.discountAmount > 0) {
    const discountText = draft.discountType === 'PERCENT' 
      ? `${draft.discountValue}%` 
      : `${formatMoney(draft.discountAmount)}฿`;
    summary += `ส่วนลด: ${discountText}\n`;
  }
  
  if (draft.vatPercent > 0) {
    summary += `รวมสุทธิ: ${formatMoney(draft.totalAmount)}฿ (VAT ${draft.vatPercent}%)\n`;
  } else {
    summary += `รวมสุทธิ: ${formatMoney(draft.totalAmount)}฿\n`;
  }
  
  // Due date (for invoice)
  if (draft.docType === DocumentType.INVOICE) {
    if (draft.dueDate) {
      summary += `ครบกำหนด: ${draft.dueDate}\n`;
    }
  }
  
  // Payment info (for receipt)
  if (draft.docType === DocumentType.RECEIPT) {
    if (draft.paymentMethod) {
      summary += `ชำระ: ${draft.paymentMethod}\n`;
    }
  }
  
  return summary;
}

// ============================================================================
// NEXT COMMANDS (CONTEXTUAL)
// ============================================================================

export function formatNextCommands(draft: ConversationalDraft): string[] {
  const { CMD_ADD_ITEM, CMD_CONFIRM } = require('../shared/commands');
  const commands: string[] = [];
  
  // Check what's missing
  const missingCustomer = !draft.customerName;
  const missingItems = draft.items.length === 0;
  const missingDueDate = draft.docType === DocumentType.INVOICE && !draft.dueDate;
  const missingPayment = draft.docType === DocumentType.RECEIPT && !draft.paymentMethod;
  
  // Priority 1: Essential missing fields
  // NOTE: These are examples, not canonical commands (will show as text only)
  if (missingCustomer) {
    commands.push('ลูกค้า บริษัท ABC'); // Example, not canonical
    return commands; // Stop here, customer is most important
  }
  
  if (missingItems) {
    // Use canonical command for "เพิ่มรายการ" (will be converted to button)
    commands.push(CMD_ADD_ITEM);
    commands.push('เพิ่ม ค่าแรง 15000'); // Example with params (text only)
    return commands;
  }
  
  // Priority 2: Document-specific requirements
  // These are examples with params (will show as text only)
  if (missingDueDate) {
    commands.push('กำหนดครบกำหนด 31/12/2568'); // Example, not canonical
    return commands;
  }
  
  if (missingPayment) {
    commands.push('ชำระเงิน โอน'); // Example, not canonical
    return commands;
  }
  
  // Priority 3: Can confirm now, or add more
  // Use canonical commands (will be converted to buttons)
  commands.push(CMD_CONFIRM);
  commands.push(CMD_ADD_ITEM);
  
  // Examples with params (will show as text only)
  if (!draft.discountAmount && draft.subTotal > 0) {
    commands.push('ส่วนลด 10%'); // Example, not canonical
  }
  
  return commands.slice(0, 3); // Max 3 commands
}

// ============================================================================
// FULL CONFIRMATION SUMMARY
// ============================================================================

export function formatConfirmationSummary(draft: ConversationalDraft): string {
  let summary = `⚠️ โปรดตรวจสอบก่อนออกเอกสาร\n\n`;
  
  summary += `ลูกค้า: ${draft.customerName}\n`;
  summary += `รายการ: ${draft.items.length} รายการ\n`;
  summary += `รวมสุทธิ: ${formatMoney(draft.totalAmount)}฿\n`;
  
  if (draft.docType === DocumentType.INVOICE && draft.dueDate) {
    summary += `ครบกำหนด: ${draft.dueDate}\n`;
  }
  
  if (draft.docType === DocumentType.RECEIPT && draft.paymentMethod) {
    summary += `ชำระ: ${draft.paymentMethod}\n`;
  }
  
  summary += `\nพิมพ์:\n`;
  summary += `• ยืนยันอีกครั้ง → ออกเอกสาร\n`;
  summary += `• แก้ไข → พิมพ์รายการใหม่`;
  
  return summary;
}

// ============================================================================
// COMPLETE RESPONSE FORMATTER
// ============================================================================

export interface FormattedResponse {
  text: string;
  quickReplies?: string[]; // Deprecated: use quickReplyActions instead
  quickReplyActions?: QuickReplyAction[]; // NEW: Safe QuickReplyAction[]
}

/**
 * Format response with draft summary and suggested commands
 * 
 * REFACTORED: Suggested commands are converted to safe QuickReplyAction[]
 * Only canonical commands are converted (safe to click, won't break flow)
 */
export function formatResponse(
  message: string,
  draft?: ConversationalDraft,
  includeSummary: boolean = true,
  includeNextCommands: boolean = true
): FormattedResponse {
  let text = message;
  
  if (draft && includeSummary) {
    text += '\n\n' + formatDraftSummary(draft);
  }
  
  let quickReplies: string[] = [];
  let quickReplyActions: QuickReplyAction[] = [];
  
  if (draft && includeNextCommands) {
    const commands = formatNextCommands(draft);
    
    if (commands.length > 0) {
      text += '\n\nพิมพ์ต่อได้:\n';
      commands.forEach(cmd => {
        text += `• ${cmd}\n`;
      });
      
      // Convert commands to safe QuickReplyAction[]
      // Only canonical commands are converted (safe to click)
      quickReplyActions = commandsToButtons(commands);
      
      // Legacy: keep string array for backward compatibility
      quickReplies = commands.slice(0, 13);
    }
  }
  
  return {
    text,
    quickReplies: quickReplies.length > 0 ? quickReplies : undefined,
    quickReplyActions: quickReplyActions.length > 0 ? quickReplyActions : undefined,
  };
}

// ============================================================================
// ERROR MESSAGES
// ============================================================================

export function formatError(error: string): string {
  const errorMessages: Record<string, string> = {
    UNKNOWN_COMMAND: 'ขออภัย ไม่เข้าใจคำสั่ง\nพิมพ์ "ช่วยเหลือ" ดูคำสั่งทั้งหมด',
    VALIDATION_FAILED: 'ข้อมูลยังไม่ครบ',
    NO_DRAFT: 'กรุณาเริ่มสร้างเอกสารก่อน\nพิมพ์: เริ่ม ใบเสนอราคา',
    ITEM_NOT_FOUND: 'ไม่พบรายการนี้',
    MISSING_CUSTOMER: '❗ ยังขาดลูกค้า\n\nพิมพ์:\nลูกค้า บริษัท ABC',
    MISSING_ITEMS: '❗ ยังขาดรายการ\n\nพิมพ์:\nเพิ่ม ค่าแรง 15000',
    MISSING_DUE_DATE: '❗ ใบวางบิลต้องระบุวันครบกำหนด\n\nพิมพ์:\nกำหนดครบกำหนด 31/12/2568',
    MISSING_PAYMENT: '❗ ใบเสร็จต้องระบุวิธีชำระเงิน\n\nพิมพ์:\nชำระเงิน โอน',
  };
  
  return errorMessages[error] || `เกิดข้อผิดพลาด: ${error}`;
}

// ============================================================================
// EXPORT
// ============================================================================

export default {
  formatDraftSummary,
  formatNextCommands,
  formatConfirmationSummary,
  formatResponse,
  formatError,
};
