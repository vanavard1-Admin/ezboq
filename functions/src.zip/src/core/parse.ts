/**
 * Thai Text Parser for EzDoc
 * Parse user messages into structured DraftPayload
 */

import { DraftPayload, DocType, ParsedItem } from '../shared/types';

/**
 * Parse Thai/numeric string to number
 */
const toNum = (s: string): number | null => {
    const cleaned = s.replace(/[฿,บาท\s]/g, '');
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : null;
};

/**
 * Normalize a line of text
 */
const normalizeLine = (line: string): string => {
    return line
        .replace(/^[\s•\-*—]+/g, '')
        .replace(/\s+/g, ' ')
        .trim();
};

/**
 * Detect document type from text
 */
function detectDocType(
    lines: string[]
): { doc_type?: DocType; warning?: string } {
    const text = lines.join('\n').toLowerCase();

    const hit = (kw: string[]) => kw.some((k) => text.includes(k));

    const quo = hit([
        'ทำใบเสนอราคา',
        'ใบเสนอราคา',
        'เสนอราคา',
        'quotation',
    ]);
    const bill = hit([
        'ทำใบวางบิล',
        'ใบวางบิล',
        'วางบิล',
        'billing note',
        'billing',
    ]);
    const rec = hit([
        'ทำใบเสร็จ',
        'ใบเสร็จ',
        'receipt',
        'ชำระแล้ว',
    ]);

    const count = [quo, bill, rec].filter(Boolean).length;

    if (count === 0) return { warning: 'MISSING_DOC_TYPE' };
    if (count > 1) return { warning: 'AMBIGUOUS_DOC_TYPE' };

    if (quo) return { doc_type: 'QUO' };
    if (bill) return { doc_type: 'BILL' };
    return { doc_type: 'RECEIPT' };
}

/**
 * Parse Thai date format to ISO
 * Supports: DD/MM/YYYY, DD-MM-YYYY, DD เดือน YYYY
 */
function parseDateThai(raw: string): { iso?: string; warning?: string } {
    // Pattern: DD/MM/YYYY or DD-MM-YYYY
    const m1 = raw.match(/(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
    if (m1) {
        const dd = Number(m1[1]);
        const mm = Number(m1[2]);
        const yy = Number(m1[3]);
        // Convert BE to AD if year > 2400
        const ad = yy >= 2400 ? yy - 543 : yy;
        const iso = `${String(ad).padStart(4, '0')}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
        return { iso };
    }

    // Pattern: DD เดือน YYYY (Thai month names)
    const months: Record<string, number> = {
        'มกราคม': 1,
        'กุมภาพันธ์': 2,
        'มีนาคม': 3,
        'เมษายน': 4,
        'พฤษภาคม': 5,
        'มิถุนายน': 6,
        'กรกฎาคม': 7,
        'สิงหาคม': 8,
        'กันยายน': 9,
        'ตุลาคม': 10,
        'พฤศจิกายน': 11,
        'ธันวาคม': 12,
    };

    const m2 = raw.match(/(\d{1,2})\s+([^\s]+)\s+(\d{4})/);
    if (m2 && months[m2[2]]) {
        const dd = Number(m2[1]);
        const mm = months[m2[2]];
        const yy = Number(m2[3]);
        const ad = yy >= 2400 ? yy - 543 : yy;
        const iso = `${String(ad).padStart(4, '0')}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
        return { iso };
    }

    return { warning: 'UNPARSEABLE_DATE' };
}

/**
 * Parse a line of text into a ParsedItem
 */
function parseItemLine(line: string): ParsedItem | null {
    // Handle bilingual with slash: "TH / EN" or "EN / TH"
    let description_th = line;
    let description_en: string | null = null;

    const slash = line.split('/').map((s) => s.trim());
    if (slash.length === 2) {
        description_th = slash[0];
        description_en = slash[1];
    }

    const tokens = description_th.split(' ').filter(Boolean);
    if (tokens.length < 2) return null;

    // Amount is typically the last numeric token
    const amount = toNum(tokens[tokens.length - 1] || '');
    if (amount === null) return null;

    // Pattern A: desc qty unit amount (4+ tokens)
    if (tokens.length >= 4) {
        const qty = toNum(tokens[tokens.length - 3]);
        const unit = tokens[tokens.length - 2];

        // Check if unit is non-numeric
        if (qty !== null && unit && isNaN(Number(unit))) {
            const desc = tokens.slice(0, -3).join(' ');
            const unit_price = qty > 0 ? amount / qty : 0;

            return {
                description_th: desc.trim(),
                description_en,
                qty,
                unit,
                unit_price: Number.isFinite(unit_price) ? unit_price : 0,
                amount,
            };
        }
    }

    // Pattern B: desc amount (fallback)
    const desc = tokens.slice(0, -1).join(' ').trim();
    return {
        description_th: desc || description_th.trim(),
        description_en,
        qty: 1,
        unit: 'งาน',
        unit_price: amount,
        amount,
    };
}

/**
 * Main parser: Convert Thai text input to structured DraftPayload
 * 
 * @param input - Raw text from LINE message
 * @returns Structured draft payload with warnings
 */
export function parseEzDocText(input: string): DraftPayload {
    const rawLines = input
        .split('\n')
        .map(normalizeLine)
        .filter((l) => l.length > 0);

    const warnings: string[] = [];

    // Extract business hint from first line (if short and not a command)
    let business_hint: string | null = null;
    if (rawLines[0] && !rawLines[0].startsWith('ทำใบ')) {
        if (rawLines[0].length <= 30 && !rawLines[0].includes(':')) {
            business_hint = rawLines[0];
        }
    }

    // Detect document type
    const { doc_type, warning: typeWarn } = detectDocType(rawLines);
    if (typeWarn) warnings.push(typeWarn);

    // Initialize fields
    let customer_name: string | null = null;
    let issue_date_raw: string | null = null;
    let issue_date_iso: string | null = null;
    let subject_th: string | null = null;
    let subject_en: string | null = null;

    let discount_amount = 0;
    let extra_fee_amount = 0;
    let vat_enabled: boolean | null = null;
    let vat_rate: number | null = null;
    let wht_enabled: boolean | null = null;
    let wht_rate: number | null = null;
    let total_hint: number | null = null;

    const items: ParsedItem[] = [];

    // Parse each line
    for (const line of rawLines) {
        const lower = line.toLowerCase();

        // Key-value pairs (key: value)
        const kv = line.split(':');
        if (kv.length >= 2) {
            const key = kv[0].trim().toLowerCase();
            const value = kv.slice(1).join(':').trim();

            // Customer name
            if (
                ['ลูกค้า', 'ชื่อลูกค้า', 'customer', 'bill to', 'ออกให้'].includes(key)
            ) {
                customer_name = value;
                continue;
            }

            // Date
            if (['วันที่', 'date'].includes(key)) {
                issue_date_raw = value;
                continue;
            }

            // Subject/description
            if (
                ['เรื่อง', 'งาน', 'subject', 'service', 'รายละเอียด'].includes(key)
            ) {
                // Optional English: " ... | EN: ..."
                const parts = value.split('|').map((s) => s.trim());
                subject_th = parts[0] || value;
                const enPart = parts.find((p) =>
                    p.toLowerCase().startsWith('en')
                );
                if (enPart) {
                    subject_en = enPart.replace(/^en\s*:\s*/i, '').trim();
                }
                continue;
            }
        }

        // Total amount
        if (lower.startsWith('รวม') || lower.startsWith('total')) {
            const n = toNum(line);
            if (n !== null) total_hint = n;
            continue;
        }

        // Discount
        if (lower.startsWith('ส่วนลด') || lower.startsWith('discount')) {
            const n = toNum(line);
            if (n !== null) discount_amount = n;
            continue;
        }

        // Extra fees
        if (
            lower.startsWith('ค่าส่ง') ||
            lower.startsWith('ค่าเดินทาง') ||
            lower.startsWith('extra')
        ) {
            const n = toNum(line);
            if (n !== null) extra_fee_amount = n;
            continue;
        }

        // VAT
        if (lower.startsWith('vat') || lower.includes('ภาษีมูลค่าเพิ่ม')) {
            vat_enabled = true;
            const m = line.match(/(\d+(\.\d+)?)\s*%/);
            if (m) vat_rate = Number(m[1]);
            continue;
        }

        // WHT (Withholding Tax)
        if (
            lower.includes('หัก') ||
            lower.startsWith('wht') ||
            lower.includes('withholding')
        ) {
            wht_enabled = true;
            const m = line.match(/(\d+(\.\d+)?)\s*%/);
            if (m) wht_rate = Number(m[1]);
            continue;
        }

        // Try to parse as item
        const item = parseItemLine(line);
        if (item) {
            items.push(item);
        }
    }

    // Add warnings for missing required fields
    if (!customer_name) warnings.push('MISSING_CUSTOMER');

    if (issue_date_raw) {
        const { iso, warning } = parseDateThai(issue_date_raw);
        if (warning) warnings.push(warning);
        issue_date_iso = iso || null;
    } else {
        warnings.push('MISSING_DATE');
    }

    if (items.length === 0) warnings.push('NO_ITEMS');

    // Calculate subtotal and check for mismatch
    const subtotal_candidate = items.reduce((acc, it) => acc + it.amount, 0);
    const mismatch =
        total_hint !== null && Math.abs(total_hint - subtotal_candidate) > 0.01;

    if (mismatch) warnings.push('TOTAL_MISMATCH');

    return {
        doc_type,
        business_hint,
        customer_name,
        issue_date_raw,
        issue_date_iso,
        subject_th,
        subject_en,
        items,
        discount_amount,
        extra_fee_amount,
        vat_enabled,
        vat_rate,
        wht_enabled,
        wht_rate,
        total_hint,
        subtotal_candidate,
        total_mismatch: mismatch,
        warnings,
    };
}
