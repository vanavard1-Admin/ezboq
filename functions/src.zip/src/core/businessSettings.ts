/**
 * EzDoc - Business Settings Service
 *
 * Handles LINE commands for configuring business profile and payment settings.
 * Settings are stored in:
 * - Business profile: users/{uid}/businesses/{bid}
 * - Payment settings: users/{uid}/businesses/{bid}/settings/payment
 * - Document terms: users/{uid}/businesses/{bid}/settings/terms
 */

import * as admin from 'firebase-admin';
import { getPromptPayLogoUrl } from '../shared/paymentAssets';
import { getBankByCode } from '../services/bankMasterService';

const db = admin.firestore();

/**
 * Settings command types
 */
type SettingsType =
  | 'BUSINESS_NAME'
  | 'ADDRESS'
  | 'TAX_ID'
  | 'PHONE'
  | 'EMAIL'
  | 'PROMPTPAY'
  | 'BANK'
  | 'SIGNATURE'
  | 'STAMP'
  | 'SIGNATORY'
  | 'TERMS_QUO'
  | 'TERMS_INVOICE'
  | 'TERMS_RECEIPT'
  | 'THEME'
  | 'SHOW'
  | 'HELP'
  | 'FORM_TEMPLATE'
  | 'FORM_SUBMIT'
  | null;

/**
 * Get business form template (copy-paste ready)
 */
export function getBusinessFormTemplate(): string {
  return `📋 ตั้งค่าธุรกิจแบบฟอร์ม

คัดลอกฟอร์มด้านล่าง ใส่ข้อมูล แล้วส่งกลับมา:

ชื่อธุรกิจ: ...
ที่อยู่: ...
เลขผู้เสียภาษี: ...
โทร: ...
อีเมล: ...
ธนาคาร: ...
เลขบัญชี: ...
ชื่อบัญชี: ...
พร้อมเพย์: ...

(แนบรูปโลโก้/ลายเซ็น/ตราประทับได้: ส่งรูป แล้วพิมพ์ โลโก้ / ลายเซ็น / ตราประทับ)`;
}

/**
 * Parse multiline business form
 * Tolerant of spaces, colons, Thai/English variants
 */
export function parseBusinessForm(multilineText: string): {
  name?: string;
  address?: string;
  taxId?: string;
  phone?: string;
  email?: string;
  bank?: string;
  bankAccount?: string;
  bankAccountName?: string;
  promptpay?: string;
} {
  const result: {
    name?: string;
    address?: string;
    taxId?: string;
    phone?: string;
    email?: string;
    bank?: string;
    bankAccount?: string;
    bankAccountName?: string;
    promptpay?: string;
  } = {};

  // Normalize line breaks
  const lines = multilineText.split(/\r?\n/).map(line => line.trim()).filter(line => line);

  for (const line of lines) {
    // Try to match key-value patterns
    // Patterns: "key: value", "key - value", "key value" (if key is short)
    
    // Name patterns
    if (/^(?:ชื่อธุรกิจ|ชื่อ|business name|name)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:ชื่อธุรกิจ|ชื่อ|business name|name)[:：\s-]+(.+)$/i);
      if (match) result.name = match[1].trim();
      continue;
    }

    // Address patterns
    if (/^(?:ที่อยู่|ที่อยู่ธุรกิจ|address)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:ที่อยู่|ที่อยู่ธุรกิจ|address)[:：\s-]+(.+)$/i);
      if (match) result.address = match[1].trim();
      continue;
    }

    // Tax ID patterns
    if (/^(?:เลขผู้เสียภาษี|เลขภาษี|tax id|taxid|tin)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:เลขผู้เสียภาษี|เลขภาษี|tax id|taxid|tin)[:：\s-]+(.+)$/i);
      if (match) result.taxId = match[1].trim();
      continue;
    }

    // Phone patterns
    if (/^(?:โทร|เบอร์โทร|phone|tel)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:โทร|เบอร์โทร|phone|tel)[:：\s-]+(.+)$/i);
      if (match) {
        // Normalize phone (remove hyphens, spaces)
        result.phone = match[1].trim().replace(/[\s-]/g, '');
      }
      continue;
    }

    // Email patterns
    if (/^(?:อีเมล|email)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:อีเมล|email)[:：\s-]+(.+)$/i);
      if (match) result.email = match[1].trim();
      continue;
    }

    // Bank patterns (simple - just bank name)
    if (/^(?:ธนาคาร|bank)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:ธนาคาร|bank)[:：\s-]+(.+)$/i);
      if (match) result.bank = match[1].trim();
      continue;
    }

    // Bank account patterns
    if (/^(?:เลขบัญชี|เลขที่บัญชี|account|acc)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:เลขบัญชี|เลขที่บัญชี|account|acc)[:：\s-]+(.+)$/i);
      if (match) {
        // Normalize account (remove hyphens, spaces)
        result.bankAccount = match[1].trim().replace(/[\s-]/g, '');
      }
      continue;
    }

    // Bank account name patterns
    if (/^(?:ชื่อบัญชี|account name)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:ชื่อบัญชี|account name)[:：\s-]+(.+)$/i);
      if (match) result.bankAccountName = match[1].trim();
      continue;
    }

    // PromptPay patterns
    if (/^(?:พร้อมเพย์|promptpay)[:：\s-]+(.+)$/i.test(line)) {
      const match = line.match(/^(?:พร้อมเพย์|promptpay)[:：\s-]+(.+)$/i);
      if (match) {
        // Normalize promptpay (remove hyphens, spaces)
        result.promptpay = match[1].trim().replace(/[\s-]/g, '');
      }
      continue;
    }
  }

  return result;
}

/**
 * Apply business form data to profile
 */
export async function applyBusinessForm(
  userId: string,
  businessId: string,
  formData: ReturnType<typeof parseBusinessForm>
): Promise<{ saved: number; summary: string }> {
  let saved = 0;
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  const updates: Record<string, string> = {};

  if (formData.name) {
    updates.name = formData.name;
    saved++;
  }
  if (formData.address) {
    updates.address = formData.address;
    saved++;
  }
  if (formData.taxId) {
    updates.taxId = formData.taxId;
    saved++;
  }
  if (formData.phone) {
    updates.phone = formData.phone;
    saved++;
  }
  if (formData.email) {
    updates.email = formData.email;
    saved++;
  }

  if (Object.keys(updates).length > 0) {
    updates.updatedAt = admin.firestore.FieldValue.serverTimestamp() as any;
    await bizRef.set(updates, { merge: true });
  }

  // Handle payment settings
  if (formData.promptpay) {
    await setPromptPay(userId, businessId, formData.promptpay);
    saved++;
  }

  if (formData.bank && formData.bankAccount && formData.bankAccountName) {
    // Bank will be handled separately (requires bank code mapping)
    // For now, just note it
    saved += 3;
  }

  // Get summary
  const summary = await getSettingsSummary(userId, businessId);

  return { saved, summary };
}

/**
 * Parse settings command from LINE message
 */
export function parseSettingsCommand(message: string): {
  type: SettingsType;
  value?: string;
  bankCode?: string;
  bankAccount?: string;
  bankAccountName?: string;
  signatoryName?: string;
  signatoryTitle?: string;
  formData?: ReturnType<typeof parseBusinessForm>;
} {
  const text = message.trim();

  // ตั้งค่าธุรกิจแบบฟอร์ม (show template)
  if (/^ตั้งค่าธุรกิจแบบฟอร์ม$/i.test(text)) {
    return { type: 'FORM_TEMPLATE' };
  }

  // Multiline form submission (starts with "ชื่อธุรกิจ:" or similar)
  if (text.includes('\n') && /^(?:ชื่อธุรกิจ|ชื่อ|business name|name)[:：\s-]/i.test(text)) {
    const formData = parseBusinessForm(text);
    if (Object.keys(formData).length > 0) {
      return { type: 'FORM_SUBMIT', formData };
    }
  }

  // ตั้งค่าธุรกิจ (show current settings or help)
  if (/^ตั้งค่าธุรกิจ$/i.test(text)) {
    return { type: 'SHOW' };
  }

  // ชื่อธุรกิจ <value> (tolerant: allow colon, extra spaces)
  const nameMatch = text.match(/^(?:ตั้งค่าธุรกิจ\s+ชื่อ|ชื่อธุรกิจ)[:：\s-]+(.+)$/i);
  if (nameMatch) {
    return { type: 'BUSINESS_NAME', value: nameMatch[1].trim() };
  }

  // ที่อยู่ <value> (tolerant)
  const addressMatch = text.match(/^(?:ตั้งค่าธุรกิจ\s+ที่อยู่|ที่อยู่ธุรกิจ|ที่อยู่)[:：\s-]+(.+)$/i);
  if (addressMatch) {
    return { type: 'ADDRESS', value: addressMatch[1].trim() };
  }

  // เลขผู้เสียภาษี <value> (tolerant: allow "เลขภาษี", "Tax ID", etc.)
  const taxMatch = text.match(/^(?:เลขผู้เสียภาษี|เลขภาษี|tax\s*id|taxid|tin)[:：\s-]+(.+)$/i);
  if (taxMatch) {
    return { type: 'TAX_ID', value: taxMatch[1].trim() };
  }

  // โทร <value> (tolerant: allow hyphens in phone)
  const phoneMatch = text.match(/^(?:โทร|เบอร์โทร|phone|tel)[:：\s-]+(.+)$/i);
  if (phoneMatch) {
    // Normalize: remove extra spaces, but keep numbers
    return { type: 'PHONE', value: phoneMatch[1].trim().replace(/\s+/g, '') };
  }

  // อีเมล <value> (tolerant)
  const emailMatch = text.match(/^(?:อีเมล|email)[:：\s-]+(.+)$/i);
  if (emailMatch) {
    return { type: 'EMAIL', value: emailMatch[1].trim() };
  }

  // ตั้งค่าพร้อมเพย์ <number>
  const promptpayMatch = text.match(/^ตั้งค่าพร้อมเพย์\s+(\d[\d-]+)$/i);
  if (promptpayMatch) {
    return { type: 'PROMPTPAY', value: promptpayMatch[1].replace(/-/g, '').trim() };
  }

  // ตั้งค่าธนาคาร (show list)
  if (/^ตั้งค่าธนาคาร$/i.test(text)) {
    return { type: 'BANK', bankCode: 'SHOW_LIST' };
  }

  // ตั้งค่าธนาคาร <bank_name_or_code> <account> <name>
  const bankMatch = text.match(/^ตั้งค่าธนาคาร\s+(.+?)\s+(\d[\d-]+)\s+(.+)$/i);
  if (bankMatch) {
    return {
      type: 'BANK',
      bankCode: bankMatch[1].trim(), // Will be resolved to code in handler
      bankAccount: bankMatch[2].replace(/-/g, '').trim(),
      bankAccountName: bankMatch[3].trim(),
    };
  }

  // ตั้งลายเซ็น <URL>
  const signatureMatch = text.match(/^(?:ตั้งลายเซ็น|ลายเซ็น)\s+(https?:\/\/.+)$/i);
  if (signatureMatch) {
    return { type: 'SIGNATURE', value: signatureMatch[1].trim() };
  }

  // ตั้งตราประทับ <URL>
  const stampMatch = text.match(/^(?:ตั้งตราประทับ|ตราประทับ)\s+(https?:\/\/.+)$/i);
  if (stampMatch) {
    return { type: 'STAMP', value: stampMatch[1].trim() };
  }

  // ตั้งผู้ลงนาม <ชื่อ> <ตำแหน่ง>
  const signatoryMatch = text.match(/^(?:ตั้งผู้ลงนาม|ผู้ลงนาม)\s+(.+?)\s+ตำแหน่ง\s+(.+)$/i);
  if (signatoryMatch) {
    return {
      type: 'SIGNATORY',
      signatoryName: signatoryMatch[1].trim(),
      signatoryTitle: signatoryMatch[2].trim(),
    };
  }

  // ตั้งเงื่อนไขใบเสนอราคา <text>
  const termsQuoMatch = text.match(/^(?:เงื่อนไขใบเสนอราคา|terms quo)\s+(.+)$/i);
  if (termsQuoMatch) {
    return { type: 'TERMS_QUO', value: termsQuoMatch[1].trim() };
  }

  // ตั้งเงื่อนไขใบวางบิล <text>
  const termsInvoiceMatch = text.match(/^(?:เงื่อนไขใบวางบิล|terms invoice)\s+(.+)$/i);
  if (termsInvoiceMatch) {
    return { type: 'TERMS_INVOICE', value: termsInvoiceMatch[1].trim() };
  }

  // ตั้งเงื่อนไขใบเสร็จ <text>
  const termsReceiptMatch = text.match(/^(?:เงื่อนไขใบเสร็จ|terms receipt)\s+(.+)$/i);
  if (termsReceiptMatch) {
    return { type: 'TERMS_RECEIPT', value: termsReceiptMatch[1].trim() };
  }

  // ตั้งค่าธีม <theme>
  const themeMatch = text.match(/^ตั้งค่าธีม\s+(เขียว|แดง|น้ำเงิน|ขาวดำ|green|red|blue|mono)$/i);
  if (themeMatch) {
    const themeInput = themeMatch[1].toLowerCase();
    // Map Thai to English
    const themeMap: Record<string, string> = {
      'เขียว': 'green',
      'แดง': 'red',
      'น้ำเงิน': 'blue',
      'ขาวดำ': 'mono',
      'green': 'green',
      'red': 'red',
      'blue': 'blue',
      'mono': 'mono',
    };
    const theme = themeMap[themeInput] || 'green';
    return { type: 'THEME', value: theme };
  }

  return { type: null };
}

/**
 * Update business profile field
 */
export async function updateBusinessProfile(
  userId: string,
  businessId: string,
  field: string,
  value: string
): Promise<void> {
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  await bizRef.set(
    {
      [field]: value,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update PromptPay settings
 */
export async function setPromptPay(
  userId: string,
  businessId: string,
  promptpayAccount: string,
  promptpayName?: string
): Promise<void> {
  const paymentRef = db.doc(`users/${userId}/businesses/${businessId}/settings/payment`);
  await paymentRef.set(
    {
      method: 'PROMPTPAY',
      promptpay_account: promptpayAccount,
      promptpay_name: promptpayName || null,
      promptpay_logo_url: getPromptPayLogoUrl(),
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update bank transfer settings
 */
export async function setBankTransfer(
  userId: string,
  businessId: string,
  bankCode: string,
  bankAccount: string,
  bankAccountName: string
): Promise<void> {
  const bank = getBankByCode(bankCode);
  
  const paymentRef = db.doc(`users/${userId}/businesses/${businessId}/settings/payment`);
  await paymentRef.set(
    {
      method: 'BANK_TRANSFER',
      bank_code: bankCode,
      bank_name: bank?.name_th || bankCode,
      bank_account: bankAccount,
      bank_account_name: bankAccountName,
      bank_logo_url: bank?.logo_url || null,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update signature settings
 */
export async function setSignature(
  userId: string,
  businessId: string,
  signatureUrl: string
): Promise<void> {
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  await bizRef.set(
    {
      signature_url: signatureUrl,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update stamp settings
 */
export async function setStamp(
  userId: string,
  businessId: string,
  stampUrl: string
): Promise<void> {
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  await bizRef.set(
    {
      stamp_url: stampUrl,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update signatory info
 */
export async function setSignatory(
  userId: string,
  businessId: string,
  signatoryName: string,
  signatoryTitle: string
): Promise<void> {
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  await bizRef.set(
    {
      signatory_name: signatoryName,
      signatory_title: signatoryTitle,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Update document terms
 */
export async function setDocumentTerms(
  userId: string,
  businessId: string,
  docType: 'quotation' | 'invoice' | 'receipt',
  terms: string
): Promise<void> {
  const termsRef = db.doc(`users/${userId}/businesses/${businessId}/settings/terms`);
  await termsRef.set(
    {
      [`${docType}_terms`]: terms,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

/**
 * Get current business settings summary
 */
export async function getSettingsSummary(
  userId: string,
  businessId: string
): Promise<string> {
  const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
  const bizSnap = await bizRef.get();
  const biz = bizSnap.data() || {};

  const paymentRef = db.doc(`users/${userId}/businesses/${businessId}/settings/payment`);
  const paymentSnap = await paymentRef.get();
  const payment = paymentSnap.data() || {};

  const termsRef = db.doc(`users/${userId}/businesses/${businessId}/settings/terms`);
  const termsSnap = await termsRef.get();
  const terms = termsSnap.data() || {};

  const lines: string[] = ['📋 ตั้งค่าธุรกิจปัจจุบัน:', ''];

  lines.push(`ชื่อ: ${biz.name || '(ยังไม่ระบุ)'}`);
  lines.push(`ที่อยู่: ${biz.address || '(ยังไม่ระบุ)'}`);
  lines.push(`เลขผู้เสียภาษี: ${biz.taxId || '(ยังไม่ระบุ)'}`);
  lines.push(`โทร: ${biz.phone || '(ยังไม่ระบุ)'}`);
  lines.push(`อีเมล: ${biz.email || '(ยังไม่ระบุ)'}`);

  const themeNames: Record<string, string> = {
    green: 'เขียว',
    red: 'แดง',
    blue: 'น้ำเงิน',
    mono: 'ขาวดำ',
  };
  lines.push(`ธีม PDF: ${themeNames[biz.pdfTheme as string] || themeNames.green}`);

  lines.push('');
  lines.push('✍️ ลายเซ็น/ตราประทับ:');
  lines.push(`ลายเซ็น: ${biz.signature_url ? '✅ ตั้งค่าแล้ว' : '(ยังไม่ระบุ)'}`);
  lines.push(`ตราประทับ: ${biz.stamp_url ? '✅ ตั้งค่าแล้ว' : '(ยังไม่ระบุ)'}`);
  lines.push(`ผู้ลงนาม: ${biz.signatory_name || '(ยังไม่ระบุ)'}`);
  if (biz.signatory_title) {
    lines.push(`ตำแหน่ง: ${biz.signatory_title}`);
  }

  lines.push('');
  lines.push('💳 ข้อมูลชำระเงิน:');

  if (payment.method === 'PROMPTPAY' && payment.promptpay_account) {
    lines.push(`พร้อมเพย์: ${payment.promptpay_account}`);
  } else if (payment.method === 'BANK_TRANSFER' && payment.bank_account) {
    lines.push(`ธนาคาร: ${payment.bank_name || payment.bank_code}`);
    lines.push(`เลขบัญชี: ${payment.bank_account}`);
    lines.push(`ชื่อบัญชี: ${payment.bank_account_name}`);
  } else {
    lines.push('(ยังไม่ได้ตั้งค่า)');
  }

  lines.push('');
  lines.push('📄 เงื่อนไขเอกสาร:');
  lines.push(`ใบเสนอราคา: ${terms.quotation_terms || '(ค่าเริ่มต้น)'}`);
  lines.push(`ใบวางบิล: ${terms.invoice_terms || '(ค่าเริ่มต้น)'}`);
  lines.push(`ใบเสร็จ: ${terms.receipt_terms || '(ค่าเริ่มต้น)'}`);

  return lines.join('\n');
}

/**
 * Get help text for settings commands
 */
export function getSettingsHelpText(): string {
  return `⚙️ คำสั่งตั้งค่าธุรกิจ:

💡 วิธีง่ายที่สุด:
พิมพ์ "ตั้งค่าธุรกิจแบบฟอร์ม"
แล้วคัดลอกฟอร์ม ใส่ข้อมูล ส่งกลับมา

📝 ตั้งค่าแบบคำสั่งเดียว:
• ชื่อธุรกิจ [ชื่อ]
• ที่อยู่ [ที่อยู่]
• เลขผู้เสียภาษี [เลข]
• โทร [เบอร์]
• อีเมล [อีเมล]
• ตั้งค่าพร้อมเพย์ [เลข]
• ตั้งค่าธนาคาร [ชื่อหรือรหัส] [เลข] [ชื่อ]
• ตั้งค่าธีม [เขียว|แดง|น้ำเงิน|ขาวดำ]

ตัวอย่าง:
"ชื่อธุรกิจ บริษัท ABC จำกัด"
"ตั้งค่าธนาคาร กสิกร 1234567890 บริษัท ABC"
"ตั้งค่าพร้อมเพย์ 0812345678"
"ตั้งค่าธีม เขียว"

พิมพ์ "ตั้งค่าธุรกิจ" เพื่อดูค่าปัจจุบัน`;
}

/**
 * Handle settings command and return response
 */
export async function handleSettingsCommand(
  userId: string,
  businessId: string,
  message: string
): Promise<string> {
  const cmd = parseSettingsCommand(message);

  if (!cmd.type) {
    return getSettingsHelpText();
  }

  switch (cmd.type) {
    case 'FORM_TEMPLATE':
      return getBusinessFormTemplate();

    case 'FORM_SUBMIT': {
      if (!cmd.formData) {
        return '❌ ไม่พบข้อมูลในฟอร์ม';
      }
      const { saved, summary } = await applyBusinessForm(userId, businessId, cmd.formData);
      
      // Handle bank if provided (requires bank name mapping)
      if (cmd.formData.bank && cmd.formData.bankAccount && cmd.formData.bankAccountName) {
        const { findBankByName } = await import('../services/bankMasterService');
        const bank = findBankByName(cmd.formData.bank);
        
        if (bank) {
          await setBankTransfer(userId, businessId, bank.code, cmd.formData.bankAccount, cmd.formData.bankAccountName);
        } else {
          // Bank not found - user will need to set it separately
          // Just continue with other fields saved
        }
      }
      
      const lines = [
        `✅ บันทึกข้อมูล ${saved} รายการ`,
        '',
        summary,
        '',
        'พิมพ์ "ใบเสนอราคา" เพื่อเริ่มออกเอกสาร',
      ];
      return lines.join('\n');
    }

    case 'SHOW':
      return await getSettingsSummary(userId, businessId);

    case 'BUSINESS_NAME':
      await updateBusinessProfile(userId, businessId, 'name', cmd.value!);
      return `✅ บันทึกชื่อธุรกิจ: ${cmd.value}`;

    case 'ADDRESS':
      await updateBusinessProfile(userId, businessId, 'address', cmd.value!);
      return `✅ บันทึกที่อยู่: ${cmd.value}`;

    case 'TAX_ID':
      await updateBusinessProfile(userId, businessId, 'taxId', cmd.value!);
      return `✅ บันทึกเลขผู้เสียภาษี: ${cmd.value}`;

    case 'PHONE':
      await updateBusinessProfile(userId, businessId, 'phone', cmd.value!);
      return `✅ บันทึกเบอร์โทร: ${cmd.value}`;

    case 'EMAIL':
      await updateBusinessProfile(userId, businessId, 'email', cmd.value!);
      return `✅ บันทึกอีเมล: ${cmd.value}`;

    case 'PROMPTPAY':
      await setPromptPay(userId, businessId, cmd.value!);
      return `✅ บันทึกพร้อมเพย์: ${cmd.value}`;

    case 'THEME': {
      const theme = cmd.value || 'green';
      const themeNames: Record<string, string> = {
        green: 'เขียว',
        red: 'แดง',
        blue: 'น้ำเงิน',
        mono: 'ขาวดำ',
      };
      const themeEmojis: Record<string, string> = {
        green: '🟢',
        red: '🔴',
        blue: '🔵',
        mono: '⚫',
      };
      await updateBusinessProfile(userId, businessId, 'pdfTheme', theme);
      const themeName = themeNames[theme] || theme;
      const themeEmoji = themeEmojis[theme] || '🎨';
      return `${themeEmoji} ตั้งธีมเอกสารเป็น "${themeName}" แล้ว\n\nเอกสาร PDF จะใช้ธีมนี้ในครั้งต่อไป`;
    }

    case 'BANK': {
      // Show bank list if no parameters
      if (cmd.bankCode === 'SHOW_LIST') {
        const { getPopularBanks } = await import('../services/bankMasterService');
        const popular = getPopularBanks();
        const lines = [
          '🏦 ธนาคารที่รองรับ:',
          '',
          'ธนาคารยอดนิยม:',
          ...popular.map(b => `• ${b.name_th} (${b.code})`),
          '',
          'ตัวอย่าง:',
          '"ตั้งค่าธนาคาร กสิกร 1234567890 บริษัท ABC"',
          '"ตั้งค่าธนาคาร KBANK 1234567890 บริษัท ABC"',
          '',
          'พิมพ์ "ตั้งค่าธนาคาร <ชื่อหรือรหัส> <เลขบัญชี> <ชื่อบัญชี>"',
        ];
        return lines.join('\n');
      }

      // Resolve bank name/code to BankMaster
      const { findBankByName, findBanksWithSuggestions } = await import('../services/bankMasterService');
      const bankInput = cmd.bankCode!;
      let bank = findBankByName(bankInput);

      // If not found, show suggestions
      if (!bank) {
        const suggestions = findBanksWithSuggestions(bankInput, 5);
        if (suggestions.length === 0) {
          return `❌ ไม่พบธนาคาร "${bankInput}"\n\nพิมพ์ "ตั้งค่าธนาคาร" เพื่อดูรายชื่อธนาคาร`;
        }
        
        const lines = [
          `❓ คุณหมายถึงธนาคารไหน?`,
          '',
          ...suggestions.map(b => `• ${b.name_th} (${b.code})`),
          '',
          'พิมพ์ "ตั้งค่าธนาคาร <ชื่อหรือรหัส> <เลขบัญชี> <ชื่อบัญชี>"',
        ];
        return lines.join('\n');
      }

      // Bank found - save settings
      await setBankTransfer(userId, businessId, bank.code, cmd.bankAccount!, cmd.bankAccountName!);
      return `✅ บันทึกบัญชีธนาคาร:\n${bank.name_th}\nเลขบัญชี: ${cmd.bankAccount}\nชื่อ: ${cmd.bankAccountName}`;
    }

    case 'SIGNATURE':
      await setSignature(userId, businessId, cmd.value!);
      return `✅ บันทึกลายเซ็น\nURL: ${cmd.value}`;

    case 'STAMP':
      await setStamp(userId, businessId, cmd.value!);
      return `✅ บันทึกตราประทับ\nURL: ${cmd.value}`;

    case 'SIGNATORY':
      await setSignatory(userId, businessId, cmd.signatoryName!, cmd.signatoryTitle!);
      return `✅ บันทึกผู้ลงนาม:\n${cmd.signatoryName}\nตำแหน่ง: ${cmd.signatoryTitle}`;

    case 'TERMS_QUO':
      await setDocumentTerms(userId, businessId, 'quotation', cmd.value!);
      return `✅ บันทึกเงื่อนไขใบเสนอราคา:\n${cmd.value}`;

    case 'TERMS_INVOICE':
      await setDocumentTerms(userId, businessId, 'invoice', cmd.value!);
      return `✅ บันทึกเงื่อนไขใบวางบิล:\n${cmd.value}`;

    case 'TERMS_RECEIPT':
      await setDocumentTerms(userId, businessId, 'receipt', cmd.value!);
      return `✅ บันทึกเงื่อนไขใบเสร็จ:\n${cmd.value}`;

    case 'HELP':
    default:
      return getSettingsHelpText();
  }
}
