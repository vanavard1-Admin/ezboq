/**
 * Report Service
 * 
 * Generates business reports from Firestore documents
 * CRITICAL RULE: Only RECEIPT documents count as revenue
 * 
 * Reports:
 * 1. Monthly Sales (revenue tracking)
 * 2. Overdue Invoices (collection focus)
 * 3. Top Customers (business insights)
 * 4. Popular Services (product performance)
 */

import * as admin from 'firebase-admin';

const db = admin.firestore();
const DOCUMENTS_COLLECTION = 'documents';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface MonthlySalesReport {
  month: string; // Format: "ธ.ค. 2568"
  monthKey: string; // Format: "2568_12"
  receiptCount: number;
  totalRevenue: number;
  netReceived: number;
  averagePerReceipt: number;
}

export interface OverdueInvoice {
  docNo: string;
  customerName: string;
  amount: number;
  overdueByDays: number;
  issuedDate: Date;
  dueDate: Date;
}

export interface TopCustomer {
  customerName: string;
  customerId?: string;
  receiptCount: number;
  totalSpent: number;
  percentOfTotal: number;
}

export interface PopularService {
  description: string;
  itemCount: number;
  totalRevenue: number;
  percentOfTotal: number;
}

// ============================================================================
// 1. MONTHLY SALES REPORT
// ============================================================================

export async function getMonthlySalesReport(
  businessId: string,
  monthKey?: string // Format: "2568_12", default = current month
): Promise<MonthlySalesReport | null> {
  try {
    // Determine month to report
    const targetMonth = monthKey || getCurrentMonthKey();

    // Query RECEIPT documents for this month
    const startDate = monthKeyToDateRange(targetMonth).start;
    const endDate = monthKeyToDateRange(targetMonth).end;

    const receipts = await db
      .collection(DOCUMENTS_COLLECTION)
      .where('business_id', '==', businessId)
      .where('doc_type', '==', 'RECEIPT')
      .where('status', '==', 'PAID')
      .where('issue_date', '>=', admin.firestore.Timestamp.fromDate(startDate))
      .where('issue_date', '<', admin.firestore.Timestamp.fromDate(endDate))
      .get();

    if (receipts.empty) {
      return {
        month: monthKeyToThaiMonth(targetMonth),
        monthKey: targetMonth,
        receiptCount: 0,
        totalRevenue: 0,
        netReceived: 0,
        averagePerReceipt: 0,
      };
    }

    let totalRevenue = 0;
    let netReceived = 0;

    receipts.docs.forEach((doc) => {
      const data = doc.data() as Record<string, unknown>;
      totalRevenue += Number(data.total_amount || 0);
      netReceived += Number(data.net_receive_amount || data.total_amount || 0);
    });

    return {
      month: monthKeyToThaiMonth(targetMonth),
      monthKey: targetMonth,
      receiptCount: receipts.size,
      totalRevenue,
      netReceived,
      averagePerReceipt: receipts.size > 0 ? Math.round(totalRevenue / receipts.size) : 0,
    };
  } catch (error: any) {
    console.error('Error generating monthly sales report:', error);
    // Check if error is due to index building
    if (error?.code === 9 || error?.message?.includes('index is currently building')) {
      console.error('Index is building, query will work once index is ready');
    }
    return null;
  }
}

// ============================================================================
// 2. OVERDUE INVOICES REPORT
// ============================================================================

export async function getOverdueInvoicesReport(
  businessId: string
): Promise<OverdueInvoice[]> {
  try {
    const now = new Date();

    // Query INVOICE documents that are not PAID
    const invoices = await db
      .collection(DOCUMENTS_COLLECTION)
      .where('business_id', '==', businessId)
      .where('doc_type', '==', 'BILL')
      .where('status', '!=', 'PAID')
      .get();

    const overdueList: OverdueInvoice[] = [];

    invoices.docs.forEach((doc) => {
      const data = doc.data() as Record<string, unknown>;
      const issueDate = data.issue_date && typeof data.issue_date === 'object' && 'toDate' in data.issue_date
        ? (data.issue_date as { toDate: () => Date }).toDate()
        : new Date();

      // Assume 30-day payment terms (configurable)
      const dueDate = new Date(issueDate);
      dueDate.setDate(dueDate.getDate() + 30);

      // Check if overdue
      if (dueDate < now) {
        const overdueByDays = Math.floor(
          (now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)
        );

        overdueList.push({
          docNo: String(data.doc_no || ''),
          customerName: String(data.customer_name || 'Unknown'),
          amount: Number(data.total_amount || 0),
          overdueByDays,
          issuedDate: issueDate,
          dueDate,
        });
      }
    });

    // Sort by overdue days (descending)
    overdueList.sort((a, b) => b.overdueByDays - a.overdueByDays);

    return overdueList;
  } catch (error) {
    console.error('Error generating overdue invoices report:', error);
    return [];
  }
}

// ============================================================================
// 3. TOP CUSTOMERS REPORT
// ============================================================================

export async function getTopCustomersReport(
  businessId: string,
  limit: number = 5,
  monthKey?: string // Optional: limit to specific month
): Promise<TopCustomer[]> {
  try {
    let query = db
      .collection(DOCUMENTS_COLLECTION)
      .where('business_id', '==', businessId)
      .where('doc_type', '==', 'RECEIPT')
      .where('status', '==', 'PAID');

    // Filter by month if specified
    if (monthKey) {
      const { start, end } = monthKeyToDateRange(monthKey);
      query = query
        .where('issue_date', '>=', admin.firestore.Timestamp.fromDate(start))
        .where('issue_date', '<', admin.firestore.Timestamp.fromDate(end));
    }

    const receipts = await query.get();

    // Aggregate by customer
    const customerMap = new Map<
      string,
      { name: string; id?: string; total: number; count: number }
    >();

    let grandTotal = 0;

    receipts.docs.forEach((doc) => {
      const data = doc.data() as Record<string, unknown>;
      const customerName = String(data.customer_name || 'Unknown');
      const customerId = data.customer_id;
      const amount = Number(data.total_amount || 0);

      grandTotal += amount;

      const key = `${customerName}|${String(customerId || '')}`;
      const existing = customerMap.get(key) || {
        name: customerName,
        id: customerId ? String(customerId) : undefined,
        total: 0,
        count: 0,
      };

      existing.total += amount;
      existing.count += 1;
      customerMap.set(key, existing);
    });

    // Convert to array and sort by total (descending)
    const customers = Array.from(customerMap.values())
      .sort((a, b) => b.total - a.total)
      .slice(0, limit)
      .map((c) => ({
        customerName: c.name,
        customerId: c.id,
        receiptCount: c.count,
        totalSpent: c.total,
        percentOfTotal: grandTotal > 0 ? Math.round((c.total / grandTotal) * 100) : 0,
      }));

    return customers;
  } catch (error) {
    console.error('Error generating top customers report:', error);
    return [];
  }
}

// ============================================================================
// 4. POPULAR SERVICES REPORT
// ============================================================================

export async function getPopularServicesReport(
  businessId: string,
  limit: number = 5,
  monthKey?: string // Optional: limit to specific month
): Promise<PopularService[]> {
  try {
    let query = db
      .collection(DOCUMENTS_COLLECTION)
      .where('business_id', '==', businessId)
      .where('doc_type', '==', 'RECEIPT')
      .where('status', '==', 'PAID');

    // Filter by month if specified
    if (monthKey) {
      const { start, end } = monthKeyToDateRange(monthKey);
      query = query
        .where('issue_date', '>=', admin.firestore.Timestamp.fromDate(start))
        .where('issue_date', '<', admin.firestore.Timestamp.fromDate(end));
    }

    const receipts = await query.get();

    // Aggregate items
    const serviceMap = new Map<
      string,
      { description: string; count: number; revenue: number }
    >();

    let grandTotal = 0;

    receipts.docs.forEach((doc) => {
      const data = doc.data() as Record<string, unknown>;
      const items = data.items && Array.isArray(data.items) ? data.items : [];

      items.forEach((item: Record<string, unknown>) => {
        const description = String(item.description_th || item.description_en || 'Unknown');
        const amount = Number(item.amount || 0);

        grandTotal += amount;

        const existing = serviceMap.get(description) || {
          description,
          count: 0,
          revenue: 0,
        };

        existing.count += 1;
        existing.revenue += amount;
        serviceMap.set(description, existing);
      });
    });

    // Convert to array and sort by revenue (descending)
    const services = Array.from(serviceMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, limit)
      .map((s) => ({
        description: s.description,
        itemCount: s.count,
        totalRevenue: s.revenue,
        percentOfTotal: grandTotal > 0 ? Math.round((s.revenue / grandTotal) * 100) : 0,
      }));

    return services;
  } catch (error) {
    console.error('Error generating popular services report:', error);
    return [];
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function getCurrentMonthKey(): string {
  const now = new Date();
  const thaiYear = now.getFullYear() + 543;
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${thaiYear}_${month}`;
}

function monthKeyToDateRange(monthKey: string): { start: Date; end: Date } {
  const [yearStr, monthStr] = monthKey.split('_');
  const gregorianYear = parseInt(yearStr, 10) - 543;
  const month = parseInt(monthStr, 10) - 1; // 0-indexed

  const start = new Date(gregorianYear, month, 1);
  const end = new Date(gregorianYear, month + 1, 1);

  return { start, end };
}

function monthKeyToThaiMonth(monthKey: string): string {
  const thaiMonths = [
    'ม.ค.',
    'ก.พ.',
    'มี.ค.',
    'เม.ย.',
    'พ.ค.',
    'มิ.ย.',
    'ก.ค.',
    'ส.ค.',
    'ก.ย.',
    'ต.ค.',
    'พ.ย.',
    'ธ.ค.',
  ];

  const [yearStr, monthStr] = monthKey.split('_');
  const year = yearStr; // Thai year as-is
  const monthIdx = parseInt(monthStr, 10) - 1;

  return `${thaiMonths[monthIdx]} ${year}`;
}
