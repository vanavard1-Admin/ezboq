import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { DraftDocType } from '../shared/schemas';

/**
 * Draft document structure for LINE-based document creation.
 * Stores temporary state while user builds document via conversation.
 */
export interface LineDraft {
  firebaseUid?: string;  // Firebase UID (not LINE user ID)
  businessId?: string;
  docType: DraftDocType;
  customerName?: string;
  customerId?: string | null;
  items: Array<{
    name: string;
    qty: number;
    price: number;
    description?: string;
  }>;
  notes?: string;
  subtotal: number;
  vat?: number;
  wht?: number;
  total: number;
  createdAt?: Timestamp | number;
  updatedAt?: Timestamp | number;
  expiresAt?: Timestamp;
  status?: 'editing' | 'pending_confirmation' | 'confirmed';
  // Source document link (for QUO → INV → RECEIPT chain)
  source_doc_type?: 'QUO' | 'BILL' | null;
  source_doc_id?: string | null;
  source_doc_no?: string | null;
  // Installment info (for multi-installment billing)
  installment_no?: number | null;
  installment_total?: number | null;
  // Locked fields (cannot be edited by user)
  locked_fields?: string[];
}

/**
 * Get or create draft for user
 * @param uid Firebase UID (not LINE user ID)
 */
export async function getOrCreateDraft(
  uid: string,
  businessId: string,
  docType: 'QUO' | 'BILL' | 'RECEIPT'
): Promise<LineDraft> {
  const db = getFirestore();
  const draftRef = db.collection('line_drafts').doc(uid);
  const snap = await draftRef.get();

  if (snap.exists) {
    const draft = snap.data() as LineDraft;
    const now = Date.now();
    const expiresAt = (draft.expiresAt as Timestamp).toMillis() || 0;

    if (expiresAt > now && draft.docType === docType) {
      console.log(`[draftStore] Reusing existing draft for ${uid}`);
      return draft;
    }

    if (expiresAt <= now) {
      console.log(`[draftStore] Draft expired, deleting for ${uid}`);
      await draftRef.delete();
    }
  }

  const now = Timestamp.now();
  const newDraft: LineDraft = {
    firebaseUid: uid,
    businessId,
    docType,
    items: [],
    subtotal: 0,
    total: 0,
    createdAt: now,
    updatedAt: now,
    expiresAt: Timestamp.fromMillis(Date.now() + 30 * 60 * 1000),
    status: 'editing',
  };

  await draftRef.set(newDraft);
  console.log(`[DRAFT_CREATED] 📝 uid=${uid}, business=${businessId}, docType=${docType}`);
  return newDraft;
}

/**
 * Update draft with partial fields
 * @param uid Firebase UID (not LINE user ID)
 */
export async function updateDraft(
  uid: string,
  patch: Partial<LineDraft>
): Promise<LineDraft> {
  const db = getFirestore();
  const draftRef = db.collection('line_drafts').doc(uid);
  const snap = await draftRef.get();

  if (!snap.exists) {
    throw new Error(`[draftStore] Draft not found for ${uid}`);
  }

  const draft = snap.data() as LineDraft;
  const updated = { ...draft, ...patch, updatedAt: Timestamp.now() };

  // Recalculate totals when items or pricing fields change
  // Pricing fields that affect total: items, vat, wht, discount (if added in future)
  if (patch.items || patch.vat !== undefined || patch.wht !== undefined) {
    // Use patch.items if provided, otherwise use existing items
    const itemsToCalculate = patch.items || draft.items;
    updated.subtotal = calculateSubtotal(itemsToCalculate);
    updated.total = calculateTotal(
      updated.subtotal,
      updated.vat ?? patch.vat,
      updated.wht ?? patch.wht
    );
  }

  await draftRef.update(updated);
  return updated;
}

/**
 * Fetch draft for user
 * @param uid Firebase UID (not LINE user ID)
 */
export async function getDraft(uid: string): Promise<LineDraft | null> {
  const db = getFirestore();
  const snap = await db.collection('line_drafts').doc(uid).get();

  if (!snap.exists) {
    return null;
  }

  const draft = snap.data() as LineDraft;
  const now = Date.now();
  const expiresAt = (draft.expiresAt as Timestamp).toMillis() || 0;

  if (expiresAt <= now) {
    console.log(`[draftStore] Draft expired for ${uid}, cleaning up`);
    await db.collection('line_drafts').doc(uid).delete();
    return null;
  }

  return draft;
}

/**
 * Clear draft for user
 * @param uid Firebase UID (not LINE user ID)
 */
export async function clearDraft(uid: string): Promise<void> {
  const db = getFirestore();
  await db.collection('line_drafts').doc(uid).delete();
  console.log(`[draftStore] Cleared draft for ${uid}`);
}

/**
 * Format draft for display in LINE message
 */
export function formatDraftForDisplay(draft: LineDraft): string {
  const typeLabel = {
    QUO: '📋 ใบเสนอราคา',
    BILL: '📄 ใบวางบิล',
    RECEIPT: '✅ ใบเสร็จรับเงิน',
  }[draft.docType];

  const itemsText = draft.items
    .map((item, i) => `${i + 1}. ${item.name} x${item.qty} @ ${item.price}฿ = ${item.qty * item.price}฿`)
    .join('\n');

  const totalsText = [
    `รวม: ${draft.subtotal.toLocaleString('th-TH')}฿`,
    draft.vat ? `VAT: +${draft.vat.toLocaleString('th-TH')}฿` : null,
    draft.wht ? `WHT: -${draft.wht.toLocaleString('th-TH')}฿` : null,
    `รวมสุทธิ: ${draft.total.toLocaleString('th-TH')}฿`,
  ]
    .filter(Boolean)
    .join('\n');

  const customerText = draft.customerName ? `ลูกค้า: ${draft.customerName}` : 'ยังไม่ได้เลือกลูกค้า';

  return `${typeLabel}\n${customerText}\n\n${itemsText || 'ยังไม่มีรายการ'}\n\n${totalsText}`;
}

/**
 * Transaction-safe draft edit: read-modify-write
 * @param uid Firebase UID (not LINE user ID)
 */
export async function updateDraftWithTransaction(
  uid: string,
  updater: (draft: LineDraft) => Partial<LineDraft>
): Promise<LineDraft> {
  const db = getFirestore();
  const draftRef = db.collection('line_drafts').doc(uid);

  return await db.runTransaction(async (transaction) => {
    const snap = await transaction.get(draftRef);

    if (!snap.exists) {
      throw new Error(`Draft not found for ${uid}`);
    }

    const draft = snap.data() as LineDraft;
    const now = Date.now();
    const expiresAt = (draft.expiresAt as Timestamp).toMillis() || 0;

    if (expiresAt <= now) {
      throw new Error('Draft expired');
    }

    const patch = updater(draft);
    const updated = { ...draft, ...patch, updatedAt: Timestamp.now() };

    if (patch.items) {
      updated.subtotal = calculateSubtotal(patch.items);
      updated.total = calculateTotal(updated.subtotal, updated.vat, updated.wht);
    }

    transaction.set(draftRef, updated);
    return updated;
  });
}

/**
 * Lock draft during confirmation
 * @param uid Firebase UID (not LINE user ID)
 */
export async function lockDraftForConfirm(uid: string): Promise<LineDraft> {
  const db = getFirestore();
  const draftRef = db.collection('line_drafts').doc(uid);

  return await db.runTransaction(async (transaction) => {
    const snap = await transaction.get(draftRef);

    if (!snap.exists) {
      throw new Error('Draft not found');
    }

    const draft = snap.data() as LineDraft;

    if (draft.status === 'pending_confirmation') {
      throw new Error('Draft already being confirmed');
    }

    transaction.update(draftRef, {
      status: 'pending_confirmation',
      updatedAt: Timestamp.now(),
    });

    return draft;
  });
}

/**
 * Helper: Calculate subtotal
 */
function calculateSubtotal(items: LineDraft['items']): number {
  return items.reduce((sum, item) => sum + item.qty * item.price, 0);
}

/**
 * Helper: Calculate total
 */
function calculateTotal(subtotal: number, vat?: number, wht?: number): number {
  let total = subtotal;
  if (vat) total += vat;
  if (wht) total -= wht;
  return Math.max(0, total);
}
