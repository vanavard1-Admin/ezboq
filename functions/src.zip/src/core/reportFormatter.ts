/**
 * Report Formatter for LINE Messages
 * 
 * Converts report data to Thai, concise LINE messages
 * Designed for quick scanning and action
 */

import {
  MonthlySalesReport,
  OverdueInvoice,
  TopCustomer,
  PopularService,
} from './reportService';

// ============================================================================
// MONTHLY SALES
// ============================================================================

export function formatMonthlySalesMessage(report: MonthlySalesReport): string {
  if (report.receiptCount === 0) {
    return `📊 สรุปยอดขาย ${report.month}\n\nยังไม่มีข้อมูล`;
  }

  return (
    `📊 สรุปยอดขาย ${report.month}\n\n` +
    `• ยอดรวม: ${formatCurrency(report.totalRevenue)} บาท\n` +
    `• ใบเสร็จ: ${report.receiptCount} ใบ\n` +
    `• ค่าเฉลี่ย/ใบ: ${formatCurrency(report.averagePerReceipt)} บาท\n` +
    `• ยอดรับจริง: ${formatCurrency(report.netReceived)} บาท`
  );
}

// ============================================================================
// OVERDUE INVOICES
// ============================================================================

export function formatOverdueInvoicesMessage(invoices: OverdueInvoice[]): string {
  if (invoices.length === 0) {
    return `✅ ไม่มีใบวางบิลค้างชำระ`;
  }

  let message = `⏰ ใบวางบิลค้างชำระ (${invoices.length})\n\n`;

  invoices.slice(0, 5).forEach((inv, idx) => {
    message += `${idx + 1}) ${inv.docNo}\n`;
    message += `   ${inv.customerName}\n`;
    message += `   ${formatCurrency(inv.amount)} บาท | เกิน ${inv.overdueByDays} วัน\n`;
    if (idx < Math.min(5, invoices.length) - 1) {
      message += '\n';
    }
  });

  if (invoices.length > 5) {
    message += `\n... และอีก ${invoices.length - 5} ใบ`;
  }

  message += `\n\nพิมพ์ "ทวงเงิน" เพื่อส่งแจ้งเตือน`;

  return message;
}

// ============================================================================
// TOP CUSTOMERS
// ============================================================================

export function formatTopCustomersMessage(
  customers: TopCustomer[],
  monthLabel: string = 'เดือนนี้'
): string {
  if (customers.length === 0) {
    return `🏆 ลูกค้ายอดสูง\n\nยังไม่มีข้อมูล`;
  }

  let message = `🏆 ลูกค้ายอดสูง (${monthLabel})\n\n`;

  customers.forEach((cust, idx) => {
    message += `${idx + 1}) ${cust.customerName}\n`;
    message += `   ${formatCurrency(cust.totalSpent)} บาท (${cust.percentOfTotal}%)\n`;
    if (idx < customers.length - 1) {
      message += '\n';
    }
  });

  return message;
}

// ============================================================================
// POPULAR SERVICES
// ============================================================================

export function formatPopularServicesMessage(
  services: PopularService[],
  monthLabel: string = ''
): string {
  if (services.length === 0) {
    return `🔥 บริการขายดี\n\nยังไม่มีข้อมูล`;
  }

  let message = `🔥 บริการขายดี${monthLabel ? ` (${monthLabel})` : ''}\n\n`;

  services.forEach((svc, idx) => {
    message += `${idx + 1}) ${svc.description}\n`;
    message += `   ${formatCurrency(svc.totalRevenue)} บาท (${svc.percentOfTotal}%)\n`;
    if (idx < services.length - 1) {
      message += '\n';
    }
  });

  return message;
}

// ============================================================================
// HELPER: CURRENCY FORMATTING
// ============================================================================

function formatCurrency(amount: number): string {
  return amount.toLocaleString('th-TH', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}

export { formatCurrency };
