/**
 * Trust Commands Service (PHASE 1 - SEV-0)
 * 
 * 4 critical commands to prevent user panic:
 * 1. เอกสารล่าสุด - Latest document status
 * 2. ส่ง PDF อีกครั้ง - Resend PDF (no re-render)
 * 3. เครดิตคงเหลือ - Credit balance
 * 4. เช็คสลิป - Check slip OCR status
 */

import * as admin from 'firebase-admin';
import fetch from 'node-fetch';
import { buildPdfFlexMessageWithShortLink } from '../shared/pdfFlexMessage';

const db = admin.firestore();

/**
 * Get latest document for user with PDF status
 */
export async function getLatestDocument(
  userId: string,
  businessId: string
): Promise<{
  doc_no: string;
  status: string; // Document status (ISSUED, PDF_READY, etc.)
  pdf_status?: 'DONE' | 'PROCESSING' | 'FAILED' | 'PENDING' | 'NONE'; // PDF job status
  pdf_path?: string;
  pdf_short_token?: string;
  pdf_delivery_status?: string;
  pdf_generated_at?: admin.firestore.Timestamp;
  created_at?: admin.firestore.Timestamp;
  doc_id?: string;
} | null> {
  const docsRef = db
    .collection(`users/${userId}/businesses/${businessId}/documents`)
    .orderBy('created_at', 'desc')
    .limit(1);
  
  const snapshot = await docsRef.get();
  if (snapshot.empty) {
    return null;
  }
  
  const doc = snapshot.docs[0];
  const data = doc.data();
  const docId = doc.id;
  const docNo = data.doc_no || docId;
  
  // Check PDF generation job status
  let pdfJobStatus: 'DONE' | 'PROCESSING' | 'FAILED' | 'PENDING' | 'NONE' = 'NONE';
  if (data.pdf_path) {
    pdfJobStatus = 'DONE';
  } else {
    // Check if there's a PDF job
    const jobQuery = await db
      .collection('pdf_generation_jobs')
      .where('user_id', '==', userId)
      .where('business_id', '==', businessId)
      .where('document_id', '==', docId)
      .orderBy('created_at', 'desc')
      .limit(1)
      .get();
    
    if (!jobQuery.empty) {
      const job = jobQuery.docs[0].data();
      const jobStatus = job.status;
      if (jobStatus === 'DONE') {
        pdfJobStatus = 'DONE';
      } else if (jobStatus === 'PROCESSING') {
        pdfJobStatus = 'PROCESSING';
      } else if (jobStatus === 'FAILED') {
        pdfJobStatus = 'FAILED';
      } else if (jobStatus === 'PENDING') {
        pdfJobStatus = 'PENDING';
      }
    }
  }
  
  return {
    doc_no: docNo,
    status: data.status || 'UNKNOWN',
    pdf_status: pdfJobStatus,
    pdf_path: data.pdf_path,
    pdf_short_token: data.pdf_short_token,
    pdf_delivery_status: data.pdf_delivery_status,
    pdf_generated_at: data.pdf_generated_at,
    created_at: data.created_at,
    doc_id: docId,
  };
}

/**
 * Resend PDF using existing short token (no re-render)
 */
export async function resendPdf(
  userId: string,
  businessId: string,
  lineUserId: string
): Promise<{ success: boolean; message: string }> {
  const latest = await getLatestDocument(userId, businessId);
  if (!latest) {
    return {
      success: false,
      message: 'ไม่พบเอกสารล่าสุด',
    };
  }
  
  if (!latest.pdf_short_token) {
    return {
      success: false,
      message: `เอกสาร ${latest.doc_no} ยังไม่มี PDF\nรอสักครู่แล้วพิมพ์ "เอกสารล่าสุด" อีกครั้ง`,
    };
  }
  
  // Get document to find docType
  const docRef = db.doc(`users/${userId}/businesses/${businessId}/documents/${latest.doc_no}`);
  const docSnap = await docRef.get();
  if (!docSnap.exists) {
    return {
      success: false,
      message: 'ไม่พบเอกสาร',
    };
  }
  
  const docData = docSnap.data()!;
  const docType = docData.doc_type || 'DOCUMENT';
  
  // Resend using existing token - use buildPdfFlexMessageWithShortLink and send directly
  const flexMessage = await buildPdfFlexMessageWithShortLink({
    docId: docSnap.id,
    docNo: latest.doc_no,
    docType,
    pdfPath: latest.pdf_path || '',
    userId,
    businessId,
  });
  
  // Send via LINE push API
  const accessToken = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
  if (!accessToken) {
    return {
      success: false,
      message: 'ระบบส่งข้อความไม่พร้อม',
    };
  }
  
  try {
    const response = await fetch('https://api.line.me/v2/bot/message/push', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: lineUserId,
        messages: [flexMessage],
      }),
    });
    
    if (!response.ok) {
      throw new Error(`LINE API error: ${response.status}`);
    }
    
    return {
      success: true,
      message: `ส่ง PDF ${latest.doc_no} แล้ว`,
    };
  } catch (err) {
    console.error('[resendPdf] Error:', err);
    return {
      success: false,
      message: `ส่ง PDF ไม่สำเร็จ: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

/**
 * Get credit balance for user
 */
export async function getCreditBalance(
  userId: string
): Promise<{
  creditsRemaining: number;
  lastSource?: string;
  lastSourceDate?: admin.firestore.Timestamp;
}> {
  const { getOrCreateSubscription } = await import('../core/subscriptionService');
  const subscription = await getOrCreateSubscription(userId);
  
  // Get last credit transaction (credits_ledger is top-level collection)
  const ledgerRef = db
    .collection('credits_ledger')
    .where('userId', '==', userId)
    .orderBy('createdAt', 'desc')
    .limit(1);
  
  const ledgerSnap = await ledgerRef.get();
  let lastSource: string | undefined;
  let lastSourceDate: admin.firestore.Timestamp | undefined;
  
  if (!ledgerSnap.empty) {
    const lastEntry = ledgerSnap.docs[0].data();
    lastSource = lastEntry.type === 'PURCHASE' ? 'แพ็ก' : 
                 lastEntry.type === 'ADJUSTMENT' ? 'ปรับปรุง' : 'ระบบ';
    lastSourceDate = lastEntry.createdAt;
  }
  
  return {
    creditsRemaining: subscription.creditsRemaining || 0,
    lastSource,
    lastSourceDate,
  };
}

/**
 * Get latest slip OCR status
 * Note: Uses credit_purchases collection (where slip images are stored)
 */
export async function getSlipOcrStatus(
  userId: string
): Promise<{
  status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'NONE';
  message: string;
  creditsAdded?: number;
  error?: string;
  ocrDate?: admin.firestore.Timestamp;
}> {
  // Get latest credit purchase with slip (has slip_image_url)
  const purchasesRef = db
    .collection('credit_purchases')
    .where('user_id', '==', userId)
    .where('slip_image_url', '!=', null)
    .orderBy('slip_image_url')
    .orderBy('created_at', 'desc')
    .limit(1);
  
  // Fallback: try without slip_image_url filter (in case index doesn't exist)
  let purchaseSnap = await purchasesRef.get().catch(() => null);
  if (!purchaseSnap || purchaseSnap.empty) {
    // Try simple query
    const simpleRef = db
      .collection('credit_purchases')
      .where('user_id', '==', userId)
      .orderBy('created_at', 'desc')
      .limit(5);
    
    purchaseSnap = await simpleRef.get();
    // Filter for ones with slip_image_url
    const withSlip = purchaseSnap.docs.filter(doc => {
      const data = doc.data();
      return data.slip_image_url;
    });
    
    if (withSlip.length === 0) {
      return {
        status: 'NONE',
        message: 'ยังไม่เคยส่งสลิป',
      };
    }
    
    purchaseSnap = { docs: [withSlip[0]], empty: false } as typeof purchaseSnap;
  }
  
  const purchase = purchaseSnap.docs[0].data();
  const purchaseStatus = purchase.status;
  const ocrDate = purchase.created_at || purchase.uploaded_at;
  
  // Status mapping: PENDING_REVIEW = PENDING, COMPLETED = SUCCESS, REJECTED = FAILED
  if (purchaseStatus === 'PENDING_REVIEW' || purchaseStatus === 'PENDING') {
    return {
      status: 'PENDING',
      message: 'กำลังตรวจสอบสลิป รอสักครู่',
      ocrDate,
    };
  }
  
  if (purchaseStatus === 'COMPLETED' || purchaseStatus === 'SUCCESS') {
    const creditsAdded = purchase.credits || purchase.credits_added || 0;
    return {
      status: 'SUCCESS',
      message: `ตรวจสอบสลิปสำเร็จ\nเพิ่มเครดิต: ${creditsAdded.toLocaleString('th-TH')} บาท`,
      creditsAdded,
      ocrDate,
    };
  }
  
  if (purchaseStatus === 'REJECTED' || purchaseStatus === 'FAILED') {
    const error = purchase.reject_reason || purchase.error || 'ไม่สามารถอ่านสลิปได้';
    return {
      status: 'FAILED',
      message: `ตรวจสอบสลิปล้มเหลว\n${error}\n\nกรุณาส่งสลิปใหม่ที่ชัดเจน`,
      error,
      ocrDate,
    };
  }
  
  return {
    status: 'NONE',
    message: `สถานะ: ${purchaseStatus || 'ไม่ทราบ'}`,
  };
}

