/**
 * Human-First Copy Service
 * 
 * All user-facing messages - short, clear, no forced keywords
 * Purpose: Guide users naturally without requiring specific commands
 */

export type DocumentType = 'QUO' | 'BILL' | 'INVOICE' | 'RECEIPT';

const DOC_TYPE_LABELS: Record<DocumentType, string> = {
  QUO: 'ใบเสนอราคา',
  BILL: 'ใบวางบิล',
  INVOICE: 'ใบแจ้งหนี้',
  RECEIPT: 'ใบเสร็จ',
};

/**
 * Start document creation message
 * ✅ FIX: Clear, natural language - no forced keywords
 */
export function startDoc(docType: DocumentType): string {
  const label = DOC_TYPE_LABELS[docType];
  return `เริ่มทำ${label}ให้แล้ว

ส่งข้อมูลได้เลย:
• ชื่อลูกค้า: บริษัท ABC
• รายการ: อาหารแมว 3000 หรือ บริการออกแบบ 1 5000

พร้อมแล้วพิมพ์: ออกเอกสาร`;
}

/**
 * No draft but user says document-related text
 */
export function noDraftButUserSaysDoc(text: string): string {
  return `ยังไม่มีเอกสาร เดี๋ยวเริ่มให้เลย: พิมพ์ 'ทำใบเสนอราคา' หรือ 'ทำใบวางบิล'`;
}

/**
 * Ask for customer name
 */
export function askCustomer(): string {
  return `ส่งชื่อลูกค้ามาได้เลย เช่น 'บริษัท ABC'`;
}

/**
 * Ask for item
 */
export function askItem(): string {
  return `ส่งรายการแบบสั้นๆได้เลย เช่น 'อาหารแมว 3000' หรือ 'งานออกแบบ 1 5000'`;
}

/**
 * Ambiguous input (could be customer or item)
 */
export function ambiguous(): string {
  return `ผมไม่แน่ใจว่าต้องการตั้งลูกค้าหรือเพิ่มรายการ — พิมพ์ 'ลูกค้า ...' หรือส่ง 'รายการ ราคา' เช่น 'อาหารแมว 3000'`;
}

/**
 * Confirm hint
 */
export function confirmHint(): string {
  return `ถ้าข้อมูลครบแล้ว พิมพ์ 'ออกเอกสาร'`;
}

/**
 * Draft summary header
 */
export function draftSummaryHeader(docType: DocumentType): string {
  const label = DOC_TYPE_LABELS[docType];
  return `${label}:`;
}

/**
 * No items yet message
 */
export function noItemsYet(): string {
  return `ยังไม่มีรายการ ส่งรายการมาได้เลย เช่น 'อาหารแมว 3000'`;
}

/**
 * No customer yet message
 */
export function noCustomerYet(): string {
  return `ยังไม่มีชื่อลูกค้า ส่งชื่อลูกค้ามาได้เลย`;
}

/**
 * Item added confirmation
 */
export function itemAdded(itemName: string, qty: number, price: number): string {
  const total = qty * price;
  return `เพิ่มรายการแล้ว: ${itemName} ${qty} x ${price.toLocaleString()} = ${total.toLocaleString()} บาท`;
}

/**
 * Customer set confirmation
 */
export function customerSet(customerName: string): string {
  return `ตั้งชื่อลูกค้าแล้ว: ${customerName}`;
}

