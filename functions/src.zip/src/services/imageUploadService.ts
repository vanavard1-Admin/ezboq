/**
 * EzDoc - Image Upload Service
 * 
 * Handles LINE image uploads for logo, signature, and stamp.
 */

import * as admin from 'firebase-admin';

const db = admin.firestore();

// Image types we support
export type ImageType = 'logo' | 'signature' | 'stamp';

// Storage paths
const STORAGE_PATH = 'business-assets';

// Pending image session object
interface PendingImageSession {
  messageId: string;
  timestamp: number;
  used: boolean;
}

// Temporary image storage (in-memory cache with TTL)
const pendingImages: Map<string, PendingImageSession> = new Map();
const PENDING_IMAGE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Store a pending image for a user
 */
export function storePendingImage(userId: string, messageId: string): void {
  pendingImages.set(userId, { messageId, timestamp: Date.now(), used: false });
  
  // Clean up old entries
  cleanupPendingImages();
}

/**
 * Get pending image if available and not used
 */
export function getPendingImage(userId: string): string | null {
  const entry = pendingImages.get(userId);
  if (!entry || entry.used) return null;
  
  // Check if expired
  if (Date.now() - entry.timestamp > PENDING_IMAGE_TTL) {
    pendingImages.delete(userId);
    return null;
  }
  
  // Mark as used
  entry.used = true;
  return entry.messageId;
}

/**
 * Check if user has a pending image (not used)
 */
export function hasPendingImage(userId: string): boolean {
  const entry = pendingImages.get(userId);
  if (!entry || entry.used) return false;
  
  if (Date.now() - entry.timestamp > PENDING_IMAGE_TTL) {
    pendingImages.delete(userId);
    return false;
  }
  
  return true;
}

/**
 * Mark pending image as used (without retrieving)
 */
export function markPendingImageUsed(userId: string): void {
  const entry = pendingImages.get(userId);
  if (entry) {
    entry.used = true;
  }
}

/**
 * Clean up expired pending images
 */
function cleanupPendingImages(): void {
  const now = Date.now();
  for (const [userId, entry] of pendingImages.entries()) {
    if (now - entry.timestamp > PENDING_IMAGE_TTL) {
      pendingImages.delete(userId);
    }
  }
}

/**
 * Download image from LINE
 */
export async function downloadLineImage(messageId: string, accessToken: string): Promise<Buffer> {
  const url = `https://api-data.line.me/v2/bot/message/${messageId}/content`;
  
  const response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to download LINE image: ${response.status}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

/**
 * Upload image to Cloud Storage
 */
export async function uploadBusinessImage(
  businessId: string,
  imageType: ImageType,
  imageBuffer: Buffer,
  contentType: string = 'image/png'
): Promise<string> {
  const storage = admin.storage();
  const bucket = storage.bucket();
  
  // Determine file extension from content type
  let extension = 'png';
  if (contentType.includes('jpeg') || contentType.includes('jpg')) {
    extension = 'jpg';
  } else if (contentType.includes('webp')) {
    extension = 'webp';
  }
  
  const filePath = `${STORAGE_PATH}/${businessId}/${imageType}.${extension}`;
  const file = bucket.file(filePath);
  
  await file.save(imageBuffer, {
    metadata: {
      contentType,
      cacheControl: 'public, max-age=3600',
    },
    public: true,
  });
  
  // Get public URL
  const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`;
  
  // Sanitize URL before logging (prevent PII/token leakage)
  const { sanitizeUrlForLogging } = await import("../utils/logSanitization");
  const sanitizedUrl = sanitizeUrlForLogging(publicUrl);
  console.log(`[imageUpload] Uploaded ${imageType} for business ${businessId}: ${sanitizedUrl}`);
  
  return publicUrl;
}

/**
 * Save image URL to business profile
 */
export async function saveImageToProfile(
  userId: string,
  businessId: string,
  imageType: ImageType,
  imageUrl: string
): Promise<void> {
  const field = `${imageType}_url`;
  
  // Update business profile
  await db
    .collection('users')
    .doc(userId)
    .collection('businesses')
    .doc(businessId)
    .set({ [field]: imageUrl, updated_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  
  // Sanitize URL before logging (prevent PII/token leakage)
  const { sanitizeUrlForLogging } = await import("../utils/logSanitization");
  const sanitizedImageUrl = sanitizeUrlForLogging(imageUrl);
  console.log(`[imageUpload] Saved ${field}=${sanitizedImageUrl} for user=${userId}, business=${businessId}`);
}

/**
 * Process image upload with keyword
 */
export async function processImageWithKeyword(
  userId: string,
  businessId: string,
  keyword: string,
  accessToken: string
): Promise<{ success: boolean; message: string }> {
  // Get pending image
  const messageId = getPendingImage(userId);
  if (!messageId) {
    // Determine intent from keyword for better error message
    const keywordLower = keyword.toLowerCase().trim();
    let thaiName = 'รูปภาพ';
    if (keywordLower === 'โลโก้' || keywordLower === 'logo') {
      thaiName = 'โลโก้';
    } else if (keywordLower === 'ลายเซ็น' || keywordLower === 'signature') {
      thaiName = 'ลายเซ็น';
    } else if (keywordLower === 'ตราประทับ' || keywordLower === 'stamp') {
      thaiName = 'ตราประทับ';
    }
    
    return {
      success: false,
      message: `❌ ไม่พบรูป${thaiName}\n\nกรุณาส่งรูป${thaiName}ก่อน แล้วพิมพ์ "${keyword}" อีกครั้ง`,
    };
  }
  
  // Determine image type from keyword
  const keywordLower = keyword.toLowerCase().trim();
  let imageType: ImageType;
  let thaiName: string;
  
  if (keywordLower === 'โลโก้' || keywordLower === 'logo') {
    imageType = 'logo';
    thaiName = 'โลโก้';
  } else if (keywordLower === 'ลายเซ็น' || keywordLower === 'signature') {
    imageType = 'signature';
    thaiName = 'ลายเซ็น';
  } else if (keywordLower === 'ตราประทับ' || keywordLower === 'stamp') {
    imageType = 'stamp';
    thaiName = 'ตราประทับ';
  } else {
    return {
      success: false,
      message: `❌ ไม่รู้จักคำสั่ง "${keyword}"\n\nพิมพ์:\n• โลโก้\n• ลายเซ็น\n• ตราประทับ`,
    };
  }
  
  try {
    // Check if asset already exists
    const bizRef = db.doc(`users/${userId}/businesses/${businessId}`);
    const bizSnap = await bizRef.get();
    const bizData = bizSnap.data() || {};
    const existingField = `${imageType}_url`;
    const existingUrl = bizData[existingField];
    const hasExisting = !!existingUrl;

    // Download image from LINE
    const imageBuffer = await downloadLineImage(messageId, accessToken);
    
    // Upload to Cloud Storage
    const imageUrl = await uploadBusinessImage(businessId, imageType, imageBuffer);
    
    // Save to business profile
    await saveImageToProfile(userId, businessId, imageType, imageUrl);
    
    const message = hasExisting 
      ? `✅ อัปเดต${thaiName}สำเร็จแล้ว (ทับของเดิม)\n\n${thaiName}จะปรากฏในเอกสารที่สร้างใหม่`
      : `✅ บันทึก${thaiName}สำเร็จแล้ว!\n\n${thaiName}จะปรากฏในเอกสารที่สร้างใหม่`;
    
    return {
      success: true,
      message,
    };
  } catch (error) {
    console.error(`[imageUpload] Error processing image:`, error);
    return {
      success: false,
      message: '❌ เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ\n\nกรุณาลองใหม่อีกครั้ง',
    };
  }
}

/**
 * Get message for image without keyword
 */
export function getImageWithoutKeywordMessage(): string {
  return `📸 ได้รับรูปภาพแล้ว!\n\nพิมพ์เพื่อบันทึก:\n• "โลโก้" - ตั้งเป็นโลโก้ธุรกิจ\n• "ลายเซ็น" - ลายเซ็นในเอกสาร\n• "ตราประทับ" - ตราประทับบริษัท`;
}

/**
 * Process image with explicit mode (direct upload without keyword)
 */
export async function processImageWithMode(
  userId: string,
  businessId: string,
  imageType: 'logo' | 'signature' | 'stamp',
  messageId: string,
  accessToken: string
): Promise<{ success: boolean; message: string }> {
  try {
    // Download image from LINE
    const imageBuffer = await downloadLineImage(messageId, accessToken);
    
    // Upload to Cloud Storage
    const imageUrl = await uploadBusinessImage(businessId, imageType, imageBuffer);
    
    // Save to business profile
    await saveImageToProfile(userId, businessId, imageType, imageUrl);
    
    const thaiName = imageType === 'logo' ? 'โลโก้' : imageType === 'signature' ? 'ลายเซ็น' : 'ตราประทับ';
    
    return {
      success: true,
      message: `✅ บันทึก${thaiName}สำเร็จแล้ว!\n\n${thaiName}จะปรากฏในเอกสารที่สร้างใหม่`,
    };
  } catch (error) {
    console.error(`[imageUpload] Error processing image:`, error);
    return {
      success: false,
      message: '❌ เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ\n\nกรุณาลองใหม่อีกครั้ง',
    };
  }
}

/**
 * Check if user has a purchase waiting for slip (handles race condition)
 * Uses hasRecentPendingPurchase to catch purchases in PENDING or WAITING_FOR_SLIP state
 */
export async function hasWaitingForSlipPurchase(userId: string): Promise<boolean> {
  const { hasRecentPendingPurchase } = await import('./purchaseService');
  const result = await hasRecentPendingPurchase(userId, 15);
  return result !== null;
}

/**
 * Get the most recent pending purchase for slip processing
 */
export async function getRecentPendingPurchase(userId: string): Promise<{ purchase: any; purchaseId: string } | null> {
  const { hasRecentPendingPurchase } = await import('./purchaseService');
  return await hasRecentPendingPurchase(userId, 15);
}

/**
 * Get message for immediate reply when receiving slip
 * 
 * CRITICAL: This must be payment-specific and reassuring
 */
export function getSlipReceivedMessage(): string {
  return `ได้รับสลิปแล้วนะคะ 🙏  
กำลังตรวจสอบการชำระเงินให้ค่ะ`;
}

/**
 * Process image as payment slip
 * Always accepts the slip first, then processes OCR async
 */
export async function processSlipUpload(
  userId: string,
  lineUserId: string,
  messageId: string,
  accessToken: string
): Promise<{ success: boolean; message: string }> {
  console.log(`[imageUpload] 🔄 Processing slip upload: userId=${userId}, messageId=${messageId}`);
  
  try {
    // Get the recent pending purchase (handles race condition)
    const recentPurchase = await getRecentPendingPurchase(userId);
    
    if (!recentPurchase) {
      console.log(`[imageUpload] ❌ No recent purchase found for userId=${userId}`);
      return {
        success: false,
        message: '❌ ไม่พบรายการรอชำระ\n\nกรุณาสั่งซื้อก่อนส่งสลิป',
      };
    }
    
    console.log(`[imageUpload] ✅ Found purchase: purchaseId=${recentPurchase.purchaseId}, status=${recentPurchase.purchase.status}`);
    
    // ✅ PATCH 2: IDEMPOTENCY CHECK - Verify slip not already uploaded
    const purchaseRef = db.collection('credit_purchases').doc(recentPurchase.purchaseId);
    const purchaseDoc = await purchaseRef.get();
    const purchaseData = purchaseDoc.data();
    
    if (purchaseData?.slip_image_url) {
      console.log(`[imageUpload] ⏭️  Slip already uploaded for purchaseId=${recentPurchase.purchaseId}, skipping duplicate upload`);
      return {
        success: false,
        message: '✅ รับสลิปแล้ว กำลังตรวจสอบ\n\nกรุณารอผลการตรวจสอบ',
      };
    }
    
    // Download image from LINE
    console.log(`[imageUpload] 📥 Downloading image from LINE: messageId=${messageId}`);
    const imageBuffer = await downloadLineImage(messageId, accessToken);
    console.log(`[imageUpload] ✅ Image downloaded: ${imageBuffer.length} bytes`);
    
    // ✅ Pre-OCR: Check image quality
    try {
      const { checkImageQuality, getQualityWarningMessage } = await import('./imageQualityService');
      const qualityResult = await checkImageQuality(imageBuffer);
      
      console.log(`[imageUpload] Image quality check: score=${qualityResult.score}, passed=${qualityResult.passed}`);
      
      if (!qualityResult.passed) {
        // Quality too low - warn user but still accept
        const warning = getQualityWarningMessage(qualityResult);
        if (warning) {
          // Send warning but continue processing
          const { pushLineMessage } = await import('./lineService');
          await pushLineMessage(lineUserId, warning).catch(err => {
            console.warn(`[imageUpload] Failed to send quality warning:`, err);
          });
        }
        
        // Store quality result for analysis
        const purchaseRef = db.collection('credit_purchases').doc(recentPurchase.purchaseId);
        await purchaseRef.update({
          image_quality_score: qualityResult.score,
          image_quality_issues: qualityResult.issues,
        }).catch(err => {
          console.warn(`[imageUpload] Failed to store quality result:`, err);
        });
      }
    } catch (qualityError) {
      // Don't block on quality check failure
      console.warn(`[imageUpload] Image quality check failed:`, qualityError);
    }
    
    // ✅ Increment retry count if this is a retry (status is PENDING_REVIEW or REJECTED)
    const { incrementRetryCount } = await import('./paymentRetryService');
    let retryCount = 0;
    if (recentPurchase.purchase.status === 'PENDING_REVIEW' || recentPurchase.purchase.status === 'REJECTED') {
      retryCount = await incrementRetryCount(recentPurchase.purchaseId);
      console.log(`[imageUpload] Retry detected: purchaseId=${recentPurchase.purchaseId}, retryCount=${retryCount}`);
      
      // ✅ Telemetry: Log retry attempted
      const { logRetryAttempted } = await import('./paymentTelemetry');
      await logRetryAttempted(
        userId,
        recentPurchase.purchaseId,
        retryCount,
        recentPurchase.purchase.status
      );
    }
    
    // Upload slip (always succeeds - slip is accepted)
    const { uploadSlipAndMarkPendingReview } = await import('./purchaseService');
    console.log(`[imageUpload] 📤 Uploading slip to storage: purchaseId=${recentPurchase.purchaseId}`);
    await uploadSlipAndMarkPendingReview(
      recentPurchase.purchaseId,
      userId,
      imageBuffer
    );
    console.log(`[imageUpload] ✅ Slip uploaded: purchaseId=${recentPurchase.purchaseId}`);
    
    // ✅ OCR is triggered automatically by uploadSlipAndMarkPendingReview
    // No need to trigger here - purchaseService handles it
    console.log(`[imageUpload] ✅ Slip uploaded, OCR will be triggered by purchaseService`);
    
    // Slip is always accepted at this point
    // OCR will run async and update status accordingly
    console.log(`[imageUpload] ✅ Slip processing complete: purchaseId=${recentPurchase.purchaseId}`);
    return {
      success: true,
      message: getSlipReceivedMessage(),
    };
  } catch (error) {
    console.error(`[imageUpload] ❌ Error processing slip: userId=${userId}, messageId=${messageId}:`, error);
    // Even on error, we should try to be graceful
    // But if we can't accept the slip, we need to inform user
    return {
      success: false,
      message: '❌ เกิดข้อผิดพลาดในการรับสลิป\n\nกรุณาลองใหม่อีกครั้ง',
    };
  }
}

