/**
 * EzDoc - Business Service
 * 
 * Handles business profile management and setup checklist.
 */

import * as admin from 'firebase-admin';

const db = admin.firestore();

export interface BusinessChecklistItem {
  field: string;
  label: string;
  value: string | null;
  completed: boolean;
}

export interface BusinessChecklist {
  items: BusinessChecklistItem[];
  completedCount: number;
  totalCount: number;
  percentComplete: number;
}

/**
 * Get business setup checklist
 */
export async function getBusinessChecklist(
  userId: string,
  businessId: string
): Promise<BusinessChecklist> {
  // Load business profile
  const bizDoc = await db
    .collection('users')
    .doc(userId)
    .collection('businesses')
    .doc(businessId)
    .get();
  
  const bizData = bizDoc.exists ? bizDoc.data() : {};
  
  // Load payment settings
  let paymentData: Record<string, unknown> = {};
  try {
    const paymentDoc = await db
      .doc(`users/${userId}/businesses/${businessId}/settings/payment`)
      .get();
    if (paymentDoc.exists) {
      paymentData = paymentDoc.data() || {};
    }
  } catch (e) {
    // Ignore
  }
  
  // Define checklist items
  const items: BusinessChecklistItem[] = [
    {
      field: 'name',
      label: 'ชื่อธุรกิจ',
      value: bizData?.name || bizData?.business_name || null,
      completed: !!(bizData?.name || bizData?.business_name),
    },
    {
      field: 'address',
      label: 'ที่อยู่',
      value: bizData?.address || null,
      completed: !!bizData?.address,
    },
    {
      field: 'tax_id',
      label: 'เลขผู้เสียภาษี',
      value: bizData?.tax_id || null,
      completed: !!bizData?.tax_id,
    },
    {
      field: 'phone',
      label: 'โทร',
      value: bizData?.phone || null,
      completed: !!bizData?.phone,
    },
    {
      field: 'email',
      label: 'อีเมล',
      value: bizData?.email || null,
      completed: !!bizData?.email,
    },
    {
      field: 'bank_account',
      label: 'บัญชีธนาคาร',
      value: paymentData?.bank_account ? `${paymentData.bank_code} ${paymentData.bank_account}` : null,
      completed: !!paymentData?.bank_account,
    },
    {
      field: 'promptpay_account',
      label: 'พร้อมเพย์',
      value: paymentData?.promptpay_account || null,
      completed: !!paymentData?.promptpay_account,
    },
    {
      field: 'logo_url',
      label: 'โลโก้',
      value: bizData?.logo_url || null,
      completed: !!bizData?.logo_url,
    },
    {
      field: 'signature_url',
      label: 'ลายเซ็น',
      value: bizData?.signature_url || null,
      completed: !!bizData?.signature_url,
    },
    {
      field: 'stamp_url',
      label: 'ตราประทับ',
      value: bizData?.stamp_url || null,
      completed: !!bizData?.stamp_url,
    },
  ];
  
  const completedCount = items.filter(item => item.completed).length;
  
  return {
    items,
    completedCount,
    totalCount: items.length,
    percentComplete: Math.round((completedCount / items.length) * 100),
  };
}

/**
 * Format business checklist for LINE message
 */
export function formatBusinessChecklist(checklist: BusinessChecklist): string {
  const { items, completedCount, totalCount, percentComplete } = checklist;
  
  let response = `📋 ตั้งค่าธุรกิจ\n\n`;
  response += `สถานะ: ${completedCount}/${totalCount} (${percentComplete}%)\n\n`;
  
  for (const item of items) {
    const icon = item.completed ? '✅' : '❌';
    const value = item.value ? ` - ${truncate(item.value, 20)}` : '';
    response += `${icon} ${item.label}${value}\n`;
  }
  
  response += `\n━━━━━━━━━━━━━━━━━━━━\n`;
  response += `📝 วิธีตั้งค่า:\n\n`;
  
  // Show instructions for missing items
  const missing = items.filter(i => !i.completed);
  if (missing.length > 0) {
    const first3 = missing.slice(0, 3);
    for (const item of first3) {
      response += getFieldInstruction(item.field);
    }
  } else {
    response += `✅ ข้อมูลครบถ้วนแล้ว!`;
  }
  
  return response;
}

/**
 * Get instruction for a specific field
 */
function getFieldInstruction(field: string): string {
  const instructions: Record<string, string> = {
    name: '• พิมพ์: ชื่อธุรกิจ [ชื่อ]\n',
    address: '• พิมพ์: ที่อยู่ [ที่อยู่]\n',
    tax_id: '• พิมพ์: เลขผู้เสียภาษี [เลข]\n',
    phone: '• พิมพ์: โทร [เบอร์]\n',
    email: '• พิมพ์: อีเมล [email]\n',
    bank_account: '• พิมพ์: ตั้งค่าธนาคาร [รหัส] [เลข] [ชื่อ]\n',
    promptpay_account: '• พิมพ์: ตั้งค่าพร้อมเพย์ [เลข]\n',
    logo_url: '• ส่งรูป แล้วพิมพ์: โลโก้\n',
    signature_url: '• ส่งรูป แล้วพิมพ์: ลายเซ็น\n',
    stamp_url: '• ส่งรูป แล้วพิมพ์: ตราประทับ\n',
  };
  
  return instructions[field] || '';
}

/**
 * Get missing fields warning for document issuance
 * Returns simple message (guided resolution with buttons is in BUSINESS_SETUP intent)
 */
export async function getMissingFieldsWarning(
  userId: string,
  businessId: string
): Promise<string | null> {
  const checklist = await getBusinessChecklist(userId, businessId);
  
  // Critical fields that should show warning
  const criticalFields = ['name', 'address', 'phone'];
  const missingCritical = checklist.items
    .filter(item => criticalFields.includes(item.field) && !item.completed)
    .map(item => item.label);
  
  if (missingCritical.length === 0) {
    return null;
  }
  
  // Simple warning message (guided resolution with buttons shown in BUSINESS_SETUP intent)
  return `⚠️ ข้อมูลธุรกิจยังไม่ครบ (${missingCritical.length} รายการ)\n\nข้อมูลที่ขาดจะไม่ปรากฏใน PDF\n\nพิมพ์ "ตั้งค่าธุรกิจ" เพื่อเพิ่มข้อมูล`;
}

/**
 * Truncate string with ellipsis
 */
function truncate(str: string, maxLen: number): string {
  if (str.length <= maxLen) return str;
  return str.substring(0, maxLen - 3) + '...';
}

