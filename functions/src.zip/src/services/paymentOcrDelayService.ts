/**
 * Payment OCR Delay Service
 * 
 * Detects when OCR is taking longer than expected and sends holding message
 * 
 * Rules:
 * - Send ONE holding message only (idempotent)
 * - Trigger after ~30-60 seconds of OCR processing
 * - No panic wording
 * - Do NOT ask for resend yet
 */

import * as admin from "firebase-admin";
import { getOcrDelayMessage } from "./paymentUXCopy";
import { pushLineMessage } from "./lineService";

const db = admin.firestore();
const OCR_DELAY_THRESHOLD_MS = 45 * 1000; // 45 seconds

/**
 * Check for purchases with OCR delay and send holding message
 * 
 * This should be called by a scheduled function periodically
 */
export async function checkAndNotifyOcrDelay(): Promise<number> {
  try {
    const now = admin.firestore.Timestamp.now();
    const thresholdTime = admin.firestore.Timestamp.fromMillis(
      now.toMillis() - OCR_DELAY_THRESHOLD_MS
    );
    
    // Find purchases in PENDING_REVIEW status that:
    // - Have slip_uploaded_at > threshold (uploaded more than 45s ago)
    // - Have NOT received delay notification yet (delay_notified !== true)
    const query = await db
      .collection('credit_purchases')
      .where('status', '==', 'PENDING_REVIEW')
      .where('slip_uploaded_at', '<=', thresholdTime)
      .where('delay_notified', '!=', true)
      .limit(50) // Process in batches
      .get();
    
    if (query.empty) {
      return 0;
    }
    
    let notifiedCount = 0;
    
    for (const doc of query.docs) {
      try {
        const purchase = doc.data();
        const purchaseId = doc.id;
        
        // Double-check: ensure we haven't notified already (race condition protection)
        const purchaseRef = db.collection('credit_purchases').doc(purchaseId);
        const currentDoc = await purchaseRef.get();
        const currentData = currentDoc.data();
        
        if (currentData?.delay_notified === true || currentData?.status !== 'PENDING_REVIEW') {
          // Already notified or status changed, skip
          continue;
        }
        
        // Send holding message
        const message = getOcrDelayMessage();
        await pushLineMessage(purchase.lineUserId, message);
        
        // ✅ Telemetry: Log OCR delay sent
        try {
          const { logOcrDelaySent } = await import('./paymentTelemetry');
          const delaySeconds = Math.floor(
            (now.toMillis() - (currentData.slip_uploaded_at?.toMillis() || now.toMillis())) / 1000
          );
          await logOcrDelaySent(
            purchase.userId,
            purchaseId,
            delaySeconds,
            currentData.slip_uploaded_at || admin.firestore.Timestamp.now()
          );
        } catch (telemetryError) {
          console.warn(`[paymentOcrDelayService] Failed to log OCR delay:`, telemetryError);
        }
        
        // Mark as notified (idempotent)
        await purchaseRef.update({
          delay_notified: true,
          delay_notified_at: admin.firestore.FieldValue.serverTimestamp(),
        });
        
        console.log(`[paymentOcrDelayService] Delay notification sent: purchaseId=${purchaseId}`);
        notifiedCount++;
      } catch (error) {
        console.error(`[paymentOcrDelayService] Error processing purchase ${doc.id}:`, error);
        // Continue with next purchase
      }
    }
    
    console.log(`[paymentOcrDelayService] Notified ${notifiedCount} purchases of OCR delay`);
    return notifiedCount;
  } catch (error) {
    console.error(`[paymentOcrDelayService] Error checking OCR delay:`, error);
    return 0;
  }
}

