/**
 * UX Copy Service
 * 
 * Centralized Thai UX copy for all user-facing messages
 * 
 * Tone: Calm, professional, reassuring
 * No sales language, no urgency, no hype
 */

import type { QuickReplyAction } from '../shared/lineQuickReply';

/**
 * Get welcome message
 * 
 * Tone: Friendly, clear, actionable
 * Shows what bot can do in one sentence
 */
export function getWelcomeMessage(): string {
  return `สวัสดีครับ ผมช่วยทำเอกสารได้เลย ต้องการทำใบเสนอราคา/ใบวางบิล/ใบเสร็จ หรือดูรายงานครับ?`;
}

/**
 * Get welcome quick reply (plan-aware, will be filtered)
 * 
 * REFACTORED: Uses ui/quickReplies.ts (Single Source of Truth)
 */
export function getWelcomeQuickReply(): QuickReplyAction[] {
  const { getMainMenuButtons } = require('../ui/quickReplies');
  return getMainMenuButtons();
}

/**
 * Get fallback message
 */
export function getFallbackMessage(hasActiveDraft: boolean): string {
  if (hasActiveDraft) {
    return `ผมยังไม่เข้าใจข้อความนี้ครับ 🤔

ตอนนี้คุณมีรายการกำลังทำอยู่ ✏️

ลองเลือกปุ่มด้านล่าง หรือพิมพ์:
• ยืนยัน
• ยกเลิก
• แก้ไข`;
  }

  return `ผมยังไม่เข้าใจข้อความนี้ครับ 🤔

ลองเลือกปุ่มด้านล่าง หรือพิมพ์:
• ทำใบเสนอราคา
• ทำใบวางบิล
• รายงาน`;
}

/**
 * Get item added confirmation message
 */
export function getItemAddedMessage(itemName: string): string {
  return `เพิ่มรายการเรียบร้อยแล้วค่ะ 😊

รายการ: ${itemName}

ต้องการทำอะไรต่อ?`;
}

/**
 * Get item removed confirmation message
 */
export function getItemRemovedMessage(itemName: string): string {
  return `ลบรายการเรียบร้อยแล้วค่ะ

รายการ: ${itemName}`;
}

/**
 * Get item edited confirmation message
 */
export function getItemEditedMessage(itemName: string): string {
  return `แก้ไขรายการเรียบร้อยแล้วค่ะ

รายการ: ${itemName}`;
}

/**
 * Get customer set confirmation message
 */
export function getCustomerSetMessage(customerName: string): string {
  return `ตั้งลูกค้าเรียบร้อยแล้วค่ะ

ลูกค้า: ${customerName}`;
}

/**
 * Get undo success message
 */
export function getUndoSuccessMessage(): string {
  return `เรียบร้อยค่ะ ยกเลิกรายการล่าสุดแล้ว`;
}

/**
 * Get document issued message
 */
export function getDocumentIssuedMessage(docNo: string, docType: string): string {
  const docTypeNames: Record<string, string> = {
    QUO: 'ใบเสนอราคา',
    INV: 'ใบวางบิล',
    BILL: 'ใบวางบิล',
    REC: 'ใบเสร็จรับเงิน',
    RECEIPT: 'ใบเสร็จรับเงิน',
  };

  const docTypeName = docTypeNames[docType] || 'เอกสาร';

  return `✅ ออก${docTypeName}เรียบร้อยแล้ว

เลขที่: ${docNo}

เอกสารจะถูกส่งให้คุณทาง LINE ภายในไม่กี่วินาที`;
}

/**
 * Get buttons after item added (with undo)
 * 
 * REFACTORED: Uses ui/quickReplies.ts (Single Source of Truth)
 */
export function getButtonsAfterItemAdded(hasUndo: boolean): QuickReplyAction[] {
  const { getDraftEditorButtons } = require('../ui/quickReplies');
  return getDraftEditorButtons(hasUndo);
}

/**
 * Get buttons for empty draft
 * 
 * REFACTORED: Uses ui/quickReplies.ts (Single Source of Truth)
 */
export function getButtonsForEmptyDraft(): QuickReplyAction[] {
  const { getEmptyDraftButtons } = require('../ui/quickReplies');
  return getEmptyDraftButtons();
}

/**
 * Get buttons for draft with items
 * 
 * REFACTORED: Uses ui/quickReplies.ts (Single Source of Truth)
 */
export function getButtonsForDraftWithItems(hasUndo: boolean): QuickReplyAction[] {
  const { getDraftWithItemsButtons } = require('../ui/quickReplies');
  return getDraftWithItemsButtons(hasUndo);
}

/**
 * Get usage guide (simple version)
 */
export function getUsageGuideSimple(): string {
  return `วิธีใช้งาน EzDoc

1️⃣ สร้างเอกสาร
พิมพ์: ทำใบเสนอราคา / ทำใบวางบิล

2️⃣ เพิ่มรายการ
พิมพ์: เพิ่มรายการ [ชื่อ] [ราคา]

3️⃣ ยืนยันออกเอกสาร
พิมพ์: ยืนยัน

หรือเลือกปุ่มด้านล่างได้เลยครับ`;
}

/**
 * Get help summary
 */
export function getHelpSummary(): string {
  return `คำสั่งที่ใช้ได้:

📄 สร้างเอกสาร
• ทำใบเสนอราคา
• ทำใบวางบิล
• ทำใบเสร็จ

✏️ แก้ไข
• เพิ่มรายการ [ชื่อ] [ราคา]
• ลบรายการ [ชื่อ]
• แก้ไข ลูกค้า: [ชื่อ]

📊 อื่นๆ
• รายงาน
• วิธีใช้งาน

เลือกปุ่มด้านล่างเพื่อเริ่มต้นได้เลยครับ`;
}

/**
 * Get business setup start message
 */
export function getBusinessSetupStartMessage(): string {
  return `เริ่มตั้งค่าธุรกิจ

กรุณาระบุข้อมูลธุรกิจของคุณ:
1. ชื่อธุรกิจ
2. ที่อยู่
3. เบอร์โทร
4. เลขผู้เสียภาษี (ถ้ามี)
5. อีเมล (ถ้ามี)

พิมพ์ข้อมูลทีละข้อ หรือเลือกปุ่มด้านล่าง`;
}

/**
 * Get incomplete business setup message
 */
export function getIncompleteBusinessSetupMessage(missingFields: string[]): { message: string } {
  const fieldNames: Record<string, string> = {
    business_name: 'ชื่อธุรกิจ',
    address: 'ที่อยู่',
    phone: 'เบอร์โทร',
  };

  const missing = missingFields.map(f => fieldNames[f] || f).join(', ');

  return {
    message: `ข้อมูลธุรกิจยังไม่ครบ

กรุณาระบุ: ${missing}

พิมพ์ "ตั้งค่าธุรกิจ" เพื่อเริ่มต้น`,
  };
}

/**
 * Get business setup complete message
 */
export function getBusinessSetupCompleteMessage(): string {
  return `✅ ตั้งค่าธุรกิจเรียบร้อยแล้ว

ตอนนี้คุณสามารถสร้างเอกสารได้เลย`;
}

/**
 * Get business setup cancel message
 */
export function getBusinessSetupCancelMessage(): string {
  return `ยกเลิกการตั้งค่าแล้ว

พิมพ์ "ตั้งค่าธุรกิจ" เมื่อต้องการตั้งค่าใหม่`;
}

/**
 * Get wizard validation error
 */
export function getWizardValidationError(field: string, error: string): string {
  return `⚠️ ${error}

กรุณาระบุ${field}ใหม่ หรือเลือกปุ่มด้านล่าง`;
}

/**
 * Get field saved message
 */
export function getFieldSavedMessage(field: string): string {
  return `✅ บันทึก${field}เรียบร้อยแล้ว

ต้องการตั้งค่าต่อหรือไม่?`;
}

/**
 * Get unknown command message
 */
export function getUnknownCommandMessage(): string {
  return `ผมยังไม่เข้าใจคำสั่งนี้ครับ 🤔

ลองเลือกปุ่มด้านล่าง หรือพิมพ์:
• ทำใบเสนอราคา
• ทำใบวางบิล
• รายงาน`;
}
