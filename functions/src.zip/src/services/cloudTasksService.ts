// Cloud Tasks Service for enqueuing PDF generation jobs

import { CloudTasksClient } from "@google-cloud/tasks";

const client = new CloudTasksClient();

// Environment variables
const PROJECT_ID = process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT || "ezdoc-v1-th";
const LOCATION = "asia-southeast1";
const QUEUE_NAME = "pdf-generate";

// Get PDF Service configuration from Firebase config
const functionsConfig = process.env.FIREBASE_CONFIG ? JSON.parse(process.env.FIREBASE_CONFIG) : {};
const PDF_SERVICE_URL = functionsConfig.pdf?.service_url || process.env.PDF_SERVICE_URL;
const PDF_SERVICE_ACCOUNT = functionsConfig.pdf?.service_account || process.env.PDF_SERVICE_ACCOUNT || `pdf-service@${PROJECT_ID}.iam.gserviceaccount.com`;

export interface PdfGenerationTask {
  docId: string;
}

/**
 * Enqueue PDF generation task to Cloud Tasks
 * 
 * Flow:
 * 1. Cloud Functions enqueues task with docId
 * 2. Cloud Tasks calls Cloud Run with OIDC auth
 * 3. Cloud Run generates PDF and calls Backend API
 * 
 * Auth: OIDC token with audience = Cloud Run URL
 * Idempotency: Task name = pdf-{docId} (only one task per docId)
 * 
 * @param task - PDF generation task payload (only docId needed)
 * @returns Task name
 */
export async function enqueuePdfGeneration(task: PdfGenerationTask): Promise<string> {
  if (!PDF_SERVICE_URL) {
    throw new Error("PDF_SERVICE_URL not configured. Run: firebase functions:config:set pdf.service_url=<URL>");
  }

  const parent = client.queuePath(PROJECT_ID, LOCATION, QUEUE_NAME);
  
  // Idempotent task name: pdf-{docId}
  // If task with same name exists, it won't be duplicated
  const taskId = `pdf-${task.docId}`;
  const taskName = client.taskPath(PROJECT_ID, LOCATION, QUEUE_NAME, taskId);
  
  // Task payload: only docId (minimal contract)
  const payload = {
    docId: task.docId,
  };

  // Create task with OIDC authentication
  // audience MUST be the Cloud Run URL (full URL)
  const taskRequest = {
    parent,
    task: {
      name: taskName,
      httpRequest: {
        httpMethod: "POST" as const,
        url: `${PDF_SERVICE_URL}/pdf/generate`,
        headers: {
          "Content-Type": "application/json",
        },
        body: Buffer.from(JSON.stringify(payload)).toString("base64"),
        oidcToken: {
          serviceAccountEmail: PDF_SERVICE_ACCOUNT,
          audience: PDF_SERVICE_URL, // CRITICAL: Must match Cloud Run URL
        },
      },
      // Schedule immediately (or add delay if needed)
      scheduleTime: {
        seconds: Math.floor(Date.now() / 1000) + 2, // 2 seconds delay
      },
    },
  };

  try {
    console.log(`[Cloud Tasks] Enqueueing PDF generation: docId=${task.docId}`);
    console.log(`[Cloud Tasks] Queue: ${parent}`);
    console.log(`[Cloud Tasks] Task ID: ${taskId}`);
    console.log(`[Cloud Tasks] URL: ${PDF_SERVICE_URL}/pdf/generate`);
    console.log(`[Cloud Tasks] Audience: ${PDF_SERVICE_URL}`);
    
    const [response] = await client.createTask(taskRequest);
    console.log(`[Cloud Tasks] Task created: ${response.name}`);
    return response.name || taskId;
    
  } catch (error: any) {
    console.error("[Cloud Tasks] Error creating task:", error);
    
    // Handle common errors
    if (error.code === 5) { // NOT_FOUND
      console.error(`[Cloud Tasks] Queue not found: ${QUEUE_NAME}`);
      console.error(`Run: gcloud tasks queues create ${QUEUE_NAME} --location=${LOCATION}`);
    } else if (error.code === 6) { // ALREADY_EXISTS
      console.log(`[Cloud Tasks] Task already exists (idempotent): ${taskId}`);
      return taskName;
    } else if (error.code === 7) { // PERMISSION_DENIED
      console.error(`[Cloud Tasks] Permission denied. Check IAM:`);
      console.error(`  1. Functions SA has roles/iam.serviceAccountTokenCreator on PDF SA`);
      console.error(`  2. Functions SA has roles/cloudtasks.enqueuer`);
      console.error(`  3. PDF SA has roles/run.invoker on Cloud Run service`);
    }
    
    throw error;
  }
}

/**
 * Check if Cloud Tasks queue exists
 */
export async function queueExists(): Promise<boolean> {
  try {
    const queuePath = client.queuePath(PROJECT_ID, LOCATION, QUEUE_NAME);
    await client.getQueue({ name: queuePath });
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Get queue configuration
 */
export async function getQueueInfo() {
  try {
    const queuePath = client.queuePath(PROJECT_ID, LOCATION, QUEUE_NAME);
    const [queue] = await client.getQueue({ name: queuePath });
    return queue;
  } catch (error) {
    return null;
  }
}
