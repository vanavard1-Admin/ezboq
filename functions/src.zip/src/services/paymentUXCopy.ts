/**
 * Payment UX Copy Service
 * 
 * Centralized payment flow messages
 * 
 * CRITICAL RULES:
 * - Tone: สุภาพ, ใจเย็น, ไม่โทษใคร, ไม่ใช้คำเทคนิค, ไม่ใช้คำ panic
 * - Never use: error, ผิดพลาด, ไม่สำเร็จ, ไม่พบการชำระเงิน (in user-facing messages)
 * - All messages must be calm and confidence-preserving
 * - Silence is NEVER allowed
 */

import type { QuickReplyAction } from '../shared/lineQuickReply';

/**
 * 1) PAYMENT ACKNOWLEDGEMENT (MANDATORY, IMMEDIATE)
 * 
 * When ANY image is received during payment flow:
 * - Reply immediately (before OCR starts)
 * - Never stay silent
 * - Never depend on OCR result
 */
export function getSlipReceivedMessage(): string {
  return `ได้รับสลิปแล้วนะคะ 😊  
กำลังตรวจสอบการชำระเงินให้ค่ะ  
ใช้เวลาประมาณไม่เกิน 1 นาทีค่ะ`;
}

/**
 * 2) PAYMENT SUCCESS UX (ONCE, CLEAR)
 * 
 * When OCR confirms payment:
 * - Send ONE confirmation message only
 * - Idempotent (never duplicate)
 * - No "confirm again"
 * - No excitement hype
 */
export function getPaymentSuccessMessage(planName: string = 'Pro'): string {
  return `ยืนยันการชำระเงินเรียบร้อยแล้วค่ะ ✅  
แพ็กเกจของคุณเปิดใช้งานแล้ว  
สามารถใช้งานต่อได้ทันทีเลยค่ะ`;
}

/**
 * Quick reply after payment success
 * 
 * REFACTORED: Uses ui/quickReplies.ts
 */
export function getPaymentSuccessQuickReply(): QuickReplyAction[] {
  const { getPaymentSuccessButtons } = require('../ui/quickReplies');
  return getPaymentSuccessButtons();
}

/**
 * 3) OCR DELAY STATE (NO PANIC)
 * 
 * If OCR takes longer than expected (≈30–60s):
 * - Send ONE holding message only
 * - No error wording
 * - Do NOT ask for resend yet
 */
export function getOcrDelayMessage(): string {
  return `ระบบกำลังตรวจสอบอยู่นะคะ  
ถ้าสลิปชัดเจน จะยืนยันให้โดยอัตโนมัติค่ะ  
ไม่ต้องส่งซ้ำก่อนนะคะ 😊`;
}

/**
 * 4) OCR FAILURE → RETRY FLOW (CALM & SAFE)
 * 
 * If OCR confidence < threshold or fails:
 * - Never imply money is lost
 * - Never blame user
 * - Retry must feel normal, not corrective
 */
export function getPaymentFailureMessage(): string {
  return `ขออภัยนะคะ ระบบอ่านข้อมูลจากสลิปไม่ครบค่ะ  
อาจเป็นเพราะภาพไม่ชัดหรือแสงสะท้อน  
คุณสามารถส่งสลิปอีกครั้งได้เลยค่ะ 🙏`;
}

/**
 * Quick reply for retry flow
 * 
 * REFACTORED: Uses ui/quickReplies.ts
 */
export function getPaymentRetryQuickReply(): QuickReplyAction[] {
  const { getPaymentRetryButtons } = require('../ui/quickReplies');
  return getPaymentRetryButtons();
}

/**
 * 5) RETRY GUARD (ANTI-SPAM, NO DRAMA)
 * 
 * After max retries, show:
 * - No urgency
 * - No "please contact admin immediately"
 * - No forced re-payment
 */
export function getMaxRetriesReachedMessage(): string {
  return `หากยังไม่สำเร็จ  
แอดมินสามารถช่วยตรวจสอบให้ได้นะคะ  
เพียงทักเข้ามาได้เลยค่ะ 😊`;
}

/**
 * 6) FALLBACK PROTECTION DURING PAYMENT
 * 
 * While user is in payment flow:
 * - Text / sticker / emoji / unknown input MUST NOT trigger generic fallback
 * - Replace ALL fallback with this message
 */
export function getProcessingPaymentMessage(): string {
  return `ระบบกำลังตรวจสอบการชำระเงินอยู่นะคะ  
รอสักครู่นะคะ 😊`;
}

/**
 * Waiting for slip message (before slip is sent)
 */
export function getWaitingForSlipMessage(): string {
  return `กำลังรอรับสลิปการชำระเงิน

กรุณาส่งสลิปการโอนเงินเป็นรูปภาพในแชทนี้`;
}

/**
 * 7) BRAND COPY CONSISTENCY (SYSTEM-WIDE)
 * 
 * Approved fallback (global):
 * - Use when NOT in payment flow
 */
export function getGlobalFallbackMessage(): string {
  return `ไม่เป็นไรเลยค่ะ 😊  
เลือกทำต่อได้จากด้านล่างนะคะ`;
}

