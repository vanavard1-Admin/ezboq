/**
 * Business Setup Copy-Paste Flow
 * 
 * Human-first business setup that accepts copy-paste input
 * 
 * PRINCIPLES:
 * - No step-by-step questions
 * - Accept "paste whole block" input
 * - Forgiving parser (keyword-based, not position-based)
 * - Summary + confirm before save
 * - Never silent
 */

import * as admin from "firebase-admin";
import { BusinessData, createBusiness, updateBusiness } from "../core/businesses";

const db = admin.firestore();

/**
 * Business setup state
 */
export type BusinessSetupState = 
  | 'IDLE'
  | 'WAITING_FOR_DATA'  // Sent template, waiting for user input
  | 'SHOWING_SUMMARY';   // Showing summary, waiting for confirm

/**
 * Get business setup template message
 */
export function getBusinessSetupTemplate(): string {
  return `ได้เลยค่ะ 😊  
กรุณาก๊อปปี้ข้อความด้านล่างนี้  
แล้วแก้ไขข้อมูลของคุณแทนที่ได้เลยค่ะ

━━━━━━━━━━━━━━
ชื่อธุรกิจ:
ที่อยู่:
เบอร์โทร:
เลขผู้เสียภาษี:
อีเมล:
━━━━━━━━━━━━━━

เมื่อแก้ไขเสร็จ ส่งกลับมาได้เลยนะคะ`;
}

/**
 * Get summary message
 */
export function getBusinessSetupSummary(parsed: Partial<BusinessData>): string {
  const lines: string[] = [];
  lines.push(`ขอสรุปข้อมูลธุรกิจของคุณนะคะ 😊\n`);
  
  lines.push(`ชื่อธุรกิจ: ${parsed.name || '—'}`);
  lines.push(`ที่อยู่: ${parsed.address || '—'}`);
  lines.push(`เบอร์โทร: ${parsed.phone || '—'}`);
  lines.push(`เลขผู้เสียภาษี: ${parsed.taxId || '—'}`);
  lines.push(`อีเมล: ${parsed.email || '—'}\n`);
  
  lines.push(`ถูกต้องไหมคะ?`);
  
  return lines.join('\n');
}

/**
 * Get save success message
 */
export function getBusinessSetupSaveSuccess(): string {
  return `บันทึกข้อมูลธุรกิจเรียบร้อยแล้วค่ะ ✅  
สามารถใช้งานออกเอกสารได้เลยนะคะ`;
}

/**
 * Get business setup state for user
 */
export async function getBusinessSetupState(userId: string): Promise<BusinessSetupState> {
  try {
    const stateDoc = await db
      .collection("users")
      .doc(userId)
      .collection("conversation_state")
      .doc("business_setup")
      .get();
    
    if (!stateDoc.exists) {
      return 'IDLE';
    }
    
    const data = stateDoc.data();
    return (data?.state as BusinessSetupState) || 'IDLE';
  } catch (error) {
    console.error(`[businessSetupCopyPaste] Error getting state:`, error);
    return 'IDLE';
  }
}

/**
 * Set business setup state
 */
export async function setBusinessSetupState(
  userId: string,
  state: BusinessSetupState,
  parsedData?: Partial<BusinessData>
): Promise<void> {
  try {
    const stateRef = db
      .collection("users")
      .doc(userId)
      .collection("conversation_state")
      .doc("business_setup");
    
    const updateData: any = {
      state,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    };
    
    if (parsedData) {
      updateData.parsedData = parsedData;
    }
    
    await stateRef.set(updateData, { merge: true });
  } catch (error) {
    console.error(`[businessSetupCopyPaste] Error setting state:`, error);
    throw error;
  }
}

/**
 * Get parsed data from state
 */
export async function getParsedBusinessData(userId: string): Promise<Partial<BusinessData> | null> {
  try {
    const stateDoc = await db
      .collection("users")
      .doc(userId)
      .collection("conversation_state")
      .doc("business_setup")
      .get();
    
    if (!stateDoc.exists) {
      return null;
    }
    
    const data = stateDoc.data();
    return data?.parsedData || null;
  } catch (error) {
    console.error(`[businessSetupCopyPaste] Error getting parsed data:`, error);
    return null;
  }
}

/**
 * Clear business setup state
 */
export async function clearBusinessSetupState(userId: string): Promise<void> {
  try {
    await db
      .collection("users")
      .doc(userId)
      .collection("conversation_state")
      .doc("business_setup")
      .delete();
  } catch (error) {
    console.error(`[businessSetupCopyPaste] Error clearing state:`, error);
  }
}

/**
 * Save business data
 */
export async function saveBusinessData(
  userId: string,
  businessId: string,
  data: Partial<BusinessData>
): Promise<{ success: boolean; message: string }> {
  try {
    // Check if business exists
    const businessRef = db
      .collection("users")
      .doc(userId)
      .collection("businesses")
      .doc(businessId);
    
    const businessDoc = await businessRef.get();
    
    if (businessDoc.exists) {
      // Update existing
      await updateBusiness(userId, businessId, data as BusinessData);
    } else {
      // Create new
      await createBusiness(userId, data as BusinessData);
    }
    
    // Clear state
    await clearBusinessSetupState(userId);
    
    return {
      success: true,
      message: getBusinessSetupSaveSuccess(),
    };
  } catch (error) {
    console.error(`[businessSetupCopyPaste] Error saving business:`, error);
    return {
      success: false,
      message: 'เกิดข้อผิดพลาดในการบันทึก กรุณาลองใหม่',
    };
  }
}

