/**
 * EzDoc - Credit Purchase Service
 * 
 * Handles credit package purchases (99 / 299) via PromptPay QR.
 * 
 * CRITICAL:
 * - Webhook replies immediately (<300ms)
 * - QR generation is async (fire-and-forget)
 * - Never await QR generation in webhook
 */

import * as admin from 'firebase-admin';
import generatePayload from 'promptpay-qr';
import * as QRCode from 'qrcode';

const db = admin.firestore();
const storage = admin.storage();

// ========================
// PAYMENT CONFIG (HARDCODED)
// ========================
const PROMPTPAY_ID = '0933299990';
const PROMPTPAY_NAME = 'นายฉัตรดนัย จิตต์เพ็ชร';
const BANK_NAME = 'KBANK';

// ========================
// PACKAGE CONFIG (AUTHORITATIVE - SINGLE SOURCE OF TRUTH)
// ========================
export type PackageKind = 'FIXED' | 'UNLIMITED';

export interface PackageDefinition {
  amount: number;
  credits: number | null;  // null for UNLIMITED
  name: string;
  type: PackageKind;
  unlimited_scope?: 'ALL_DOCUMENTS';
}

export const PACKAGES: Record<99 | 299, PackageDefinition> = {
  99: { 
    amount: 99, 
    credits: 100, 
    name: 'แพ็ค 100 เครดิต',
    type: 'FIXED',
  },
  299: { 
    amount: 299, 
    credits: null, 
    name: 'แพ็คอันลิมิต',
    type: 'UNLIMITED',
    unlimited_scope: 'ALL_DOCUMENTS',
  },
};

export type PackageType = keyof typeof PACKAGES;

// ========================
// TIMING CONFIG
// ========================
const QR_EXPIRY_MINUTES = 15;
const REMINDER_AFTER_MINUTES = 10;

// ========================
// PURCHASE STATUSES
// ========================
export type PurchaseStatus = 
  | 'PENDING'           // QR not yet generated
  | 'WAITING_FOR_SLIP'  // QR sent, waiting for slip image
  | 'PENDING_REVIEW'    // Slip received, pending admin review
  | 'PAID'              // Payment confirmed
  | 'EXPIRED'           // QR expired
  | 'FAILED'            // QR generation failed
  | 'REJECTED';         // Slip OCR rejected

// Instruction message after QR
export const SLIP_INSTRUCTION_MESSAGE = `📸 หลังโอนเงิน กรุณาส่งสลิปในแชทนี้\nระบบจะตรวจสอบให้โดยอัตโนมัติ`;

export interface CreditPurchase {
  id: string;
  userId: string;
  lineUserId: string;
  packageType: PackageType;
  packageKind: PackageKind;
  amount: number;
  credits: number | null;  // null for UNLIMITED
  status: PurchaseStatus;
  referenceId: string;
  promptpayId: string;
  promptpayName: string;
  qrDataUrl?: string;
  qrImageUrl?: string;
  qrPayload?: string;
  createdAt: admin.firestore.Timestamp;
  expiresAt: admin.firestore.Timestamp;
  paidAt?: admin.firestore.Timestamp;
  payment_pending_reminded?: boolean;
  // Slip OCR fields
  slip_image_url?: string;
  slip_uploaded_at?: admin.firestore.Timestamp;
  slip_hash?: string;
  slip_transaction_ref?: string;
  slip_ocr_raw_text?: string;
  slip_ocr_confidence?: number;
  slip_parsed_result?: {
    amount: number | null;
    receiverMatched: boolean;
    suffixMatched: boolean;
    ref: string | null;
    transaction_datetime?: Date | null;
  };
  verified_by?: 'OCR' | 'ADMIN' | null;
  // Fraud detection fields
  fraud_score?: number;
  fraud_flags?: string[];
  fraud_reason?: string;
  time_check_result?: 'PASS' | 'FAIL' | 'UNKNOWN';
  reviewed_by?: string;
  reviewed_at?: admin.firestore.Timestamp;
  // Retry tracking
  retry_count?: number;
  last_retry_at?: admin.firestore.Timestamp;
  // OCR delay notification
  delay_notified?: boolean;
  delay_notified_at?: admin.firestore.Timestamp;
  // Image quality
  image_quality_score?: number;
  image_quality_issues?: string[];
  // Updated timestamp
  updatedAt?: admin.firestore.Timestamp;
}

/**
 * Generate unique reference ID for purchase
 */
function generateReferenceId(): string {
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `EZ${dateStr}${random}`;
}

/**
 * Create a new credit purchase (PENDING) and trigger async QR generation
 * 
 * This function returns IMMEDIATELY with a confirmation message.
 * QR generation happens in the background (fire-and-forget).
 * 
 * @returns Immediate reply message for webhook
 */
export async function createPurchase(params: {
  userId: string;
  lineUserId: string;
  packageType: PackageType;
}): Promise<{ purchaseId: string; message: string }> {
  const { userId, lineUserId, packageType } = params;
  
  // ✅ GUARD 1: Validate userId
  if (!userId || userId.trim() === '') {
    console.log(`[BUY_FLOW_ABORTED] reason=invalid_userId, lineUserId=${lineUserId}, packageType=${packageType}`);
    return { purchaseId: '', message: '❌ ไม่พบข้อมูลผู้ใช้ กรุณาเชื่อมต่อบัญชีอีกครั้ง' };
  }

  // ✅ GUARD 2: Validate lineUserId
  if (!lineUserId || lineUserId.trim() === '') {
    console.log(`[BUY_FLOW_ABORTED] reason=invalid_lineUserId, userId=${userId}, packageType=${packageType}`);
    return { purchaseId: '', message: '❌ ไม่พบข้อมูล LINE กรุณาลองใหม่อีกครั้ง' };
  }

  // ✅ GUARD 3: Validate packageType
  const pkg = PACKAGES[packageType];
  if (!pkg) {
    console.log(`[BUY_FLOW_ABORTED] reason=invalid_package, userId=${userId}, packageType=${packageType}`);
    return { purchaseId: '', message: '❌ แพ็คเกจไม่ถูกต้อง' };
  }

  // ✅ GUARD 4: Validate package config
  if (!pkg.amount || pkg.amount <= 0) {
    console.log(`[BUY_FLOW_ABORTED] reason=missing_package_amount, userId=${userId}, packageType=${packageType}, pkg=${JSON.stringify(pkg)}`);
    return { purchaseId: '', message: '❌ ไม่พบราคาแพ็คเกจ กรุณาลองใหม่อีกครั้ง' };
  }

  // ✅ CRITICAL: Use transaction to prevent race condition (double purchase creation)
  // Two concurrent requests could both pass the check and create duplicate purchases
  const now = admin.firestore.Timestamp.now();
  
  // First, check for existing purchases (outside transaction for query)
  const existingQuery = await db
    .collection('credit_purchases')
    .where('userId', '==', userId)
    .where('status', '==', 'PENDING')
    .limit(5)
    .get();
  
  // Filter expired in-memory
  const validPurchases = existingQuery.docs.filter(doc => {
    const data = doc.data() as CreditPurchase;
    return data.expiresAt && data.expiresAt.toMillis() > now.toMillis();
  });

  if (validPurchases.length > 0) {
    const existing = validPurchases[0];
    const existingData = existing.data() as CreditPurchase;

    console.log(`[BUY_FLOW_ABORTED] reason=existing_pending_purchase, userId=${userId}, existingPurchaseId=${existing.id}, status=${existingData.status}, hasQR=${!!existingData.qrDataUrl}`);

    // If QR already exists, push it again
    if (existingData.qrDataUrl || existingData.qrImageUrl) {
      console.log(`[purchaseService] Reusing existing purchase: ${existing.id}`);
      
      // Push existing QR async (don't await in webhook context)
      pushQrToLineAsync(lineUserId, existingData, existing.id).catch((e) => {
        console.error('[purchaseService] Failed to push existing QR:', e);
      });

      return {
        purchaseId: existing.id,
        message: `⏳ กำลังส่ง QR ชำระเงิน ${existingData.amount} บาท...`,
      };
    }

    // QR not ready yet, tell user to wait
    return {
      purchaseId: existing.id,
      message: `⏳ QR กำลังสร้าง กรุณารอสักครู่...`,
    };
  }

  // ✅ CRITICAL: Use lock document to prevent race condition (double purchase creation)
  // Pattern: Create lock document atomically, then create purchase
  // If lock exists, another request is creating purchase - wait and retry check
  const lockId = `purchase_lock_${userId}_${packageType}`;
  const lockRef = db.collection('_purchase_locks').doc(lockId);
  let purchaseRefFinal: admin.firestore.DocumentReference;
  let referenceId: string;
  
  try {
    // Try to acquire lock (atomic create - fails if exists)
    await lockRef.set({
      userId,
      packageType,
      createdAt: admin.firestore.Timestamp.now(),
      expiresAt: admin.firestore.Timestamp.fromMillis(Date.now() + 60000), // 1 min TTL
    }, { merge: false }); // merge: false = fail if exists
    
    // Lock acquired - proceed with purchase creation
    referenceId = generateReferenceId();
    const expiresAt = admin.firestore.Timestamp.fromMillis(
      now.toMillis() + QR_EXPIRY_MINUTES * 60 * 1000
    );

    purchaseRefFinal = db.collection('credit_purchases').doc();
    const purchaseData: Omit<CreditPurchase, 'id'> = {
      userId,
      lineUserId,
      packageType,
      packageKind: pkg.type,
      amount: pkg.amount,
      credits: pkg.credits,
      status: 'PENDING',
      referenceId,
      promptpayId: PROMPTPAY_ID,
      promptpayName: PROMPTPAY_NAME,
      createdAt: now,
      expiresAt,
      payment_pending_reminded: false,
    };

    await purchaseRefFinal.set(purchaseData);
    
    // Release lock immediately after purchase creation
    await lockRef.delete().catch(() => {
      // Ignore delete errors (lock may have expired)
    });

  } catch (lockError: any) {
    // Lock already exists - another request is creating purchase
    // Re-check for existing purchase (may have been created by other request)
    console.log(`[PURCHASE_LOCK_EXISTS] userId=${userId}, packageType=${packageType}, re-checking for existing purchase`);
    
    const recheckQuery = await db
      .collection('credit_purchases')
      .where('userId', '==', userId)
      .where('status', '==', 'PENDING')
      .limit(1)
      .get();
    
    if (!recheckQuery.empty) {
      const existing = recheckQuery.docs[0];
      const existingData = existing.data() as CreditPurchase;
      
      if (existingData.qrDataUrl || existingData.qrImageUrl) {
        pushQrToLineAsync(lineUserId, existingData, existing.id).catch((e) => {
          console.error('[purchaseService] Failed to push existing QR:', e);
        });
        return {
          purchaseId: existing.id,
          message: `⏳ กำลังส่ง QR ชำระเงิน ${existingData.amount} บาท...`,
        };
      }
      
      return {
        purchaseId: existing.id,
        message: `⏳ QR กำลังสร้าง กรุณารอสักครู่...`,
      };
    }
    
    // Lock exists but no purchase found - retry after short delay
    // This is a rare race condition - wait 500ms and retry once
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const finalCheck = await db
      .collection('credit_purchases')
      .where('userId', '==', userId)
      .where('status', '==', 'PENDING')
      .limit(1)
      .get();
    
    if (!finalCheck.empty) {
      const existing = finalCheck.docs[0];
      const existingData = existing.data() as CreditPurchase;
      return {
        purchaseId: existing.id,
        message: existingData.qrImageUrl ? `⏳ กำลังส่ง QR ชำระเงิน ${existingData.amount} บาท...` : `⏳ QR กำลังสร้าง กรุณารอสักครู่...`,
      };
    }
    
    // Still no purchase - throw error (should not happen)
    throw new Error('Failed to create purchase: lock conflict and no existing purchase found');
  }

  // Purchase created successfully - continue with setup
  console.log(`[PURCHASE_CREATED] ✅ purchaseId=${purchaseRefFinal.id}, userId=${userId}, packageType=${packageType}, amount=${pkg.amount}, ref=${referenceId}, status=PENDING`);

  // Set image_mode to SLIP (user will send slip image next)
  const { setUserImageMode } = await import('./userStateService');
  await setUserImageMode(userId, 'SLIP').catch((err) => {
    console.error('[purchaseService] Failed to set image_mode:', err);
  });

  // Fire-and-forget: Generate QR and push to LINE (do NOT await)
  generateAndPushQrAsync(purchaseRefFinal.id, lineUserId, pkg.amount).catch((e) => {
    console.error('[purchaseService] Async QR generation failed:', e);
  });

  return {
    purchaseId: purchaseRefFinal.id,
    message: `⏳ กำลังสร้าง QR สำหรับการชำระเงิน`,
  };
}

/**
 * Generate PromptPay QR and push to LINE (async, fire-and-forget)
 */
async function generateAndPushQrAsync(
  purchaseId: string,
  lineUserId: string,
  amount: number
): Promise<void> {
  const purchaseRef = db.collection('credit_purchases').doc(purchaseId);
  const purchaseDoc = await purchaseRef.get();

  if (!purchaseDoc.exists) {
    console.error(`[purchaseService] Purchase not found: ${purchaseId}`);
    return;
  }

  const purchaseData = purchaseDoc.data() as CreditPurchase;
  const referenceId = purchaseData.referenceId;

  try {
    // Generate PromptPay payload (convert to E.164 format for Thai mobile)
    let promptpayId = PROMPTPAY_ID.replace(/-/g, '');
    // Convert Thai mobile 0xxxxxxxxx to +66xxxxxxxxx
    if (promptpayId.startsWith('0') && promptpayId.length === 10) {
      promptpayId = '+66' + promptpayId.substring(1);
    }
    const payload = generatePayload(promptpayId, { amount });

    // Generate QR as PNG buffer
    const qrBuffer = await QRCode.toBuffer(payload, {
      type: 'png',
      width: 400,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });

    // Upload QR to Cloud Storage
    const bucket = storage.bucket();
    const qrPath = `payment-qr/${purchaseId}.png`;
    const file = bucket.file(qrPath);
    
    await file.save(qrBuffer, {
      metadata: {
        contentType: 'image/png',
        cacheControl: 'public, max-age=86400',
      },
    });

    // Generate signed URL (valid for 1 hour - enough for payment)
    const [qrImageUrl] = await file.getSignedUrl({
      action: 'read',
      expires: Date.now() + 60 * 60 * 1000, // 1 hour
    });

    // Update purchase with QR URL
    await purchaseRef.update({
      qrImageUrl,
      qrPayload: payload,
    });

    console.log(`[purchaseService] QR uploaded for purchase: ${purchaseId}`);

    // Push QR to LINE
    await pushQrToLine(lineUserId, {
      amount,
      qrImageUrl,
      referenceId,
      promptpayName: PROMPTPAY_NAME,
      bankName: BANK_NAME,
    });

    console.log(`[QR_SENT] 📤 purchaseId=${purchaseId}, lineUserId=${lineUserId}, amount=${amount}, ref=${referenceId}`);

    // Update status to WAITING_FOR_SLIP
    await purchaseRef.update({
      status: 'WAITING_FOR_SLIP',
    });

    console.log(`[PAYMENT_WAITING_FOR_SLIP] ✅ purchaseId=${purchaseId}, status=WAITING_FOR_SLIP`);

    // Send instruction message after QR
    try {
      const { pushLineMessage } = await import('./lineService');
      await pushLineMessage(lineUserId, SLIP_INSTRUCTION_MESSAGE);
    } catch (e) {
      console.error('[purchaseService] Failed to send slip instruction:', e);
    }

    console.log(`[purchaseService] QR sent, status=WAITING_FOR_SLIP for purchase: ${purchaseId}`);

  } catch (error) {
    console.error(`[purchaseService] QR generation failed for ${purchaseId}:`, error);

    // Mark as failed
    await purchaseRef.update({ status: 'FAILED' });

    // Notify user
    try {
      const { pushLineMessage } = await import('./lineService');
      await pushLineMessage(
        lineUserId,
        `❌ สร้าง QR ไม่สำเร็จ กรุณาลองใหม่\n\nRef: ${referenceId}`
      );
    } catch (e) {
      console.error('[purchaseService] Failed to notify user of QR failure:', e);
    }
  }
}

/**
 * Push QR to LINE (for reusing existing QR)
 */
async function pushQrToLineAsync(lineUserId: string, purchase: CreditPurchase, purchaseId: string): Promise<void> {
  const qrUrl = purchase.qrImageUrl || purchase.qrDataUrl;
  if (!qrUrl) return;

  await pushQrToLine(lineUserId, {
    amount: purchase.amount,
    qrImageUrl: qrUrl,
    referenceId: purchase.referenceId,
    promptpayName: PROMPTPAY_NAME,
    bankName: BANK_NAME,
  });

  // Update status to WAITING_FOR_SLIP if not already
  if (purchase.status === 'PENDING') {
    await db.collection('credit_purchases').doc(purchaseId).update({
      status: 'WAITING_FOR_SLIP',
    });
  }

  // Send instruction message
  try {
    const { pushLineMessage } = await import('./lineService');
    await pushLineMessage(lineUserId, SLIP_INSTRUCTION_MESSAGE);
  } catch (e) {
    console.error('[purchaseService] Failed to send slip instruction:', e);
  }
}

/**
 * Push QR message to LINE
 */
async function pushQrToLine(
  lineUserId: string,
  params: {
    amount: number;
    qrImageUrl: string;
    referenceId: string;
    promptpayName: string;
    bankName: string;
  }
): Promise<void> {
  const { amount, qrImageUrl, referenceId, promptpayName, bankName } = params;
  const token = process.env.LINE_CHANNEL_ACCESS_TOKEN?.trim() || '';

  if (!token) {
    console.error('[purchaseService] LINE_CHANNEL_ACCESS_TOKEN not configured');
    return;
  }

  // Build Flex message with QR
  const flexMessage = {
    type: 'flex',
    altText: `💳 ชำระเงิน ${amount} บาท`,
    contents: {
      type: 'bubble',
      size: 'mega',
      header: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: '💳 ชำระเงินผ่าน PromptPay',
            weight: 'bold',
            size: 'lg',
            color: '#1DB446',
          },
        ],
        backgroundColor: '#F7F7F7',
        paddingAll: '15px',
      },
      hero: {
        type: 'image',
        url: qrImageUrl,
        size: 'full',
        aspectRatio: '1:1',
        aspectMode: 'fit',
      },
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: `ยอดชำระ: ${amount} บาท`,
            weight: 'bold',
            size: 'xl',
            align: 'center',
            color: '#1DB446',
          },
          {
            type: 'separator',
            margin: 'lg',
          },
          {
            type: 'box',
            layout: 'vertical',
            margin: 'lg',
            spacing: 'sm',
            contents: [
              {
                type: 'box',
                layout: 'baseline',
                contents: [
                  { type: 'text', text: 'ชื่อบัญชี:', size: 'sm', color: '#666666', flex: 2 },
                  { type: 'text', text: promptpayName, size: 'sm', color: '#333333', flex: 4, wrap: true },
                ],
              },
              {
                type: 'box',
                layout: 'baseline',
                contents: [
                  { type: 'text', text: 'ธนาคาร:', size: 'sm', color: '#666666', flex: 2 },
                  { type: 'text', text: bankName, size: 'sm', color: '#333333', flex: 4 },
                ],
              },
              {
                type: 'box',
                layout: 'baseline',
                contents: [
                  { type: 'text', text: 'Ref:', size: 'sm', color: '#666666', flex: 2 },
                  { type: 'text', text: referenceId, size: 'sm', color: '#333333', flex: 4 },
                ],
              },
            ],
          },
          {
            type: 'separator',
            margin: 'lg',
          },
          {
            type: 'text',
            text: `⏰ QR หมดอายุใน ${QR_EXPIRY_MINUTES} นาที`,
            size: 'xs',
            color: '#FF5555',
            align: 'center',
            margin: 'lg',
          },
          {
            type: 'text',
            text: '━━━━━━━━━━━━━━━━',
            size: 'sm',
            color: '#AAAAAA',
            align: 'center',
            margin: 'md',
          },
          {
            type: 'text',
            text: 'โอนเงินแล้วพิมพ์',
            size: 'sm',
            color: '#666666',
            align: 'center',
          },
          {
            type: 'text',
            text: '"ยืนยันการชำระเงิน"',
            weight: 'bold',
            size: 'lg',
            color: '#1DB446',
            align: 'center',
          },
        ],
        paddingAll: '20px',
      },
    },
  };

  const response = await fetch('https://api.line.me/v2/bot/message/push', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({
      to: lineUserId,
      messages: [flexMessage],
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`LINE API error ${response.status}: ${errorText}`);
  }

  console.log(`[purchaseService] QR pushed to LINE: ${lineUserId}`);
}

/**
 * Confirm credit payment
 */
/**
 * Apply entitlements based on package type
 */
export async function applyEntitlement(
  userId: string,
  purchase: CreditPurchase,
  purchaseId: string,
  verifiedBy: 'OCR' | 'ADMIN' | 'MANUAL' = 'MANUAL'
): Promise<{ success: boolean; message: string }> {
  const now = admin.firestore.Timestamp.now();
  const userRef = db.collection('users').doc(userId);
  const purchaseRef = db.collection('credit_purchases').doc(purchaseId);
  
  const pkg = PACKAGES[purchase.packageType];
  const packageKind = pkg?.type || purchase.packageKind || 'FIXED';

  // Mark purchase as PAID
  await purchaseRef.update({
    status: 'PAID',
    paidAt: now,
    verified_by: verifiedBy,
  });

  // Clear image_mode after slip is accepted
  const { clearUserImageMode } = await import('./userStateService');
  await clearUserImageMode(userId).catch((err) => {
    console.error('[purchaseService] Failed to clear image_mode:', err);
  });

  if (packageKind === 'UNLIMITED') {
    // Apply UNLIMITED entitlement
    await userRef.set({
      unlimited: true,
      unlimited_package_id: purchaseId,
      unlimited_activated_at: now,
      unlimited_scope: 'ALL_DOCUMENTS',
      updated_at: now,
    }, { merge: true });

    console.log(`[purchaseService] UNLIMITED activated for user ${userId}, purchase ${purchaseId}`);
    
    // ✅ Telemetry: Log credits applied
    try {
      const { logCreditsApplied } = await import('./paymentTelemetry');
      await logCreditsApplied(
        userId,
        purchaseId,
        null, // null for unlimited
        purchase.packageType,
        verifiedBy
      );
    } catch (telemetryError) {
      console.warn(`[purchaseService] Failed to log credits applied:`, telemetryError);
    }

    return {
      success: true,
      message:
        `✅ รับชำระเงินแล้ว\n\n` +
        `🎉 เปิดใช้งานแพ็คอันลิมิตเรียบร้อย\n` +
        `📝 Ref: ${purchase.referenceId}\n\n` +
        `ใช้งานได้ไม่จำกัด ขอบคุณที่ใช้ EzDoc!`,
    };
  } else {
    // Apply FIXED credits using ledger service (audit trail)
    const creditsToAdd = pkg?.credits || purchase.credits || 100;
    
    // Use credits ledger for audit trail
    const { addCreditsWithLedger } = await import('./creditsLedger');
    await addCreditsWithLedger(
      userId,
      creditsToAdd,
      `Payment confirmed: ${purchase.referenceId} (${pkg?.name || 'Package'})`,
      purchaseId, // Use purchaseId as referenceId for idempotency
      {
        packageType: purchase.packageType,
        amount: purchase.amount,
        verifiedBy,
      }
    );

    console.log(`[purchaseService] Added ${creditsToAdd} credits for user ${userId} (via ledger)`);
    
    // ✅ Telemetry: Log credits applied
    try {
      const { logCreditsApplied } = await import('./paymentTelemetry');
      await logCreditsApplied(
        userId,
        purchaseId,
        creditsToAdd,
        purchase.packageType,
        verifiedBy
      );
    } catch (telemetryError) {
      console.warn(`[purchaseService] Failed to log credits applied:`, telemetryError);
    }

    return {
      success: true,
      message:
        `✅ รับชำระเงินแล้ว\n\n` +
        `🎁 ได้รับ ${creditsToAdd} เครดิต\n` +
        `📝 Ref: ${purchase.referenceId}\n\n` +
        `ขอบคุณที่ใช้ EzDoc!`,
    };
  }
}

/**
 * Manual confirmation (deprecated - use slip OCR instead)
 * Keep for backward compatibility
 */
export async function confirmPayment(
  userId: string
): Promise<{ success: boolean; message: string; credits?: number }> {
  const now = admin.firestore.Timestamp.now();

  // Find PENDING purchases for user
  const purchaseQuery = await db
    .collection('credit_purchases')
    .where('userId', '==', userId)
    .where('status', '==', 'PENDING')
    .limit(5)
    .get();
  
  // Filter expired in-memory and get latest
  const validPurchases = purchaseQuery.docs
    .filter(doc => {
      const data = doc.data() as CreditPurchase;
      return data.expiresAt && data.expiresAt.toMillis() > now.toMillis();
    })
    .sort((a, b) => {
      const aData = a.data() as CreditPurchase;
      const bData = b.data() as CreditPurchase;
      return bData.createdAt.toMillis() - aData.createdAt.toMillis();
    });

  if (validPurchases.length === 0) {
    return {
      success: false,
      message: '❌ ไม่พบรายการที่รอชำระ หรือ QR หมดอายุแล้ว\n\nกรุณาสั่งซื้อใหม่',
    };
  }

  const purchaseDoc = validPurchases[0];
  const purchase = purchaseDoc.data() as CreditPurchase;

  // Use new entitlement function
  const result = await applyEntitlement(userId, purchase, purchaseDoc.id, 'MANUAL');
  
  return {
    success: result.success,
    message: result.message,
    credits: purchase.credits || undefined,
  };
}

/**
 * Get purchase history for user
 */
export async function getPurchaseHistory(
  userId: string,
  limit: number = 5
): Promise<string> {
  const purchaseQuery = await db
    .collection('credit_purchases')
    .where('userId', '==', userId)
    .orderBy('createdAt', 'desc')
    .limit(limit)
    .get();

  if (purchaseQuery.empty) {
    return '📋 ยังไม่มีประวัติการซื้อเครดิต';
  }

  const lines = ['📋 ประวัติการซื้อเครดิต (ล่าสุด 5 รายการ)', ''];

  for (const doc of purchaseQuery.docs) {
    const p = doc.data() as CreditPurchase;
    const date = p.createdAt.toDate().toLocaleDateString('th-TH', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
    const statusIcon =
      p.status === 'PAID' ? '✅' :
      p.status === 'EXPIRED' ? '⏰' :
      p.status === 'FAILED' ? '❌' :
      p.status === 'PENDING_REVIEW' ? '🔍' :
      p.status === 'WAITING_FOR_SLIP' ? '📸' : '⏳';
    const statusText =
      p.status === 'PAID' ? 'ชำระแล้ว' :
      p.status === 'EXPIRED' ? 'หมดอายุ' :
      p.status === 'FAILED' ? 'ล้มเหลว' :
      p.status === 'PENDING_REVIEW' ? 'รอตรวจสอบ' :
      p.status === 'WAITING_FOR_SLIP' ? 'รอรับสลิป' : 'รอชำระ';

    const pkg = PACKAGES[p.packageType];
    const creditText = pkg?.type === 'UNLIMITED' ? 'อันลิมิต' : `${p.credits || pkg?.credits} เครดิต`;
    lines.push(`${statusIcon} ${date}`);
    lines.push(`   ${pkg?.name || 'แพ็ค'} - ${p.amount}฿ (${creditText})`);
    lines.push(`   สถานะ: ${statusText}`);
    lines.push('');
  }

  return lines.join('\n').trim();
}

/**
 * Expire pending purchases (called by scheduled function)
 * Handles both PENDING and WAITING_FOR_SLIP statuses
 */
export async function expirePendingPurchases(): Promise<number> {
  const now = admin.firestore.Timestamp.now();
  let totalExpired = 0;

  // Check PENDING purchases
  const pendingQuery = await db
    .collection('credit_purchases')
    .where('status', '==', 'PENDING')
    .limit(100)
    .get();

  // Check WAITING_FOR_SLIP purchases
  const waitingQuery = await db
    .collection('credit_purchases')
    .where('status', '==', 'WAITING_FOR_SLIP')
    .limit(100)
    .get();

  const allDocs = [...pendingQuery.docs, ...waitingQuery.docs];

  // ✅ PATCH 4: Expire stuck PENDING_REVIEW purchases (7 days timeout)
  // ✅ FIX 2: Use Firestore query with where clause (more efficient than in-memory filtering)
  const reviewExpiry = admin.firestore.Timestamp.fromMillis(
    now.toMillis() - 7 * 24 * 60 * 60 * 1000 // 7 days
  );

  // Query PENDING_REVIEW purchases with slip_uploaded_at older than 7 days
  // Note: Requires composite index on (status, slip_uploaded_at)
  // If index doesn't exist, Firestore will error - fallback to in-memory filter
  let stuckDocs: admin.firestore.QueryDocumentSnapshot[] = [];
  try {
    const stuckQuery = await db
      .collection('credit_purchases')
      .where('status', '==', 'PENDING_REVIEW')
      .where('slip_uploaded_at', '<', reviewExpiry)
      .orderBy('slip_uploaded_at', 'asc')
      .limit(100)
      .get();
    
    stuckDocs = stuckQuery.docs;
    console.log(`[purchaseService] Found ${stuckDocs.length} stuck PENDING_REVIEW purchases via Firestore query`);
  } catch (queryError: any) {
    // Fallback: Query all PENDING_REVIEW with orderBy and filter in memory
    // This happens if composite index doesn't exist
    // Note: Single-field index on slip_uploaded_at is required (not composite)
    console.warn(`[purchaseService] Firestore query failed (likely missing composite index), using fallback with orderBy:`, queryError.message);
    try {
      const stuckQueryFallback = await db
        .collection('credit_purchases')
        .where('status', '==', 'PENDING_REVIEW')
        .orderBy('slip_uploaded_at', 'asc')  // ✅ FIX 2: Prioritize oldest purchases
        .limit(100)
        .get();
      
      stuckDocs = stuckQueryFallback.docs.filter(doc => {
        const data = doc.data() as CreditPurchase;
        return data.slip_uploaded_at && data.slip_uploaded_at.toMillis() < reviewExpiry.toMillis();
      });
      console.log(`[purchaseService] Found ${stuckDocs.length} stuck PENDING_REVIEW purchases via fallback query (with orderBy)`);
    } catch (fallbackError: any) {
      // Final fallback: No orderBy (if single-field index also missing)
      console.warn(`[purchaseService] Fallback query with orderBy failed (likely missing single-field index), using random order:`, fallbackError.message);
      const stuckQueryFinal = await db
        .collection('credit_purchases')
        .where('status', '==', 'PENDING_REVIEW')
        .limit(100)
        .get();
      
      stuckDocs = stuckQueryFinal.docs.filter(doc => {
        const data = doc.data() as CreditPurchase;
        return data.slip_uploaded_at && data.slip_uploaded_at.toMillis() < reviewExpiry.toMillis();
      });
      console.log(`[purchaseService] Found ${stuckDocs.length} stuck PENDING_REVIEW purchases via final fallback (random order)`);
    }
  }

  if (allDocs.length === 0 && stuckDocs.length === 0) {
    return 0;
  }

  // Filter expired in memory (for PENDING and WAITING_FOR_SLIP)
  const expiredDocs = allDocs.filter(doc => {
    const data = doc.data() as CreditPurchase;
    return data.expiresAt && data.expiresAt.toMillis() < now.toMillis();
  });

  if (expiredDocs.length === 0 && stuckDocs.length === 0) {
    return 0;
  }

  const batch = db.batch();
  for (const doc of expiredDocs) {
    batch.update(doc.ref, { status: 'EXPIRED' });
  }
  
  // Update stuck PENDING_REVIEW purchases
  for (const doc of stuckDocs) {
    batch.update(doc.ref, { 
      status: 'EXPIRED',
      expired_reason: 'PENDING_REVIEW_TIMEOUT'
    });
  }
  
  await batch.commit();

  totalExpired = expiredDocs.length + stuckDocs.length;
  if (stuckDocs.length > 0) {
    console.log(`[purchaseService] Expired ${stuckDocs.length} stuck PENDING_REVIEW purchases (7+ days old)`);
  }
  console.log(`[purchaseService] Expired ${totalExpired} total purchases (${expiredDocs.length} pending/waiting, ${stuckDocs.length} stuck reviews)`);
  return totalExpired;
}

/**
 * Send reminders for purchases waiting for slip (called by scheduled function)
 */
export async function sendPendingReminders(): Promise<number> {
  const now = admin.firestore.Timestamp.now();
  const reminderThreshold = admin.firestore.Timestamp.fromMillis(
    now.toMillis() - REMINDER_AFTER_MINUTES * 60 * 1000
  );

  // Query WAITING_FOR_SLIP purchases (these have QR but no slip yet)
  const waitingQuery = await db
    .collection('credit_purchases')
    .where('status', '==', 'WAITING_FOR_SLIP')
    .limit(50)
    .get();

  if (waitingQuery.empty) {
    return 0;
  }

  // Filter: older than REMINDER_AFTER_MINUTES, not expired, not reminded
  const toRemind = waitingQuery.docs.filter(doc => {
    const p = doc.data() as CreditPurchase;
    const isOldEnough = p.createdAt && p.createdAt.toMillis() < reminderThreshold.toMillis();
    const notExpired = p.expiresAt && p.expiresAt.toMillis() > now.toMillis();
    const notReminded = !p.payment_pending_reminded;
    return isOldEnough && notExpired && notReminded;
  });

  if (toRemind.length === 0) {
    return 0;
  }

  let count = 0;
  const { pushLineMessage } = await import('./lineService');

  for (const doc of toRemind) {
    const p = doc.data() as CreditPurchase;

    // Calculate remaining time
    const remainingMs = p.expiresAt.toMillis() - now.toMillis();
    const remainingMin = Math.ceil(remainingMs / 60000);

    // Send reminder
    try {
      await pushLineMessage(
        p.lineUserId,
        `⏰ QR ใกล้หมดอายุ!\n\nเหลือเวลา ${remainingMin} นาที\n\nหากโอนแล้ว กรุณาส่งสลิปในแชทนี้`
      );

      await doc.ref.update({ payment_pending_reminded: true });
      count++;
    } catch (e) {
      console.error(`[purchaseService] Failed to send reminder for ${doc.id}:`, e);
    }
  }

  if (count > 0) {
    console.log(`[purchaseService] Sent ${count} payment reminders`);
  }

  return count;
}

/**
 * Check if user has a recent pending purchase (within time window)
 * Used to handle race conditions where status hasn't updated yet
 */
export async function hasRecentPendingPurchase(
  userId: string,
  minutes: number = 15
): Promise<{ purchase: CreditPurchase; purchaseId: string } | null> {
  const now = admin.firestore.Timestamp.now();
  const cutoffTime = admin.firestore.Timestamp.fromMillis(
    now.toMillis() - minutes * 60 * 1000
  );

  // Check for recent purchases with PENDING or WAITING_FOR_SLIP status
  // Note: Using 'in' query without orderBy to avoid composite index requirement
  // Results are sorted in memory by createdAt
  const pendingQuery = await db
    .collection('credit_purchases')
    .where('userId', '==', userId)
    .where('status', 'in', ['PENDING', 'WAITING_FOR_SLIP'])
    .limit(10) // Get more to filter in memory
    .get();

  if (pendingQuery.empty) {
    return null;
  }

  // Sort by createdAt descending in memory
  const sortedDocs = pendingQuery.docs.sort((a, b) => {
    const aData = a.data() as CreditPurchase;
    const bData = b.data() as CreditPurchase;
    return bData.createdAt.toMillis() - aData.createdAt.toMillis();
  });

  // Find the most recent valid purchase (created within time window and not expired)
  for (const doc of sortedDocs) {
    const purchase = doc.data() as CreditPurchase;
    
    // Must be created within the time window
    if (purchase.createdAt.toMillis() < cutoffTime.toMillis()) {
      continue;
    }

    // Must not be expired (with grace period)
    const graceMs = 5 * 60 * 1000;
    const expiryWithGrace = purchase.expiresAt.toMillis() + graceMs;
    
    if (now.toMillis() <= expiryWithGrace) {
      return { purchase, purchaseId: doc.id };
    }
  }

  return null;
}

/**
 * Get purchase in WAITING_FOR_SLIP status for a user
 */
export async function getWaitingForSlipPurchase(
  userId: string
): Promise<{ purchase: CreditPurchase; purchaseId: string } | null> {
  const now = admin.firestore.Timestamp.now();
  const graceMs = 5 * 60 * 1000; // 5 minute grace after expiry

  // Check for WAITING_FOR_SLIP purchases
  const purchaseQuery = await db
    .collection('credit_purchases')
    .where('userId', '==', userId)
    .where('status', '==', 'WAITING_FOR_SLIP')
    .limit(5)
    .get();

  if (purchaseQuery.empty) {
    return null;
  }

  // Find valid (not expired) purchase
  for (const doc of purchaseQuery.docs) {
    const purchase = doc.data() as CreditPurchase;
    const expiryWithGrace = purchase.expiresAt.toMillis() + graceMs;
    
    if (now.toMillis() <= expiryWithGrace) {
      return { purchase, purchaseId: doc.id };
    }
  }

  return null;
}

/**
 * Upload slip image and update purchase status to PENDING_REVIEW
 */
export async function uploadSlipAndMarkPendingReview(
  purchaseId: string,
  userId: string,
  imageBuffer: Buffer
): Promise<{ success: boolean; message: string }> {
  // ✅ CRITICAL: Validate userId (prevent unauthorized access)
  if (!userId || userId.trim() === '') {
    console.error(`[uploadSlipAndMarkPendingReview] Missing userId for purchaseId=${purchaseId}`);
    return { success: false, message: '❌ ไม่พบข้อมูลผู้ใช้' };
  }

  const purchaseRef = db.collection('credit_purchases').doc(purchaseId);
  const purchaseDoc = await purchaseRef.get();

  if (!purchaseDoc.exists) {
    console.error(`[uploadSlipAndMarkPendingReview] Purchase not found: purchaseId=${purchaseId}`);
    return { success: false, message: '❌ ไม่พบรายการซื้อ' };
  }

  const purchase = purchaseDoc.data() as CreditPurchase;

  // ✅ CRITICAL: Ownership check - ensure userId matches purchase owner
  if (purchase.userId !== userId) {
    console.error(`[uploadSlipAndMarkPendingReview] Ownership mismatch: purchase.userId=${purchase.userId}, provided userId=${userId}, purchaseId=${purchaseId}`);
    return { success: false, message: '❌ ไม่มีสิทธิ์เข้าถึงรายการนี้' };
  }

  // Validate status - accept PENDING or WAITING_FOR_SLIP (handles race condition)
  if (purchase.status !== 'WAITING_FOR_SLIP' && purchase.status !== 'PENDING') {
    if (purchase.status === 'PAID') {
      return { success: false, message: '✅ รายการนี้ชำระเงินแล้ว' };
    }
    if (purchase.status === 'EXPIRED') {
      return { success: false, message: '⏰ QR หมดอายุแล้ว กรุณาสั่งซื้อใหม่' };
    }
    if (purchase.status === 'PENDING_REVIEW') {
      return { success: false, message: '🔍 รับสลิปแล้ว กำลังตรวจสอบ' };
    }
    if (purchase.status === 'REJECTED') {
      return { success: false, message: '❌ สลิปนี้ถูกปฏิเสธแล้ว กรุณาส่งสลิปใหม่' };
    }
  }

  try {
    // Upload slip to Cloud Storage
    const bucket = storage.bucket();
    const timestamp = Date.now();
    const slipPath = `credit-slips/${purchaseId}_${timestamp}.jpg`;
    const file = bucket.file(slipPath);

    await file.save(imageBuffer, {
      metadata: {
        contentType: 'image/jpeg',
        cacheControl: 'private, max-age=86400',
      },
    });

    // Generate signed URL for admin review
    const [slipImageUrl] = await file.getSignedUrl({
      action: 'read',
      expires: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    // Update purchase with slip URL (status will be updated by OCR)
    await purchaseRef.update({
      slip_image_url: slipImageUrl,
      slip_uploaded_at: admin.firestore.Timestamp.now(),
    });

    console.log(`[purchaseService] Slip uploaded for purchase ${purchaseId}, triggering OCR`);

    // Trigger OCR verification (async, fire-and-forget)
    const { runSlipOcrAndVerify, applyVerificationResult } = await import('./slipOcrService');
    
    runSlipOcrAndVerify({
      imageUrl: slipImageUrl,
      expectedAmount: purchase.amount,
      expectedPromptPayName: 'นายฉัตรดนัย จิตต์เพ็ชร',
      purchaseId,
    })
      .then((verification) => {
        console.log(`[purchaseService] OCR verification completed for ${purchaseId}: ${verification.status}`);
        return applyVerificationResult(purchaseId, verification);
      })
      .catch((error) => {
        console.error(`[purchaseService] OCR verification failed for ${purchaseId}:`, error);
        // On error, ensure status is set to PENDING_REVIEW for manual review
        purchaseRef.update({ status: 'PENDING_REVIEW' }).catch((e) => {
          console.error(`[purchaseService] Failed to update status to PENDING_REVIEW:`, e);
        });
      });

    return {
      success: true,
      message: '⏳ รับสลิปแล้ว กำลังตรวจสอบการชำระเงิน',
    };
  } catch (error) {
    console.error(`[purchaseService] Failed to upload slip for ${purchaseId}:`, error);
    return {
      success: false,
      message: '❌ เกิดข้อผิดพลาดในการรับสลิป กรุณาลองใหม่',
    };
  }
}

/**
 * Mark purchase as PENDING_REVIEW (idempotent)
 * Called when slip image is received but before OCR processing
 * 
 * Behavior:
 * - If status is WAITING_FOR_SLIP → change to PENDING_REVIEW
 * - If already PENDING_REVIEW → no-op (idempotent)
 * - If PAID/REJECTED → ignore (prevent slip confusion)
 * 
 * @param purchaseId - Purchase ID
 * @param messageId - LINE message ID of the slip image
 * @param traceId - Optional trace ID for logging
 * @returns true if status was updated, false if no-op
 */
export async function markPurchasePendingReview(
  purchaseId: string,
  messageId: string,
  traceId?: string
): Promise<boolean> {
  const purchaseRef = db.collection('credit_purchases').doc(purchaseId);
  
  try {
    // Use transaction for atomic update
    return await db.runTransaction(async (tx) => {
      const purchaseDoc = await tx.get(purchaseRef);
      
      if (!purchaseDoc.exists) {
        console.warn(`[markPurchasePendingReview] Purchase not found: purchaseId=${purchaseId}`);
        return false;
      }
      
      const purchase = purchaseDoc.data() as CreditPurchase;
      
      // Idempotent: If already PENDING_REVIEW, no-op
      if (purchase.status === 'PENDING_REVIEW') {
        console.log(`[markPurchasePendingReview] Purchase already PENDING_REVIEW: purchaseId=${purchaseId}`);
        return false;
      }
      
      // Ignore if PAID/REJECTED (prevent slip confusion)
      if (purchase.status === 'PAID' || purchase.status === 'REJECTED') {
        console.warn(`[markPurchasePendingReview] Purchase in final state, ignoring: purchaseId=${purchaseId}, status=${purchase.status}`);
        return false;
      }
      
      // Only update if WAITING_FOR_SLIP or PENDING
      if (purchase.status === 'WAITING_FOR_SLIP' || purchase.status === 'PENDING') {
        const updateData: any = {
          status: 'PENDING_REVIEW',
          slipMessageId: messageId,
          slipReceivedAt: admin.firestore.Timestamp.now(),
        };
        
        if (traceId) {
          updateData.traceId = traceId;
        }
        
        tx.update(purchaseRef, updateData);
        console.log(`[markPurchasePendingReview] Marked purchase as PENDING_REVIEW: purchaseId=${purchaseId}, messageId=${messageId}`);
        return true;
      }
      
      // Other statuses (EXPIRED, FAILED) - ignore
      console.warn(`[markPurchasePendingReview] Purchase in unexpected state, ignoring: purchaseId=${purchaseId}, status=${purchase.status}`);
      return false;
    });
  } catch (error) {
    console.error(`[markPurchasePendingReview] Failed to mark purchase: purchaseId=${purchaseId}`, error);
    throw error;
  }
}
