/**
 * Payment State Service
 * 
 * Manages payment flow state detection and guards
 * 
 * CRITICAL: Payment flow must NEVER go silent
 * Payment flow must NEVER fall into fallback
 */

import { hasRecentPendingPurchase, type CreditPurchase } from "./purchaseService";

/**
 * Payment states
 */
export type PaymentState = 
  | 'NO_PAYMENT'           // No active payment
  | 'WAITING_FOR_SLIP'     // QR sent, waiting for slip
  | 'PROCESSING_PAYMENT'   // Slip received, OCR in progress
  | 'PENDING_REVIEW';      // OCR unclear, admin review needed

/**
 * Get current payment state for user
 */
export async function getPaymentState(userId: string): Promise<PaymentState> {
  try {
    // Check for recent purchase (within 15 minutes)
    const recentPurchase = await hasRecentPendingPurchase(userId, 15);
    
    if (!recentPurchase) {
      return 'NO_PAYMENT';
    }
    
    const purchase = recentPurchase.purchase as CreditPurchase;
    const status = purchase.status;
    
    switch (status) {
      case 'WAITING_FOR_SLIP':
        return 'WAITING_FOR_SLIP';
      
      case 'PENDING_REVIEW':
        return 'PROCESSING_PAYMENT';
      
      case 'PAID':
      case 'EXPIRED':
      case 'FAILED':
      case 'REJECTED':
        // Payment completed or failed - no longer in payment flow
        return 'NO_PAYMENT';
      
      case 'PENDING':
        // QR not yet sent - still waiting
        return 'WAITING_FOR_SLIP';
      
      default:
        return 'NO_PAYMENT';
    }
  } catch (error) {
    console.error(`[paymentStateService] Error getting payment state for userId=${userId}:`, error);
    // On error, assume no payment (safe default)
    return 'NO_PAYMENT';
  }
}

/**
 * Check if user is in payment flow
 */
export async function isInPaymentFlow(userId: string): Promise<boolean> {
  const state = await getPaymentState(userId);
  return state !== 'NO_PAYMENT';
}

/**
 * Get payment-aware message for current state
 */
export async function getPaymentStatusMessage(userId: string): Promise<string | null> {
  const state = await getPaymentState(userId);
  
  switch (state) {
    case 'WAITING_FOR_SLIP':
      return `กำลังรอรับสลิปการชำระเงิน

กรุณาส่งสลิปการโอนเงินเป็นรูปภาพในแชทนี้`;

    case 'PROCESSING_PAYMENT':
      return `กำลังตรวจสอบการชำระเงินให้อยู่นะคะ  
เดี๋ยวแจ้งผลให้ทันทีค่ะ 🙂`;

    case 'PENDING_REVIEW':
      return `กำลังตรวจสอบการชำระเงินให้อยู่นะคะ  
เดี๋ยวแจ้งผลให้ทันทีค่ะ 🙂`;

    default:
      return null;
  }
}

/**
 * Get recent purchase info (for logging)
 */
export async function getRecentPurchaseInfo(userId: string): Promise<{
  purchaseId: string | null;
  status: string | null;
  amount: number | null;
} | null> {
  try {
    const recentPurchase = await hasRecentPendingPurchase(userId, 15);
    
    if (!recentPurchase) {
      return null;
    }
    
    const purchase = recentPurchase.purchase as CreditPurchase;
    
    return {
      purchaseId: recentPurchase.purchaseId,
      status: purchase.status,
      amount: purchase.amount,
    };
  } catch (error) {
    console.error(`[paymentStateService] Error getting purchase info:`, error);
    return null;
  }
}

