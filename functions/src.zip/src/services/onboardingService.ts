/**
 * EzDoc - Onboarding Service
 * 
 * Handles first-time user onboarding and help text.
 */

import * as admin from 'firebase-admin';

const db = admin.firestore();

/**
 * Check if user needs onboarding
 */
export async function needsOnboarding(userId: string): Promise<boolean> {
  try {
    const userDoc = await db.collection('users').doc(userId).get();
    if (!userDoc.exists) return true;
    
    const userData = userDoc.data();
    return !userData?.onboarding_completed;
  } catch (e) {
    console.warn('[onboarding] Error checking onboarding status:', e);
    return false;
  }
}

/**
 * Mark onboarding as completed
 * Also sets up retention flow tracking
 */
export async function completeOnboarding(userId: string): Promise<void> {
  try {
    await db.collection('users').doc(userId).set({
      onboarding_completed: true,
      onboarding_completed_at: admin.firestore.FieldValue.serverTimestamp(),
      onboardingCompletedAt: admin.firestore.FieldValue.serverTimestamp(), // For retention flow
      retentionFlowActive: true, // Enable retention flow
    }, { merge: true });
  } catch (e) {
    console.warn('[onboarding] Error marking onboarding complete:', e);
  }
}

/**
 * Get onboarding messages (5 messages)
 */
export function getOnboardingMessages(): string[] {
  return [
    // Message 1: Welcome
    `👋 ยินดีต้อนรับสู่ EzDoc!\n\nระบบออกเอกสารธุรกิจอัตโนมัติ ผ่าน LINE`,

    // Message 2: Business setup
    `📋 ก่อนเริ่มใช้งาน แนะนำให้ตั้งค่าธุรกิจก่อน:\n\nพิมพ์ "ตั้งค่าธุรกิจ" เพื่อดูรายการ\nหรือพิมพ์ทีละรายการ:\n\n• ชื่อธุรกิจ บริษัท ABC จำกัด\n• ที่อยู่ 123 ถนนสุขุมวิท\n• เลขผู้เสียภาษี 0105xxx\n• โทร 0812345678`,

    // Message 3: Document types
    `📄 เอกสารที่สร้างได้:\n\n• ใบเสนอราคา (QUO)\n• ใบวางบิล (INV)\n• ใบเสร็จ (REC)\n\nพิมพ์ "ทำใบเสนอราคา" เพื่อเริ่มต้น`,

    // Message 4: Usage example
    `✍️ ตัวอย่างการสร้างเอกสาร:\n\n1️⃣ ทำใบเสนอราคา\n2️⃣ ลูกค้า คุณสมชาย\n3️⃣ เพิ่มรายการ ค่าออกแบบ 30000\n4️⃣ ยืนยัน\n\n✅ ระบบจะสร้าง PDF และส่งให้ทันที!`,

    // Message 5: Image upload & help
    `📸 อัปโหลดรูปภาพ:\n\nส่งรูป แล้วพิมพ์:\n• "โลโก้" - ตั้งเป็นโลโก้ธุรกิจ\n• "ลายเซ็น" - ลายเซ็นในเอกสาร\n• "ตราประทับ" - ตราประทับบริษัท\n\n💡 พิมพ์ "วิธีใช้งาน" หรือ "ช่วยเหลือ" เมื่อต้องการความช่วยเหลือ`,
  ];
}

/**
 * Get usage guide text
 */
export function getUsageGuide(): string {
  return `📖 วิธีใช้งาน EzDoc

━━━━━━━━━━━━━━━━━━━━
📝 สร้างเอกสาร
━━━━━━━━━━━━━━━━━━━━

1️⃣ พิมพ์ "ทำใบเสนอราคา"
2️⃣ พิมพ์ "ลูกค้า [ชื่อ]"
3️⃣ พิมพ์ "เพิ่มรายการ [ชื่อ] [ราคา]"
   เพิ่มได้หลายรายการ
4️⃣ พิมพ์ "ยืนยัน"
   ✅ ได้ PDF ทันที!

━━━━━━━━━━━━━━━━━━━━
🔄 ต่อเอกสาร
━━━━━━━━━━━━━━━━━━━━

• สร้างใบวางบิลจาก QUO-xxxx
• สร้างใบเสร็จจาก INV-xxxx

━━━━━━━━━━━━━━━━━━━━
⚙️ ตั้งค่า
━━━━━━━━━━━━━━━━━━━━

• ตั้งค่าธุรกิจ - ดูรายการตั้งค่า
• ตั้งค่าพร้อมเพย์ [เลข]
• ตั้งค่าธนาคาร [รหัส] [เลขบัญชี]

━━━━━━━━━━━━━━━━━━━━
📸 อัปโหลดรูป
━━━━━━━━━━━━━━━━━━━━

ส่งรูปแล้วพิมพ์:
• "โลโก้" • "ลายเซ็น" • "ตราประทับ"`;
}

/**
 * Get help text (command list) - copy/paste oriented
 */
export function getHelpText(): string {
  return `📋 คำสั่งทั้งหมด

💡 คัดลอกแล้วแก้ไขค่าได้เลย:

━━━━━━━━━━━━━━━━━━━━
📝 ตัวอย่าง 1: ตั้งค่าธุรกิจ (แบบฟอร์ม)
━━━━━━━━━━━━━━━━━━━━
พิมพ์ "ตั้งค่าธุรกิจแบบฟอร์ม" เพื่อดูฟอร์ม
แล้วคัดลอก ใส่ข้อมูล ส่งกลับมา

━━━━━━━━━━━━━━━━━━━━
📝 ตัวอย่าง 2: ตั้งค่าธนาคาร
━━━━━━━━━━━━━━━━━━━━
ตั้งค่าธนาคาร กสิกร 1234567890 บริษัท ABC

━━━━━━━━━━━━━━━━━━━━
📝 ตัวอย่าง 3: ซื้อแพ็ค + ส่งสลิป
━━━━━━━━━━━━━━━━━━━━
ซื้อแพ็ค 99
(รอ QR แล้วโอนเงิน)
(ส่งรูปสลิป)

━━━━━━━━━━━━━━━━━━━━
📄 เอกสาร
━━━━━━━━━━━━━━━━━━━━
• ทำใบเสนอราคา
• ลูกค้า [ชื่อ]
• เพิ่มรายการ [ชื่อ] [ราคา]
• ยืนยัน

⚙️ ธุรกิจ
• ตั้งค่าธุรกิจแบบฟอร์ม
• ตั้งค่าธนาคาร [ชื่อหรือรหัส] [เลข] [ชื่อ]

💳 เครดิต
• ซื้อแพ็ค 99 / 299
• ประวัติการซื้อเครดิต

💡 พิมพ์ "วิธีใช้งาน" สำหรับคำแนะนำเพิ่มเติม`;
}

/**
 * Get fallback message for true free-text input that we don't understand
 * This is ONLY for genuine text input, NOT button actions
 * 
 * Tone: Polite, non-blaming, with clear guidance
 * Button actions should NEVER reach this function
 */
export function getFallbackMessage(input?: string): string {
  // Never blame the user - always be helpful and polite
  let response = `ขอบคุณมากนะคะ 😊`;
  
  response += `\n\nเลือกทำต่อได้เลยด้านล่างค่ะ`;

  return response;
}

/**
 * Suggest corrections for common typos
 */
export function suggestTypoCorrection(input: string): string | null {
  const text = input.toLowerCase().trim();
  
  const corrections: Record<string, { pattern: RegExp; suggestion: string; command: string }> = {
    // Missing space after "ลูกค้า"
    'customer_no_space': {
      pattern: /^ลูกค้า\S+/,
      suggestion: 'ลูกค้า [ชื่อ]',
      command: text.replace(/^ลูกค้า/, 'ลูกค้า '),
    },
    // Typo: เพิ้ม -> เพิ่ม
    'add_item_typo': {
      pattern: /^เพิ้มรายการ/,
      suggestion: 'เพิ่มรายการ',
      command: text.replace(/^เพิ้มรายการ/, 'เพิ่มรายการ'),
    },
    // Missing space after "เพิ่มรายการ"
    'add_item_no_space': {
      pattern: /^เพิ่มรายการ\S+\d+$/,
      suggestion: 'เพิ่มรายการ [ชื่อ] [ราคา]',
      command: text.replace(/^เพิ่มรายการ(\S+)(\d+)$/, 'เพิ่มรายการ $1 $2'),
    },
    // "ใบเสนอ" without "ราคา"
    'quotation_short': {
      pattern: /^ใบเสนอ$/,
      suggestion: 'ทำใบเสนอราคา',
      command: 'ทำใบเสนอราคา',
    },
    // "บิล" alone
    'invoice_short': {
      pattern: /^บิล$/,
      suggestion: 'ทำใบวางบิล',
      command: 'ทำใบวางบิล',
    },
    // "เสร็จ" alone
    'receipt_short': {
      pattern: /^เสร็จ$/,
      suggestion: 'ทำใบเสร็จ',
      command: 'ทำใบเสร็จ',
    },
  };

  for (const [, correction] of Object.entries(corrections)) {
    if (correction.pattern.test(text)) {
      return `💡 คุณหมายถึง "${correction.suggestion}" หรือเปล่า?\n\nลอง: ${correction.command}`;
    }
  }

  return null;
}

/**
 * Push onboarding messages to LINE (async, non-blocking)
 */
export async function sendOnboardingAsync(lineUserId: string, userId: string): Promise<void> {
  try {
    const messages = getOnboardingMessages();
    const { pushLineMessage } = await import('./lineService');
    
    // Send messages with small delays to ensure order
    for (let i = 0; i < messages.length; i++) {
      await pushLineMessage(lineUserId, messages[i]);
      // Small delay between messages
      if (i < messages.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    // Mark onboarding as completed
    await completeOnboarding(userId);
    
    console.log(`[onboarding] Completed for userId=${userId}`);
  } catch (e) {
    console.error('[onboarding] Error sending onboarding:', e);
  }
}

