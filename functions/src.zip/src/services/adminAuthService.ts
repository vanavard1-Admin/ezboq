/**
 * EzDoc - Admin Authorization Service
 * 
 * Hard admin auth: Exact match on email + line_user_id only.
 */

import * as admin from 'firebase-admin';

const db = admin.firestore();

/**
 * Hardcoded admin allowlist
 */
const ADMIN_ALLOWLIST = [
  {
    email: 'song141@gmail.com',
    line_user_id: 'PYvi3VTscOfh83McWIQ3cU05n1l1',
  },
];

/**
 * Admin authorization error
 */
export class AdminAuthorizationError extends Error {
  name = 'AdminAuthorizationError';
  constructor(message: string) {
    super(message);
  }
}

/**
 * Get Firebase Auth user email by Firebase UID
 */
async function getUserEmail(firebaseUid: string): Promise<string | null> {
  try {
    const userRecord = await admin.auth().getUser(firebaseUid);
    return userRecord.email || null;
  } catch (error) {
    console.error('[adminAuthService] Failed to get user email:', error);
    return null;
  }
}

/**
 * Get Firebase UID by lineUserId
 */
async function getFirebaseUidByLineUserId(lineUserId: string): Promise<string | null> {
  const usersQuery = await db
    .collection('users')
    .where('lineUserId', '==', lineUserId)
    .limit(1)
    .get();

  if (usersQuery.empty) {
    return null;
  }

  return usersQuery.docs[0].id;
}

/**
 * Assert that user is admin
 * Requires BOTH email AND line_user_id to match allowlist
 * Throws AdminAuthorizationError if not authorized
 */
export async function assertAdmin(lineUserId: string): Promise<void> {
  if (!lineUserId) {
    throw new AdminAuthorizationError('Missing lineUserId');
  }

  // Get Firebase UID from lineUserId
  const firebaseUid = await getFirebaseUidByLineUserId(lineUserId);
  if (!firebaseUid) {
    throw new AdminAuthorizationError('User not found');
  }

  // Get email from Firebase Auth
  const email = await getUserEmail(firebaseUid);
  if (!email) {
    throw new AdminAuthorizationError('User email not found');
  }

  // Exact match check: BOTH email AND line_user_id must match
  const isAdmin = ADMIN_ALLOWLIST.some(
    (admin) => admin.email === email && admin.line_user_id === lineUserId
  );

  if (!isAdmin) {
    throw new AdminAuthorizationError('User is not an admin');
  }
}

/**
 * Check if user is admin (non-throwing)
 */
export async function isAdmin(lineUserId: string): Promise<boolean> {
  try {
    await assertAdmin(lineUserId);
    return true;
  } catch {
    return false;
  }
}

/**
 * Require admin from LINE event
 * Returns admin status and can throw
 */
export async function requireAdmin(event: { source?: { userId?: string } }): Promise<boolean> {
  const lineUserId = event.source?.userId;
  if (!lineUserId) {
    throw new AdminAuthorizationError('Missing LINE userId');
  }

  await assertAdmin(lineUserId);
  return true;
}

/**
 * Log admin action
 */
export async function logAdminAction(params: {
  adminLineUserId: string;
  action: string;
  targetId?: string;
  details?: Record<string, unknown>;
}): Promise<void> {
  try {
    await db.collection('admin_logs').add({
      adminLineUserId: params.adminLineUserId,
      action: params.action,
      targetId: params.targetId || null,
      details: params.details || {},
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error('[adminAuthService] Failed to log admin action:', error);
    // Don't throw - logging failure shouldn't block the operation
  }
}

